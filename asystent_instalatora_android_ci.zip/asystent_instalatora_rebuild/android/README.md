# Android build – Asystent Instalatora

Projekt natywny został odtworzony jako szkielet Capacitor 6. Przed kompilacją wymagane jest środowisko Android Studio, JDK 17, Android SDK 34 oraz dostęp do internetu, aby pobrać zależności Gradle/npm.

## Przygotowanie
1. W katalogu głównym projektu uruchom `npm install`.
2. Uruchom `npx cap sync android`. Polecenie wygeneruje pliki integracji pluginów w `android/`.
3. Otwórz katalog `android/` w Android Studio i poczekaj na synchronizację Gradle.
4. Zbuduj wariant `app` → `debug` lub uruchom `./gradlew assembleDebug` (po dodaniu wrappera przez Android Studio).

APK debug powinno pojawić się w `android/app/build/outputs/apk/debug/app-debug.apk`.

## Uwaga
To jest odtworzony szkielet, nie potwierdzona kompilacja. Nie odzyskano oryginalnych plików Gradle ani oryginalnego keystore. Należy sprawdzić wszystkie pluginy, w szczególności `capacitor-plugin-cdv-purchase`, podczas `cap sync` i testów urządzeniowych.
