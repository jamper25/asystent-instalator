# Keep Capacitor bridge and plugin classes in release builds.
-keep class com.getcapacitor.** { *; }
-keep class pl.asystentinstalatora.app.** { *; }
