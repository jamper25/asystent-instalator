const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const source = fs.readFileSync("www/js/buderus_catalog.js", "utf8");
const data = new Map();
const localStorage = {
  getItem: k => data.has(k) ? data.get(k) : null,
  setItem: (k, v) => data.set(k, String(v))
};
const context = { localStorage, Date, JSON, Math, Set, Object, String, Number, Array, Error };
vm.createContext(context);
vm.runInContext(source, context);
const api = context.BuderusCatalog;
assert(api, "API BuderusCatalog musi być dostępne");
const p = api.upsert({
  sku: "7736901234", name: "Kocioł testowy", category: "kociol",
  source: "manual", prices: { catalogNet: 5000, purchaseNet: 3200, saleNet: 4200, vatRate: 0.23 }
});
assert.strictEqual(api.list().length, 1);
assert.strictEqual(api.getBySku("7736901234").id, p.id);
assert.strictEqual(api.gross(100, 0.23), 123);
const offer = api.toOfferItem(p);
assert.strictEqual(offer.price, 4200);
assert.strictEqual(offer.sku, "7736901234");
const updated = api.setPrices(p.id, { saleNet: 4300 }, "test zmiany ceny");
assert.strictEqual(updated.prices.saleNet, 4300);
assert.strictEqual(updated.priceHistory.length, 1);
const exported = api.exportJSON();
const secondData = new Map();
const secondStorage = { getItem:k=>secondData.has(k)?secondData.get(k):null, setItem:(k,v)=>secondData.set(k,String(v)) };
const context2 = { localStorage: secondStorage, Date, JSON, Math, Set, Object, String, Number, Array, Error };
vm.createContext(context2);
vm.runInContext(source, context2);
const result = context2.BuderusCatalog.importJSON(exported);
assert.strictEqual(result.stored, 1);
assert.strictEqual(context2.BuderusCatalog.list()[0].prices.saleNet, 4300);
const csv = api.exportCSV();
assert(csv.startsWith("\uFEFFsku;name;"), "CSV powinien mieć BOM i nagłówki przyjazne Excelowi");
const thirdData = new Map();
const thirdStorage = { getItem:k=>thirdData.has(k)?thirdData.get(k):null, setItem:(k,v)=>thirdData.set(k,String(v)) };
const context3 = { localStorage: thirdStorage, Date, JSON, Math, Set, Object, String, Number, Array, Error };
vm.createContext(context3);
vm.runInContext(source, context3);
const csvResult = context3.BuderusCatalog.importCSV(csv);
assert.strictEqual(csvResult.stored, 1);
assert.strictEqual(context3.BuderusCatalog.list()[0].sku, "7736901234");
assert.strictEqual(context3.BuderusCatalog.list()[0].prices.saleNet, 4300);
console.log("OK: CRUD, wyszukiwanie po SKU, brutto, adapter oferty, historia cen oraz import/eksport JSON i CSV.");
