/* ===== ui_settings.js ===== */
/* ============================================================
   USTAWIENIA FIRMY I KATALOG CEN
   ============================================================ */
Object.assign(ICO, {
  gear: '<circle cx="12" cy="12" r="3.2"/><path d="M19.4 13.5a7.6 7.6 0 0 0 0-3l1.8-1.4-1.9-3.2-2.2.9a7.6 7.6 0 0 0-2.6-1.5L14.1 3H9.9l-.4 2.3a7.6 7.6 0 0 0-2.6 1.5l-2.2-.9-1.9 3.2 1.8 1.4a7.6 7.6 0 0 0 0 3l-1.8 1.4 1.9 3.2 2.2-.9a7.6 7.6 0 0 0 2.6 1.5l.4 2.3h4.2l.4-2.3a7.6 7.6 0 0 0 2.6-1.5l2.2.9 1.9-3.2z"/>',
  building: '<path d="M4 21V5.5A1.5 1.5 0 0 1 5.5 4h7A1.5 1.5 0 0 1 14 5.5V21"/><path d="M14 10h4.5A1.5 1.5 0 0 1 20 11.5V21M2.5 21h19M7 8h4M7 12h4M7 16h4M17 14h1M17 18h1"/>',
  image: '<rect x="3" y="4.5" width="18" height="15" rx="2.5"/><circle cx="8.5" cy="10" r="1.7"/><path d="M3.5 17l5-4.5 4 3.5 3-2.5 5 4"/>',
  restore: '<path d="M4 4v6h6"/><path d="M4.5 13a7.5 7.5 0 1 0 1.9-6.4L4 10"/>',
  tag: '<path d="M3.5 11.2V4.5a1 1 0 0 1 1-1h6.7a1 1 0 0 1 .7.3l8 8a1 1 0 0 1 0 1.4l-6.7 6.7a1 1 0 0 1-1.4 0l-8-8a1 1 0 0 1-.3-.7z"/><circle cx="7.8" cy="7.8" r="1.3"/>',
});

/* Adres, na który trafiają zgłoszenia błędów. To adres autora aplikacji,
   a nie użytkownika — dlatego jest tutaj, w kodzie, a nie w ustawieniach
   profilu, gdzie każdy mógłby go sobie nadpisać. */
const KONTAKT_EMAIL = 'jacekkoz9@gmail.com';
const APP_WERSJA = '1.6.0';

const TEMATY_BLEDU = [
  'Błędny wynik obliczeń',
  'Aplikacja się zacięła lub zamknęła',
  'Problem z ofertą lub fakturą',
  'Problem z plikiem XML do KSeF',
  'Propozycja zmiany albo nowego kalkulatora',
  'Coś innego',
];

state.settings = loadSettings();
state.catalog = loadCatalog();
state.setScreen = 'main';
/* Miejsce w katalogu cen: dział, rozmiar i wpisana fraza. */
state.catGrp = null;
state.catEdyt = null;      // własna pozycja otwarta do edycji (koło zębate)
state.catDn = null;
state.catQ = '';
/* Treść zgłoszenia trzymamy w pamięci ekranu, a nie w telefonie — to jedna
   wiadomość do wysłania, a nie dane, do których się wraca. */
state.bug = { temat: 0, tresc: '', dane: true, kiedy: '' };

const persistSettings = () => saveSettings(state.settings);
const persistCatalog = () => saveCatalog(state.catalog);

/* Zmniejszamy logo przed zapisem — zdjęcie z telefonu potrafi mieć kilka MB,
   a pamięć przeglądarki jest ograniczona. */
function readLogo(file, done) {
  const fr = new FileReader();
  fr.onload = () => {
    const img = new Image();
    img.onload = () => {
      const max = 240;
      const sc = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * sc);
      c.height = Math.round(img.height * sc);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      done(c.toDataURL('image/png'));
    };
    img.onerror = () => done(null);
    img.src = fr.result;
  };
  fr.onerror = () => done(null);
  fr.readAsDataURL(file);
}

/* ============================================================
   EKRAN GŁÓWNY USTAWIEŃ — menu
   ------------------------------------------------------------
   Ustawienia rozrosły się do czterech różnych rzeczy: danych firmy,
   katalogu cen, opisu metod obliczeniowych i listy tego, czego aplikacja
   nie liczy. Jeden długi ekran ze wszystkim naraz oznaczałby przewijanie
   przez dane firmy za każdym razem, gdy ktoś chce tylko sprawdzić wzór.
   Dlatego ekran główny to menu, a każda pozycja ma własny ekran.
   ============================================================ */
function renderSettingsMain() {
  const s = state.settings;
  const filled = ['company', 'nip', 'address', 'phone', 'email'].filter(k => s[k]).length;

  const poz = (klucz, ikona, tytul, opis) => `<button class="mrow" data-setgo="${klucz}">
      <span class="mrow-i">${svg(ikona)}</span>
      <span class="mrow-t"><strong>${esc(tytul)}</strong><span>${esc(opis)}</span></span>
      ${svg('chev')}</button>`;

  return `<header class="hdr"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><div class="hdr-ico">${svg('gear')}</div>
      <div><h1>Ustawienia</h1><p>Profil firmy, ceny i opis metod obliczeniowych</p></div></div></header>
    <div class="body">
      <div class="mlist">
        ${poz('profil', 'building', 'Ustawienia profilu',
              filled >= 3 ? 'Dane firmy, logo, domyślne wartości ofert i faktur'
                          : 'Uzupełnij dane firmy — pojawią się na ofercie i fakturze')}
        ${poz('catalog', 'tag', 'Katalog cen', state.catalog.length + ' pozycji — Twoje stawki materiałów i robocizny')}
        ${poz('karta', 'doc', 'Karta informacyjna', 'Wzory, źródła i przyjęte wartości — dla każdego kalkulatora')}
        ${poz('nieliczy', 'shield', 'Czego aplikacja nie liczy', 'Zakresy świadomie pominięte — warto wiedzieć przed wyceną')}
        ${poz('kopia', 'save', 'Kopia zapasowa', (() => {
          const o = ostatniaKopia();
          return o ? 'Ostatnia ' + (dataPoPolsku(o) || o).split(',')[0]
                   : 'Zapisz wszystko do pliku — albo wczytaj z kopii';
        })())}
        ${poz('polityka', 'shield', 'Polityka prywatności',
              'Co aplikacja zapisuje w telefonie i czego nie wysyła nigdzie dalej')}
        ${poz('blad', 'alert', 'Zgłoś błąd', 'Coś liczy się źle albo nie działa? Napisz do autora')}
      </div>

      ${filled < 3 ? `<div class="checks">
        <div class="checks-h">${svg('alert')}Uzupełnij dane firmy</div>
        <ul><li>${svg('alert')}<span>Bez nazwy i kontaktu oferta wygląda nieprofesjonalnie — to pierwsze, co widzi klient.</span></li></ul>
      </div>` : ''}

      <div class="tip">${svg('spark')}<div>Wszystko zapisuje się w telefonie i działa bez internetu.
        Kopię zapasową zrobisz w pozycji powyżej; synchronizacja
        między urządzeniami to kolejny etap.</div></div>
    </div>`;
}

/* ============================================================
   EKRAN: USTAWIENIA PROFILU
   ============================================================ */
/* Pobranie własnych danych z wykazu VAT. Ten sam mechanizm, co przy NIP-ie
   nabywcy na fakturze — tyle że wpisuje do profilu firmy. Guzik pojawia się
   dopiero przy dziesięciu cyfrach, bo wcześniej nie ma czego szukać. */
function gusFirmaBtnHtml(s) {
  const n = String(s.nip || '').replace(/[^0-9]/g, '');
  if (n.length !== 10) return '';
  return `<button class="btn2" style="width:100%" data-gusfirma>${svg('search')}Pobierz dane z wykazu VAT</button>`;
}

function renderProfil() {
  const s = state.settings;

  return `<header class="hdr hdr--cat" style="--c:var(--cat-pump)"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" id="backset" aria-label="Wróć">${svg('back')}</button>
      <div><h1>Ustawienia profilu</h1><p>Dane firmy, logo i domyślne wartości</p></div></div></header>
    <div class="body">

      <div class="card"><div class="card-head">${svg('building')}Dane firmy</div><div class="fields">
        <div class="field"><label for="s-company">Nazwa firmy</label>
          <input id="s-company" type="text" autocapitalize="words" autocomplete="organization" data-s="company" value="${esc(s.company)}"
            placeholder="np. Jan Kowalski Instalacje"></div>
        <div class="field"><label for="s-nip">NIP</label>
          <input id="s-nip" type="text" inputmode="numeric" data-s="nip" value="${esc(s.nip)}"></div>
        <div id="gusbox-firma">${gusFirmaBtnHtml(s)}</div>
        <div class="field"><label for="s-address">Adres</label>
          <input id="s-address" type="text" autocapitalize="words" autocomplete="street-address" data-s="address" value="${esc(s.address)}"></div>
        <div class="row2">
          <div class="field"><label for="s-phone">Telefon</label>
            <input id="s-phone" type="text" data-s="phone" value="${esc(s.phone)}"></div>
          <div class="field"><label for="s-email">E-mail</label>
            <input id="s-email" type="text" data-s="email" value="${esc(s.email)}"></div>
        </div>
      </div></div>

      <div class="card"><div class="card-head">${svg('image')}Logo na ofercie</div>
        <div class="logo-row">
          ${s.logo ? `<img class="logo-prev" src="${s.logo}" alt="Logo firmy">`
                   : `<div class="logo-empty">${svg('image')}</div>`}
          <div class="logo-btns">
            <label class="btn2 as-label">${svg('image')}${s.logo ? 'Zmień' : 'Wgraj logo'}
              <input type="file" accept="image/*" id="s-logo" hidden></label>
            ${s.logo ? `<button class="btn2" data-logodel>${svg('trash')}Usuń</button>` : ''}
          </div>
        </div>
        <p class="hint">Obrazek jest pomniejszany przed zapisem, więc nie zajmie miejsca w telefonie.</p>
      </div>

      <div class="card"><div class="card-head">${svg('money')}Domyślne wartości nowych ofert</div><div class="fields">
        <div class="row2">
          <div class="field"><label for="s-margin">Marża na materiałach</label>
            <input id="s-margin" type="number" inputmode="decimal" step="1" data-s="marginPct" value="${s.marginPct}">
            <span class="unit">%</span></div>
          <div class="field"><label for="s-valid">Oferta ważna</label>
            <input id="s-valid" type="number" inputmode="numeric" step="1" data-s="validDays" value="${s.validDays}">
            <span class="unit">dni</span></div>
        </div>
        <div class="field"><label for="s-vat">Stawka VAT</label>
          <select id="s-vat" data-s="vatRate">
            ${VAT_RATES.map(r => `<option value="${r.value}"${Number(s.vatRate) === r.value ? ' selected' : ''}>${esc(r.label)}</option>`).join('')}
          </select><span class="chev">${svg('chevDown')}</span></div>
        <div class="field"><label for="s-prefix">Prefiks numeracji ofert</label>
          <input id="s-prefix" type="text" data-s="numberPrefix" value="${esc(s.numberPrefix)}"
            placeholder="np. OF — zostaw puste, jeśli niepotrzebny"></div>
        <div class="mini grow" style="margin-top:2px"><label for="s-terms">Warunki na ofercie</label>
          <textarea id="s-terms" rows="2" autocapitalize="sentences" data-s="terms">${esc(s.terms)}</textarea></div>
      </div></div>

      <div class="card"><div class="card-head">${svg('doc')}Faktury</div><div class="fields">
        <div class="field"><label for="s-bank">Numer konta do przelewu</label>
          <input id="s-bank" type="text" inputmode="numeric" data-s="bank" value="${esc(s.bank || '')}"
            placeholder="PL00 0000 0000 0000 0000 0000 0000"></div>
        <div class="row2">
          <div class="field"><label for="s-invpfx">Prefiks numeru faktury</label>
            <input id="s-invpfx" type="text" data-s="invPrefix" value="${esc(s.invPrefix || 'FV')}"></div>
          <div class="field"><label for="s-paydays">Domyślny termin płatności</label>
            <input id="s-paydays" type="number" inputmode="numeric" step="1" data-s="payDays" value="${s.payDays || 14}">
            <span class="unit">dni</span></div>
        </div>
        <div class="field"><label for="s-vatst">Status VAT</label>
          <select id="s-vatst" data-s="vatStatus">
            <option value="czynny"${s.vatStatus !== 'zwolniony' ? ' selected' : ''}>Czynny podatnik VAT</option>
            <option value="zwolniony"${s.vatStatus === 'zwolniony' ? ' selected' : ''}>Zwolniony z VAT</option>
          </select><span class="chev">${svg('chevDown')}</span></div>
        ${s.vatStatus === 'zwolniony' ? `<div class="field"><label for="s-zw">Podstawa zwolnienia</label>
          <input id="s-zw" type="text" data-s="zwPodstawa" value="${esc(s.zwPodstawa || '')}"></div>` : ''}
        <div class="mini grow" style="margin-top:2px"><label for="s-foot">Domyślna stopka faktury</label>
          <textarea id="s-foot" rows="2" autocapitalize="sentences" data-s="invFooter">${esc(s.invFooter || '')}</textarea></div>
      </div></div>

      <div class="tip">${svg('spark')}<div>Dane zapisują się od razu, nie ma przycisku „zapisz".
        Wszystko zostaje w telefonie i działa bez internetu.</div></div>
    </div>`;
}

/* ============================================================
   EKRANY TEKSTOWE — karta informacyjna i lista pominięć
   ------------------------------------------------------------
   Treść obu bierze się z karta.html przez karta_build.py, więc dokument
   dla specjalisty i ekran w aplikacji nie mogą się rozjechać.
   ============================================================ */
function renderKarta() {
  return `<header class="hdr hdr--cat" style="--c:var(--cat-pipe)"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" id="backset" aria-label="Wróć">${svg('back')}</button>
      <div><h1>Karta informacyjna</h1><p>Wzory, źródła i przyjęte wartości</p></div></div></header>
    <div class="body">
      <div class="tip">${svg('spark')}<div>Każdy kalkulator ma tu swoją sekcję: co liczy, jakim wzorem,
        skąd wzięły się dane i co zostało uproszczone. Miejsca oznaczone jako <b>przyjęcie</b> to
        wartości z praktyki, a nie z normy — przy wycenie warto o nich wiedzieć.</div></div>
      <div class="karta">${KARTA_HTML}</div>
    </div>`;
}

/* ============================================================
   EKRAN: POLITYKA PRYWATNOŚCI
   ------------------------------------------------------------
   Google Play wymaga, żeby polityka była dostępna nie tylko pod adresem
   podanym w Konsoli, ale też z wnętrza aplikacji. Wklejamy więc całą treść,
   a nie odnośnik: w kotłowni nie ma zasięgu, a dokument, którego nie da się
   otworzyć, nie jest dostępny. Tekst jest generowany z tego samego pliku,
   który leży w sieci, więc obie wersje nie mogą się rozjechać.
   ============================================================ */
function renderPolityka() {
  return `<header class="hdr hdr--cat" style="--c:var(--cat-safe)"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" id="backset" aria-label="Wróć">${svg('back')}</button>
      <div><h1>Polityka prywatności</h1><p>Obowiązuje od ${esc(POLITYKA_DATA)}</p></div></div></header>
    <div class="body">
      <div class="tip">${svg('shield')}<div>Ta sama treść, co pod adresem podanym w Google Play —
        tutaj czyta się ją bez internetu. Aplikacja nie ma serwera i nie wysyła nigdzie
        Twoich danych.</div></div>
      <div class="karta pol">${POLITYKA_HTML}</div>
    </div>`;
}

function renderNieLiczy() {
  return `<header class="hdr hdr--cat" style="--c:var(--cat-safe)"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" id="backset" aria-label="Wróć">${svg('back')}</button>
      <div><h1>Czego nie liczy</h1><p>Zakresy świadomie pominięte</p></div></div></header>
    <div class="body">
      <div class="tip tip--warn">${svg('shield')}<div>Te rzeczy aplikacja pomija celowo. Nie są błędem,
        ale wpływają na wynik — przy wycenie trzeba je uwzględnić osobno albo zostawić zapas.</div></div>
      <div class="karta">${NIELICZY_HTML}</div>
    </div>`;
}

/* ============================================================
   EKRAN: EDYTOR KATALOGU CEN
   ============================================================ */
function renderCatalogEditor() {
  const menu = katalogMenu();
  const szukane = (state.catQ || '').trim();
  const wybrana = menu.find(g => g.nazwa === state.catGrp);
  const ileCen = state.catalog.filter(c => Number(c.price) > 0).length;

  /* Wiersz do wpisania ceny. Indeksem jest identyfikator pozycji, a nie
     miejsce na liście — lista zmienia się przy każdym przejściu poziomu
     i numer wskazywałby po chwili na coś zupełnie innego. */
  /* Własne pozycje (dopisane przez użytkownika) mają edytowalną nazwę,
     jednostkę i rodzaj — fabrycznych nie ruszamy, bo po ich nazwach
     działa kontrola kompletności oferty. */
  /* Własna pozycja: zwięzły wiersz z kołem zębatym; po dotknięciu koła
     rozwija się edycja nazwy, jednostki i rodzaju (jak w zestawieniu). */
  const wlasny = c => state.catEdyt !== c.id ? `<div class="crow">
      <span class="crow-t">${esc(c.name)}<span>${esc(c.unit)} · ${c.cat === 'rob' ? 'robocizna' : 'materiał'}</span></span>
      <input type="number" inputmode="decimal" step="any" data-cena="${esc(c.id)}"
        value="${Number(c.price) ? c.price : ''}" placeholder="0,00" aria-label="Cena: ${esc(c.name)}">
      <button class="item-x crow-gear" data-cedyt="${esc(c.id)}" aria-label="Edytuj pozycję">${svg('gear')}</button>
    </div>` : `<div class="crow crow--wl">
      <div class="crow-wl">
        <textarea class="crow-n" rows="${Math.min(3, Math.ceil(String(c.name).length / 30) || 1)}" data-cnazwa="${esc(c.id)}"
          placeholder="Nazwa pozycji" autocapitalize="sentences" aria-label="Nazwa pozycji">${esc(c.name === 'Nowa pozycja' ? '' : c.name)}</textarea>
        <div class="crow-wr">
          <select data-cjedn="${esc(c.id)}" aria-label="Jednostka">${UNITS.concat(UNITS.includes(c.unit) ? [] : [c.unit])
            .map(u => `<option value="${esc(u)}"${u === c.unit ? ' selected' : ''}>${esc(u)}</option>`).join('')}</select>
          <button class="pill-cat ${c.cat === 'rob' ? 'pill-rob' : 'pill-mat'}" data-ccat="${esc(c.id)}">${svg('pen')}${c.cat === 'rob' ? 'robocizna' : 'materiał'}</button>
          <input type="number" inputmode="decimal" step="any" data-cena="${esc(c.id)}"
            value="${Number(c.price) ? c.price : ''}" placeholder="0,00" aria-label="Cena">
        </div>
      </div>
      <div class="crow-btns">
        <button class="item-x crow-gear on" data-cedyt="${esc(c.id)}" aria-label="Zakończ edycję">${svg('check')}</button>
        <button class="item-x crow-del" data-cdelid="${esc(c.id)}" aria-label="Usuń">${svg('trash')}</button>
      </div>
    </div>`;
  const wiersz = c => katalogWlasna(c) ? wlasny(c) : `<div class="crow">
      <span class="crow-t">${esc(c.name)}<span>${esc(c.unit)} · ${
        c.cat === 'rob' ? 'robocizna' : 'materiał'}${c.tag ? ' · rozpoznawana przez kontrolę ofert' : ''}</span></span>
      <input type="number" inputmode="decimal" step="any" data-cena="${esc(c.id)}"
        value="${Number(c.price) ? c.price : ''}" placeholder="0,00" aria-label="Cena: ${esc(c.name)}">
      ${/^c\d/.test(String(c.id)) ? `<button class="item-x" data-cdelid="${esc(c.id)}" aria-label="Usuń">${svg('x')}</button>` : ''}
    </div>`;

  let tresc;
  let podtytul;

  if (szukane) {
    const trafienia = katalogSzukajFrazy(szukane, 80);
    podtytul = trafienia.length ? trafienia.length + ' znalezionych' : 'nic nie pasuje';
    tresc = trafienia.length ? trafienia.map(wiersz).join('')
      : `<p class="empty">Nic nie pasuje do „${esc(szukane)}".</p>`;

  } else if (wybrana && wybrana.rozmiary.length && !state.catDn) {
    podtytul = wybrana.nazwa;
    tresc = `<button class="btn2" style="width:100%;margin-bottom:12px" data-catback="grp">${svg('back')}Wróć do działów</button>
      <div class="cgrp">Wybierz rozmiar</div><div class="dnlist">`
      + wybrana.rozmiary.map(d => `<button class="dnbtn" data-catdn="${esc(d)}">${esc(d)}</button>`).join('')
      + `</div>`
      + (wybrana.bezRozmiaru ? `<button class="citem" data-catdn="${BEZ_ROZMIARU}">
          <span class="citem-t"><strong>Bez rozmiaru</strong>
            <span>${wybrana.bezRozmiaru} pozycji</span></span>${svg('chev')}</button>` : '')
      + `<button class="citem" data-catdn="*"><span class="citem-t"><strong>Wszystkie rozmiary</strong>
          <span>${wybrana.ile} pozycji</span></span></button>`;

  } else if (wybrana) {
    const lista = katalogWGrupie(wybrana.nazwa, state.catDn === '*' ? null : state.catDn);
    podtytul = wybrana.nazwa + (state.catDn && state.catDn !== '*' ? ' · ' + state.catDn : '');
    tresc = `<button class="btn2" style="width:100%;margin-bottom:12px" data-catback="${
        wybrana.rozmiary.length ? 'dn' : 'grp'}">${svg('back')}Wróć</button>`
      + lista.map(wiersz).join('')
      + `<button class="addbtn" data-caddtu style="--c:var(--flame);margin-top:6px">${svg('plus')}Dodaj własną pozycję${
          state.catDn && state.catDn !== '*' && state.catDn !== BEZ_ROZMIARU ? ' — ' + esc(state.catDn) : ' w tym dziale'}</button>`;

  } else {
    podtytul = state.catalog.length + ' pozycji · ' + ileCen + ' z ceną';
    tresc = `<button class="addbtn" data-cadd style="--c:var(--flame);margin-bottom:12px">${
        svg('plus')}Dodaj własną pozycję</button>`
      + `<div class="cgrp">Działy</div>`
      + menu.map(g => `<button class="citem" data-catgrp="${esc(g.nazwa)}">
          <span class="citem-t"><strong>${esc(g.nazwa)}</strong>
            <span>${g.ile} pozycji${g.rozmiary.length ? ' · ' + g.rozmiary.length + ' rozmiarów' : ''}</span></span>
          ${svg('chev')}</button>`).join('');
  }

  return `<header class="hdr hdr--cat" style="--c:var(--flame)"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" id="backset" aria-label="Wróć">${svg('back')}</button>
      <div><h1>Katalog cen</h1><p>${esc(podtytul)}</p></div></div></header>
    <div class="body">
      <div class="search">${svg('search')}
        <input type="search" data-catq placeholder="Szukaj: kolano 25, filtr 3/4…"
          value="${esc(szukane)}" autocapitalize="off" autocorrect="off" spellcheck="false">
      </div>

      ${!szukane && !wybrana ? `<div class="tip">${svg('spark')}<div>Baza ma ${state.catalog.length} pozycji
        i celowo jest bez cen — każdy kupuje u swojego hurtownika, na swoim rabacie.
        Wpisz stawki tam, gdzie ich potrzebujesz; reszta poczeka pusta i nie przeszkadza.
        Cena wpisana w ofercie też tu trafia.</div></div>` : ''}

      <div class="items">${tresc}</div>

      ${!szukane && !wybrana ? `<button class="btn2" data-creset style="width:100%">${
        svg('restore')}Wyczyść wszystkie moje ceny</button>` : ''}
    </div>`;
}

/* ============================================================
   EKRAN: ZGŁOSZENIE BŁĘDU
   ------------------------------------------------------------
   Aplikacja działa bez internetu i nie ma własnego serwera, więc zgłoszenie
   nie leci „w tło" — otwiera się program pocztowy z gotową wiadomością,
   a użytkownik naciska wyślij. Dzięki temu widzi dokładnie, co wychodzi,
   i ma kopię w swoich wysłanych. Gdyby program pocztowy się nie otworzył
   (zdarza się w przeglądarce), zostaje przycisk kopiowania całej treści.
   ============================================================ */

/* Dane techniczne dopisywane na końcu wiadomości. Bez nich połowa zgłoszeń
   kończy się dopytywaniem „a na czym to było i w którym miejscu". */
function daneTechniczne() {
  const lin = [];
  lin.push('Wersja aplikacji: ' + APP_WERSJA);
  lin.push('Uruchomiona jako: ' + (typeof naTelefonie === 'function' && naTelefonie()
    ? 'aplikacja na telefonie' : 'strona w przeglądarce'));
  try { lin.push('Urządzenie: ' + navigator.userAgent); } catch (e) { /* nieistotne */ }
  try { lin.push('Ekran: ' + window.innerWidth + '×' + window.innerHeight); } catch (e) { /* nieistotne */ }
  const c = CALCS.find(x => x.id === state.calc);
  lin.push('Ostatnio otwarty kalkulator: ' + (c ? c.title : 'żaden'));
  /* Data ustalana przy wejściu na ekran, a nie przy składaniu wiadomości.
     Inaczej podgląd „co zostanie wysłane" pokazywałby sekundę wcześniejszą
     niż to, co faktycznie wychodzi — drobiazg, ale to właśnie ten ekran
     obiecuje użytkownikowi, że widzi dokładnie treść maila. */
  lin.push('Data zgłoszenia: ' + (state.bug.kiedy || new Date().toLocaleString('pl-PL')));
  return lin.join('\n');
}

function trescZgloszenia() {
  const b = state.bug;
  const czesci = [b.tresc.trim() || '(nie opisano)'];
  if (b.dane) czesci.push('---\nDane techniczne (dopisane automatycznie):\n' + daneTechniczne());
  return czesci.join('\n\n');
}

const tematZgloszenia = () =>
  'Asystent Instalatora — ' + (TEMATY_BLEDU[state.bug.temat] || TEMATY_BLEDU[0]);

/* Sam adres, bez otwierania czegokolwiek — dzięki temu da się go sprawdzić
   w testach, nie wywołując programu pocztowego. */
const mailtoZgloszenia = () => 'mailto:' + KONTAKT_EMAIL
  + '?subject=' + encodeURIComponent(tematZgloszenia())
  + '&body=' + encodeURIComponent(trescZgloszenia());

function wyslijZgloszenie() {
  if (!state.bug.tresc.trim()) { toast('Napisz, co się stało — bez opisu trudno będzie to naprawić.'); return; }
  const url = mailtoZgloszenia();
  /* Bardzo długi mailto potrafi zostać ucięty przez system, więc pilnujemy
     rozsądnej granicy i mówimy o tym wprost, zamiast wysyłać połowę opisu. */
  if (url.length > 6000) {
    toast('Opis jest bardzo długi — skopiuj treść i wklej ją do maila ręcznie.');
    return;
  }
  try { window.location.href = url; } catch (e) {
    toast('Nie udało się otworzyć programu pocztowego. Skopiuj treść i wyślij ręcznie.');
  }
}

function renderBlad() {
  const b = state.bug;
  const podglad = esc(trescZgloszenia());

  return `<header class="hdr hdr--cat" style="--c:var(--cat-heat)"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" id="backset" aria-label="Wróć">${svg('back')}</button>
      <div><h1>Zgłoś błąd</h1><p>Wiadomość trafi do autora aplikacji</p></div></div></header>
    <div class="body">
      <div class="card"><div class="card-head">${svg('alert')}Czego dotyczy</div><div class="fields">
        <div class="field"><label for="b-temat">Temat</label>
          <select id="b-temat" data-bug="temat">
            ${TEMATY_BLEDU.map((t, i) => `<option value="${i}"${i === Number(b.temat) ? ' selected' : ''}>${esc(t)}</option>`).join('')}
          </select><span class="chev">${svg('chevDown')}</span></div>
        <div class="mini grow"><label for="b-tresc">Opis</label>
          <textarea id="b-tresc" rows="5" autocapitalize="sentences" data-bug="tresc"
            placeholder="Co robiłeś, co się stało i czego się spodziewałeś. Jeśli chodzi o wynik obliczeń — podaj wpisane dane, to najszybsza droga do naprawy.">${esc(b.tresc)}</textarea></div>
      </div></div>

      <div class="card"><div class="card-head">${svg('gear')}Dane techniczne</div>
        <label class="chk">
          <input type="checkbox" data-bug="dane"${b.dane ? ' checked' : ''}>
          <span>Dołącz wersję aplikacji, model urządzenia i ostatnio otwarty kalkulator</span>
        </label>
        <p class="hint">Nic poza tym nie wychodzi z telefonu — ani dane firmy, ani oferty,
          ani faktury. Wiadomość zobaczysz przed wysłaniem w swoim programie pocztowym.</p>
      </div>

      <div class="card"><div class="card-head">${svg('doc')}Co zostanie wysłane</div>
        <p class="hint" style="margin-top:0"><b>Do:</b> ${esc(KONTAKT_EMAIL)}<br>
          <b>Temat:</b> ${esc(tematZgloszenia())}</p>
        <pre class="bugprev">${podglad}</pre>
      </div>

      <button class="jump" style="--c:var(--cat-heat);width:100%" data-bugsend>
        ${svg('arrow')}Otwórz pocztę z gotową wiadomością</button>
      <button class="btn2" style="width:100%" data-bugcopy>${svg('list')}Kopiuj treść zgłoszenia</button>

      <div class="tip">${svg('spark')}<div>Aplikacja nie wysyła niczego sama — otwiera Twój program
        pocztowy z przygotowaną wiadomością, a Ty ją wysyłasz. Jeśli poczta się nie otworzy,
        skopiuj treść i wyślij ją na ${esc(KONTAKT_EMAIL)} z dowolnego miejsca.</div></div>
    </div>`;
}

const SET_SCREENS = {
  profil: renderProfil,
  catalog: renderCatalogEditor,
  karta: renderKarta,
  nieliczy: renderNieLiczy,
  polityka: renderPolityka,
  blad: renderBlad,
  kopia: renderKopia,
};
function renderSettingsTab() {
  const f = SET_SCREENS[state.setScreen];
  return f ? f() : renderSettingsMain();
}

/* ============================================================
   ZDARZENIA
   ============================================================ */
document.addEventListener('click', e => {
  const go = e.target.closest('[data-setgo]');
  if (go) {
    state.setScreen = go.dataset.setgo;
    if (state.setScreen === 'blad') state.bug.kiedy = new Date().toLocaleString('pl-PL');
    if (state.setScreen === 'catalog') { state.catGrp = null; state.catDn = null; state.catQ = ''; }
    /* Wejście na ekran kopii zawsze zaczyna się od czystej kartki — plik
       wybrany kwadrans temu i porzucony nie ma prawa czekać z boku. */
    if (state.setScreen === 'kopia') { state.kopia.plik = null; state.kopia.blad = null; }
    render(true); return;
  }
  /* Skrót do katalogu bywa naciskany także z ekranu oferty, więc przełączamy
     zakładkę, a nie tylko ekran w ustawieniach — inaczej nic by się nie stało. */
  if (e.target.closest('[data-opencat]')) {
    state.tab = 'settings'; state.setScreen = 'catalog';
    state.catGrp = null; state.catDn = null; state.catQ = '';
    render(true); return;
  }

  const kgrp = e.target.closest('[data-catgrp]');
  if (kgrp) { state.catGrp = kgrp.dataset.catgrp; state.catDn = null; render(true); return; }

  const kdn = e.target.closest('[data-catdn]');
  if (kdn) { state.catDn = kdn.dataset.catdn; render(true); return; }

  const kback = e.target.closest('[data-catback]');
  if (kback) {
    if (kback.dataset.catback === 'dn') state.catDn = null;
    else { state.catGrp = null; state.catDn = null; }
    render(true); return;
  }
  if (e.target.closest('#backset')) { state.setScreen = 'main';
/* Miejsce w katalogu cen: dział, rozmiar i wpisana fraza. */
state.catGrp = null;
state.catDn = null;
state.catQ = ''; render(true); return; }

  if (e.target.closest('[data-bugsend]')) { wyslijZgloszenie(); return; }
  if (e.target.closest('[data-bugcopy]')) {
    const pelna = 'Do: ' + KONTAKT_EMAIL + '\nTemat: ' + tematZgloszenia() + '\n\n' + trescZgloszenia();
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(pelna)
        .then(() => toast('Skopiowano treść zgłoszenia.'))
        .catch(() => toast('Schowek zablokowany — zaznacz treść na ekranie i skopiuj ręcznie.'));
    } else {
      toast('Ta przeglądarka nie daje dostępu do schowka — zaznacz treść i skopiuj ręcznie.');
    }
    return;
  }

  const gusF = e.target.closest('[data-gusfirma]');
  if (gusF) {
    gusF.disabled = true; gusF.textContent = 'Pobieram…';
    pobierzZWykazu(state.settings.nip, w => {
      const odswiez = () => {
        const gb = document.getElementById('gusbox-firma');
        if (gb) gb.innerHTML = gusFirmaBtnHtml(state.settings);
      };
      if (w.err) { toast(w.err); odswiez(); return; }
      state.settings.company = w.name || state.settings.company;
      state.settings.address = w.addr || state.settings.address;
      persistSettings();
      render(false);
      toast(w.status && w.status !== 'Czynny'
        ? 'Pobrano dane. Uwaga: Twój status VAT w wykazie to „' + w.status + '".'
        : 'Pobrano dane z wykazu.');
    });
    return;
  }

  if (e.target.closest('[data-logodel]')) {
    state.settings.logo = null; persistSettings(); render(false); return;
  }
  const ced = e.target.closest('[data-cedyt]');
  if (ced) {
    const id = ced.dataset.cedyt;
    state.catEdyt = state.catEdyt === id ? null : id;
    renderKeepScroll();
    if (state.catEdyt) { const n = document.querySelector(`[data-cnazwa="${id}"]`); if (n) n.focus(); }
    return;
  }
  const ccat = e.target.closest('[data-ccat]');
  if (ccat) {
    const c = state.catalog.find(x => x.id === ccat.dataset.ccat);
    if (c) { c.cat = c.cat === 'rob' ? 'mat' : 'rob'; persistCatalog(); renderKeepScroll(); }
    return;
  }
  /* Własna pozycja od razu w dziale i rozmiarze, w którym właśnie jesteśmy —
     np. kolano, którego brakuje w bazie, ląduje przy swojej średnicy. */
  if (e.target.closest('[data-caddtu]')) {
    const nowa = blankCatalogItem();
    nowa.grp = state.catGrp || 'Moje pozycje';
    if (state.catDn && state.catDn !== '*' && state.catDn !== BEZ_ROZMIARU) nowa.dn = state.catDn;
    const wzor = katalogWGrupie(nowa.grp, nowa.dn || null).find(c => c.unit);
    if (wzor && wzor.unit === 'mb' && !/rura/i.test(wzor.name)) nowa.unit = 'mb';
    state.catalog.push(nowa); persistCatalog(); state.catEdyt = nowa.id;
    renderKeepScroll();
    const pole = document.querySelector(`[data-cnazwa="${nowa.id}"]`);
    if (pole) { pole.focus(); pole.scrollIntoView({ block: 'center' }); }
    toast('Nowa pozycja w dziale „' + nowa.grp + '”' + (nowa.dn ? ', rozmiar ' + nowa.dn : '') + ' — wpisz nazwę i cenę.');
    return;
  }
  if (e.target.closest('[data-cadd]')) {
    const nowa = blankCatalogItem();
    state.catalog.push(nowa); persistCatalog(); state.catEdyt = nowa.id;
    state.catGrp = nowa.grp; state.catDn = null; state.catQ = '';
    render(true);
    const pole = document.querySelector(`[data-cnazwa="${nowa.id}"]`);
    if (pole) { pole.focus(); pole.scrollIntoView({ block: 'center' }); }
    toast('Dodano pozycję — wpisz nazwę, jednostkę i cenę.');
    return;
  }
  /* Kasujemy po identyfikatorze, nie po miejscu na liście: lista zmienia
     się przy każdym przejściu poziomu, a numer wskazywałby wtedy na
     zupełnie inną pozycję. */
  const cdel = e.target.closest('[data-cdelid]');
  if (cdel) {
    const i = state.catalog.findIndex(c => c.id === cdel.dataset.cdelid);
    if (i >= 0) { state.catalog.splice(i, 1); persistCatalog(); }
    renderKeepScroll(); return;
  }

  /* Czyszczenie cen kasuje to, co użytkownik wpisał, a nie bazę — baza
     siedzi w kodzie i nie ma jej jak „przywrócić". Pozycje własne
     zostają, tracą tylko cenę: to jego nazwy, nie nasze.

     Kasujemy prosto z pamięci telefonu, a nie przez wyzerowanie listy
     i zapis. Zapisana lista samych zer znaczyłaby „każda z dziewięciuset
     pozycji kosztuje zero" i zajęłaby w telefonie więcej miejsca niż
     wszystkie jego prawdziwe ceny razem wzięte.

     Przed skasowaniem odkładamy kopię, bo to jedno dotknięcie kasuje
     pracę wielu wieczorów. */
  if (e.target.closest('[data-creset]')) {
    let kopia = null;
    try {
      kopia = { ceny: localStorage.getItem(CENY_KEY), wlasne: localStorage.getItem(CATALOG_KEY) };
      const bezCen = state.catalog.filter(c => /^c\d/.test(String(c.id)))
        .map(c => Object.assign({}, c, { price: 0 }));
      localStorage.setItem(CENY_KEY, '{}');
      localStorage.setItem(CATALOG_KEY, JSON.stringify(bezCen));
    } catch (err) { /* bez pamięci i tak nie ma czego czyścić */ }
    state.catalog = loadCatalog();
    state.cofnij = { typ: 'ceny', dane: kopia, opis: 'ceny' };
    render(false);
    toast('Wyczyszczono wszystkie Twoje ceny.', 'Cofnij');
    return;
  }
});

document.addEventListener('input', e => {
  const t = e.target;

  /* Zgłoszenie błędu. Podgląd „co zostanie wysłane" odświeżamy w miejscu,
     bez przebudowy ekranu — przerysowanie w trakcie pisania gubiłoby kursor. */
  if (t.dataset.bug !== undefined) {
    const k = t.dataset.bug;
    state.bug[k] = t.type === 'checkbox' ? t.checked : t.value;
    if (t.tagName === 'TEXTAREA') autosize(t);
    const prev = document.querySelector('.bugprev');
    if (prev) prev.textContent = trescZgloszenia();
    return;
  }

  if (t.dataset.s !== undefined) {
    const k = t.dataset.s;
    state.settings[k] = (k === 'marginPct' || k === 'validDays' || k === 'vatRate' || k === 'payDays')
      ? (t.value === '' ? 0 : parseFloat(t.value))
      : t.value;
    if (t.tagName === 'TEXTAREA') autosize(t);
    persistSettings();
    /* Guzik pobierania podmieniamy w miejscu, bez przerysowania ekranu —
       inaczej kursor wyskakiwałby z pola przy każdej cyfrze NIP-u. */
    if (k === 'nip') {
      const gb = document.getElementById('gusbox-firma');
      if (gb) gb.innerHTML = gusFirmaBtnHtml(state.settings);
    }
    return;
  }
  /* Wyszukiwarka katalogu. Przerysowujemy ekran, bo lista musi się zmienić,
     ale kursor wraca do pola — inaczej po pierwszej literze trzeba by
     dotykać pola od nowa. */
  if (t.dataset.catq !== undefined) {
    state.catQ = t.value;
    render(false);
    const pole = document.querySelector('[data-catq]');
    if (pole) { pole.focus(); pole.setSelectionRange(pole.value.length, pole.value.length); }
    return;
  }
  if (t.dataset.cnazwa !== undefined) {
    const c = state.catalog.find(x => x.id === t.dataset.cnazwa);
    if (c) { c.name = t.value.trim() || 'Nowa pozycja'; persistCatalog(); }
    return;
  }
  if (t.dataset.cena !== undefined) {
    const c = state.catalog.find(x => x.id === t.dataset.cena);
    if (c) { c.price = t.value === '' ? 0 : parseFloat(t.value) || 0; persistCatalog(); }
    return;
  }
});

document.addEventListener('change', e => {
  if (e.target.id === 's-logo' && e.target.files && e.target.files[0]) {
    readLogo(e.target.files[0], data => {
      if (data) { state.settings.logo = data; persistSettings(); render(false); }
    });
  }
  /* Po wpisaniu nazwy pozycja z „Moje pozycje” trafia do swojego działu. */
  if (e.target.dataset && e.target.dataset.cnazwa !== undefined) {
    const c = state.catalog.find(x => x.id === e.target.dataset.cnazwa);
    if (c && c.grp === 'Moje pozycje') {
      const g = katalogDzial(c.name, c.cat);
      if (g !== 'Moje pozycje') { c.grp = g; persistCatalog(); toast('Przeniesiono do działu „' + g + '”.'); }
    }
  }
  if (e.target.dataset && e.target.dataset.cjedn !== undefined) {
    const c = state.catalog.find(x => x.id === e.target.dataset.cjedn);
    if (c) { c.unit = e.target.value; persistCatalog(); }
  }
  if (e.target.dataset && (e.target.dataset.s === 'vatRate' || e.target.dataset.s === 'vatStatus')) render(false);
  /* Zmiana tematu i przełącznik danych technicznych zmieniają nagłówek
     podglądu, więc tu przerysowanie jest w porządku — nikt nie pisze
     w liście wyboru ani w polu wyboru. */
  if (e.target.dataset && e.target.dataset.bug !== undefined && e.target.tagName !== 'TEXTAREA') {
    const k = e.target.dataset.bug;
    state.bug[k] = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    render(false);
  }
});

