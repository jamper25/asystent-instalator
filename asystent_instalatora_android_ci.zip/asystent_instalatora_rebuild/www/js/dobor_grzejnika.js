/* ===== dobor_grzejnika.js ===== */
/* ============================================================
   DOBÓR GRZEJNIKA — PŁYTOWY ALBO DRABINKOWY
   ------------------------------------------------------------
   Obliczenie dla kalkulatora „Dobór grzejnika". Pola i ich warunki
   stoją w ui.js przy samym kalkulatorze; tu jest to, co się z nich liczy.

   Płytowy: jeden albo dwa takie same grzejniki. Przy dwóch każdy
   dostaje połowę mocy — dwa okna w pokoju albo za mało ściany na jeden
   duży. Do oferty idą dwie sztuki, do średnic jeden wiersz pomieszczenia
   z mocą podzieloną na dwa grzejniki.

   Drabinkowy: płaski albo wypukły, z kart katalogowych. Liczby są te
   z karty (pomieszczenie 20 °C); pod wybraną drabinką pokazujemy, ile odda
   w łazience przy 24 °C, i ostrzegamy, gdy to mniej, niż trzeba.
   ============================================================ */

/* Lista dopasowań: sześć pozycji, po rozwinięciu trzydzieści, i zawsze
   tyle, żeby zmieścił się wybrany. */
function doborWidoczne(m, i0, v) {
  const limit = v.all ? 30 : 6;
  const koniec = Math.max(limit, i0 + 1);
  const more = (!v.all && m.length > koniec)
    ? `<button type="button" class="matches-more" data-radall>Pokaż więcej dopasowań (z ${m.length})</button>`
    : (v.all && m.length > koniec
      ? `<button type="button" class="matches-more" data-radless>Zwiń do sześciu najbliższych</button>`
      : (v.all ? `<button type="button" class="matches-more" data-radless>Zwiń listę</button>` : ''));
  return { widoczne: m.slice(0, koniec), more };
}

const SPADL_TXT = 'Wybrany wcześniej grzejnik nie mieści się już w wynikach po zmianie danych — pokazany jest '
  + 'najbliższy z nowej listy. Wybierz go ponownie, jeśli nadal ma być ten sam.';

function dobierzPlytowy(v) {
  const dwa = String(v.ile) === '2';
  /* Przy dwóch grzejnikach każdy musi pokryć połowę — w górę do wata,
     żeby suma nigdy nie wyszła poniżej zapotrzebowania. */
  const naJeden = dwa ? Math.ceil(v.req / 2) : v.req;
  const m = radiatorMatches(naJeden, v.reg, { height: v.hgt || null, type: v.typ || null,
    maxLength: v.maxl || null });
  if (!m.length) return { error: 'Brak grzejnika o takiej mocy w tabeli przy zadanych ograniczeniach. '
    + (dwa ? 'Zwiększ dopuszczalną długość albo wysokość.'
           : 'Zwiększ dopuszczalną długość, wysokość albo przełącz na dwa grzejniki.') };

  /* Wybór zapamiętujemy przez wymiary, nie przez numer pozycji — po zmianie
     mocy lista jest inna i numer wskazywałby zupełnie inny grzejnik. */
  const sameOne = (a, x) => a && a.length === x.length && a.height === x.height && a.type === x.type;
  const chosenIdx = v.pick ? m.findIndex(x => sameOne(v.pick, x)) : -1;
  const spadl = !!v.pick && chosenIdx < 0;
  const i0 = chosenIdx >= 0 ? chosenIdx : 0;
  const b = m[i0];
  const { widoczne, more } = doborWidoczne(m, i0, v);

  const list = widoczne.map((x, i) => `
    <button type="button" class="match${i === i0 ? ' best' : ''}" data-pickrad="${i}"
      aria-pressed="${i === i0}">
      <div class="match-pick"></div>
      <div class="match-badge">${x.type}</div>
      <div class="match-txt"><strong>Typ ${x.type}, wys. ${x.height} mm</strong><span>długość ${x.length} mm</span></div>
      <div class="match-w"><b>${x.watts} W</b><span>zapas ${fmt(x.margin, 0)}%</span></div>
    </button>`).join('');

  const razem = dwa ? b.watts * 2 : b.watts;
  const zapas = (razem / v.req - 1) * 100;
  const rez = v.reg.replace(/\//g, '/');
  return {
    results: [{ label: chosenIdx >= 0 ? (dwa ? 'Wybrane grzejniki' : 'Wybrany grzejnik') : 'Najbliższe dopasowanie',
      icon: 'check', value: (dwa ? '2 × ' : '') + `Typ ${b.type} · ${b.height}×${b.length}`, unit: '',
      foot: dwa
        ? `razem ${razem} W przy ${rez} °C (po ${b.watts} W) — zapas ${fmt(zapas, 0)}% ponad wymagane ${v.req} W`
        : `${b.watts} W przy ${rez} °C — zapas ${fmt(zapas, 0)}% ponad wymagane ${v.req} W` }],
    warn: spadl ? SPADL_TXT : null,
    extra: `<div class="subhead">${dwa ? `Grzejniki na ${naJeden} W każdy` : 'Pasujące grzejniki'} (${m.length}) — dotknij, żeby wybrać</div>`
         + `<div class="matches">${list}</div>${more}`,
    addTo: { name: `Grzejnik płytowy typ ${b.type}, ${b.height}×${b.length} mm (${b.watts} W)`,
             tag: 'grzejnik', unit: 'szt', cat: 'mat', qty: dwa ? 2 : 1 },
    /* Do średnic jedzie zapotrzebowanie pomieszczenia, a grzejnik obok
       jako wybrany — tak samo, jak gdyby instalator wybrał go „Zmień".
       Przy dwóch: jeden wiersz, moc podzielona po połowie, oba wybrane. */
    doSrednic: {
      tytul: (dwa ? '2 × ' : '') + `Grzejnik typ ${b.type}, ${b.height}×${b.length}`,
      moc: v.req,
      grz: { t: b.type, h: b.height, l: b.length },
      dziel: dwa ? { u: 0.5 } : null,
      grz2: dwa ? { t: b.type, h: b.height, l: b.length } : null,
    },
    _matches: m,
  };
}

function dobierzDrabinke(v) {
  const [tz, tp] = String(v.regD || '75/65/20').split('/').map(Number);
  const m = drabinkiNaMoc(v.req, tz, tp, 20, { ksztalt: v.ksztalt || 'plaska',
    maxSzer: Number(v.szer) || null, maxWys: Number(v.wys) || null });
  const nazwa = drabinkaNazwa(v.ksztalt || 'plaska');
  if (!m.length) return { error: `Żadna drabinka — kształt ${nazwa} — nie pokrywa ${v.req} W przy tych ograniczeniach. `
    + 'Zdejmij ograniczenia, zmień kształt albo przełącz na płytowe.' };

  const sameOne = (a, x) => a && a.k === x.ksztalt && Number(a.h) === x.height && Number(a.w) === x.width;
  const chosenIdx = v.pickD ? m.findIndex(x => sameOne(v.pickD, x)) : -1;
  const spadl = !!v.pickD && chosenIdx < 0;
  const i0 = chosenIdx >= 0 ? chosenIdx : 0;
  const b = m[i0];
  const { widoczne, more } = doborWidoczne(m, i0, v);

  const list = widoczne.map((x, i) => `
    <button type="button" class="match${i === i0 ? ' best' : ''}" data-pickrad="${i}"
      aria-pressed="${i === i0}">
      <div class="match-pick"></div>
      <div class="match-badge match-badge--drab" aria-hidden="true"></div>
      <div class="match-txt"><strong>${x.height} × ${x.width} mm</strong><span>wysokość ${x.height} · szerokość ${x.width}</span></div>
      <div class="match-w"><b>${x.watts} W</b><span>zapas ${fmt(x.margin, 0)}%</span></div>
    </button>`).join('');

  const w24 = drabinkaW24(b, tz, tp);
  const zaMalo24 = w24 < v.req;
  const rez = tz + '/' + tp + '/20';
  return {
    results: [{ label: chosenIdx >= 0 ? 'Wybrana drabinka' : 'Najbliższe dopasowanie',
      icon: 'check', value: drabinkaOpis(b), unit: '',
      foot: `${b.watts} W przy ${rez} °C — zapas ${fmt(b.margin, 0)}% ponad wymagane ${v.req} W. `
        + `W łazience przy 24 °C odda ok. ${w24} W.` }],
    warn: spadl ? SPADL_TXT
      : (zaMalo24 ? `W łazience przy 24 °C ta drabinka odda ok. ${w24} W, czyli mniej niż potrzebne ${v.req} W. `
        + 'Moc z karty jest liczona dla 20 °C — jeśli to łazienka, weź o rozmiar większą.' : null),
    extra: `<div class="subhead">Drabinki — ${nazwa} (${m.length}) — dotknij, żeby wybrać</div>`
         + `<div class="matches">${list}</div>${more}`,
    addTo: { name: `Grzejnik drabinkowy ${nazwa} ${b.height} × ${b.width} mm (${b.watts} W)`,
             tag: 'grzejnik', unit: 'szt', cat: 'mat' },
    doSrednic: {
      tytul: `Grzejnik drabinkowy ${nazwa} ${b.height}×${b.width}`,
      moc: v.req,
      grz: { d: b.ksztalt, h: b.height, w: b.width },
    },
    _matches: m,
  };
}


