/* ===== ksef.js ===== */
/* ============================================================
   PLIK XML FAKTURY W STRUKTURZE FA(3) DLA KSeF
   ------------------------------------------------------------
   Wszystkie nazwy pól, ich kolejność i wymagalność pochodzą
   z oficjalnego schematu:
     https://crd.gov.pl/wzor/2025/06/25/13775/schemat.xsd
   Kolejność elementów w sekwencji XSD jest wiążąca — plik z tymi
   samymi polami ustawionymi inaczej zostanie odrzucony.

   Zakres: faktura podstawowa (RodzajFaktury = VAT), sprzedaż krajowa,
   waluta PLN. Korekty, zaliczki, procedura marży, WDT i eksport nie są
   objęte — aplikacja ich nie wystawia, więc lepiej ich nie generować
   niż generować na ślepo.
   ============================================================ */

const KSEF_NS = 'http://crd.gov.pl/wzor/2025/06/25/13775/';
const KSEF_SYSTEM = 'Asystent Instalatora';

/* Formy płatności wg TFormaPlatnosci: 1 gotówka, 2 karta, 3 bon,
   4 czek, 5 kredyt, 6 przelew, 7 mobilna. */
const KSEF_PAY = { 'gotówka': '1', 'karta': '2', 'przelew': '6', 'blik': '7' };

/* Kwoty: TKwotowy to maksymalnie dwa miejsca po przecinku, z kropką. */
const ksefAmt = x => (Math.round((Number(x) || 0) * 100) / 100).toFixed(2);
/* Ilości: TIlosci dopuszcza więcej miejsc, ale trzymamy się sześciu. */
const ksefQty = x => String(Number((Number(x) || 0).toFixed(6)));

/* W treści elementu XML trzeba uciec tylko & < >. Cudzysłowu nie ruszamy,
   bo nazwy pozycji roją się od cali (rura ½") i &quot; robiłoby z nich sieczkę
   przy każdym podglądzie pliku. */
const ksefEsc = s => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const ksefNip = s => String(s || '').replace(/[^0-9]/g, '');

/* Znacznik czasu w UTC, bez milisekund — schemat wymaga strefy. */
function ksefStamp(d) {
  const x = d || new Date();
  return x.toISOString().replace(/\.\d{3}Z$/, 'Z');
}

const tag = (n, v) => '<' + n + '>' + v + '</' + n + '>';

/* Grupowanie wartości sprzedaży wg stawki.
   P_13_1/P_14_1 → stawka podstawowa 23%
   P_13_2/P_14_2 → obniżona pierwsza 8%
   P_13_3/P_14_3 → obniżona druga 5%
   P_13_7        → sprzedaż zwolniona (bez pola z podatkiem)        */
function ksefTotals(lines, stawka) {
  const r2 = x => Math.round(x * 100) / 100;
  const net = r2(lines.reduce((a, l) => a + l.val, 0));
  if (stawka === 'zw') return { zw: net, net, vat: 0, brutto: net };
  const pct = Number(stawka) || 0;
  const vat = r2(net * pct / 100);
  return { pct, net, vat, brutto: r2(net + vat) };
}

/* Wiersz faktury. P_8A to jednostka miary, P_8B ilość, P_9A cena
   jednostkowa netto, P_11 wartość netto wiersza, P_12 stawka. */
function ksefLine(l, i, stawka) {
  return '      <FaWiersz>\n'
    + '        ' + tag('NrWierszaFa', i + 1) + '\n'
    + '        ' + tag('P_7', ksefEsc(l.name)) + '\n'
    + '        ' + tag('P_8A', ksefEsc(l.jm || 'szt')) + '\n'
    + '        ' + tag('P_8B', ksefQty(l.qty)) + '\n'
    + '        ' + tag('P_9A', ksefAmt(l.unit)) + '\n'
    + '        ' + tag('P_11', ksefAmt(l.val)) + '\n'
    + '        ' + tag('P_12', ksefEsc(stawka)) + '\n'
    + '      </FaWiersz>';
}

/* p = { seller:{nip,name,addr1,addr2}, buyer:{nip,name,addr1,addr2,brakID},
         inv:{number,issue,sale,method,due,paid,paidAt,bank},
         lines:[{name,jm,qty,unit,val}], stawka:'23'|'8'|'zw' }        */
function ksefInvoiceXml(p) {
  const t = ksefTotals(p.lines, p.stawka);
  const zwolniona = p.stawka === 'zw';

  /* Podmiot2: dla firmy NIP, dla osoby prywatnej znacznik BrakID.
     Schemat wymaga wyboru jednej z tych możliwości. */
  const buyerId = p.buyer.nip
    ? '    ' + tag('NIP', ksefNip(p.buyer.nip))
    : '    ' + tag('BrakID', '1');

  const podmiot2Adres = p.buyer.addr1
    ? '\n  <Adres>\n'
      + '    ' + tag('KodKraju', 'PL') + '\n'
      + '    ' + tag('AdresL1', ksefEsc(p.buyer.addr1)) + '\n'
      + (p.buyer.addr2 ? '    ' + tag('AdresL2', ksefEsc(p.buyer.addr2)) + '\n' : '')
      + '  </Adres>'
    : '';

  /* Sumy wg stawek. Pary P_13_x/P_14_x muszą występować razem. */
  let sumy = '';
  if (zwolniona) sumy = '    ' + tag('P_13_7', ksefAmt(t.net)) + '\n';
  else if (t.pct === 23) sumy = '    ' + tag('P_13_1', ksefAmt(t.net)) + '\n    ' + tag('P_14_1', ksefAmt(t.vat)) + '\n';
  else if (t.pct === 8) sumy = '    ' + tag('P_13_2', ksefAmt(t.net)) + '\n    ' + tag('P_14_2', ksefAmt(t.vat)) + '\n';
  else if (t.pct === 5) sumy = '    ' + tag('P_13_3', ksefAmt(t.net)) + '\n    ' + tag('P_14_3', ksefAmt(t.vat)) + '\n';

  /* Adnotacje — wszystkie osiem pozycji jest obowiązkowe.
     Wartość "2" znaczy „nie dotyczy"; przy zwolnieniu podajemy
     podstawę w P_19A, w przeciwnym razie znacznik braku P_19N. */
  const adnotacje = '    <Adnotacje>\n'
    + '      ' + tag('P_16', '2') + '\n'
    + '      ' + tag('P_17', '2') + '\n'
    + '      ' + tag('P_18', '2') + '\n'
    + '      ' + tag('P_18A', '2') + '\n'
    + '      <Zwolnienie>\n'
    + (zwolniona
        ? '        ' + tag('P_19', '1') + '\n        ' + tag('P_19A', ksefEsc(p.zwPodstawa || 'art. 113 ust. 1 ustawy o VAT')) + '\n'
        : '        ' + tag('P_19N', '1') + '\n')
    + '      </Zwolnienie>\n'
    + '      <NoweSrodkiTransportu>\n        ' + tag('P_22N', '1') + '\n      </NoweSrodkiTransportu>\n'
    + '      ' + tag('P_23', '2') + '\n'
    + '      <PMarzy>\n        ' + tag('P_PMarzyN', '1') + '\n      </PMarzy>\n'
    + '    </Adnotacje>';

  /* Płatność: sekcja opcjonalna, ale bez niej klient nie wie, na jakie
     konto zapłacić i do kiedy. */
  let platnosc = '';
  const forma = KSEF_PAY[p.inv.method];
  if (forma || p.inv.due || p.inv.bank) {
    /* Schemat wiąże te dwa pola w parę: Zaplacono bez DataZaplaty to błąd
       walidacji, a nie drobiazg — cały plik przepada. Dlatego znacznik
       zapłaty wchodzi tylko wtedy, gdy znamy datę.
       Termin płatności przy fakturze już zapłaconej pomijamy: nie ma czego
       terminować, a schemat nie dopuszcza go po znaczniku zapłaty. */
    const oplacona = !!(p.inv.paid && p.inv.paidAt);
    platnosc = '\n    <Platnosc>\n'
      + (oplacona ? '      ' + tag('Zaplacono', '1') + '\n'
                  + '      ' + tag('DataZaplaty', p.inv.paidAt) + '\n' : '')
      + (!oplacona && p.inv.due ? '      <TerminPlatnosci>\n        ' + tag('Termin', p.inv.due) + '\n      </TerminPlatnosci>\n' : '')
      + (forma ? '      ' + tag('FormaPlatnosci', forma) + '\n' : '')
      + (p.inv.bank ? '      <RachunekBankowy>\n        ' + tag('NrRB', ksefEsc(String(p.inv.bank).replace(/\s/g, ''))) + '\n      </RachunekBankowy>\n' : '')
      + '    </Platnosc>';
  }

  return '<?xml version="1.0" encoding="UTF-8"?>\n'
    + '<Faktura xmlns="' + KSEF_NS + '">\n'
    + '  <Naglowek>\n'
    + '    <KodFormularza kodSystemowy="FA (3)" wersjaSchemy="1-0E">FA</KodFormularza>\n'
    + '    ' + tag('WariantFormularza', '3') + '\n'
    + '    ' + tag('DataWytworzeniaFa', ksefStamp(p.now)) + '\n'
    + '    ' + tag('SystemInfo', KSEF_SYSTEM) + '\n'
    + '  </Naglowek>\n'
    + '  <Podmiot1>\n'
    + '    <DaneIdentyfikacyjne>\n'
    + '      ' + tag('NIP', ksefNip(p.seller.nip)) + '\n'
    + '      ' + tag('Nazwa', ksefEsc(p.seller.name)) + '\n'
    + '    </DaneIdentyfikacyjne>\n'
    + '    <Adres>\n'
    + '      ' + tag('KodKraju', 'PL') + '\n'
    + '      ' + tag('AdresL1', ksefEsc(p.seller.addr1)) + '\n'
    + (p.seller.addr2 ? '      ' + tag('AdresL2', ksefEsc(p.seller.addr2)) + '\n' : '')
    + '    </Adres>\n'
    + '  </Podmiot1>\n'
    + '  <Podmiot2>\n'
    + '    <DaneIdentyfikacyjne>\n'
    + '  ' + buyerId + '\n'
    + (p.buyer.name ? '      ' + tag('Nazwa', ksefEsc(p.buyer.name)) + '\n' : '')
    + '    </DaneIdentyfikacyjne>'
    + podmiot2Adres.replace(/\n {2}/g, '\n    ') + '\n'
    /* JST i GV to obowiązkowe znaczniki: czy nabywca jest jednostką
       samorządu terytorialnego i czy jest członkiem grupy VAT.
       Wartość 2 znaczy „nie". */
    + '    ' + tag('JST', '2') + '\n'
    + '    ' + tag('GV', '2') + '\n'
    + '  </Podmiot2>\n'
    + '  <Fa>\n'
    + '    ' + tag('KodWaluty', 'PLN') + '\n'
    + '    ' + tag('P_1', p.inv.issue) + '\n'
    + '    ' + tag('P_2', ksefEsc(p.inv.number)) + '\n'
    + (p.inv.sale ? '    ' + tag('P_6', p.inv.sale) + '\n' : '')
    + sumy
    + '    ' + tag('P_15', ksefAmt(t.brutto)) + '\n'
    + adnotacje + '\n'
    + '    ' + tag('RodzajFaktury', 'VAT') + '\n'
    + p.lines.map((l, i) => ksefLine(l, i, p.stawka)).join('\n') + '\n'
    + (platnosc ? platnosc + '\n' : '')
    + '  </Fa>\n'
    + '</Faktura>\n';
}


