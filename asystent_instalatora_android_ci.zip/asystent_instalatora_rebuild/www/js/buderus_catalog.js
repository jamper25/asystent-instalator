/* ===== buderus_catalog.js =====
   Nowy, odseparowany moduł katalogu Buderus.
   Na tym etapie: warstwa danych i adapter do istniejącego modułu ofert.
   Interfejs użytkownika zostanie podłączony po stabilizacji odtworzonego APK.
*/
(function (root) {
  'use strict';

  const STORAGE_KEY = 'ai_buderus_catalog_v1';
  const SCHEMA_VERSION = 1;
  const CATEGORIES = [
    'kociol', 'zasobnik', 'regulator', 'modul', 'czujnik',
    'hydraulika', 'komin', 'akcesorium', 'czesc_zamienna', 'inne'
  ];
  const SOURCES = ['official', 'manual', 'import'];

  function storage() {
    try { return root.localStorage || null; } catch (_) { return null; }
  }

  function readState() {
    const s = storage();
    if (!s) return { schemaVersion: SCHEMA_VERSION, products: [] };
    try {
      const raw = s.getItem(STORAGE_KEY);
      if (!raw) return { schemaVersion: SCHEMA_VERSION, products: [] };
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        // Wsteczna obsługa wczesnego formatu listy produktów.
        return { schemaVersion: SCHEMA_VERSION, products: parsed };
      }
      if (!parsed || !Array.isArray(parsed.products)) {
        return { schemaVersion: SCHEMA_VERSION, products: [] };
      }
      return { schemaVersion: SCHEMA_VERSION, products: parsed.products };
    } catch (_) {
      return { schemaVersion: SCHEMA_VERSION, products: [] };
    }
  }

  function writeState(products) {
    const s = storage();
    if (!s) throw new Error('Pamięć lokalna jest niedostępna.');
    const payload = { schemaVersion: SCHEMA_VERSION, products: products };
    s.setItem(STORAGE_KEY, JSON.stringify(payload));
    return products;
  }

  function cleanText(value, max) {
    return String(value == null ? '' : value).trim().slice(0, max || 500);
  }

  function finiteOrNull(value) {
    if (value === '' || value == null) return null;
    const n = Number(String(value).replace(',', '.'));
    return Number.isFinite(n) ? n : null;
  }

  function normalize(product) {
    if (!product || typeof product !== 'object') {
      throw new Error('Produkt musi być obiektem.');
    }
    const sku = cleanText(product.sku, 80);
    const name = cleanText(product.name, 180);
    if (!sku) throw new Error('Symbol katalogowy Buderus jest wymagany.');
    if (!name) throw new Error('Nazwa produktu jest wymagana.');

    const pricesIn = product.prices || {};
    const vatRate = finiteOrNull(product.vatRate != null ? product.vatRate : pricesIn.vatRate);
    const prices = {
      catalogNet: finiteOrNull(pricesIn.catalogNet),
      purchaseNet: finiteOrNull(pricesIn.purchaseNet),
      purchaseDiscountPct: finiteOrNull(pricesIn.purchaseDiscountPct),
      saleNet: finiteOrNull(pricesIn.saleNet),
      vatRate: vatRate == null ? 0.23 : vatRate
    };
    for (const [key, value] of Object.entries(prices)) {
      if (value != null && value < 0) throw new Error('Ceny i rabaty nie mogą być ujemne: ' + key);
    }
    if (prices.purchaseDiscountPct != null && prices.purchaseDiscountPct > 100) {
      throw new Error('Rabat zakupowy nie może przekraczać 100%.');
    }
    if (prices.vatRate > 1) throw new Error('Stawka VAT musi być podana jako ułamek, np. 0.23.');
    const category = CATEGORIES.includes(product.category) ? product.category : 'inne';
    const source = SOURCES.includes(product.source) ? product.source : 'manual';

    return {
      id: cleanText(product.id, 120) || ('buderus-' + sku.replace(/[^a-zA-Z0-9_-]/g, '-')),
      manufacturer: 'Buderus',
      sku: sku,
      name: name,
      category: category,
      description: cleanText(product.description, 2000),
      technicalData: product.technicalData && typeof product.technicalData === 'object'
        ? product.technicalData : {},
      source: source,
      sourceReference: cleanText(product.sourceReference, 500),
      sourceDate: cleanText(product.sourceDate, 30),
      image: cleanText(product.image, 1000),
      documents: Array.isArray(product.documents) ? product.documents.map(x => cleanText(x, 1000)).filter(Boolean) : [],
      compatibility: Array.isArray(product.compatibility) ? product.compatibility.map(x => cleanText(x, 120)).filter(Boolean) : [],
      prices: prices,
      active: product.active !== false,
      priceHistory: Array.isArray(product.priceHistory) ? product.priceHistory : [],
      createdAt: cleanText(product.createdAt, 40) || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }

  function list(options) {
    const opts = options || {};
    let products = readState().products.slice();
    if (opts.activeOnly) products = products.filter(p => p.active !== false);
    if (opts.category) products = products.filter(p => p.category === opts.category);
    if (opts.query) {
      const q = String(opts.query).toLocaleLowerCase('pl-PL');
      products = products.filter(p =>
        [p.sku, p.name, p.description].join(' ').toLocaleLowerCase('pl-PL').includes(q)
      );
    }
    return products.sort((a, b) => String(a.name).localeCompare(String(b.name), 'pl'));
  }

  function get(id) {
    return readState().products.find(p => p.id === id) || null;
  }

  function getBySku(sku) {
    const target = cleanText(sku, 80).toLocaleLowerCase('pl-PL');
    return readState().products.find(p => String(p.sku).toLocaleLowerCase('pl-PL') === target) || null;
  }

  function upsert(input) {
    const product = normalize(input);
    const products = readState().products;
    const byId = products.findIndex(p => p.id === product.id);
    const bySku = products.findIndex(p => String(p.sku).toLocaleLowerCase('pl-PL') === product.sku.toLocaleLowerCase('pl-PL'));
    const index = byId >= 0 ? byId : bySku;
    if (index >= 0) {
      const old = products[index];
      product.id = old.id;
      product.createdAt = old.createdAt || product.createdAt;
      product.priceHistory = old.priceHistory || [];
      products[index] = product;
    } else {
      products.push(product);
    }
    writeState(products);
    return product;
  }

  function remove(id) {
    const products = readState().products;
    const index = products.findIndex(p => p.id === id);
    if (index < 0) return false;
    products.splice(index, 1);
    writeState(products);
    return true;
  }

  function setPrices(id, patch, reason) {
    const products = readState().products;
    const product = products.find(p => p.id === id);
    if (!product) throw new Error('Nie znaleziono produktu Buderus.');
    const next = normalize(Object.assign({}, product, {
      prices: Object.assign({}, product.prices, patch || {})
    }));
    // Historia cen zachowywana oddzielnie od bieżących pól produktu.
    const history = Array.isArray(product.priceHistory) ? product.priceHistory.slice() : [];
    history.push({
      changedAt: new Date().toISOString(),
      reason: cleanText(reason, 300),
      previous: Object.assign({}, product.prices),
      current: Object.assign({}, next.prices)
    });
    next.priceHistory = history;
    const index = products.findIndex(p => p.id === id);
    products[index] = next;
    writeState(products);
    return next;
  }

  function gross(net, vatRate) {
    const n = finiteOrNull(net);
    const v = finiteOrNull(vatRate);
    if (n == null || v == null) return null;
    return Math.round((n * (1 + v) + Number.EPSILON) * 100) / 100;
  }

  function toOfferItem(productOrId) {
    const p = typeof productOrId === 'string' ? get(productOrId) : productOrId;
    if (!p) throw new Error('Nie znaleziono produktu Buderus.');
    if (p.prices.saleNet == null) throw new Error('Uzupełnij cenę sprzedaży netto produktu.');
    return {
      name: p.name,
      unit: 'szt',
      cat: 'mat',
      price: p.prices.saleNet,
      tag: 'buderus',
      katId: p.id,
      qty: 1,
      manufacturer: 'Buderus',
      sku: p.sku,
      vatRate: p.prices.vatRate
    };
  }

  function exportJSON() {
    return JSON.stringify({ schemaVersion: SCHEMA_VERSION, exportedAt: new Date().toISOString(), products: list() }, null, 2);
  }

  const CSV_COLUMNS = [
    'sku', 'name', 'category', 'description', 'catalogNet', 'purchaseNet',
    'purchaseDiscountPct', 'saleNet', 'vatRate', 'source', 'sourceReference',
    'sourceDate', 'active', 'technicalData', 'compatibility', 'documents'
  ];

  function csvCell(value) {
    const text = String(value == null ? '' : value);
    return '"' + text.replace(/"/g, '""') + '"';
  }

  function csvNumber(value) {
    return value == null ? '' : String(value).replace('.', ',');
  }

  function exportCSV() {
    const rows = [CSV_COLUMNS.join(';')];
    list().forEach(function (p) {
      const values = {
        sku: p.sku, name: p.name, category: p.category, description: p.description,
        catalogNet: csvNumber(p.prices.catalogNet), purchaseNet: csvNumber(p.prices.purchaseNet),
        purchaseDiscountPct: csvNumber(p.prices.purchaseDiscountPct), saleNet: csvNumber(p.prices.saleNet),
        vatRate: csvNumber(p.prices.vatRate), source: p.source, sourceReference: p.sourceReference,
        sourceDate: p.sourceDate, active: p.active ? 'true' : 'false',
        technicalData: JSON.stringify(p.technicalData || {}),
        compatibility: (p.compatibility || []).join('|'), documents: (p.documents || []).join('|')
      };
      rows.push(CSV_COLUMNS.map(function (key) { return csvCell(values[key]); }).join(';'));
    });
    return '\uFEFF' + rows.join('\r\n');
  }

  function parseCSV(raw) {
    const input = String(raw || '').replace(/^\uFEFF/, '');
    const rows = [];
    let row = [], cell = '', quoted = false;
    for (let i = 0; i < input.length; i++) {
      const ch = input[i];
      if (quoted) {
        if (ch === '"' && input[i + 1] === '"') { cell += '"'; i++; }
        else if (ch === '"') quoted = false;
        else cell += ch;
      } else if (ch === '"') quoted = true;
      else if (ch === ';') { row.push(cell); cell = ''; }
      else if (ch === '\n' || ch === '\r') {
        if (ch === '\r' && input[i + 1] === '\n') i++;
        row.push(cell); cell = '';
        if (row.some(function (v) { return v !== ''; })) rows.push(row);
        row = [];
      } else cell += ch;
    }
    row.push(cell);
    if (row.some(function (v) { return v !== ''; })) rows.push(row);
    if (!rows.length) throw new Error('Plik CSV jest pusty.');
    const headers = rows.shift().map(function (h) { return h.trim(); });
    if (!headers.includes('sku') || !headers.includes('name')) {
      throw new Error('CSV musi zawierać kolumny sku oraz name.');
    }
    return rows.map(function (values) {
      const obj = {};
      headers.forEach(function (key, i) { obj[key] = values[i] == null ? '' : values[i]; });
      let technicalData = {};
      if (obj.technicalData) {
        try { technicalData = JSON.parse(obj.technicalData); }
        catch (_) { throw new Error('Nieprawidłowy JSON w kolumnie technicalData dla SKU ' + obj.sku + '.'); }
      }
      const split = function (v) { return String(v || '').split('|').map(function (x) { return x.trim(); }).filter(Boolean); };
      return {
        sku: obj.sku, name: obj.name, category: obj.category, description: obj.description,
        prices: {
          catalogNet: obj.catalogNet, purchaseNet: obj.purchaseNet,
          purchaseDiscountPct: obj.purchaseDiscountPct, saleNet: obj.saleNet, vatRate: obj.vatRate
        }, source: obj.source, sourceReference: obj.sourceReference, sourceDate: obj.sourceDate,
        active: String(obj.active).toLowerCase() !== 'false', technicalData: technicalData,
        compatibility: split(obj.compatibility), documents: split(obj.documents)
      };
    });
  }

  function importCSV(raw, options) {
    const incoming = parseCSV(raw);
    return importJSON({ products: incoming }, options);
  }

  function importJSON(raw, options) {
    const opts = options || {};
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    const incoming = Array.isArray(parsed) ? parsed : parsed && parsed.products;
    if (!Array.isArray(incoming)) throw new Error('Plik importu nie zawiera listy produktów.');
    const existing = opts.replace ? [] : readState().products.slice();
    const seen = new Set(existing.map(p => String(p.sku).toLowerCase()));
    for (const item of incoming) {
      const normalized = normalize(item);
      const key = normalized.sku.toLowerCase();
      if (seen.has(key)) {
        if (!opts.updateExisting) continue;
      }
      const idx = existing.findIndex(p => String(p.sku).toLowerCase() === key);
      if (idx >= 0) {
        normalized.id = existing[idx].id;
        normalized.createdAt = existing[idx].createdAt;
        normalized.priceHistory = existing[idx].priceHistory || [];
        existing[idx] = normalized;
      } else {
        existing.push(normalized);
        seen.add(key);
      }
    }
    writeState(existing);
    return { imported: incoming.length, stored: existing.length };
  }

  root.BuderusCatalog = Object.freeze({
    storageKey: STORAGE_KEY,
    schemaVersion: SCHEMA_VERSION,
    categories: CATEGORIES.slice(),
    sources: SOURCES.slice(),
    list: list,
    get: get,
    getBySku: getBySku,
    upsert: upsert,
    remove: remove,
    setPrices: setPrices,
    gross: gross,
    toOfferItem: toOfferItem,
    exportJSON: exportJSON,
    importJSON: importJSON,
    exportCSV: exportCSV,
    importCSV: importCSV
  });
})(typeof window !== 'undefined' ? window : globalThis);
