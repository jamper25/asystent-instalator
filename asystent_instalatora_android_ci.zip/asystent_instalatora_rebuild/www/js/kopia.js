/* ===== kopia.js ===== */
/* ============================================================
   KOPIA ZAPASOWA
   ------------------------------------------------------------
   Cała aplikacja działa bez internetu i wszystko trzyma w telefonie.
   To jest jej zaleta i jej jedyne poważne ryzyko: zgubiony telefon
   albo odinstalowana aplikacja zabiera ze sobą katalog cen budowany
   miesiącami i wszystkie wystawione faktury. Kopia to jeden plik,
   który można wysłać sobie mailem albo wrzucić na dysk — i z którego
   po zmianie telefonu wszystko wraca.

   Plik jest zwykłym tekstem w formacie JSON i celowo trzyma dane
   dokładnie tak, jak leżą w telefonie: bez przerabiania, bez
   „porządkowania". Dzięki temu odtworzenie jest zwykłym przepisaniem
   z powrotem i nie ma miejsca, w którym coś mogłoby się po drodze
   zgubić albo zmienić.

   Przy wczytywaniu nie podmieniamy wszystkiego w ciemno. Instalator
   widzi, co jest w pliku, i zaznacza, które części wziąć — bo typowy
   przypadek to nie awaria, tylko przeniesienie samego katalogu cen
   z jednego telefonu na drugi, bez ruszania ofert.
   ============================================================ */

Object.assign(ICO, {
  save: '<path d="M5 3.5h10.5L20.5 8.5V19a1.5 1.5 0 0 1-1.5 1.5H5A1.5 1.5 0 0 1 3.5 19V5A1.5 1.5 0 0 1 5 3.5z"/>'
      + '<path d="M7.5 3.5v5h7v-5M7.5 20.5v-6h9v6"/>',
});

const KOPIA_WERSJA = 1;
const KOPIA_META = 'ai_kopia_v1';

/* Co wchodzi do kopii. Grupa to jedna pozycja na liście wyboru przy
   wczytywaniu, więc dzielimy tak, jak instalator myśli o swoich danych,
   a nie tak, jak leżą klucze w pamięci: ceny i pozycje własne to dla
   niego jeden „katalog", choć w telefonie są dwoma wpisami. */
const KOPIA_GRUPY = [
  { id: 'firma', ikona: 'building', nazwa: 'Dane firmy',
    klucze: ['ai_ustawienia_v1'],
    opis(d) {
      const s = kopiaJson(d['ai_ustawienia_v1']);
      if (!s) return 'brak';
      const nazwa = s.company ? s.company : 'bez nazwy';
      return nazwa + (s.logo ? ' · z logo' : ' · bez logo');
    } },
  { id: 'katalog', ikona: 'tag', nazwa: 'Katalog cen',
    klucze: ['ai_ceny_v1', 'ai_katalog_v1'],
    opis(d) {
      const ceny = kopiaJson(d['ai_ceny_v1']) || {};
      const wlasne = kopiaJson(d['ai_katalog_v1']) || [];
      const ile = Object.keys(ceny).length;
      const w = Array.isArray(wlasne) ? wlasne.length : 0;
      if (!ile && !w) return 'brak zmienionych cen';
      return `${ile} ${odmiana(ile, 'zmieniona cena', 'zmienione ceny', 'zmienionych cen')}`
        + (w ? ` · ${w} ${odmiana(w, 'pozycja własna', 'pozycje własne', 'pozycji własnych')}` : '');
    } },
  { id: 'oferty', ikona: 'doc', nazwa: 'Oferty i faktury',
    klucze: ['ai_oferty_v1'],
    opis(d) {
      const l = kopiaJson(d['ai_oferty_v1']);
      if (!Array.isArray(l) || !l.length) return 'brak';
      const f = l.filter(o => o && o.faktura).length;
      return `${l.length} ${odmiana(l.length, 'dokument', 'dokumenty', 'dokumentów')}`
        + (f ? ` · w tym ${f} ${odmiana(f, 'faktura', 'faktury', 'faktur')}` : '');
    } },
  { id: 'projekty', ikona: 'kotlownia', nazwa: 'Projekty kotłowni',
    klucze: ['ai_projekty_v1'],
    opis(d) {
      const l = kopiaJson(d['ai_projekty_v1']);
      if (!Array.isArray(l) || !l.length) return 'brak';
      return `${l.length} ${odmiana(l.length, 'projekt', 'projekty', 'projektów')}`;
    } },
  { id: 'notatki', ikona: 'pen', nazwa: 'Notatnik (bez zdjęć)',
    klucze: ['ai_notatki_v1'],
    opis(d) {
      const l = kopiaJson(d['ai_notatki_v1']);
      if (!Array.isArray(l) || !l.length) return 'brak';
      return `${l.length} ${odmiana(l.length, 'notatka', 'notatki', 'notatek')} · zdjęcia zostają tylko w telefonie`;
    } },
  { id: 'klienci', ikona: 'user', nazwa: 'Baza klientów',
    klucze: ['ai_klienci_v1'],
    opis(d) {
      const l = kopiaJson(d['ai_klienci_v1']);
      if (!Array.isArray(l) || !l.length) return 'brak';
      const firm = l.filter(k => k && k.type === 'firma').length;
      return `${l.length} ${odmiana(l.length, 'klient', 'klientów', 'klientów')}`
        + (firm ? ` · w tym ${firm} ${odmiana(firm, 'firma', 'firmy', 'firm')}` : '');
    } },
  { id: 'sprzedaz', ikona: 'doc', nazwa: 'Sprzedaż i rozliczenia',
    klucze: ['ai_sales_register_v1'],
    opis(d) {
      const l = kopiaJson(d['ai_sales_register_v1']);
      if (!Array.isArray(l) || !l.length) return 'brak wpisów sprzedaży';
      const unpaid = l.filter(x => Number(x.gross||0) > Number(x.paid||0)).length;
      return `${l.length} ${odmiana(l.length, 'wpis sprzedaży', 'wpisy sprzedaży', 'wpisów sprzedaży')}`
        + (unpaid ? ` · ${unpaid} z nierozliczoną kwotą` : '');
    } },
  { id: 'magazyn', ikona: 'building', nazwa: 'Magazyn i ruchy',
    klucze: ['ai_inventory_items_v1', 'ai_inventory_moves_v1'],
    opis(d) {
      const items = kopiaJson(d['ai_inventory_items_v1']);
      const moves = kopiaJson(d['ai_inventory_moves_v1']);
      const n = Array.isArray(items) ? items.length : 0;
      const m = Array.isArray(moves) ? moves.length : 0;
      return `${n} kart towarów · ${m} ruchów magazynowych`;
    } },
  { id: 'zakupy', ikona: 'doc', nazwa: 'Dokumenty zakupowe',
    klucze: ['ai_purchase_docs_v1'],
    opis(d) {
      const l = kopiaJson(d['ai_purchase_docs_v1']);
      if (!Array.isArray(l) || !l.length) return 'brak dokumentów';
      const attachments = l.filter(x => x && x.attachment && x.attachment.data).length;
      const payments = l.reduce((n,x) => n + (Array.isArray(x.payments) ? x.payments.length : 0), 0);
      return `${l.length} dokumentów · ${payments} wpłat`
        + (attachments ? ` · ${attachments} załączników` : '');
    } },
  { id: 'kalkulatory', ikona: 'calc', nazwa: 'Stan kalkulatorów',
    klucze: ['ai_kalkulatory_v1'],
    opis(d) {
      const v = kopiaJson(d['ai_kalkulatory_v1']);
      if (!v || typeof v !== 'object') return 'brak';
      const n = Object.keys(v).length;
      return n ? `${n} ${odmiana(n, 'zapisany kalkulator', 'zapisane kalkulatory', 'zapisanych kalkulatorów')}`
               : 'nic nie policzone';
    } },
];

function kopiaJson(raw) {
  if (!raw) return null;
  try { return JSON.parse(raw); } catch (e) { return null; }
}

/* Stan ekranu kopii. `plik` pojawia się dopiero po wczytaniu pliku
   z dysku i znika po wczytaniu albo anulowaniu — nie zapisujemy go
   nigdzie, bo to jest decyzja na jedną chwilę, a nie dane. */
state.kopia = { plik: null, blad: null, wybrane: {}, zajety: false };
state.kopiaCofnij = null;

/* ------------------------------------------------------------
   ZAPIS
   ------------------------------------------------------------ */

function zbierzKopie() {
  const dane = {};
  KOPIA_GRUPY.forEach(g => g.klucze.forEach(k => {
    let v = null;
    try { v = localStorage.getItem(k); } catch (e) { /* zablokowana pamięć */ }
    if (v !== null) dane[k] = v;
  }));
  return {
    aplikacja: 'Asystent Instalatora',
    wersjaAplikacji: typeof APP_WERSJA === 'string' ? APP_WERSJA : '',
    kopiaWersja: KOPIA_WERSJA,
    data: new Date().toISOString(),
    dane,
  };
}

function nazwaPlikuKopii(d) {
  const t = d instanceof Date ? d : new Date();
  const dwa = n => String(n).padStart(2, '0');
  return `asystent-kopia-${t.getFullYear()}-${dwa(t.getMonth() + 1)}-${dwa(t.getDate())}.json`;
}

/* Data ostatniej kopii. Trzymamy ją osobno od samej kopii, żeby ekran
   mógł powiedzieć „ostatnia dwa tygodnie temu" bez wczytywania pliku. */
function ostatniaKopia() {
  const m = kopiaJson((() => { try { return localStorage.getItem(KOPIA_META); } catch (e) { return null; } })());
  return m && m.kiedy ? m.kiedy : null;
}
function zapiszDateKopii(iso) {
  try { localStorage.setItem(KOPIA_META, JSON.stringify({ kiedy: iso })); } catch (e) { /* trudno */ }
}

function kopiaZdjeciaOtworz() {
  return new Promise((ok, fail) => {
    const req=indexedDB.open('asystent_zdjecia',1);
    req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains('zdj'))req.result.createObjectStore('zdj');};
    req.onsuccess=()=>ok(req.result); req.onerror=()=>fail(req.error||new Error('Nie można otworzyć bazy zdjęć.'));
  });
}
async function kopiaZdjeciaEksportuj() {
  const db=await kopiaZdjeciaOtworz();
  try {
    return await new Promise((ok,fail)=>{
      const tx=db.transaction('zdj','readonly'), store=tx.objectStore('zdj');
      const keysReq=store.getAllKeys(), valuesReq=store.getAll();
      tx.oncomplete=()=>ok(keysReq.result.map((key,i)=>({id:String(key),data:valuesReq.result[i]})));
      tx.onerror=()=>fail(tx.error||new Error('Nie udało się odczytać zdjęć.'));
    });
  } finally { db.close(); }
}
async function kopiaZdjeciaImportuj(entries) {
  if(!Array.isArray(entries)) throw new Error('Nieprawidłowa lista zdjęć w kopii.');
  const db=await kopiaZdjeciaOtworz();
  try {
    await new Promise((ok,fail)=>{
      const tx=db.transaction('zdj','readwrite'), store=tx.objectStore('zdj');
      store.clear(); entries.forEach(item=>{if(item&&typeof item.id==='string'&&item.data&&typeof item.data==='object')store.put(item.data,item.id);});
      tx.oncomplete=ok; tx.onerror=()=>fail(tx.error||new Error('Nie udało się przywrócić zdjęć.'));
    });
  } finally { db.close(); }
}
async function zrobKopie() {
  if (state.kopia.zajety) return;
  state.kopia.zajety = true; render(false);
  try {
    const paczka=zbierzKopie();
    paczka.zdjecia=await kopiaZdjeciaEksportuj();
    const tresc=JSON.stringify(paczka,null,1), nazwa=nazwaPlikuKopii(new Date(paczka.data));
    pobierzPlik(nazwa,tresc,'application/json',w=>{
      state.kopia.zajety=false;
      if(w&&w.ok){zapiszDateKopii(paczka.data);render(false);toast(w.gdzie?`Kopia zapisana w folderze ${w.gdzie}.`:'Kopia zapisana.');}
      else{render(false);toast((w&&w.powod)||'Nie udało się zapisać kopii.');}
    });
  } catch(err) { state.kopia.zajety=false; render(false); toast('Nie udało się dołączyć zdjęć do kopii: '+(err.message||'błąd bazy')); }
}

/* ------------------------------------------------------------
   WCZYTANIE
   ------------------------------------------------------------ */

/* Sprawdzamy plik, zanim cokolwiek ruszymy. Wybrany przez pomyłkę PDF
   albo faktura XML mają się skończyć zdaniem po polsku, a nie zniknięciem
   danych. */
function sprawdzKopie(tekst) {
  let o = null;
  try { o = JSON.parse(tekst); } catch (e) {
    return { blad: 'To nie jest plik kopii — nie da się go odczytać. Wybierz plik '
      + 'o nazwie zaczynającej się od „asystent-kopia".' };
  }
  if (!o || typeof o !== 'object' || !o.dane || typeof o.dane !== 'object') {
    return { blad: 'Ten plik nie zawiera kopii z tej aplikacji.' };
  }
  if (Number(o.kopiaWersja) > KOPIA_WERSJA) {
    return { blad: 'Kopia pochodzi z nowszej wersji aplikacji niż ta w telefonie. '
      + 'Zaktualizuj aplikację i spróbuj jeszcze raz.' };
  }
  const grupy = KOPIA_GRUPY.filter(g => g.klucze.some(k => o.dane[k] !== undefined));
  if (!grupy.length) return { blad: 'Plik jest pusty — nie ma w nim żadnych danych do wczytania.' };
  return { plik: o, grupy };
}

function otworzKopie(file) {
  const fr = new FileReader();
  fr.onerror = () => { state.kopia.blad = 'Nie udało się otworzyć pliku.'; render(false); };
  fr.onload = () => {
    const w = sprawdzKopie(String(fr.result || ''));
    if (w.blad) { state.kopia.plik = null; state.kopia.blad = w.blad; render(false); return; }
    state.kopia.blad = null;
    state.kopia.plik = w.plik;
    /* Domyślnie zaznaczone jest wszystko, co w pliku jest — to najczęstszy
       przypadek (nowy telefon), a odznaczyć jest łatwiej niż zaznaczać. */
    state.kopia.wybrane = {};
    w.grupy.forEach(g => { state.kopia.wybrane[g.id] = true; });
    render(false);
  };
  fr.readAsText(file);
}

function grupyWPliku(plik) {
  if (!plik) return [];
  return KOPIA_GRUPY.filter(g => g.klucze.some(k => plik.dane[k] !== undefined));
}

/* Przeładowanie tego, co aplikacja trzyma w pamięci. Bez tego ekran
   pokazywałby stare dane aż do zamknięcia aplikacji, choć w telefonie
   leżałyby już nowe. */
function przeladujZPamieci() {
  state.settings = loadSettings();
  state.catalog = loadCatalog();
  state.offers = loadOffers();
  state.klienci = loadKlienci();
  state.values = loadCalcValues();
  state.mode = {};
  if (typeof loadProjekty === 'function') state.projekty = loadProjekty();
  if (typeof loadNotatki === 'function') state.notatki = loadNotatki();
  try { state.salesRecords = JSON.parse(localStorage.getItem('ai_sales_register_v1') || '[]'); } catch (_) { state.salesRecords = []; }
  try { state.inventoryItems = JSON.parse(localStorage.getItem('ai_inventory_items_v1') || '[]'); } catch (_) { state.inventoryItems = []; }
  try { state.inventoryMoves = JSON.parse(localStorage.getItem('ai_inventory_moves_v1') || '[]'); } catch (_) { state.inventoryMoves = []; }
  try { state.purchaseDocs = JSON.parse(localStorage.getItem('ai_purchase_docs_v1') || '[]'); } catch (_) { state.purchaseDocs = []; }
}

async function wczytajKopie() {
  const plik = state.kopia.plik;
  if (!plik) return;
  const grupy = grupyWPliku(plik).filter(g => state.kopia.wybrane[g.id]);
  if (!grupy.length) { toast('Nic nie zaznaczone — wybierz, co wczytać.'); return; }

  /* Zanim cokolwiek nadpiszemy, odkładamy obecny stan tych samych kluczy.
     Wczytanie kopii to jedyna operacja w aplikacji, która potrafi skasować
     wszystko naraz, więc musi mieć drogę powrotną. */
  const przed = {};
  let zdjeciaPrzed = null;
  try { zdjeciaPrzed = await kopiaZdjeciaEksportuj(); } catch (_) { /* starsze urządzenie bez IndexedDB */ }
  grupy.forEach(g => g.klucze.forEach(k => {
    try { przed[k] = localStorage.getItem(k); } catch (e) { przed[k] = null; }
  }));

  let bledy = 0;
  grupy.forEach(g => g.klucze.forEach(k => {
    const v = plik.dane[k];
    try {
      if (v === undefined || v === null) localStorage.removeItem(k);
      else localStorage.setItem(k, v);
    } catch (e) { bledy++; }
  }));

  if (bledy) {
    toast('Pamięć telefonu odmówiła zapisu — część danych mogła się nie wczytać.');
  }
  if (Array.isArray(plik.zdjecia)) {
    try { await kopiaZdjeciaImportuj(plik.zdjecia); state.kopiaCofnijZdjecia=zdjeciaPrzed; }
    catch(err) {
      Object.keys(przed).forEach(k=>{try{if(przed[k]===null)localStorage.removeItem(k);else localStorage.setItem(k,przed[k]);}catch(_){}});
      toast('Nie udało się przywrócić zdjęć. Pozostawiono poprzednie dane aplikacji.'); return;
    }
  }
  state.kopiaCofnij = przed;
  state.kopia.plik = null;
  state.kopia.blad = null;
  przeladujZPamieci();
  render(false);
  const co = grupy.map(g => g.nazwa.toLowerCase()).join(', ');
  toast('Wczytano: ' + co + '.', 'Cofnij');
}

function cofnijWczytanie() {
  const przed = state.kopiaCofnij;
  if (!przed) return;
  Object.keys(przed).forEach(k => {
    try {
      if (przed[k] === null) localStorage.removeItem(k);
      else localStorage.setItem(k, przed[k]);
    } catch (e) { /* trudno */ }
  });
  state.kopiaCofnij = null;
  if(Array.isArray(state.kopiaCofnijZdjecia)){kopiaZdjeciaImportuj(state.kopiaCofnijZdjecia).catch(()=>{});state.kopiaCofnijZdjecia=null;}
  przeladujZPamieci();
  render(false);
  toast('Cofnięto — dane są takie jak przed wczytaniem.');
}

function anulujKopie() {
  state.kopia.plik = null;
  state.kopia.blad = null;
  render(false);
}

/* ------------------------------------------------------------
   EKRAN
   ------------------------------------------------------------ */

function dataPoPolsku(iso) {
  if (!iso) return null;
  const d = new Date(iso);
  if (isNaN(d)) return null;
  return d.toLocaleDateString('pl-PL', { day: 'numeric', month: 'long', year: 'numeric' })
    + ', ' + d.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' });
}

function renderKopia() {
  const teraz = zbierzKopie();
  const ost = ostatniaKopia();
  const plik = state.kopia.plik;

  const wiersz = (g, dane, zaznaczalny) => `<label class="kop-row${zaznaczalny ? ' kop-row--pick' : ''}">
      ${zaznaczalny ? `<input type="checkbox" data-kopgrp="${g.id}"${
        state.kopia.wybrane[g.id] ? ' checked' : ''}>` : `<span class="kop-i">${svg(g.ikona)}</span>`}
      <span class="kop-t"><strong>${esc(g.nazwa)}</strong><span>${esc(g.opis(dane))}</span></span>
    </label>`;

  const wPliku = grupyWPliku(plik);

  return `<header class="hdr hdr--cat" style="--c:var(--cat-water)"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" id="backset" aria-label="Wróć">${svg('back')}</button>
      <div><h1>Kopia zapasowa</h1><p>Jeden plik z całą zawartością telefonu</p></div></div></header>
    <div class="body">

      <div class="card"><div class="card-head">${svg('save')}Co jest teraz w telefonie</div>
        <div class="kop-list">
          ${KOPIA_GRUPY.map(g => wiersz(g, teraz.dane, false)).join('')}
        </div>
        <button class="jump" style="--c:var(--cat-water);margin-top:12px" data-kopzapisz${
          state.kopia.zajety ? ' disabled' : ''}>${svg('save')}${
          state.kopia.zajety ? 'Zapisywanie…' : 'Zapisz kopię do pliku'}</button>
        <p class="hint">${ost
          ? 'Ostatnia kopia: ' + esc(dataPoPolsku(ost) || ost) + '.'
          : 'Jeszcze nie robiłeś kopii.'}
          ${naTelefonie && naTelefonie()
            ? 'Plik trafia do folderu Dokumenty i od razu możesz go wysłać sobie mailem albo na dysk.'
            : 'Plik zapisze się tam, gdzie przeglądarka zapisuje pobrane pliki.'}</p>
      </div>

      ${plik ? `<div class="card"><div class="card-head">${svg('restore')}Wczytaj z pliku</div>
        <p class="hint" style="margin:0 0 10px">Kopia z <b>${esc(dataPoPolsku(plik.data) || 'nieznanej daty')}</b>.
          Zaznacz, co wziąć — reszta w telefonie zostanie bez zmian.</p>
        <div class="kop-list">
          ${wPliku.map(g => wiersz(g, plik.dane, true)).join('')}
        </div>
        <button class="jump" style="--c:var(--cat-water);margin-top:12px" data-kopwczytaj>${svg('restore')}Wczytaj zaznaczone</button>
        <button class="btn2" style="width:100%;margin-top:8px" data-kopanuluj>Nie wczytuj</button>
        <p class="hint">Zaznaczone części zostaną zastąpione tym, co jest w pliku.
          Zaraz po wczytaniu pasek na dole pozwala to cofnąć.</p>
      </div>`
      : `<div class="card"><div class="card-head">${svg('restore')}Wczytaj z pliku</div>
        ${state.kopia.blad ? `<div class="checks"><div class="checks-h">${svg('alert')}Nie ten plik</div>
          <ul><li>${svg('alert')}<span>${esc(state.kopia.blad)}</span></li></ul></div>` : ''}
        <label class="btn2 as-label" style="width:100%">${svg('restore')}Wybierz plik kopii
          <input type="file" accept="application/json,.json" id="s-kopia" hidden></label>
        <p class="hint">Najpierw pokażę, co jest w pliku i z kiedy pochodzi. Nic nie zmieni się
          bez Twojego potwierdzenia.</p>
      </div>`}

      <div class="tip">${svg('spark')}<div>Kopia obejmuje również sprzedaż, magazyn, ruchy magazynowe i dokumenty zakupowe wraz z załącznikami oraz historią wpłat. Zdjęcia notatek są dołączane z osobnej bazy aplikacji. Kopia to zwykły plik tekstowy — możesz go trzymać
        na dysku, w mailu do siebie albo na drugim telefonie. Nie ma w nim nic poza tym,
        co i tak jest w Twojej aplikacji, ale są w nim Twoje ceny i dane klientów,
        więc nie wysyłaj go komuś przypadkiem.</div></div>
    </div>`;
}

document.addEventListener('click', e => {
  if (e.target.closest('[data-kopzapisz]')) { zrobKopie(); return; }
  if (e.target.closest('[data-kopwczytaj]')) { wczytajKopie(); return; }
  if (e.target.closest('[data-kopanuluj]')) { anulujKopie(); return; }
});

document.addEventListener('change', e => {
  if (e.target.id === 's-kopia' && e.target.files && e.target.files[0]) {
    otworzKopie(e.target.files[0]);
    e.target.value = '';
    return;
  }
  const g = e.target.dataset && e.target.dataset.kopgrp;
  if (g) { state.kopia.wybrane[g] = e.target.checked; }
});


