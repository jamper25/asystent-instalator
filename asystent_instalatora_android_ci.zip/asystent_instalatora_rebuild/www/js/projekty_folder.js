/* ===== projekty_folder.js ===== */
/* ============================================================
   EKRANY PROJEKTU I POŁĄCZENIE Z KALKULATORAMI
   ============================================================ */
const projNazwa = id => { const p = state.projekty.find(x => x.id === id); return p ? p.nazwa : ''; };
const projOferty = p => state.offers.filter(o => o && o.projektId === p.id);

function projektySekcjaHtml() {
  const l = state.projekty;
  return `<button class="jump" style="--c:#2E7D5B;margin-top:8px" data-projnowy>${svg('plus')}Nowy projekt</button>
    <div class="sechead">${svg('kotlownia')}Projekty<span>${l.length}</span></div>
    ${l.length ? `<div class="olist">${l.map(p => {
      return `<div class="orow"><button class="ocard" data-projotworz="${p.id}">
        <span class="ocard-n proj-ikona">${svg('kotlownia')}</span>
        <span class="ocard-t"><strong>${esc(p.nazwa || 'Projekt bez nazwy')}</strong>
          <span>${esc(p.klient && p.klient.name ? p.klient.name + ' · ' : '')}${esc(projOpis(p))}<br>zmieniony ${plDate(p.zm)}</span></span>
      </button></div>`; }).join('')}</div>`
      : '<p class="empty">Nie ma jeszcze projektów. Projekt to teczka jednej budowy: podłogówka, grzejniki, schemat kotłowni, a do tego oferty i faktury. Zacznij od „Nowy projekt” albo przenieś wynik guzikiem „Przenieś do projektu” pod kalkulatorem.</p>'}`;
}

/* Najważniejsze liczby kotłowni w projekcie — z doboru, jak w kreatorze:
   źródło, każdy obieg (moc, pompa, mieszacz), bufor/sprzęgło, rozdzielacz,
   naczynia, rury i łączna długość rury pętli podłogówki. */
/* Rura od źródła (z pionem) i parametry pracy obiegu — z kalkulatora,
   z którego obieg przyszedł. */
const PROJ_MAT = { copper: 'Cu', steel: 'stal', press: 'stal press', multi: 'PE-X/Al', pp20: 'PP', pp16: 'PP' };
function projRegTekst(v) {
  const reg = Number(v.reg);
  if (reg === -1) return 'Δt ' + fmt(Number(v.dt) || 0, 0) + ' K';
  const r = REGIMES_CO[reg] || REGIMES_CO[1];
  return r[0] + ' (Δt ' + r[1] + ' K)';
}
function projObiegZrodlo(p, o) {
  if (!o || !o.zP || !p.czesci[o.zP]) return '';
  const cw = projCzWartosci(p, o.zP), v = cw.v, t = [];
  if (o.rk && o.rk.p) t.push('rura od źródła ' + (PROJ_MAT[o.rk.mat] || '') + ' ' + String(o.rk.p).replace(/x/g, '×').replace(/\.(\d)/g, ',$1')
    + (o.dl ? ' · ' + fmt(o.dl, 0) + ' m z pionem' : ''));
  else if (o.dl) t.push('rura od źródła ' + fmt(o.dl, 0) + ' m z pionem');
  if (projTyp(o.zP) === 'grz') t.push('parametry ' + projRegTekst(v));
  else {
    const d = (DT_PODLOGOWKA[Number(v.dtp)] || DT_PODLOGOWKA[0]);
    const podl = d[0].split('·').pop().trim() + ' (Δt ' + d[1] + ' K)';
    t.push(v.mie === 'nisko' ? 'parametry ' + podl : 'podłoga ' + podl + ', kocioł ' + projRegTekst(v));
  }
  return t.join(' · ');
}
/* Pompy do ręcznego doboru — lista z projektu. */
function projPompyLista(p) {
  const v = projCzWartosci(p, 'kot').v, k = ktKonfig(v), D = ktDobor(k);
  if (!D) return [];
  const l = [];
  k.obiegi.forEach((ob, i) => {
    const pp = D.pompy[i]; if (!pp) return;
    const nz = k.nazwyOb[i] || {};
    l.push({ r: 'ob', i, nazwa: (ob[0] === 'g' ? 'Grzejniki' : 'Podłogówka') + (nz.nazwa ? ' — ' + nz.nazwa : nz.nr ? ' ' + nz.nr : ''), pp, zP: (v.ob[i] || {}).zP, podl: ob[0] === 'p' });
  });
  (D.pompyZr || []).forEach(pp => {
    const r = /cyrkulacyjna/.test(pp.nazwa) ? 'cyrk' : /ładująca/.test(pp.nazwa) ? 'cwu' : 'kotl';
    l.push({ r, i: 0, nazwa: pp.nazwa, pp });
  });
  if (k.cyrk && !l.some(x => x.r === 'cyrk')) l.push({ r: 'cyrk', i: 0, nazwa: 'Pompa cyrkulacyjna', pp: null });
  return l;
}
function projPompyHtml(p) {
  const l = projPompyLista(p);
  const opis = pp => !pp ? 'jeszcze niedobrana' : pp.kl === 'cyrkulacyjna' ? (pp.zKalk ? 'dobrana z kalkulatora' : 'szacunek') : pp.kl + ' · ' + fmt(pp.H, 1) + ' m · ' + (pp.zKalk ? 'dobrana z kalkulatora' : 'szacunek');
  return `<div class="sheet" data-closepompy role="dialog" aria-label="Którą pompę dobrać">
    <div class="sheet-in" data-stop>
      <div class="sheet-h">${svg('gauge')}<strong>Którą pompę dobrać?</strong>
        <button class="item-x" data-closepompy aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        <p class="hint" style="margin:0 0 10px">Otworzę kalkulator „Dobór pompy” z wpisaną mocą i temperaturami. Po „Zapisz pompę w schemacie” wynik trafi do projektu.</p>
        ${l.map((x, j) => `<button class="ocard" data-projpompa="${j}" style="margin-bottom:8px;width:100%">
          <span class="ocard-t"><strong>${esc(x.nazwa)}</strong><span>${esc(opis(x.pp))}${x.podl ? ' · liczy kalkulator podłogówki' : ''}</span></span></button>`).join('')}
      </div></div></div>`;
}

/* Wyniki kreatora kotłowni (te z kolorowych kart w edycji) policzone dla
   projektu: bez paska projektu, bez zapisu i bez ruszania stanu kreatora. */
function projKotWyniki(v) {
  const kot = ktKalk(), mode = activeMode(kot), zap = { r: state.ktRys, p: state.ktPompa };
  try { return mode.compute(Object.assign(projKopia(v), { _zProjektu: true })).results || []; }
  catch (e) { return []; }
  finally { state.ktRys = zap.r; state.ktPompa = zap.p; }
}
function projKotWynikiHtml(v, p) {
  let k, D;
  try { k = ktKonfig(v); D = ktDobor(k); } catch (e) { return ''; }
  const cale = s => String(s).replace(/^DN\d+ \((.+)\)$/, '$1');
  // 1) opisy z kreatora: krótkie w całości, długie — dwie linie i strzałka „rozwiń”
  const lw = projKotWyniki(v);
  /* Rozdzielacz w kotłowni — razem z układem kotłowni, za sprzęgłem/buforem. */
  if (D && k.obiegi.length > 1 && k.grp !== 'szaf') {
    let po = -1;
    lw.forEach((r, i) => { if (/Moc|Sprzęgło|ufor/.test(r.label)) po = i; });
    const ko = D.korpusRoz;
    lw.splice(po + 1, 0, { label: 'Rozdzielacz w kotłowni', value: cale(D.dnRoz[1]), unit: 'przyłącze · ' + k.obiegi.length + ' obiegi',
      foot: 'Przyłącze ' + D.dnRoz[1] + ' · ' + k.obiegi.length + ' obiegi · ' + fmt(D.qIn1, 2) + ' m³/h · korpus spawany ' + ko[1] + ' (Ø' + String(ko[2]).replace('.', ',') + ' mm).'
        + '\nW przyłącze wchodzi rura od ' + (k.rozdz === 'buf' ? 'bufora' : k.rozdz === 'sprz' ? 'sprzęgła' : k.rozdz === 'wym' ? 'wymiennika' : 'kotła')
        + ', a każdy obieg wychodzi z belki z własną grupą pompową. Gotowy rozdzielacz dobierz na ten przepływ i liczbę obiegów. Spawany z rury ma mieć korpus ' + ko[1] + ', żeby woda płynęła w nim wolno (do 0,3 m/s) i każdy obieg miał to samo ciśnienie na odejściu.' });
  }
  const wyn = lw.map(r => {
    const wart = esc(r.value) + (r.unit ? ' <small>' + esc(r.unit) + '</small>' : '');
    const dobierz = r.label === 'Pompy' && p ? ' <button class="proj-dobierz" type="button" data-projpompy>dobierz ręcznie</button>' : '';
    return '<div class="proj-wyn"><div class="proj-wyn-h"><span>' + esc(r.label) + dobierz + '</span><b>' + wart + '</b></div>'
      + (r.foot ? stopkaWyniku('proj-kot', r) : '') + '</div>';
  }).join('');
  if (!D) return wyn ? '<div class="proj-wyniki">' + wyn + '</div>' : '';
  // 2) obiegi, rozdzielacz, rury i rura pętli — tego nie ma w kartach kreatora
  const R = [], sek = t => R.push([t]);
  sek('Obiegi');
  k.obiegi.forEach((ob, i) => {
    const nz = k.nazwyOb[i] || {};
    const n = (ob[0] === 'g' ? 'Grzejniki' : 'Podłogówka') + (nz.nazwa ? ' — ' + nz.nazwa : nz.nr ? ' ' + nz.nr : '');
    const pp = D.pompy[i], z = D.zawory[i];
    const zr = p ? projObiegZrodlo(p, (v.ob || [])[i]) : '';
    R.push([n, 'ob', fmt(k.kw[i] || 0, 1) + ' kW'
      + (pp ? ' · pompa ' + pp.kl + (pp.szac ? ' (szac.)' : '') : D.maPompy ? '' : ' · pompa źródła')
      + (z ? ' · Kvs ' + String(z.kvs).replace('.', ',') + ' ' + z.pick.dn.replace(' ', '') : '')
      + (k.rozd && k.rozd[i] ? ' · rozdzielacz ' + cale(ktKorpusDN(k.rozd[i].korpus)) + (k.rozd[i].wyj ? ' / ' + k.rozd[i].wyj + ' obw.' : '') : ''), zr]);
  });
  R.push(['Razem', fmt(D.qco, 1) + ' kW · ' + fmt(D.qIn1, 2) + ' m³/h']);
  // średnice rur w kotłowni są opisane na schemacie
  if (p && projCzesciTypu(p, 'podl').length) {
    let m = 0, petle = 0, ile = 0; const rozm = [];
    projCzesciTypu(p, 'podl').forEach(c => (projCzWartosci(p, c).v.rozdz || []).filter(r => Number(r.w) > 0).forEach(r => {
      ile++; petle += Number(r.wyj) || 0; m += Number(r.metrow) || 0;
      (r.rury || []).forEach(x => { if (rozm.indexOf(x) < 0) rozm.push(x); });
    }));
    sek('Podłogówka');
    R.push(['Rozdzielacze', String(ile)]);
    R.push(['Pętle — razem', String(petle)]);
    R.push(['Rura pętli — razem', m > 0 ? fmt(m, 0) + ' m' + (rozm.length ? ' · ' + rozm.join(', ') : '') : 'policz pętle w kalkulatorze']);
  }
  return '<div class="proj-wyniki">' + wyn + '</div>'
    + '<div class="rows" style="margin-top:10px">' + R.map(r => r.length === 1
    ? '<div class="r proj-sek"><span>' + esc(r[0]) + '</span></div>'
    : r[1] === 'ob' ? '<div class="r proj-ob"><span>' + esc(r[0]) + '</span><b>' + esc(r[2]) + '</b>' + (r[3] ? '<em>' + esc(r[3]) + '</em>' : '') + '</div>'
    : '<div class="r"><span>' + esc(r[0]) + '</span><b>' + esc(r[1]) + '</b></div>').join('') + '</div>';
}

/* Karta jednej części projektu. */
function projCzescHtml(p, cz) {
  const c = cz.c;
  if (!p.czesci[c]) {
    return `<div class="card proj-cz proj-cz--pusta"><div class="card-head">${svg(cz.ikona)}${esc(cz.nazwa)}</div>
      <p class="hint" style="margin:0 2px 10px">Tej części jeszcze nie ma w projekcie.</p>
      <div class="proj-btny" style="margin:0">
        <button class="btn2" data-czdodaj="${c}">${svg('plus')}Zacznij od zera</button>
        <button class="btn2" data-czzkalk="${c}">${svg('arrow')}Weź z kalkulatora</button>
      </div></div>`;
  }
  const w = projCzWynik(p, c);
  let srodek = '', rysBtn = '';
  if (c === 'kot') {
    try {
      const s = ktSchemat(ktKonfig(w.v));
      // pełny rysunek do powiększenia — bez dotykania pomp i obiegów (to tylko podgląd)
      PROJ_KT_RYS = s.rys.replace(/ data-kt(pompa|klik)="[^"]*"/g, '').replace(/cursor:pointer/g, '');
      srodek = `<div class="sch-plot kt-plot kt-plot--mini" data-projktfull role="button" aria-label="Powiększ schemat" style="cursor:zoom-in">${s.rys.replace(/viewBox="0 0 ([\d.]+) ([\d.]+)" width="(\d+)" height="(\d+)"/, (_, x) => `viewBox="0 0 ${x} ${s.H0}"`)}</div>`;
    } catch (e) { srodek = ''; }
    rysBtn = `<button class="btn2" data-czpdf>${svg('doc')}PDF</button>`;
    // obiegi z pozostałych części projektu — jednym dotknięciem do schematu
    const zCzesci = ['grz', 'podl'].map(t => {
      const kw = projCzesciTypu(p, t).reduce((a, x) => { const cw = projCzWartosci(p, x); return a + ktZKalkulatora(cw.calc.id, cw.v, cw.mode.key).reduce((s2, o) => s2 + o.kw, 0); }, 0);
      return kw > 0 ? (t === 'grz' ? 'grzejniki ' : 'podłogówka ') + fmt(kw, 1) + ' kW' : '';
    }).filter(Boolean);
    srodek += projKotWynikiHtml(w.v, p);
    if (zCzesci.length) srodek += `<p class="hint" style="margin:8px 2px 0">Obiegi z projektu: ${esc(zCzesci.join(', '))} — schemat aktualizuje się sam.</p>`;
    else srodek += `<p class="hint" style="margin:8px 2px 0">Obiegi dojdą z kalkulatorów: policz grzejniki albo podłogówkę i kliknij pod wynikiem „Przenieś do projektu”.</p>`;
  } else if (w.res.error) {
    srodek = `<div class="tip tip--warn" style="margin:0">${svg('shield')}<div>${esc(w.res.error)}</div></div>`;
  } else {
    srodek = '<div class="rows">' + (w.res.results || []).map(r => '<div class="r"><span>' + esc(r.label) + '</span><b>'
      + esc(r.value) + (r.unit ? ' ' + esc(r.unit) : '') + '</b></div>').join('') + '</div>';
    if (w.res.schemat || (w.res.schematy || []).length) rysBtn = `<button class="btn2" data-czrys="${c}">${svg('list')}Rysunek i PDF</button>`;
  }
  return `<div class="card proj-cz"><div class="card-head">${svg(cz.ikona)}${esc(cz.nazwa)}</div>
    <p class="hint" style="margin:0 2px 8px">${esc(projOpisCz(p, c))}</p>
    ${srodek}
    <div class="proj-btny" style="margin:10px 0 0">
      <button class="btn2 proj-zapisz" data-czedytuj="${c}">${svg('pen')}Edytuj</button>
      ${rysBtn}
      <button class="btn2 proj-czusun" data-czusun="${c}">${svg('trash')}Usuń</button>
    </div>
    ${projZestHtml(p, c)}
  </div>`;
}

/* Projekt nie trzyma ofert u siebie — oferty i faktury są w Biurze, na
   jednej liście ze wszystkimi. Tu zostaje tylko przekazanie zaznaczonych
   pozycji do wybranej oferty albo do nowej. */
function projOfertyHtml(p) {
  const zazn = projZaznaczoneWszystkie(p);
  return `<div class="card proj-ofe"><div class="card-head">${svg('money')}Do oferty</div>
    <p class="hint" style="margin:0 2px" data-sumaall>Zaznaczone we wszystkich częściach: ${zazn.length} poz. · razem netto ${zl(projSuma(zazn))}</p>
    <button class="jump" style="--c:#2E7D5B;margin-top:10px" data-projdooferty>${svg('plus')}Dodaj zaznaczone do oferty</button>
  </div>`;
}

/* Przebudowa projektu: na razie widać tylko dane projektu i klienta.
   Części (podłogówka, grzejniki, kotłownia) i „Do oferty” wrócą w nowym układzie. */
const PROJ_POKAZ_CZESCI = false;
function renderProjekt() {
  const p = currentProjekt();
  if (!p) { state.offerScreen = 'list'; return renderOffersList(); }
  if (projSyncKot(p, 'grz') | projSyncKot(p, 'podl')) persistProj();
  const kl = p.klient || {};
  return `<header class="hdr hdr--cat" style="--c:#2E7D5B"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" data-projwroc aria-label="Wróć">${svg('back')}</button>
      <div><h1>${esc(p.nazwa || 'Projekt')}</h1><p>${esc(kl.name ? kl.name + ' · ' : '')}zmieniony ${plDate(p.zm)}</p></div></div></header>
    <div class="body">
      <details class="card proj-dane" open>
        <summary class="card-head">${svg('user')}Dane projektu i klient${svg('chevDown')}</summary>
        <div class="fields" style="margin-top:10px">
        <div class="field"><label for="pr-n">Nazwa projektu</label>
          <input id="pr-n" type="text" autocapitalize="sentences" data-projpole="nazwa" value="${esc(p.nazwa || '')}"></div>
        <div class="field"><label for="pr-a">Adres budowy</label>
          <input id="pr-a" type="text" autocapitalize="words" data-projpole="adres" value="${esc(p.adres || '')}"></div>
        <div class="field"><label for="pr-k">Klient</label>
          <input id="pr-k" type="text" autocapitalize="words" data-projklient="name" value="${esc(kl.name || '')}" placeholder="imię i nazwisko albo firma"></div>
        ${state.klienci.length ? `<div class="field"><label for="pr-kb">…albo wybierz z bazy</label>
          <select id="pr-kb" data-projzbazy><option value="">— z bazy klientów —</option>${klienciPosortowane(state.klienci)
            .map(x => `<option value="${esc(x.id)}">${esc(x.name || 'bez nazwy')}</option>`).join('')}</select>
          <span class="chev">${svg('chevDown')}</span></div>` : ''}
        <div class="field"><label for="pr-t">Telefon klienta</label>
          <input id="pr-t" type="text" inputmode="tel" data-projklient="phone" value="${esc(kl.phone || '')}"></div>
        <div class="mini grow"><label for="pr-u">Notatki</label>
          <textarea id="pr-u" rows="2" data-projpole="notatki" placeholder="np. kotłownia w piwnicy, rozdzielacze w szafkach na piętrach">${esc(p.notatki || '')}</textarea></div>
      </div></details>

      ${PROJ_POKAZ_CZESCI ? PROJ_CZESCI.map(b => { const l = projCzesciTypu(p, b.c); return l.length ? l.map(c => projCzescHtml(p, projCz(c))).join('') : projCzescHtml(p, b); }).join('') + projOfertyHtml(p) : projCzescHtml(p, projCz('kot'))
        + ['grz', 'podl'].reduce((a, t) => a + projCzesciTypu(p, t).map(c => projCzescHtml(p, projCz(c))).join(''), '')
        + (projCzesciWszystkie(p).length ? projOfertyHtml(p) : '')}

      <button class="btn2 proj-usun" style="width:100%" data-projusun>${svg('trash')}Usuń projekt</button>
    </div>`;
}

/* --- pod kalkulatorem: pasek połączenia albo „Przenieś do projektu” --- */
function projPrzenies(calcId, p, c, nowy) {
  const calc = CALCS.find(k => k.id === calcId), mode = activeMode(calc);
  const bylo = !!p.czesci[c];
  projUstawCzesc(p, c, mode.key, getValues(calc, mode));
  state.projWybor = null; state.projWyborP = null;
  render(false);
  toast((bylo ? 'Zastąpiono „' : nowy ? 'Dodano nowy obieg „' : 'Dodano „') + projCz(c).nazwa + '” w projekcie „' + p.nazwa + '”.'
    + (p.czesci.kot ? ' Schemat kotłowni przeliczył się sam.' : '')
    + ' Żeby coś zmienić, przelicz w kalkulatorze i przenieś jeszcze raz („Zastąp”).');
}
/* Dwa kroki: najpierw projekt (projekty zakłada się w kreatorze kotłowni),
   potem — jeśli projekt ma już taki obieg — nowy obieg czy zastąpienie. */
function projWyborHtml(calcId) {
  const cz = projCzCalc(calcId);
  const p = state.projWyborP ? state.projekty.find(x => x.id === state.projWyborP) : null;
  if (p) {
    const jest = projCzesciTypu(p, cz.c);
    return `<div class="proj-wybor">
      <p class="hint" style="margin:0 2px 8px">Projekt <b>${esc(p.nazwa)}</b> ma już ${jest.length === 1 ? 'taki obieg' : 'takie obiegi'}. Dodać ten wynik jako nowy obieg czy zastąpić?</p>
      <button class="citem" data-projdo="${p.id}" data-calc="${calcId}" data-nowa="1"><span class="citem-ico">${svg('plus')}</span>
        <span class="citem-t"><strong>Dodaj jako nowy obieg</strong><span>np. piętro albo druga strefa — w kotłowni osobna grupa pompowa</span></span></button>
      ${jest.map(c => `<button class="citem" data-projdo="${p.id}" data-calc="${calcId}" data-cz="${c}">
        <span class="citem-t"><strong>Zastąp: ${esc(projCz(c).nazwa)}</strong><span><b>${esc(projOpisCz(p, c))}</b></span></span></button>`).join('')}
      <button class="btn2" style="width:100%" data-projwybwroc>${svg('back')}Inny projekt</button>
    </div>`;
  }
  if (!state.projekty.length) return `<div class="proj-wybor"><p class="hint" style="margin:0 2px">Nie masz jeszcze projektu. Załóż go w kreatorze: Kalkulatory → Schemat kotłowni → „Stwórz projekt”.</p></div>`;
  return `<div class="proj-wybor">
    <p class="hint" style="margin:0 2px 8px">Do którego projektu?</p>
    ${state.projekty.map(x => `<button class="citem" data-projwyb="${x.id}" data-calcwyb="${calcId}"><span class="citem-ico">${svg('kotlownia')}</span>
      <span class="citem-t"><strong>${esc(x.nazwa)}</strong><span>${esc(x.klient && x.klient.name ? x.klient.name + ' · ' : '')}${esc(projOpis(x))}</span></span></button>`).join('')}
  </div>`;
}
function projPasek(calcId, modeKey, v, dodatkowe) {
  const cz = projCzCalc(calcId);
  const p = projZapiszZKalk(calcId, modeKey, v);
  if (p) return `<div class="tip proj-pasek">${svg(cz.ikona)}<div><b>Projekt: ${esc(p.nazwa)}</b> — ${esc(((state.projAkt[calcId] && projCz(state.projAkt[calcId].c)) || cz).nazwa.toLowerCase())}<br>Zmiany zapisują się w projekcie same.</div></div>
    <div class="proj-btny"><button class="btn2 proj-zapisz" data-projwrocdo="${p.id}">${svg('back')}Wróć do projektu</button>
      ${dodatkowe || ''}
      <button class="btn2" data-projodlacz="${calcId}">${svg('x')}Odłącz</button></div>`;
  return `<div class="proj-btny"><button class="btn2 proj-zapisz" data-projprzenies="${calcId}">${svg('doc')}Przenieś do projektu</button>${dodatkowe || ''}</div>`
    + (state.projWybor === calcId ? projWyborHtml(calcId) : '');
}
function projPasekKalk(calcId, modeKey, v, res, dodatkowe) {
  if (calcId === 'kotlownia' || !projCzCalc(calcId) || !res || res.error) return '';
  return projPasek(calcId, modeKey, v, dodatkowe || '');
}
/* Kreator kotłowni: to samo, plus PDF i czysta kartka. */
function ktPasekProjektu(v) {
  const pdf = `<button class="btn2" data-ktpdf>${svg('doc')}PDF</button>`;
  // kotłownia z projektu — pasek projektu (zapis sam, powrót, odłączenie)
  if (state.projAkt.kotlownia) return projPasek('kotlownia', '_', v, pdf);
  /* Kreator otwarty z menu to zawsze nowa kotłownia — zapisuje się ją,
     zakładając dla niej projekt. */
  return `<div class="proj-btny"><button class="btn2 proj-zapisz" data-ktnowyproj>${svg('plus')}Stwórz projekt</button>${pdf}</div>`;
}

/* ============================================================
   ZDARZENIA
   ============================================================ */
function projDoOferty(p, nowa) {
  const poz = projZaznaczoneWszystkie(p);
  if (!poz.length) { toast('Zaznacz co najmniej jedną pozycję w zestawieniach.'); return; }
  let o = !nowa && p.ofertaId ? state.offers.find(x => x.id === p.ofertaId && !x.invoice) : null;
  const utw = !o;
  if (!o) {
    o = blankOffer(state.offers, state.settings);
    const kl = p.klient || {};
    o.client = Object.assign(o.client, { name: kl.name || '', address: kl.address || p.adres || '', phone: kl.phone || '', email: kl.email || '' });
    o.projektId = p.id;
    state.offers.push(o); p.ofertaId = o.id; persistProj();
  }
  poz.forEach(it => o.items.push({ name: it.name, unit: it.unit, cat: it.cat, price: Number(it.price) || 0, tag: it.tag || null, katId: it.katId, qty: Number(it.qty) || 1 }));
  persist();
  state.projWrocDo = p.id;
  state.offerId = o.id; state.offerScreen = 'edit'; render(true);
  const bez = poz.filter(it => !(Number(it.price) > 0)).length;
  toast((utw ? 'Utworzono ofertę ' + o.number : 'Dodano do oferty ' + o.number) + ' — ' + poz.length + ' poz.' + (bez ? ', ' + bez + ' z ceną do uzupełnienia.' : '.'));
}

function projOdlaczWszystko(id, c) {
  Object.keys(state.projAkt).forEach(k => { const a = state.projAkt[k]; if (a.p === id && (!c || a.c === c)) delete state.projAkt[k]; });
}

document.addEventListener('click', e => {
  const t = e.target;
  // oferta otwarta z projektu: „wstecz” wraca do projektu
  if (t.closest('.proj-ofe [data-openoffer], .proj-ofe [data-openinv]')) { state.projWrocDo = state.projektId; return; }
  if (t.closest('#backoffers') && state.projWrocDo && state.projekty.some(p => p.id === state.projWrocDo)) {
    state.projektId = state.projWrocDo; state.projWrocDo = null; state.offerScreen = 'projekt';
    render(true); e.stopPropagation(); return;
  }
}, true);

document.addEventListener('click', e => {
  const t = e.target;
  const ds = sel => t.closest(sel);
  let x;

  if (ds('[data-projnowy]')) {
    const p = nowyProjekt();
    state.projektId = p.id; state.offerScreen = 'projekt'; state.projUsun = false;
    render(true); toast('Nowy projekt. Wpisz nazwę i klienta, a potem dodaj części.');
    return;
  }
  if ((x = ds('[data-projotworz]'))) { state.projektId = x.dataset.projotworz; state.offerScreen = 'projekt'; state.projUsun = false; state.projUsunCz = null; render(true); return; }
  if (ds('[data-projwroc]')) { state.offerScreen = 'list'; state.projektId = null; state.projUsun = false; render(true); return; }
  if ((x = ds('[data-projwrocdo]'))) {
    state.tab = 'offers'; state.offerScreen = 'projekt'; state.projektId = x.dataset.projwrocdo; state.projUsunCz = null;
    render(true); return;
  }

  // części
  if ((x = ds('[data-czedytuj]'))) { const p = currentProjekt(); if (p) projDoKalk(p, x.dataset.czedytuj); return; }
  if ((x = ds('[data-czdodaj]'))) {
    const p = currentProjekt(); if (!p) return;
    const c = x.dataset.czdodaj, calc = CALCS.find(k => k.id === projCz(c).calc);
    const mode = calc.modes ? calc.modes[0] : activeMode(calc);
    const d = {};
    fieldList(mode).forEach(f => { d[f.k] = (f.def && typeof f.def === 'object') ? projKopia(f.def) : f.def; });
    if (projTyp(c) === 'grz') { d.rad = []; d.radNazwy = []; }
    if (projTyp(c) === 'podl') d.rozdz = [];
    projUstawCzesc(p, c, mode.key, d);
    projDoKalk(p, c);
    return;
  }
  if ((x = ds('[data-czzkalk]'))) {
    const p = currentProjekt(); if (!p) return;
    const c = x.dataset.czzkalk, calc = CALCS.find(k => k.id === projCz(c).calc), mode = activeMode(calc);
    projUstawCzesc(p, c, mode.key, getValues(calc, mode));
    render(false); toast('Dodano część „' + projCz(c).nazwa + '” z tego, co jest teraz w kalkulatorze.');
    return;
  }
  if ((x = ds('[data-czusun]'))) {
    const p = currentProjekt(); if (!p) return;
    const c = x.dataset.czusun;
    state.projPotw = { co: 'czesc', c, tytul: 'Usunąć część „' + projCz(c).nazwa + '”?',
      tekst: 'Znikną dane tej części i jej zestawienie z Twoimi poprawkami. Pozostałe części, oferty i faktury projektu zostają.', tak: 'Usuń część' };
    renderOverlay(); return;
  }
  if (ds('[data-czobiegi]')) {
    const p = currentProjekt(); if (!p || !p.czesci.kot) return;
    const kv = projCzWartosci(p, 'kot').v;
    let ob = kv.ob || [], ile = 0;
    ['podl', 'grz'].forEach(t => {   // wszystkie części danego rodzaju naraz — każda to osobny obieg
      const nowe = projCzesciTypu(p, t).reduce((a, c) => { const cw = projCzWartosci(p, c); return a.concat(ktZKalkulatora(cw.calc.id, cw.v, cw.mode.key)); }, []);
      if (nowe.length) { ob = ktScalObiegi(ob, nowe); ile += nowe.length; }
    });
    if (!ile) { toast('W częściach projektu nie ma jeszcze mocy do przeniesienia.'); return; }
    kv.ob = ob;
    projUstawCzesc(p, 'kot', p.czesci.kot.mode, kv);
    // kreator otwarty na tej kotłowni — niech od razu widzi nowe obiegi
    const a = state.projAkt.kotlownia;
    if (a && a.p === p.id) { const kot = ktKalk(); state.values[vkey(kot.id, activeMode(kot).key)] = projKopia(kv); saveCalcValues(); }
    render(false);
    toast('Obiegi z projektu są w schemacie kotłowni (' + ile + '). Obiegi tego samego rodzaju zostały zastąpione, reszta została.');
    return;
  }
  if (ds('[data-czpdf]')) { const p = currentProjekt(); if (p) projZapiszPdf(projCzWartosci(p, 'kot').v, p); return; }
  if ((x = ds('[data-czrys]'))) {
    const p = currentProjekt(); if (!p) return;
    const r = projCzWynik(p, x.dataset.czrys).res;
    state.schemat = r.schemat || (r.schematy || [])[0] || null;
    renderOverlay(); return;
  }

  // oferta
  if (ds('[data-projdooferty]')) {
    const p = currentProjekt(); if (!p) return;
    const poz = projZaznaczoneWszystkie(p);
    if (!poz.length) { toast('Zaznacz co najmniej jedną pozycję w zestawieniach.'); return; }
    const lista = poz.map(it => ({ name: it.name, unit: it.unit, cat: it.cat, price: Number(it.price) || 0, tag: it.tag || null, katId: it.katId, qty: Number(it.qty) || 1 }));
    // wybór oferty (albo nowa — z klientem i adresem projektu)
    state.wybOferty = { name: lista.length + ' ' + odmiana(lista.length, 'pozycja', 'pozycje', 'pozycji') + ' z projektu „' + (p.nazwa || '') + '”', lista,
      klient: Object.assign({}, p.klient || {}, { address: (p.klient && p.klient.address) || p.adres || '' }) };
    renderOverlay(); return;
  }

  if (ds('[data-projusun]')) {
    const p = currentProjekt(); if (!p) return;
    const n = projOferty(p).length;
    state.projPotw = { co: 'projekt', tytul: 'Usunąć projekt „' + (p.nazwa || 'bez nazwy') + '”?',
      tekst: 'Znikną wszystkie części projektu i ich zestawienia.' + (n ? ' Oferty i faktury (' + n + ') zostaną na liście w Biurze.' : ''), tak: 'Usuń projekt' };
    renderOverlay(); return;
  }
  if (ds('[data-potwtak]')) {
    const w = state.projPotw; const p = w && w.pid ? state.projekty.find(k => k.id === w.pid) : currentProjekt();
    state.projPotw = null; renderOverlay();
    if (w && w.co === 'odlacz') {
      delete state.projAkt[w.calc]; delete state.projKalkPrzed[w.calc];
      render(false);
      toast('Odłączono. Projekt zostaje w Biurze, a dalsze zmiany w kalkulatorze już się do niego nie zapisują.');
      return;
    }
    if (!w || !p) return;
    if (w.co === 'czesc') {
      delete p.czesci[w.c]; delete p.zest[w.c];
      projOdlaczWszystko(p.id, w.c);
      if (projTyp(w.c) === 'grz' || projTyp(w.c) === 'podl') projSyncKot(p, projTyp(w.c));
      p.zm = projDzis(); persistProj(); renderKeepScroll();
      toast('Usunięto część „' + projCz(w.c).nazwa + '” z projektu.');
      return;
    }
    const id = p.id;
    state.projekty = state.projekty.filter(x => x.id !== id);
    projOdlaczWszystko(id);
    state.offers.forEach(o => { if (o.projektId === id) delete o.projektId; });
    persist(); persistProj(); state.offerScreen = 'list'; state.projektId = null; render(true);
    toast('Usunięto projekt. Jego oferty i faktury zostały na liście.');
    return;
  }
  if (state.projPotw && ds('[data-potwzamknij]') && (!ds('[data-stop]') || ds('.sheet-h [data-potwzamknij]') || ds('.proj-potw-nie'))) {
    state.projPotw = null; renderOverlay(); return;
  }

  // pod kalkulatorem
  if ((x = ds('[data-projprzenies]'))) {
    state.projWybor = state.projWybor === x.dataset.projprzenies ? null : x.dataset.projprzenies;
    state.projWyborP = null;
    render(false);
    const w = document.querySelector('.proj-wybor'); if (w) w.scrollIntoView({ block: 'nearest' });
    return;
  }
  if ((x = ds('[data-projwyb]'))) {
    const p = state.projekty.find(k => k.id === x.dataset.projwyb); if (!p) return;
    const cz = projCzCalc(x.dataset.calcwyb);
    // projekt bez takiego obiegu — nie ma o co pytać, od razu dodajemy
    if (!projCzesciTypu(p, cz.c).length) { projPrzenies(x.dataset.calcwyb, p, cz.c, false); return; }
    state.projWyborP = p.id; render(false);
    const w = document.querySelector('.proj-wybor'); if (w) w.scrollIntoView({ block: 'nearest' });
    return;
  }
  if (ds('[data-projwybwroc]')) { state.projWyborP = null; render(false); return; }
  if ((x = ds('[data-projdo]'))) {
    const calc = CALCS.find(k => k.id === x.dataset.calc), cz = projCzCalc(calc.id), mode = activeMode(calc);
    const p = x.dataset.projdo === 'nowy' ? nowyProjekt() : state.projekty.find(k => k.id === x.dataset.projdo);
    if (!p) return;
    projPrzenies(calc.id, p, x.dataset.cz || (x.dataset.nowa ? projWolnaCz(p, cz.c) : cz.c), !!x.dataset.nowa);
    return;
  }
  if ((x = ds('[data-projodlacz]'))) {
    const id = x.dataset.projodlacz, a = state.projAkt[id];
    const p = a && state.projekty.find(k => k.id === a.p);
    state.projPotw = { co: 'odlacz', calc: id, pid: p ? p.id : null, tytul: 'Odłączyć od projektu?',
      tekst: 'To, co jest teraz w projekcie' + (p ? ' „' + p.nazwa + '”' : '') + ', zostaje. Dalsze zmiany w tym kalkulatorze nie będą się już do niego zapisywać.',
      tak: 'Odłącz' };
    renderOverlay(); return;
  }

  // kreator kotłowni
  if (ds('[data-ktpdf]')) {
    const a = state.projAkt.kotlownia;
    const p = a ? state.projekty.find(k => k.id === a.p) : null;
    projZapiszPdf(p ? ktWartosci() : Object.assign({}, ktWartosci(), { ob: [] }), p); return;
  }
  if (ds('[data-ktnowyproj]')) {
    const kot = ktKalk(), mk = activeMode(kot), v = ktWartosci();
    const p = nowyProjekt();
    projUstawCzesc(p, 'kot', mk.key, Object.assign({}, v, { ob: [] }));   // obiegi dojdą z części projektu
    // kreator wraca do czystej kartki — ta kotłownia jest już w projekcie
    Object.keys(v).forEach(k => { delete v[k]; });
    Object.assign(v, ktDomyslne());
    saveCalcValues();
    state.tab = 'offers'; state.offerScreen = 'projekt'; state.projektId = p.id; state.screen = 'home';
    render(true);
    toast('Utworzono projekt „' + p.nazwa + '” ze schematem kotłowni. Nadaj mu nazwę i dopisz klienta.');
    return;
  }
  if (ds('[data-ktnowa]')) {
    if (!state.ktNowaPotw) { state.ktNowaPotw = true; render(false); setTimeout(() => { if (state.ktNowaPotw) { state.ktNowaPotw = false; if (state.calc === 'kotlownia') render(false); } }, 4000); return; }
    state.ktNowaPotw = false;
    const v = ktWartosci();
    Object.keys(v).forEach(k => { delete v[k]; });
    Object.assign(v, ktDomyslne());
    delete state.projAkt.kotlownia;
    saveCalcValues(); render(false);
    toast('Czysty kreator — zaczynasz nową kotłownię.');
  }
});

document.addEventListener('input', e => {
  const t = e.target; const p = currentProjekt();
  if (!p || !t.dataset) return;
  if (t.dataset.projpole) { p[t.dataset.projpole] = t.value; p.zm = projDzis(); persistProj(); }
  else if (t.dataset.projklient) { p.klient = p.klient || {}; p.klient[t.dataset.projklient] = t.value; p.zm = projDzis(); persistProj(); }
});
document.addEventListener('change', e => {
  const t = e.target; const p = currentProjekt();
  if (!p || !t.dataset || t.dataset.projzbazy === undefined || !t.value) return;
  const k = state.klienci.find(x => x.id === t.value); if (!k) return;
  p.klient = { name: k.name || '', address: k.address || '', phone: k.phone || '', email: k.email || '' };
  if (!p.adres && k.address) p.adres = k.address;
  p.zm = projDzis(); persistProj(); render(false);
});

/* Okno potwierdzenia usunięcia — w nakładce, żeby nie przewijać ekranu. */
state.projPotw = null;
function projPotwHtml(w) {
  return `<div class="sheet" data-potwzamknij role="dialog" aria-label="${esc(w.tytul)}">
    <div class="sheet-in" data-stop>
      <div class="sheet-h">${svg(w.co === 'odlacz' ? 'x' : 'trash')}<strong>${esc(w.tytul)}</strong>
        <button class="item-x" data-potwzamknij aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        <p class="hint" style="margin:0 0 14px">${esc(w.tekst)}</p>
        <button class="jump" style="--c:${w.co === 'odlacz' ? '#2E7D5B' : '#C62828'}" data-potwtak>${svg(w.co === 'odlacz' ? 'x' : 'trash')}${esc(w.tak)}</button>
        <button class="btn2 proj-potw-nie" style="width:100%;margin-top:8px" data-potwzamknij>Anuluj</button>
      </div>
    </div></div>`;
}
const _renderOverlayProj = renderOverlay;
renderOverlay = function () {
  const el = document.getElementById('overlay');
  if (state.projPotw && el) { el.innerHTML = projPotwHtml(state.projPotw); return; }
  if (state.projPompy && el) { const p = state.projekty.find(x => x.id === state.projPompy); if (p) { el.innerHTML = projPompyHtml(p); return; } }
  if (state.kalkZest && el) { el.innerHTML = kalkZestHtml(state.kalkZest); return; }
  return _renderOverlayProj();
};

/* Zakładka Biuro: ekran projektu wpięty w istniejący przełącznik ekranów. */
const _renderOffersTab = renderOffersTab;
renderOffersTab = function () {
  if (state.offerScreen === 'projekt') return renderProjekt();
  return _renderOffersTab();
};

/* Dotknięcie miniatury schematu kotłowni w projekcie — pełny ekran z powiększaniem. */
let PROJ_KT_RYS = '';
document.addEventListener('click', e => {
  if (!e.target.closest || !e.target.closest('[data-projktfull]') || !PROJ_KT_RYS) return;
  e.stopPropagation();
  state.ktPelny = { rys: PROJ_KT_RYS, proc: 100 };
  renderOverlay(); ktDopasuj();
}, true);

/* Kalkulator otwarty „na nowo” — z listy kalkulatorów, skokiem z innego
   wyniku, z bazy wiedzy albo dopisaniem pomieszczenia — to nie jest edycja
   projektu: odłączamy go od projektu i przywracamy wcześniejsze wpisy.
   Projekt edytuje się wyłącznie z Biura, przyciskiem „Edytuj”. */
document.addEventListener('click', e => {
  if (!e.target.closest) return;
  let id = null, x;
  if ((x = e.target.closest('[data-calc]')) && !x.closest('[data-projdo]') && !x.hasAttribute('data-projdo')) id = x.dataset.calc;
  else if ((x = e.target.closest('[data-jumpidx]'))) { const j = (state.pendingJumps || [])[+x.dataset.jumpidx]; id = j && j.calc; }
  else if ((x = e.target.closest('[data-kbcalc]'))) id = x.dataset.kbcalc;
  else if (e.target.closest('[data-doSrednic]')) id = 'co_dia';
  else if (e.target.closest('[data-rozdzdo]')) id = 'rozdz_dia';
  if (id && state.projAkt[id]) projPrzywrocKalk(id);
}, true);

/* Strzałka „wstecz” w kalkulatorze otwartym z projektu wraca do projektu,
   a nie na listę kalkulatorów. */
document.addEventListener('click', e => {
  if (!e.target.closest || !e.target.closest('#back')) return;
  const a = state.screen === 'calc' && state.calc && state.projAkt[state.calc];
  const p = a && state.projekty.find(x => x.id === a.p);
  if (!p) return;
  e.stopPropagation(); e.preventDefault();
  state.gasWarn = false; state.screen = 'home';
  state.tab = 'offers'; state.offerScreen = 'projekt'; state.projektId = p.id; state.projUsunCz = null;
  render(true);
}, true);

/* „Dobierz ręcznie” przy pompach w projekcie. */
document.addEventListener('click', e => {
  if (!e.target.closest) return;
  if (e.target.closest('[data-projpompy]')) {
    const p = currentProjekt(); if (!p || !p.czesci.kot) return;
    state.projPompy = p.id; renderOverlay(); return;
  }
  if (!state.projPompy) return;
  const b = e.target.closest('[data-projpompa]');
  if (b) {
    const p = state.projekty.find(x => x.id === state.projPompy);
    const x = p && projPompyLista(p)[+b.dataset.projpompa];
    state.projPompy = null; renderOverlay();
    if (!x) return;
    // podłogówka: pompę liczy jej kalkulator — otwieramy go na tej części projektu
    if (x.podl && x.zP && p.czesci[x.zP]) {
      projDoKalk(p, x.zP);
      toast('Pompę podłogówki liczy ten kalkulator (pętle, rozdzielacz, mieszacz). Zmiany zapisują się w projekcie same.');
      return;
    }
    projDoKalk(p, 'kot');     // kreator na kotłowni projektu, potem kalkulator pompy
    ktDobierzPompe(x.r, x.i);
    return;
  }
  if (e.target.closest('[data-closepompy]') && (!e.target.closest('[data-stop]') || e.target.closest('.sheet-h [data-closepompy]'))) {
    state.projPompy = null; renderOverlay();
  }
});

