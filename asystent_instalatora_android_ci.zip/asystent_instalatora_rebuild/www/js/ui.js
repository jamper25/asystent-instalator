/* ===== ui.js ===== */
/* ============================================================
   INTERFEJS APLIKACJI
   ============================================================ */
const ICO = {
  thermo:'<path d="M10 14.2V5a2 2 0 1 1 4 0v9.2a4 4 0 1 1-4 0z"/>',
  drop:'<path d="M12 3.2s6 6.4 6 10.3a6 6 0 0 1-12 0C6 9.6 12 3.2 12 3.2z"/>',
  pipe:'<rect x="3" y="9" width="18" height="6" rx="1.5"/><path d="M8.2 9v6M15.8 9v6"/>',
  tank:'<rect x="6.5" y="7" width="11" height="13" rx="4"/><path d="M12 7V3.5M9.5 3.5h5"/>',
  shield:'<path d="M12 3.2l7 2.9v5.6c0 4.4-2.9 7.4-7 9-4.1-1.6-7-4.6-7-9V6.1z"/>',
  gauge:'<circle cx="12" cy="12" r="8.2"/><path d="M12 12l4.2-3.1M12 12h.01"/>',
  search:'<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>',
  chev:'<path d="M9 5l7 7-7 7"/>',
  back:'<path d="M15 5l-7 7 7 7"/>',
  chevDown:'<path d="M6 9l6 6 6-6"/>',
  check:'<circle cx="12" cy="12" r="8.5"/><path d="M8.5 12.2l2.5 2.5 4.5-5"/>',
  spark:'<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/>',
  tune:'<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
  home:'<path d="M4 10.5L12 4l8 6.5V20a1 1 0 0 1-1 1h-4v-6h-6v6H5a1 1 0 0 1-1-1z"/>',
  fire:'<path d="M12 3s5 4.2 5 8.6a5 5 0 0 1-10 0c0-1.7.8-3 1.7-4.1.3 1.3 1 2.2 1.8 2.2 1.2 0 1.5-1.5 1.5-3.1z"/>',
  calc:'<rect x="4" y="3" width="16" height="18" rx="2.5"/><path d="M8 7.5h8M8.5 12h.01M12 12h.01M15.5 12h.01M8.5 16h.01M12 16h.01M15.5 16h.01"/>',
  doc:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
  bolt:'<path d="M13 3L5.5 13.5H11L10 21l7.5-10.5H12z"/>',
  wrench:'<path d="M15.5 3.5a5 5 0 0 0-5.9 6.6L3.5 16.2a2 2 0 1 0 2.8 2.8l6.1-6.1a5 5 0 0 0 6.6-5.9l-3 3-2.6-.7-.7-2.6z"/>',
  plumb:'<path d="M5 20v-5a4 4 0 0 1 4-4h2V7H8V3h9v4h-2.5v4H17a4 4 0 0 1 4 4v5"/>',
  water:'<path d="M3 15c2.2 0 2.2 2 4.4 2s2.2-2 4.4-2 2.2 2 4.4 2 2.2-2 4.4-2M3 9c2.2 0 2.2 2 4.4 2S9.6 9 11.8 9s2.2 2 4.4 2S18.4 9 20.6 9"/>',
  box:'<path d="M3.5 7.5L12 3l8.5 4.5v9L12 21l-8.5-4.5z"/><path d="M3.5 7.5L12 12l8.5-4.5M12 12v9"/>',
  snow:'<path d="M12 2v20M4.2 7l15.6 10M19.8 7L4.2 17"/><path d="M12 6l-2-2m2 2l2-2m-2 14l-2 2m2-2l2 2"/>',
  wall:'<rect x="3" y="4" width="18" height="16" rx="1.5"/><path d="M3 9.3h18M3 14.6h18M9 4v5.3M15 9.3v5.3M9 14.6V20"/>',
  window:'<rect x="4" y="3.5" width="16" height="17" rx="1.5"/><path d="M12 3.5v17M4 12h16"/>',
  layers:'<path d="M12 3l9 4.5-9 4.5-9-4.5z"/><path d="M3 12l9 4.5 9-4.5M3 16.5L12 21l9-4.5"/>',
  wind:'<path d="M3 8h10a3 3 0 1 0-3-3M3 16h13a3 3 0 1 1-3 3M3 12h16"/>',
  chart:'<path d="M4 4v16h16"/><path d="M7 15l3.5-4 3 2.5L20 7"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  trash:'<path d="M4 7h16M9.5 7V5h5v2M6.5 7l1 13h9l1-13"/>',
  ruler:'<rect x="2.5" y="8" width="19" height="8" rx="1.5"/><path d="M7 8v3M11 8v4M15 8v3M19 8v4"/>',
  arrow:'<path d="M5 12h14M13 6l6 6-6 6"/>',
  list:'<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>',
  floor:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M6.5 8.5h11M6.5 12h11M6.5 15.5h11"/><path d="M17.5 8.5v3.5M6.5 12v3.5"/>',
  therm:'<path d="M12 3v11"/><circle cx="12" cy="17.5" r="3.5"/><path d="M9.5 6h2.5M9.5 9h2.5"/>',
};
const svg = (k, cls) => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" ' +
  'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' + (cls ? ' class="' + cls + '"' : '') + '>' + (ICO[k] || '') + '</svg>';

const CATS = {
  heating: { label: 'Ogrzewanie', c: 'var(--cat-heat)' },
  water:   { label: 'Woda i pojemności', c: 'var(--cat-water)' },
  pipes:   { label: 'Rury i przekroje', c: 'var(--cat-pipe)' },
  safety:  { label: 'Bezpieczeństwo', c: 'var(--cat-safe)' },
  pumps:   { label: 'Pompy i hydraulika', c: 'var(--cat-pump)' },
};

const esc = s => String(s).replace(/[&<>"]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]));

/* Listy pomieszczeń w stratach ciepła i w podłogówce są różne (podłogówka ma
   jeszcze strefę brzegową, a nie ma klatki schodowej), więc dopasowujemy je
   po nazwie, a nie po numerze pozycji. Bez tego wybrana łazienka zamieniała
   się w pokój i limit temperatury podłogi schodził z 33 na 29 °C. */
function ufhRoomFor(roomIdx) {
  const name = (ROOM_TEMPS[roomIdx] || [])[0];
  const i = UFH_ROOMS.findIndex(r => r[0] === name);
  return i >= 0 ? i : 0;
}
/* Zastosowania pompy: typowe parametry, które wybór wpisuje w formularz. */
/* Karta pompy obiegu grzejnikowego — liczona sama, jak w podłogówce.
   Bez długości rury podpowiadamy, co wpisać. Dokładny dobór zostaje
   w kalkulatorze „Dobór pompy”. */
function coPompaKarta(pp) {
  if (!pp) return [{ label: 'Pompa obiegowa', icon: 'gauge', value: 'wpisz długość', unit: '', small: true,
    foot: 'Wpisz niżej „Rurę od źródła do najdalszego grzejnika” (w jedną stronę, z pionem), a policzę pompę sam — opory rury, grzejnika z zaworem termostatycznym i armatury. Dokładnie dobierzesz ją też w kalkulatorze „Dobór pompy”.' }];
  const kl = typeof ktKlasaPompy === 'function' ? ktKlasaPompy(pp.q, pp.H) : '';
  return [{ label: 'Pompa obiegowa', icon: 'gauge', value: kl || fmt(pp.H, 1), unit: kl ? (kl.startsWith('25') ? 'rura 1″' : kl.startsWith('32') ? 'rura 5/4″' : 'DN40') : 'm',
    foot: (kl && typeof ktOpisPompy === 'function' ? ktOpisPompy(kl) + '.\n' : '')
      + 'Nastaw: ' + fmt(pp.H, 1) + ' m (tryb zmiennej różnicy ciśnień przy zaworach termostatycznych), przepływ ' + fmt(pp.q, 2) + ' m³/h = ' + fmt(pp.q * 1000, 0) + ' l/h.'
      + '\nOpory: rura ' + fmt(2 * pp.dl, 0) + ' m tam i z powrotem z kształtkami ' + fmt(pp.dpRury, 1) + ' kPa + grzejnik z zaworem termostatycznym ' + fmt(pp.dpGrz, 0)
      + ' kPa + armatura w kotłowni ' + fmt(pp.dpArm, 0) + ' kPa' + (pp.dpRozdz ? ' + rozdzielacz ' + fmt(pp.dpRozdz, 0) + ' kPa' : '') + ' i 10% zapasu = ' + fmt(pp.zZapasem, 1) + ' kPa.'
      + '\nChcesz dobrać sam? Kalkulator „Dobór pompy”.' }];
}

const POMPA_CEL = {
  grz:  { nazwa: 'Obieg grzejnikowy', sup: 70, ret: 55, len: 60, rb: 10, rv: 5, rr: 10, tryb: 'tryb zmiennej różnicy ciśnień przy zaworach termostatycznych',
          oferta: 'Pompa obiegowa c.o.', opory: (a, b, c) => 'kocioł ' + fmt(a, 0) + ' + armatura ' + fmt(b, 0) + ' + jeden grzejnik ' + fmt(c, 0) },
  kotl: { nazwa: 'Pompa kotłowa (kocioł → sprzęgło / bufor)', sup: 80, ret: 60, len: 6, rb: 10, rv: 8, rr: 1, tryb: 'stała prędkość albo stała różnica ciśnień',
          oferta: 'Pompa kotłowa', opory: (a, b, c) => 'kocioł ' + fmt(a, 0) + ' + ochrona powrotu, separator ' + fmt(b, 0) + ' + sprzęgło / bufor ' + fmt(c, 0),
          uwaga: 'Przy kotle na paliwo stałe pompa musi pracować zawsze, gdy w kotle się pali — także po zaniku prądu (zasilanie awaryjne).' },
  cwu:  { nazwa: 'Ładowanie zasobnika c.w.u.', sup: 80, ret: 65, len: 10, rb: 10, rv: 5, rr: 10, tryb: 'stała prędkość — pracuje tylko podczas ładowania',
          oferta: 'Pompa ładująca c.w.u.', opory: (a, b, c) => 'kocioł ' + fmt(a, 0) + ' + armatura ' + fmt(b, 0) + ' + wężownica ' + fmt(c, 0),
          uwaga: 'Za pompą zawór zwrotny — inaczej ciepła woda z zasobnika ucieka grawitacyjnie, kiedy pompa stoi.' },
  cyrk: { nazwa: 'Cyrkulacja c.w.u.', sup: 55, ret: 50, len: 60, rb: 0, rv: 5, rr: 0, tryb: '',
          oferta: 'Pompa cyrkulacyjna c.w.u.', opory: (a, b) => 'zawory zwrotne i termostatyczne ' + fmt(b, 0) },
};

const fmt = (n, d = 1) => (Number.isFinite(n) ? n : 0).toFixed(d).replace('.', ',');
const opts = (arr, labeler) => arr.map((e, i) => ({ value: i, label: labeler(e, i) }));

/* ---------- Wykres charakterystyki pompy (poglądowy) ---------- */
function pumpChart(q, H) {
  const W = 320, Hh = 205, L = 36, R = 10, T = 22, B = 28;
  const qmax = Math.max(1.5, q * 1.9), hmax = Math.max(4, H * 1.85);
  const X = v => L + (v / qmax) * (W - L - R);
  const Y = v => Hh - B - (v / hmax) * (Hh - T - B);
  const speeds = [{ h: .40, q: .62 }, { h: .64, q: .80 }, { h: .92, q: .97 }];

  // który bieg leży najbliżej ponad punktem pracy
  let hiIdx = speeds.length - 1;
  for (let i = 0; i < speeds.length; i++) {
    const q0 = speeds[i].q * qmax, h0 = speeds[i].h * hmax;
    if (q < q0 && h0 * (1 - Math.pow(q / q0, 2)) >= H) { hiIdx = i; break; }
  }

  let s = `<svg class="chart" viewBox="0 0 ${W} ${Hh}" role="img" aria-label="Wykres charakterystyki pompy z naniesionym punktem pracy">`;
  // siatka + opisy osi
  for (let i = 1; i <= 4; i++) {
    const hv = hmax * i / 4, qv = qmax * i / 4;
    s += `<line class="gr" x1="${L}" y1="${Y(hv).toFixed(1)}" x2="${W - R}" y2="${Y(hv).toFixed(1)}"/>`;
    // najwyższej podziałki nie opisujemy — w tym miejscu stoi nazwa osi
    if (i < 4) s += `<text class="lbl" x="${L - 5}" y="${(Y(hv) + 3).toFixed(1)}" text-anchor="end">${fmt(hv, 1)}</text>`;
    if (i < 4) s += `<text class="lbl" x="${X(qv).toFixed(1)}" y="${Hh - B + 13}" text-anchor="middle">${fmt(qv, 1)}</text>`;
  }
  s += `<line class="ax" x1="${L}" y1="${T}" x2="${L}" y2="${Hh - B}"/>`;
  s += `<line class="ax" x1="${L}" y1="${Hh - B}" x2="${W - R}" y2="${Hh - B}"/>`;
  s += `<text class="lbl" x="${L - 5}" y="${T - 7}" text-anchor="end">H [m]</text>`;
  s += `<text class="lbl" x="${W - R}" y="${Hh - B + 13}" text-anchor="end">q [m³/h]</text>`;

  // krzywe biegów
  speeds.forEach((sp, i) => {
    const q0 = sp.q * qmax, h0 = sp.h * hmax;
    let d = '';
    for (let k = 0; k <= 24; k++) {
      const qq = q0 * k / 24, hh = h0 * (1 - Math.pow(qq / q0, 2));
      d += (k ? 'L' : 'M') + X(qq).toFixed(1) + ' ' + Y(hh).toFixed(1) + ' ';
    }
    s += `<path class="cv${i === hiIdx ? ' hi' : ''}" d="${d.trim()}"/>`;
    s += `<text class="lbl" x="${X(q0 * 0.06).toFixed(1)}" y="${(Y(h0) - 4).toFixed(1)}">${['I', 'II', 'III'][i]} bieg</text>`;
  });

  // punkt pracy
  const px = X(Math.min(q, qmax)), py = Y(Math.min(H, hmax));
  s += `<line class="ptl" x1="${L}" y1="${py.toFixed(1)}" x2="${px.toFixed(1)}" y2="${py.toFixed(1)}"/>`;
  s += `<line class="ptl" x1="${px.toFixed(1)}" y1="${(Hh - B).toFixed(1)}" x2="${px.toFixed(1)}" y2="${py.toFixed(1)}"/>`;
  s += `<circle class="pt" cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="5"/>`;
  const anchor = px > W * 0.62 ? 'end' : 'start';
  const dx = anchor === 'end' ? -9 : 9;
  s += `<text class="ptx" x="${(px + dx).toFixed(1)}" y="${(py - 9).toFixed(1)}" text-anchor="${anchor}">punkt pracy</text>`;
  s += '</svg>';
  return s;
}

/* ============================================================
   KALKULATORY
   ============================================================ */
/* ============================================================
   OSTRZEŻENIE O UPRAWNIENIACH DO PRAC GAZOWYCH
   ------------------------------------------------------------
   Treść dosłowna, uzgodniona z zamawiającym. Pokazuje się przy każdym
   wejściu do kalkulatora gazowego — nie raz na urządzenie. Jedno
   dotknięcie kosztuje sekundę, a ostrzeżenie, które widać tylko przy
   pierwszym uruchomieniu, w praktyce nie istnieje: telefonu używa się
   miesiącami, a pod instalację gazową podchodzi się raz na jakiś czas.
   ============================================================ */
const GAS_WARN_TEXT = 'Przebudowę instalacji gazowej może wykonać wyłącznie '
  + 'wykwalifikowany instalator posiadający aktualne uprawnienia budowlane '
  + 'lub eksploatacyjne (tzw. uprawnienia gazowe). Samodzielne wykonywanie '
  + 'jakichkolwiek prac przy instalacji gazowej jest nielegalne i stwarza '
  + 'ogromne zagrożenie dla życia i zdrowia.';

function gasWarnHtml() {
  /* Zamknięcie także dotknięciem tła. Okno zasłania cały ekran razem
     z dolnym paskiem, więc bez tego użytkownik, który wszedł tu przez
     pomyłkę, nie miałby jak się wycofać. Pasek z ostrzeżeniem i tak
     zostaje nad formularzem, więc treść nie znika z oczu. */
  return '<div class="sheet" data-gasok role="alertdialog" aria-modal="true" aria-label="Ostrzeżenie o uprawnieniach">'
    + '<div class="sheet-in" data-stop><div class="warn-h">' + svg('alert')
    + '<strong>Uprawnienia do prac gazowych</strong></div>'
    + '<div class="sheet-body">'
    + '<p class="warn-t">' + esc(GAS_WARN_TEXT) + '</p>'
    + '<p class="warn-s">Ten kalkulator służy do doboru wstępnego i do wyceny. '
    + 'Nie zastępuje projektu instalacji gazowej ani odbioru przez uprawnionego projektanta.</p>'
    + '<button class="jump" style="--c:var(--cat-safe);width:100%" data-gasok>Rozumiem</button>'
    + '</div></div></div>';
}

const CALCS = [

/* ---------------- 1. STRATA CIEPŁA POMIESZCZENIA ---------------- */
{
  id: 'heat_loss', cat: 'heating', icon: 'wall',
  title: 'Strata ciepła pomieszczenia',
  desc: 'Pełne obliczenie wg PN-EN 12831',
  sub: 'Przenikanie przez przegrody + wentylacja',
  cards: [
    { title: 'Lokalizacja i pomieszczenie', icon: 'snow', fields: [
      { k: 'zone', type: 'select', label: 'Strefa klimatyczna', def: 1,
        options: opts(ZONES, z => `Strefa ${z[0]} (${z[1]} °C) — ${z[2].split('(')[0].trim()}`) },
      { k: 'room', type: 'select', label: 'Rodzaj pomieszczenia', def: 0,
        options: opts(ROOM_TEMPS, r => `${r[0]} — ${r[1]} °C`) },
    ]},
    { title: 'Wymiary pomieszczenia', icon: 'ruler', fields: [
      { row: [
        { k: 'len', type: 'num', label: 'Długość', unit: 'm', def: 5, step: 0.1 },
        { k: 'wid', type: 'num', label: 'Szerokość', unit: 'm', def: 4, step: 0.1 },
      ]},
      { k: 'hgt', type: 'num', label: 'Wysokość', unit: 'm', def: 2.7, step: 0.1 },
    ]},
    { title: 'Ściany zewnętrzne', icon: 'wall', fields: [
      { k: 'nwalls', type: 'select', label: 'Liczba ścian zewnętrznych', def: 2,
        options: [{value:0,label:'0 — pomieszczenie wewnętrzne'},{value:1,label:'1 ściana'},
                  {value:2,label:'2 ściany (narożnik)'},{value:3,label:'3 ściany'},{value:4,label:'4 ściany'}] },
      { k: 'wmat', type: 'select', label: 'Materiał ściany', def: 0,
        options: opts(WALL_MATERIALS, m => `${m[0]} (λ=${fmt(m[1], 2)})`) },
      { k: 'wd', type: 'num', label: 'Grubość ściany', unit: 'cm', def: 38, step: 1 },
      { k: 'imat', type: 'select', label: 'Ocieplenie', def: 1,
        options: opts(INSULATIONS, m => m[1] ? `${m[0]} (λ=${m[1].toFixed(3).replace('.', ',')})` : m[0]) },
      { k: 'id', type: 'num', label: 'Grubość ocieplenia', unit: 'cm', def: 10, step: 1 },
    ]},
    { title: 'Okna', icon: 'window', fields: [
      { k: 'wc', type: 'num', label: 'Liczba okien', unit: 'szt', def: 2, step: 1 },
      { row: [
        { k: 'ww', type: 'num', label: 'Szerokość okna', unit: 'm', def: 1.5, step: 0.1 },
        { k: 'wh', type: 'num', label: 'Wysokość okna', unit: 'm', def: 1.5, step: 0.1 },
      ]},
      { k: 'wtyp', type: 'select', label: 'Rodzaj oszklenia', def: 4,
        options: opts(WINDOW_TYPES, w => `${w[0]} (U=${fmt(w[1], 1)})`) },
    ]},
    { title: 'Podłoga i strop', icon: 'layers', fields: [
      { k: 'flo', type: 'select', label: 'Podłoga', def: 3,
        options: opts(FLOOR_TYPES, f => f[1] ? `${f[0]} (U=${fmt(f[1], 2)})` : f[0]) },
      { k: 'cei', type: 'select', label: 'Strop / dach', def: 0,
        options: opts(CEILING_TYPES, c => c[1] ? `${c[0]} (U=${fmt(c[1], 2)})` : c[0]) },
    ]},
    { title: 'Wentylacja', icon: 'wind', fields: [
      { k: 'vent', type: 'select', label: 'Rodzaj wentylacji', def: 2,
        options: opts(VENTILATION, v => `${v[0]} — n=${fmt(v[1], 2)} 1/h`) },
    ]},
  ],
  tip: 'Obliczenie w ujęciu uproszczonym PN-EN 12831: dla gruntu i pomieszczeń nieogrzewanych stosowany jest współczynnik temperaturowy (0,5 dla gruntu i piwnicy, 0,8 dla poddasza). Do projektu z pieczątką potrzebne jest pełne obliczenie z mostkami cieplnymi.',
  compute(v) {
    const te = ZONES[v.zone][1], ti = ROOM_TEMPS[v.room][1];
    const lazienka = /^łazienka/i.test(String((ROOM_TEMPS[v.room] || [])[0] || ''));
    if (ti <= te) return { error: 'Temperatura pomieszczenia musi być wyższa od zewnętrznej.' };
    const uW = wallU(WALL_MATERIALS[v.wmat][1], v.wd / 100, INSULATIONS[v.imat][1], v.id / 100);
    const flo = FLOOR_TYPES[v.flo], cei = CEILING_TYPES[v.cei];
    const r = roomHeatLoss({
      tIn: ti, tOut: te, len: v.len, wid: v.wid, h: v.hgt, nWalls: v.nwalls,
      uWall: uW, winCount: v.wc, winW: v.ww, winH: v.wh, uWin: WINDOW_TYPES[v.wtyp][1],
      uFloor: flo[1], fxFloor: flo[2], uCeil: cei[1], fxCeil: cei[2], n: VENTILATION[v.vent][1],
    });
    const rows = [
      ['Współczynnik U ściany', fmt(uW, 3) + ' W/(m²·K)'],
      ['Δt obliczeniowa', fmt(r.dT, 0) + ' K'],
      ['Ściany zewnętrzne ' + fmt(r.aWall, 1) + ' m²', fmt(r.qWall, 0) + ' W'],
      ['Okna ' + fmt(r.aWindows, 1) + ' m²', fmt(r.qWin, 0) + ' W'],
      ['Podłoga ' + fmt(r.aFloor, 1) + ' m²', fmt(r.qFloor, 0) + ' W'],
      ['Strop / dach', fmt(r.qCeil, 0) + ' W'],
      ['Wentylacja (' + fmt(r.V, 0) + ' m³)', fmt(r.qVent, 0) + ' W'],
    ];
    return {
      results: [{ label: 'Strata ciepła pomieszczenia', icon: 'fire', value: fmt(r.total, 0), unit: 'W',
                  foot: 'przenikanie ' + fmt(r.qTrans, 0) + ' W + wentylacja ' + fmt(r.qVent, 0) + ' W' },
                { label: 'Na metr kwadratowy', icon: 'ruler', value: fmt(r.perM2, 0), unit: 'W/m²', small: true }],
      rows,
      jump: [
        /* Z łazienki do doboru wchodzi się na drabinkach, z każdego innego
           pomieszczenia — na samych płytowych, bez przełącznika. */
        lazienka
          ? { calc: 'radiator', fields: { req: Math.round(r.total), rodzaj: 'drab', zrodlo: 'lazienka' },
              label: 'Dobierz grzejnik do łazienki na ' + fmt(r.total, 0) + ' W' }
          : { calc: 'radiator', fields: { req: Math.round(r.total), rodzaj: 'plyt', zrodlo: 'pokoj' },
              label: 'Dobierz grzejnik na ' + fmt(r.total, 0) + ' W' },
        { calc: 'ufh',
          fields: { loss: Math.round(r.total), area: Math.round(r.aFloor * 10) / 10,
                    room: ufhRoomFor(v.room) },
          label: 'Zaprojektuj ogrzewanie podłogowe' },
      ],
    };
  },
},

/* ---------------- 2. ZAPOTRZEBOWANIE NA CIEPŁO (SZYBKIE) ---------------- */
{
  id: 'heat_demand', cat: 'heating', icon: 'thermo',
  title: 'Zapotrzebowanie budynku',
  desc: 'Szybki szacunek mocy wg wieku budynku',
  sub: 'Orientacyjna moc grzewcza całego budynku',
  cards: [{ title: 'Dane budynku', icon: 'home', fields: [
    { k: 'area', type: 'num', label: 'Powierzchnia ogrzewana', unit: 'm²', def: 120 },
    { k: 'tier', type: 'select', label: 'Wiek budynku / stan ocieplenia', def: 3,
      options: opts(TIERS, t => `${t[0]} — ${t[1]} (${t[2]} W/m²)`) },
  ]}],
  tip: 'Metoda orientacyjna do szybkiej wyceny i doboru źródła ciepła. Do doboru grzejników policz straty pomieszczenie po pomieszczeniu w kalkulatorze „Strata ciepła pomieszczenia”.',
  compute(v) {
    const w = TIERS[v.tier][2], watts = v.area * w;
    return { results: [{ label: 'Szacowana moc grzewcza', icon: 'fire', value: fmt(watts / 1000, 1), unit: 'kW',
      foot: fmt(v.area, 0) + ' m² × ' + w + ' W/m² = ' + fmt(watts, 0) + ' W' }] };
  },
},

/* ---------------- 3. DOBÓR GRZEJNIKA ---------------- */
{
  id: 'radiator', cat: 'heating', icon: 'layers',
  title: 'Dobór grzejnika',
  desc: 'Płytowe i drabinkowe — z tabeli mocy',
  sub: 'Grzejniki płytowe i łazienkowe drabinkowe',
  cards: [
    { title: 'Grzejnik', icon: 'layers', fields: [
      /* Drabinki są do łazienki. Kto przychodzi ze straty ciepła pokoju czy
         kuchni, dostaje same płytowe, bez przełącznika — nie ma po co mu go
         podsuwać. Z łazienki i z ekranu głównego przełącznik jest. */
      { k: 'rodzaj', type: 'seg', label: 'Rodzaj grzejnika', def: 'plyt',
        options: [{ value: 'plyt', label: 'Płytowe' }, { value: 'drab', label: 'Drabinkowe' }],
        when: v => v.zrodlo !== 'pokoj' },
      { k: 'ksztalt', type: 'seg', label: 'Kształt drabinki', def: 'plaska',
        options: [{ value: 'plaska', label: 'Płaski' }, { value: 'wypukla', label: 'Wypukły' }],
        when: v => v.rodzaj === 'drab' },
      /* Dwa okna w pokoju albo ściana, na której jeden duży grzejnik się nie
         zmieści — moc dzielimy po połowie na dwa takie same. */
      { k: 'ile', type: 'seg', label: 'Liczba grzejników', def: '1',
        options: [{ value: '1', label: 'Jeden grzejnik' }, { value: '2', label: 'Dwa grzejniki' }],
        when: v => v.rodzaj !== 'drab' },
    ]},
    { title: 'Wymagana moc', icon: 'fire', fields: [
      { k: 'req', type: 'num', label: 'Moc potrzebna w pomieszczeniu', unit: 'W', def: 900 },
      { k: 'reg', type: 'select', label: 'Parametry instalacji (zasilanie/powrót/pom.)', def: '70/55/20',
        options: RADSON_REGIMES.map(r => ({ value: r, label: r.replace(/\//g, ' / ') + ' °C' })),
        when: v => v.rodzaj !== 'drab' },
      /* Drabinki mają w karcie dwa zestawy parametrów i tylko te pokazujemy —
         liczby zgadzają się wtedy co do wata z katalogiem. */
      { k: 'regD', type: 'select', label: 'Parametry instalacji (zasilanie/powrót/pom.)', def: '75/65/20',
        options: DRABINKI_PARAMETRY.map(r => ({ value: r, label: r.replace(/\//g, ' / ') + ' °C' })),
        when: v => v.rodzaj === 'drab' },
    ]},
    { title: 'Ograniczenia (opcjonalnie)', icon: 'tune', fields: [
      { k: 'hgt', type: 'select', label: 'Wysokość grzejnika', def: 0,
        options: [{ value: 0, label: 'Dowolna' }].concat(RADSON_HEIGHTS.map(h => ({ value: h, label: h + ' mm' }))),
        when: v => v.rodzaj !== 'drab' },
      { k: 'typ', type: 'select', label: 'Typ grzejnika', def: '',
        options: [{ value: '', label: 'Dowolny' }].concat(RADSON_TYPES.map(t => ({ value: t, label: 'Typ ' + t }))),
        when: v => v.rodzaj !== 'drab' },
      /* Lista długości idzie wprost z tabeli producenta. Wcześniej była
         wpisana ręcznie i zaczynała się od 800 mm, więc grzejników 400,
         520, 600 i 720 mm nie dało się wybrać, choć w tabeli były —
         a to są właśnie te pod wąskie okna i do łazienek. */
      { k: 'maxl', type: 'select', label: 'Maksymalna długość', def: 0,
        options: [{ value: 0, label: 'Bez ograniczeń' }]
          .concat(RADSON_LENGTHS.map(l => ({ value: l, label: 'do ' + l + ' mm' }))),
        when: v => v.rodzaj !== 'drab' },
      { k: 'szer', type: 'select', label: 'Maksymalna szerokość', def: 0,
        options: [{ value: 0, label: 'Dowolna' }].concat(DRAB_SZEROKOSCI.map(w => ({ value: w, label: 'do ' + w + ' mm' }))),
        when: v => v.rodzaj === 'drab' },
      { k: 'wys', type: 'select', label: 'Maksymalna wysokość', def: 0,
        options: [{ value: 0, label: 'Bez ograniczeń' }].concat(DRAB_WYSOKOSCI.map(h => ({ value: h, label: 'do ' + h + ' mm' }))),
        when: v => v.rodzaj === 'drab' },
    ]},
  ],
  tip: 'Płytowe liczą się z tabeli mocy cieplnych grzejników Radson z Twojego poradnika. Im niższe parametry zasilania, '
     + 'tym większy grzejnik potrzebny do tej samej mocy — przy 55/45 °C grzejnik musi być wyraźnie większy '
     + 'niż przy 75/65 °C.\n\n'
     + 'Tabela płytowych obejmuje długości od 400 do 3000 mm. Krótkie grzejniki pokazują się same, '
     + 'kiedy moc jest mała — przy 900 W żaden czterystumilimetrowy nie wejdzie na listę, bo najmocniejszy '
     + 'z nich daje przy 70/55 °C ledwie 1034 W i to dopiero w typie 33 o wysokości 900 mm. Jeżeli szukasz grzejnika pod wąskie okno, ustaw maksymalną długość — lista '
     + 'zostawi wtedy tylko to, co się tam zmieści. Dwa okna albo za mało ściany na jeden duży grzejnik? '
     + 'Przełącz na dwa grzejniki — moc dzieli się po połowie i dostajesz dwa takie same.\n\n'
     + 'Drabinkowe są z kart katalogowych serii inwestycyjnej, płaskie i wypukłe, każde w kilkunastu rozmiarach. '
     + 'Moce są dokładnie te z karty, czyli dla pomieszczenia 20 °C. W łazience jest 24 °C, więc ta sama drabinka '
     + 'grzeje tam słabiej — przy 75/65 o mniej więcej jedną dziesiątą, przy 55/45 o jedną szóstą. Aplikacja '
     + 'pod wybraną drabinką pokazuje, ile odda w łazience, i ostrzega, jeśli to za mało.',
  compute(v) {
    if (!(v.req > 0)) return { error: 'Podaj wymaganą moc grzejnika w watach.' };
    return v.rodzaj === 'drab' ? dobierzDrabinke(v) : dobierzPlytowy(v);
  },
},

/* ---------------- 3b. OGRZEWANIE PODŁOGOWE ---------------- */
{
  id: 'ufh', cat: 'heating', icon: 'floor',
  title: 'Ogrzewanie podłogowe',
  desc: 'Rozstaw, pętle, przepływ i temperatura podłogi',
  sub: 'Projekt pętli podłogowej',
  cards: [
    { title: 'Pomieszczenie', icon: 'home', fields: [
      { k: 'room', type: 'select', label: 'Rodzaj pomieszczenia', def: 0,
        options: opts(UFH_ROOMS, r => `${r[0]} — ${r[1]} °C, podłoga do ${r[2]} °C`) },
      { row: [
        { k: 'area', type: 'num', label: 'Powierzchnia grzewcza', unit: 'm²', def: 20, step: 0.5 },
        { k: 'loss', type: 'num', label: 'Straty ciepła', unit: 'W', def: 1200, step: 10 },
      ]},
    ]},
    { title: 'Parametry instalacji', icon: 'therm', fields: [
      { row: [
        { k: 'tsup', type: 'num', label: 'Temp. zasilania', unit: '°C', def: 35, step: 1 },
        { k: 'dt', type: 'num', label: 'Δt zas./powr.', unit: 'K', def: 5, step: 1 },
      ]},
      { k: 'spacing', type: 'select', label: 'Rozstaw rur', def: 15,
        options: UFH_SPACINGS.map(s => ({ value: s, label: s + ' cm' })) },
      { k: 'pipe', type: 'select', label: 'Rura', def: '16x2',
        options: UFH_PIPES.map(p => ({ value: p[0], label: `${p[0]} — pętla maks. ${p[3]} m` })) },
      { k: 'lead', type: 'num', label: 'Odległość do rozdzielacza', unit: 'm', def: 3, step: 0.5 },
    ]},
    { title: 'Warstwy podłogi', icon: 'layers', fields: [
      { k: 'cov', type: 'select', label: 'Wykończenie podłogi', def: 0,
        options: opts(FLOOR_COVERINGS, c => `${c[0]} (R=${c[1].toFixed(3).replace('.', ',')})`) },
      { k: 'screedT', type: 'select', label: 'Rodzaj wylewki', def: 0,
        options: opts(SCREED_TYPES, s => `${s[0]} — λ=${fmt(s[1], 2)}, zwykle ${s[3]} mm`) },
      { k: 'screed', type: 'num', label: 'Grubość warstwy nad rurą', unit: 'mm', def: 45, step: 5 },
    ]},
  ],
  tip: 'Obliczenie w ujęciu uproszczonym PN-EN 1264. Model uwzględnia opór przejmowania ciepła, jastrych, '
     + 'wykładzinę i rozstaw rur. Dla konkretnego systemu producenta sprawdź jeszcze jego tabele — '
     + 'różnią się szczegółami konstrukcji płyty.\n\n'
     + 'Nastawa rotametru bierze się z mocy pomieszczenia i z Δt, nie z długości pętli. '
     + 'Wzór jest jeden: przepływ w l/h to 0,86 razy moc w watach podzielone przez Δt, '
     + 'a na litry na minutę dzielimy to jeszcze przez sześćdziesiąt. Przy Δt 5 K na każdy kilowat '
     + 'wypada mniej więcej 2,9 l/min, przy 7 K około 2,0, przy 10 K około 1,4. '
     + 'Jeśli pomieszczenie ma kilka pętli, ta liczba dzieli się na nie po równo i wszystkie '
     + 'rotametry tego pomieszczenia ustawia się tak samo.\n\n'
     + 'Zasada „dłuższa pętla, wyższa nastawa" sprawdza się tylko dlatego, że dłuższe pętle zwykle '
     + 'leżą w większych pomieszczeniach, a te potrzebują więcej ciepła. Sama długość przepływu nie '
     + 'wyznacza. Sto metrów w ciepłej, dobrze ocieplonej sypialni potrzebuje mniej wody niż '
     + 'sześćdziesiąt metrów w zimnym salonie z przeszkleniem na południe — i gdyby ustawiać '
     + 'po metrach, sypialnia byłaby przegrzana, a salon zimny. Długość decyduje o czym innym: '
     + 'o oporach pętli, czyli o pompie, i o tym, czy woda zdąży oddać ciepło, zanim dojdzie '
     + 'do końca. Dlatego jest maksymalna długość pętli, a nie maksymalny przepływ.\n\n'
     + 'Każde pomieszczenie liczy się osobno i dostaje własną pętlę albo własne pętle — nigdy '
     + 'wspólną z sąsiednim. Kuchnia ma mieć 20 °C, łazienka 24, sypialnia 18, każde siedzi na '
     + 'swoim termostacie i swoim siłowniku na belce. Pętla poprowadzona przez dwa pomieszczenia '
     + 'oddaje je pod jedną regulację: termostat kuchni zamyka siłownik i łazienka stygnie razem '
     + 'z nią, a temperatury podłogi w obu i tak są inne, bo i dopuszczalne maksimum jest inne. '
     + 'Dlatego kalkulator liczy pomieszczenie po pomieszczeniu, a na rozdzielaczu każdy pokój '
     + 'ma swoje wyjście. Jeżeli w małym pomieszczeniu przepływ wychodzi bardzo mały, '
     + 'rozwiązaniem nie jest doczepienie go do sąsiada, tylko podniesienie nastawy '
     + 'do minimum — i to kalkulator robi już sam.\n\n'
     + 'Nastawa ma bowiem dolną granicę i nie bierze się ona z podziałki przyrządu, tylko z samej '
     + 'wody. Poniżej mniej więcej 0,15 m/s woda przestaje porywać ze sobą pęcherzyki powietrza '
     + 'i pętli nie da się porządnie odpowietrzyć; dla rury 16×2 wypada z tego około 1,0 l/min. '
     + 'Dlatego nastawa to większa z dwóch liczb: ta z mocy albo ta z minimalnej prędkości. '
     + 'W korytarzu albo małej łazience prawie zawsze wygrywa minimum i wtedy woda wraca '
     + 'cieplejsza, niż zakłada projektowe Δt — kalkulator pokazuje, ile to Δt rzeczywiście '
     + 'wyniesie. Nic złego się nie dzieje: pomieszczenie nie weźmie więcej ciepła, niż wynika '
     + 'ze strat, a nadmiar ścina termostat.\n\n'
     + 'Δt jest tu wielkością zadaną, nie wynikową: wybierasz je w polu „Δt zas./powr.", a przepływ '
     + 'wychodzi taki, żeby dokładnie to Δt utrzymać. Ustawisz mniej wody — różnica między zasilaniem '
     + 'a powrotem rośnie i koniec pętli robi się chłodny; ustawisz więcej — różnica maleje, podłoga '
     + 'grzeje równiej, ale pompa pracuje ciężej niż musi. Typowo przyjmuje się 5 K, przy pompie '
     + 'ciepła bywa 7, rzadziej 10.',
  compute(v) {
    if (!(v.area > 0)) return { error: 'Podaj powierzchnię grzewczą pomieszczenia.' };
    if (!(v.dt > 0)) return { error: 'Δt musi być większe od zera.' };
    const room = UFH_ROOMS[v.room], cov = FLOOR_COVERINGS[v.cov], scr = SCREED_TYPES[v.screedT];
    const pipe = UFH_PIPES.find(p => p[0] === v.pipe) || UFH_PIPES[0];
    if (v.tsup - v.dt / 2 <= room[1]) {
      return { error: 'Temperatura wody jest niższa niż temperatura pomieszczenia — podłoga nie będzie grzać.' };
    }

    const dry = scr[2] === 'suchy';
    const d = ufhDesign({
      area: v.area, loss: v.loss, tIn: room[1], tMaxSurface: room[2],
      tSupply: v.tsup, dt: v.dt, spacing: v.spacing,
      pipeOuter: pipe[1], pipeWall: pipe[2], maxLoop: pipe[3], lead: v.lead,
      screed: v.screed, lambdaScreed: scr[1], rCov: cov[1], dry,
    });

    const warns = [];
    if (!d.covers) warns.push(`Przy tych parametrach podłoga da ${fmt(d.qAch, 0)} W/m², a potrzeba ${fmt(d.qReq, 0)} W/m². `
      + 'Zmniejsz rozstaw rur, podnieś temperaturę zasilania albo dogrzej pomieszczenie grzejnikiem.');
    if (!d.surfaceOk) warns.push(`Temperatura powierzchni ${fmt(d.tSurface, 1)} °C przekracza dopuszczalne `
      + `${room[2]} °C dla tego pomieszczenia. Obniż temperaturę zasilania albo zwiększ rozstaw.`);
    if (cov[1] > 0.15) warns.push('Ta wykładzina ma opór cieplny powyżej 0,15 — nie nadaje się pod ogrzewanie podłogowe.');
    if (d.velocity > V_MAX_PETLA_POD) warns.push(`Prędkość ${fmt(d.velocity, 2)} m/s w pętli przekracza `
      + `${fmt(V_MAX_PETLA_POD, 2)} m/s — opory rosną szybciej niż pożytek z nich. Podziel na więcej pętli.`);
    /* Doprowadzenie zjadające całą dopuszczalną długość pętli. Rzadkie,
       ale wtedy podział na pętle przestaje mieć sens i trzeba ruszyć
       samą szafkę, a nie liczby. */
    if (d.zaDaleko) warns.push(`Samo dojście do rozdzielacza i z powrotem to ${fmt(d.dojscie, 0)} m, `
      + `a cała pętla nie może przekroczyć ${pipe[3]} m — na grzanie nie zostaje nic. `
      + 'Przenieś rozdzielacz bliżej albo postaw drugi w tej części domu.');
    /* Nastawa rotametru ma dwie granice i obie trzeba pokazać. Dolna nie
       bierze się z podziałki przyrządu, tylko z prędkości wody: poniżej
       0,15 m/s pętla nie chce się odpowietrzyć. Górna to już sam zakres
       przepływomierza. */
    const rot = d.flowNastawa / 60;
    if (d.ponizejMin) warns.push(`Na pętlę wypada ${fmt(rot, 2)} l/min, czyli `
      + `${fmt(d.velocity, 3)} m/s w rurze ${pipe[0]}. Liczba jest poprawna — przy takiej mocy `
      + 'tyle właśnie trzeba — ale wytyczne projektowania podłogówki przyjmują zwykle minimum '
      + `${fmt(V_MIN_PETLA_POD, 2)} m/s, czyli około ${fmt(d.flowMinPetla / 60, 1)} l/min `
      + 'dla tej rury. Sprawdź dwie rzeczy: czy przepływomierz w ogóle pokaże tak małą wartość '
      + 'i czy pętla da się odpowietrzyć. Jeśli chcesz podnieść przepływ, zmniejsz Δt — '
      + 'nie łącz tego pomieszczenia z sąsiednim, bo każde ma swój termostat.');
    if (rot > ROTAMETR_MAX) warns.push(`Na pętlę wypada ${fmt(rot, 1)} l/min, a najszersze `
      + `spotykane wkładki przepływomierzy kończą się na ${fmt(ROTAMETR_MAX, 1)} l/min. `
      + 'Podziel pomieszczenie na więcej pętli albo zwiększ Δt obiegu.');
    else if (rot > ROTAMETR_SKALA_MALA) warns.push(`Na pętlę wypada ${fmt(rot, 1)} l/min. `
      + `Wkładki przepływomierzy bywają na ${ROTAMETR_SKALE.join(', ')} l/min, więc `
      + 'sprawdź, jaką masz na belce — na najczęstszej skali do 3 l/min tej pętli nie ustawisz. '
      + 'To też sygnał, że na jeden obieg przypada dużo mocy: typowa pętla to 500–1000 W, '
      + 'a przy większej warto podzielić pomieszczenie.');
    if (dry && v.screed > 30) warns.push(`W systemie suchym warstwa nad rurą to zwykle ${scr[3]} mm, a nie ${fmt(v.screed, 0)} mm — sprawdź wpis.`);
    if (dry) warns.push('System suchy: rozstaw rur narzuca konstrukcja płyty, nie projektant, '
      + 'a rozpływ ciepła zależy od rozpraszacza. Wynik zweryfikuj z tabelami producenta systemu.');

    return {
      results: [
        { label: d.covers ? 'Podłoga pokrywa straty' : 'Za mało mocy', icon: d.covers ? 'check' : 'alert',
          value: fmt(d.qAch, 0), unit: 'W/m²',
          foot: `potrzeba ${fmt(d.qReq, 0)} W/m² · ${fmt(v.loss, 0)} W na ${fmt(v.area, 1)} m²` },
        { label: 'Temperatura powierzchni podłogi', icon: 'therm', small: true,
          value: fmt(d.tSurface, 1), unit: '°C', foot: `dopuszczalne ${room[2]} °C` },
        { label: 'Pętle', icon: 'floor', small: true,
          value: `${d.loops} × ${fmt(d.loopLength, 0)} m`, unit: '',
          foot: `razem ${fmt(d.pipeLength, 0)} m rury ${pipe[0]} przy rozstawie ${v.spacing} cm` },
      ],
      rows: [
        ['Rodzaj systemu', dry ? 'suchy (rura w rozpraszaczu)' : 'mokry (rura w wylewce)'],
        ['Średnia temperatura wody', fmt(d.tWaterMean, 1) + ' °C'],
        ['Opór cieplny warstw', fmt(d.R.total, 3) + ' m²·K/W'],
        ['Wystarczy temp. zasilania', fmt(d.tSupplyNeeded, 1) + ' °C'],
        ['Rura w podłodze', fmt(d.grzejna, 0) + ' m przy rozstawie ' + v.spacing + ' cm'],
      ].concat(d.dojscie > 0 ? [
        ['Dojście do rozdzielacza', d.loops + ' × ' + fmt(d.dojscie, 0) + ' m = '
          + fmt(d.loops * d.dojscie, 0) + ' m — każda pętla jedzie od szafki osobno'],
      ] : []).concat([
        ['Przepływ całkowity', fmt(d.flowTotal, 0) + ' l/h'],
        ['Przepływ na pętlę', fmt(d.flowLoop, 0) + ' l/h'],
        /* Rotametr na rozdzielaczu ma podziałkę w litrach na minutę, więc
           podajemy tę samą liczbę jeszcze raz w jednostce, która stoi
           na belce — żeby instalator nie dzielił przez sześćdziesiąt
           w pamięci, klęcząc przy szafce. */
        ['Nastawa rotametru', fmt(d.flowNastawa / 60, 1) + ' l/min na każdą pętlę'],
        ['Prędkość w pętli', fmt(d.velocity, 2) + ' m/s  ·  nie mniej niż '
          + fmt(V_MIN_PETLA_POD, 2) + ' m/s, bo inaczej pętla się nie odpowietrzy'],
        ['Opory jednej pętli', fmt(d.dpLoop / 1000, 1) + ' kPa', true],
      ].concat(d.ponizejMin ? [
        ['Poniżej zalecanej prędkości', 'wytyczne przyjmują od ' + fmt(V_MIN_PETLA_POD, 2)
          + ' m/s, czyli około ' + fmt(d.flowMinPetla / 60, 1) + ' l/min dla tej rury'],
      ] : [])),
      warn: warns.length ? warns.join(' ') : null,
      addTo: { name: `Rura do ogrzewania podłogowego ${pipe[0]}, rozstaw ${v.spacing} cm (${d.loops} pętle)`,
               tag: 'rura', unit: 'mb', cat: 'mat', qty: Math.ceil(d.pipeLength) },
      /* Do rozdzielacza jedzie moc pomieszczenia i liczba jego pętli. Moce
         i pętle z kolejnych pomieszczeń sumują się w jednym wierszu, bo
         rozdzielacz obsługuje je wszystkie naraz — i to z tej sumy wychodzi
         średnica rury, którą trzeba do niego dojechać. */
      doRozdzielacza: {
        tytul: `Podłogówka ${fmt(v.area, 1)} m² · ${d.loops} ${odmiana(d.loops, 'pętla', 'pętle', 'pętli')}`,
        moc: v.loss,
        petle: d.loops,
        /* Opory pętli decydują o pompie, a długość o tym, która pętla
           w całym domu jest najgorsza. Rozdzielacz zapamiętuje największą
           z dopisanych — pompa musi poradzić sobie z najgorszą, nie ze
           średnią, a sumować ich nie wolno, bo wiszą równolegle. */
        dpPetli: d.dpLoop / 1000,
        dlPetli: d.loopLength,
        /* Metry rury sumują się — w odróżnieniu od oporów, które biorą
           maksimum. To jest liczba, którą zamawia się w hurtowni, więc
           niesiemy też rozmiar rury: 140 metrów samo w sobie nic nie mówi. */
        metrow: d.pipeLength,
        rura: pipe[0],
      },
    };
  },
},

/* ---------------- 4. DOBÓR POMPY ---------------- */
{
  id: 'pump', cat: 'pumps', icon: 'gauge',
  title: 'Dobór pompy',
  desc: 'Obiegi c.o., kotłowa, ładowanie zasobnika, cyrkulacja',
  sub: 'Przepływ q, wysokość podnoszenia H i jaka pompa',
  cards: [
    { title: 'Do czego jest pompa', icon: 'gauge', fields: [
      /* Wybór ustawia typowe temperatury i opory dla tego zastosowania
         (patrz POMPA_CEL) — potem i tak można je poprawić. Pompy podłogówki
         tu nie ma: liczy ją kalkulator „Ogrzewanie podłogowe”, dla każdej
         szafki z jej pętlami, belką i mieszaczem — dokładniej niż tutaj. */
      { k: 'cel', type: 'select', label: 'Zastosowanie', def: 'grz',
        options: Object.keys(POMPA_CEL).map(x => ({ value: x, label: POMPA_CEL[x].nazwa })) },
    ]},
    { title: 'Obieg', icon: 'fire', fields: [
      { k: 'power', type: 'num', label: 'Moc obiegu (Q)', unit: 'kW', def: 20, when: v => v.cel !== 'cyrk' && v.cel !== 'cwu' },
      { k: 'power', type: 'num', label: 'Moc kotła (ładuje zasobnik)', unit: 'kW', def: 20, when: v => v.cel === 'cwu' },
      { k: 'wm', type: 'num', label: 'Straty ciepła rur c.w.u. i cyrkulacji', unit: 'W/m', def: 10, step: 1, when: v => v.cel === 'cyrk' },
      { row: [
        { k: 'sup', type: 'num', label: 'Zasilanie', unit: '°C', def: 70 },
        { k: 'ret', type: 'num', label: 'Powrót', unit: '°C', def: 55 },
      ]},
    ]},
    { title: 'Najdłuższy obieg', icon: 'pipe', fields: [
      { k: 'len', type: 'num', label: 'Długość obiegu (zasilanie + powrót)', unit: 'm', def: 60, when: v => v.cel !== 'cyrk' },
      { k: 'len', type: 'num', label: 'Długość rur c.w.u. i cyrkulacji (razem)', unit: 'm', def: 60, when: v => v.cel === 'cyrk' },
      { k: 'mat', type: 'select', label: 'Materiał rury', def: 'copper',
        options: PIPE_MATERIALS.map(m => ({ value: m[0], label: m[1] })) },
      { k: 'dia', type: 'select', label: 'Średnica rury', def: '', dynamic: 'pipeDia',
        /* Liczymy całą długość jedną średnicą przy pełnym przepływie — więc
           średnica rury, którą płynie cała woda obiegu, nie najcieńsza. */
        note: v => ({ grz: 'główna rura od kotła', kotl: 'rura kocioł – sprzęgło / bufor', cwu: 'rura do wężownicy',
          cyrk: 'rura cyrkulacji' })[v.cel] || 'główna rura od kotła' },
      { k: 'fit', type: 'slider', label: 'Narzut na opory miejscowe (kolana, trójniki)', min: 1.1, max: 2, step: 0.05, def: 1.3, suffix: '×' },
    ]},
    /* Wszystkie trzy wartości dotyczą JEDNEGO obiegu — tego najdłuższego,
       który dyktuje pompę. Nie mnoży się ich przez liczbę grzejników, bo
       grzejniki wiszą równolegle: woda idąca do kuchni nie przechodzi przez
       grzejnik w salonie. Pompa musi dowieźć wodę do najgorszego z nich,
       a reszta dostanie swoje tym łatwiej. */
    { title: 'Opory urządzeń na najdłuższym obiegu', icon: 'tune', fields: [
      { k: 'rb', type: 'num', label: 'Kocioł / źródło ciepła', unit: 'kPa', def: 10, step: 1, when: v => v.cel !== 'cyrk' },
      { k: 'rv', type: 'num', label: 'Zawory, filtr, sprzęgło po drodze', unit: 'kPa', def: 5, step: 1, when: v => v.cel === 'grz' || !POMPA_CEL[v.cel] },
      { k: 'rv', type: 'num', label: 'Zawór ochrony powrotu, separator, zwrotny', unit: 'kPa', def: 8, step: 1, when: v => v.cel === 'kotl' },
      { k: 'rv', type: 'num', label: 'Zawór zwrotny, filtr, odcięcia', unit: 'kPa', def: 5, step: 1, when: v => v.cel === 'cwu' },
      { k: 'rv', type: 'num', label: 'Zawory zwrotne i termostatyczne cyrkulacji', unit: 'kPa', def: 5, step: 1, when: v => v.cel === 'cyrk' },
      { k: 'rr', type: 'num', label: 'Jeden grzejnik z zaworem — ten najdalszy', unit: 'kPa', def: 10, step: 1, when: v => v.cel === 'grz' || !POMPA_CEL[v.cel] },
      { k: 'rr', type: 'num', label: 'Sprzęgło albo bufor', unit: 'kPa', def: 1, step: 1, when: v => v.cel === 'kotl' },
      { k: 'rr', type: 'num', label: 'Wężownica zasobnika', unit: 'kPa', def: 10, step: 1, when: v => v.cel === 'cwu' },
    ]},
    { title: 'Wysokość instalacji', icon: 'ruler', fields: [
      { k: 'hbud', type: 'num', label: 'Wysokość od kotła do najwyższego punktu', unit: 'm', def: 8, step: 0.5 },
    ]},
  ],
  tip: 'Pompę ogrzewania podłogowego liczy kalkulator „Ogrzewanie podłogowe” — osobno dla każdej szafki, z oporami pętli, przepływomierzy, belki i mieszacza.\n\n'
     + 'Uwaga: w instalacji ZAMKNIĘTEJ wysokość budynku nie wchodzi do wysokości podnoszenia pompy — obieg jest zrównoważony, więc pompa pokonuje wyłącznie opory przepływu. Wysokość służy do ustalenia ciśnienia napełnienia i nastawy naczynia wzbiorczego (patrz niżej).\n\n'
     + 'Opory urządzeń wpisuje się dla jednego obiegu — tego najdłuższego, najbardziej oporowego. '
     + 'Nie mnoży się ich przez liczbę grzejników i to jest najczęstsza pomyłka przy doborze pompy. '
     + 'Grzejniki wiszą równolegle: woda płynąca do kuchni nie przechodzi po drodze przez grzejnik '
     + 'w salonie, więc ich opory się nie sumują. Przy ośmiu grzejnikach w pole „Jeden grzejnik '
     + 'z zaworem" wpisujesz opór jednego, nie ośmiu — inaczej wyjdzie pompa kilka razy za duża, '
     + 'głośna i zużywająca prąd bez powodu.\n\n'
     + 'Tak samo kocioł i armatura: liczy się to, co stoi na drodze wody do najdalszego grzejnika '
     + 'i z powrotem — kocioł, filtr, zawory odcinające, sprzęgło. Każde raz.\n\n'
     + 'Skąd wziąć liczby: opór zaworu termostatycznego podaje producent w karcie, zależnie od '
     + 'nastawy wstępnej, i typowo wychodzi 3–10 kPa. Sam grzejnik to ułamek kilopaskala, więc '
     + 'zwykle wpisuje się jedną wartość na komplet zawór plus grzejnik. Opór kotła znajdziesz '
     + 'w jego instrukcji, w tabeli oporów wymiennika przy danym przepływie.',
  compute(v) {
    const cel = POMPA_CEL[v.cel] ? v.cel : 'grz';
    const cyrk = cel === 'cyrk';
    const dt = v.sup - v.ret;
    if (dt <= 0) return { error: 'Temperatura zasilania musi być wyższa niż temperatura powrotu.' };
    /* Cyrkulacja nie przenosi mocy grzewczej — pompuje tyle wody, żeby
       pokryć straty ciepła rur i utrzymać ciepłą wodę przy kranach. */
    const moc = cyrk ? (Number(v.len) || 0) * (Number(v.wm) || 0) / 1000 : v.power;
    const q = pumpFlow(moc, dt);
    const rb = cyrk ? 0 : Number(v.rb) || 0, rr = cyrk ? 0 : Number(v.rr) || 0;
    const list = pipeList(v.mat);
    const pipe = list.find(p => p[0] === v.dia) || list[Math.min(2, list.length - 1)];
    const inner = pipeInner(pipe);
    const f = pipeFriction(q, inner, v.len, v.mat);
    const dpLin = f.dp * v.fit;
    const dpDev = (rb + (Number(v.rv) || 0) + rr) * 1000;
    const dpTot = dpLin + dpDev;
    const H = dpTot / (WATER.rho * WATER.g);
    state.pompaWynik = { q, H };     // do zapisania w schemacie kotłowni
    const sp = staticPressure(v.hbud);
    const fast = f.v > 1.0;

    const C = POMPA_CEL[cel];
    const kl = typeof ktKlasaPompy === 'function' ? ktKlasaPompy(q, H) : '';
    const jaka = cyrk
      ? { label: 'Jaka pompa', icon: 'gauge', value: 'cyrkulacyjna', unit: 'do wody pitnej',
          foot: 'Korpus z brązu albo stali nierdzewnej — zwykła pompa c.o. z żeliwa w wodzie pitnej rdzewieje. '
            + (H <= 1.2 ? 'Wystarczy najmniejsza (do ok. 1,5 m). ' : 'Wysokość podnoszenia co najmniej ' + fmt(H * 1.3, 1) + ' m. ')
            + 'Z zegarem albo termostatem — cyrkulacja przez całą dobę wychładza zasobnik.' }
      : { label: 'Jaka pompa', icon: 'gauge', value: kl, unit: kl.startsWith('25') ? 'rura 1″' : kl.startsWith('32') ? 'rura 5/4″' : 'DN40',
          foot: (typeof ktOpisPompy === 'function' ? ktOpisPompy(kl) + '.\n' : '') + 'Nastaw ok. ' + fmt(H, 1) + ' m (' + C.tryb + ').\n'
            + 'Oznaczenie „' + kl + '”: ' + kl.split('-')[0] + ' to przyłącze, ' + kl.split('-')[1] + ' to maks. wysokość podnoszenia w decymetrach — z zapasem, żeby pompa pracowała w środku zakresu.'
            + (C.uwaga ? '\n' + C.uwaga : '') };
    return {
      results: [
        jaka,
        { label: 'Wymagana wydajność pompy', icon: 'gauge', value: fmt(q, 2), unit: 'm³/h',
          foot: cyrk ? `straty ${fmt(moc * 1000, 0)} W (${fmt(v.len, 0)} m × ${fmt(v.wm, 0)} W/m) przy Δt ${fmt(dt, 0)} K = ${fmt(q * 1000, 0)} l/h`
            : `q = ${fmt(moc, 1)} / (1,163 × ${fmt(dt, 0)}) = ${fmt(q * 1000, 0)} l/h`, small: true },
        { label: 'Wysokość podnoszenia', icon: 'arrow', value: fmt(H, 2), unit: 'm H₂O',
          foot: `${fmt(dpTot / 1000, 1)} kPa oporów całkowitych`, small: true },
      ],
      rows: [
        ['Prędkość w rurze ' + pipe[0], fmt(f.v, 2) + ' m/s'],
        ['Opór jednostkowy', fmt(f.R, 0) + ' Pa/m'],
        ['Opory liniowe rur × ' + fmt(v.fit, 2), fmt(dpLin / 1000, 1) + ' kPa'],
        ['Opory urządzeń', fmt(dpDev / 1000, 1) + ' kPa  ·  ' + C.opory(rb, Number(v.rv) || 0, rr)],
      ].concat(cel === 'grz' ? [['Dlaczego jeden grzejnik', 'grzejniki wiszą równolegle — pompa pokonuje najgorszy obieg, '
          + 'a nie sumę wszystkich']] : []).concat([
        ['Razem opory obiegu', fmt(dpTot / 1000, 1) + ' kPa', true],
        ['Ciśnienie statyczne (' + fmt(v.hbud, 1) + ' m)', fmt(sp.stat, 2) + ' bar'],
        ['Zalecane ciśnienie napełnienia', fmt(sp.fill, 2) + ' bar'],
      ]),
      top: state.ktPompa ? `<button class="btn2 kt-zapisz-pompe" type="button" data-ktzapiszpompe>${svg('kotlownia')}Zapisz pompę w schemacie — ${esc(state.ktPompa.nazwa)}</button>` : '',
      extra: `<div class="chartbox" style="--c:${CATS.pumps.c}">
          <h4>${svg('chart')}Punkt pracy pompy</h4>
          <p>Wykres poglądowy z zaznaczonym Twoim punktem pracy (q = ${fmt(q, 2)} m³/h, H = ${fmt(H, 2)} m).
             Porównaj go z charakterystyką konkretnej pompy z katalogu producenta.</p>
          ${pumpChart(q, H)}
        </div>`,
      addTo: { name: `${C.oferta}${cyrk ? '' : ' ' + kl} — wydajność ${fmt(q, 2)} m³/h, wys. podnoszenia ${fmt(H, 2)} m`,
               tag: 'pompa', unit: 'szt', cat: 'mat' },
      warn: fast ? `Prędkość ${fmt(f.v, 2)} m/s w rurze ${pipe[0]} jest wysoka — instalacja może szumieć. Rozważ większą średnicę.` : null,
    };
  },
},

/* ---------------- 5. NACZYNIE WZBIORCZE ---------------- */
{
  id: 'vessel', cat: 'pumps', icon: 'tank',
  title: 'Naczynie wzbiorcze',
  desc: 'Ze znanej mocy albo z pojemności instalacji',
  sub: 'Dobór naczynia przeponowego',
  modes: [
    { key: 'moc', label: 'Znana moc',
      cards: [
        { title: 'Instalacja', icon: 'fire', fields: [
          { k: 'height', type: 'seg', def: '7', options: REFLEX_HEIGHTS.map(h =>
            ({ value: String(h.h), label: h.h + ' m' })) },
          { k: 'kwUfh', type: 'num', label: 'Ogrzewanie podłogowe', unit: 'kW', def: 4, step: 0.5 },
          { k: 'kwRad', type: 'num', label: 'Grzejniki płytowe', unit: 'kW', def: 6, step: 0.5 },
        ]},
        { title: 'Czynnik i zabezpieczenie', icon: 'tune', fields: [
          { k: 'fluid', type: 'select', label: 'Czynnik w instalacji', def: 0,
            options: opts(REFLEX_FLUIDS, f => f[0]) },
          { k: 'sv', type: 'seg', def: '3.0', options: [
            { value: '3.0', label: 'Zawór 3,0 bar' }, { value: '2.5', label: 'Zawór 2,5 bar' },
          ]},
        ]},
      ],
      tip: 'Tryb dla instalacji o znanej mocy, kiedy nie znasz jej pojemności wodnej — dobór wprost z tablic producenta, bez liczenia litrów. Wysokość statyczna to różnica poziomów między naczyniem a najwyższym punktem instalacji; od niej zależy ciśnienie wstępne naczynia, które trzeba ustawić przed napełnieniem. Podaj moc tylko tych rodzajów instalacji, które faktycznie występują — drugie pole zostaw na zerze. Jeżeli znasz pojemność wodną instalacji, dokładniejszy będzie tryb „Centralne ogrzewanie".',
      compute(v) {
        const r = expansionFromPower({
          height: +v.height,
          kwUfh: v.kwUfh, kwRad: v.kwRad,
          fluid: (REFLEX_FLUIDS[v.fluid] || REFLEX_FLUIDS[0])[1],
          sv25: v.sv === '2.5',
        });
        if (!r) return { error: 'Podaj moc przynajmniej jednego rodzaju instalacji.' };

        const rows = r.parts.map(p =>
          [p.label + ' — ' + fmt(p.kW, 1) + ' kW', fmt(p.v, 2) + ' l']);
        if (r.parts.length > 1) rows.push(['Razem z tablicy', fmt(r.vSum, 2) + ' l']);
        if (r.vFluid !== r.vSum) rows.push(['Po mnożniku dla płynu niezamarzającego', fmt(r.vFluid, 2) + ' l']);
        if (r.small) rows.push([`Zapas dla naczyń poniżej ${REFLEX_SMALL} l (+${r.H.extra} l)`, fmt(r.vExtra, 2) + ' l']);
        if (r.svApplied !== 1) rows.push([`Po mnożniku zaworu 2,5 bar (×${fmt(r.svApplied, 2)})`, fmt(r.vFinal, 2) + ' l']);
        rows.push(['Ciśnienie wstępne naczynia', fmt(r.H.p0, 1) + ' bar']);
        rows.push(['Ciśnienie początkowe instalacji', fmt(r.H.pStart, 1) + ' bar']);

        return {
          results: [
            { label: 'Pojemność obliczeniowa', icon: 'calc', value: fmt(r.vFinal, 1), unit: 'l',
              foot: `wysokość statyczna ${r.H.h} m · ciśnienie wstępne ${fmt(r.H.p0, 1)} bar` },
            { label: 'Dobrane naczynie', icon: 'box', value: String(r.rec), unit: 'l', small: true,
              foot: 'typoszereg producenta · ciśnienie początkowe instalacji ' + fmt(r.H.pStart, 1) + ' bar' },
          ],
          rows,
          warn: r.svMissing
            ? 'Dla wysokości 10 m tablica nie podaje mnożnika dla zaworu 2,5 bar — przy tej wysokości ciśnienie początkowe instalacji wynosi 1,6 bar i zawór 2,5 bar daje już bardzo mały zapas. Wynik policzony bez mnożnika; dobierz zawór 3,0 bar albo zweryfikuj dobór z producentem.'
            : (r.parts.length === 1 && r.parts[0].label === 'Ogrzewanie podłogowe' && r.parts[0].kW >= 15 && r.parts[0].kW <= 25
              ? 'Uwaga: w kolumnie ogrzewania podłogowego tablica źródłowa ma w okolicy 20–25 kW wyraźny przeskok wartości, którego nie ma w pozostałych kolumnach. Wynik z tego zakresu warto potwierdzić u producenta naczynia.'
              : null),
          addTo: { name: `Naczynie wzbiorcze przeponowe c.o. ${r.rec} l`,
                   tag: 'naczynie', unit: 'szt', cat: 'mat' },
        };
      },
    },
    { key: 'co', label: 'Centralne ogrzewanie',
      cards: [{ title: 'Instalacja c.o.', icon: 'fire', fields: [
        { k: 'vol', type: 'num', label: 'Pojemność wodna instalacji', unit: 'l', def: 150 },
        { k: 't', type: 'select', label: 'Maks. temperatura zasilania', def: 80,
          options: Object.keys(EXPANSION).map(t => ({ value: +t, label: t + ' °C' })) },
        { row: [
          { k: 'p0', type: 'num', label: 'Ciśnienie wstępne (p₀)', unit: 'bar', def: 1.5, step: 0.1 },
          { k: 'pw', type: 'num', label: 'Zawór bezp. (p_w)', unit: 'bar', def: 3, step: 0.1 },
        ]},
      ]}],
      tip: 'Ciśnienie wstępne naczynia ustaw co najmniej równe ciśnieniu statycznemu instalacji (wysokość słupa wody ÷ 10). Dla instalacji o wysokości 8 m to minimum 0,8 bar.',
      compute(v) {
        const n = EXPANSION[v.t];
        const r = expansionVessel(v.vol, n, v.p0, v.pw);
        if (!r) return { error: 'Ciśnienie zaworu bezpieczeństwa musi być większe niż ciśnienie wstępne.' };
        const inne = r.rec !== r.recBez;
        return {
          results: [
            { label: 'Minimalna pojemność naczynia', icon: 'calc', value: fmt(r.vn, 1), unit: 'l' },
            { label: 'Zalecany typoszereg', icon: 'box', value: String(r.rec), unit: 'l', small: true },
          ],
          rows: [
            ['Współczynnik rozszerzalności wody', n.toFixed(4).replace('.', ',')],
            ['Przyrost objętości Ve', fmt(r.ve, 2) + ' l'],
            ['Zapas wodny Vv', fmt(r.vv, 2) + ' l'],
            ['Bez zapasu wyszłoby', fmt(r.vnBez, 1) + ' l' + (inne ? ' → naczynie ' + r.recBez + ' l' : '')],
            ['Wzór', 'Vn = (Ve + Vv) × (p_w+1) / (p_w−p₀)'],
          ],
          warn: inne ? `Bez zapasu wodnego wyszłoby naczynie ${r.recBez} l zamiast ${r.rec} l. Zapas to woda, która ma zostać w naczyniu po wystygnięciu instalacji — bez niej układ zasysa powietrze.` : null,
          addTo: { name: `Naczynie wzbiorcze przeponowe c.o. ${r.rec} l`,
                   tag: 'naczynie', unit: 'szt', cat: 'mat' },
        };
      },
    },
    { key: 'cwu', label: 'Zasobnik c.w.u.',
      cards: [{ title: 'Zasobnik ciepłej wody', icon: 'drop', fields: [
        { k: 'vol', type: 'num', label: 'Pojemność zasobnika c.w.u.', unit: 'l', def: 200 },
        { k: 't', type: 'select', label: 'Maks. temperatura wody', def: 60,
          options: [40, 50, 60, 70, 80].map(t => ({ value: t, label: t + ' °C' })) },
        { row: [
          { k: 'p0', type: 'num', label: 'Ciśnienie wody (p₀)', unit: 'bar', def: 3.5, step: 0.1 },
          { k: 'pw', type: 'num', label: 'Zawór bezp. (p_w)', unit: 'bar', def: 6, step: 0.1 },
        ]},
      ]}],
      tip: 'Do c.w.u. musi być naczynie przeponowe przeznaczone do wody pitnej (z atestem higienicznym) — nie wolno stosować naczynia od c.o. Ciśnienie wstępne ustaw równe ciśnieniu wody w instalacji.',
      compute(v) {
        const n = EXPANSION[v.t] || EXPANSION[60];
        /* W c.w.u. nie doliczamy zapasu wodnego: zasobnik jest stale zasilany
           z wodociągu pod ciśnieniem, więc przy stygnięciu nie ma czego zasysać.
           Zapas wodny dotyczy zamkniętego obiegu c.o. */
        const r = expansionVessel(v.vol, n, v.p0, v.pw, { reserve: false });
        if (!r) return { error: 'Ciśnienie zaworu bezpieczeństwa musi być większe niż ciśnienie wody w instalacji.' };
        return {
          results: [
            { label: 'Minimalna pojemność naczynia', icon: 'calc', value: fmt(r.vn, 1), unit: 'l' },
            { label: 'Zalecany typoszereg', icon: 'box', value: String(r.rec), unit: 'l', small: true },
          ],
          rows: [
            ['Pojemność zasobnika', fmt(v.vol, 0) + ' l'],
            ['Przyrost objętości Ve', fmt(r.ve, 2) + ' l'],
            ['Zapas wodny', 'nie dotyczy — układ otwarty na wodociąg'],
            ['Wymagany atest', 'do wody pitnej (PZH)'],
          ],
          addTo: { name: `Naczynie przeponowe c.w.u. ${r.rec} l (atest do wody pitnej)`,
                   tag: 'naczynie_cwu', unit: 'szt', cat: 'mat' },
        };
      },
    },
  ],
},

/* ---------------- 6. PRZEKRÓJ RUROCIĄGU ---------------- */
{
  id: 'pipe', cat: 'pipes', icon: 'pipe',
  title: 'Przekrój rurociągu',
  desc: 'Dobór średnicy wg przepływu i prędkości',
  sub: 'Średnica dla zadanej mocy odcinka',
  cards: [
    { title: 'Parametry odcinka', icon: 'tune', fields: [
      { k: 'power', type: 'num', label: 'Moc przesyłana odcinkiem', unit: 'kW', def: 15 },
      { k: 'dt', type: 'num', label: 'Δt (zasilanie − powrót)', unit: '°C', def: 15 },
      { k: 'v', type: 'slider', label: 'Zalecana prędkość', min: 0.2, max: 1.5, step: 0.05, def: 0.6, suffix: ' m/s' },
      { k: 'mat', type: 'select', label: 'Materiał rury', def: 'copper',
        options: PIPE_MATERIALS.map(m => ({ value: m[0], label: m[1] })) },
    ]},
  ],
  tip: 'Typowe prędkości: 0,3–0,6 m/s przy instalacjach grawitacyjnych i w pomieszczeniach cichych, 0,6–1,0 m/s dla typowych instalacji pompowych, do 1,5 m/s dla pionów i rozdzielaczy. Polipropylen ma grube ścianki — przy tej samej średnicy zewnętrznej przepuszcza wyraźnie mniej niż miedź.',
  compute(v) {
    if (v.dt <= 0) return { error: 'Δt musi być większe od zera.' };
    const q = pumpFlow(v.power, v.dt);
    const s = selectPipe(q, v.mat, v.v);
    if (!s) return { error: 'Uzupełnij dane, aby obliczyć średnicę.' };
    const f = pipeFriction(q, s.inner, 1, v.mat);
    return {
      results: [
        { label: 'Zalecana średnica', icon: 'check', value: s.pick[0], unit: '',
          foot: `wymagane min. Ø wewn. ${fmt(s.needMm, 1)} mm · przepływ ${fmt(q, 3)} m³/h` },
        { label: 'Prędkość rzeczywista', icon: 'gauge', value: fmt(s.vAct, 2), unit: 'm/s', small: true },
      ],
      rows: [
        ['Średnica wewnętrzna', fmt(s.inner, 1) + ' mm'],
        ['Pojemność wodna rury', fmt(pipeLitersPerM(s.pick), 3) + ' l/m'],
        ['Opór jednostkowy', fmt(f.R, 0) + ' Pa/m'],
      ],
      warn: s.tooSmall ? 'Nawet największa rura z tego typoszeregu jest za mała — podziel przepływ na dwa obiegi.' : null,
    };
  },
},

/* ---------------- 7. ŚREDNICE CENTRALNEGO OGRZEWANIA ----------------
   Rozprowadzenie robi się na trzy sposoby i każdy liczy się inaczej,
   więc system wybiera się na samej górze ekranu — zanim zacznie się
   wpisywać grzejniki. Trójnikowy dzieli gałąź na odcinki, rozdzielaczowy
   nie ma gałęzi w ogóle, a Tichelmann ma dwie, zwężające się w przeciwne
   strony. ------------------------------------------------------------ */
{
  id: 'co_dia', cat: 'pipes', icon: 'layers',
  title: 'Ogrzewanie grzejnikowe',
  desc: 'Średnice do grzejników — trójnikowo albo z rozdzielacza',
  sub: 'Dobór średnic instalacji grzejnikowej',
  modes: [
    { key: 'troj', label: 'Trójnikowy',
      cards: [
        { title: 'Grzejniki zasilane odcinkiem', icon: 'layers', fields: [
          /* Z kotła wychodzi czasem jedna gałąź, a czasem dwie albo trzy —
             w mieszkaniu typowo jedna w lewo, druga w prawo. Dopóki
             przełącznik stoi na „jedna", ekran wygląda dokładnie tak jak
             dawniej; dopiero po przełączeniu przy każdym grzejniku pojawia
             się numer gałęzi. */
          { k: 'galezie', type: 'seg', label: 'Gałęzie wychodzące z kotła', def: 'nie',
            options: [{ value: 'nie', label: 'Jedna' }, { value: 'tak', label: 'Kilka' }] },
          { k: 'rad', type: 'numlist', label: 'Moc grzejnika', unit: 'W', def: [900, 1200, 750],
            addLabel: 'Dodaj grzejnik', nazwy: true, nazwaPrzyklad: 'np. Kuchnia', zbierane: true,
            galezie: true, grzejnik: true },
        ]},
        { title: 'Parametry odcinka', icon: 'tune', fields: [
          { k: 'reg', type: 'select', label: 'Parametry pracy instalacji', def: 1,
            options: opts(REGIMES_CO, r => r[0] + '  ·  Δt ' + r[1] + ' K')
              .concat([{ value: -1, label: 'Własne Δt' }]) },
          { k: 'dt', type: 'num', label: 'Δt (zasilanie − powrót)', unit: '°C', def: 15,
            when: v => Number(v.reg) === -1 },
          { k: 'v', type: 'slider', label: 'Zalecana prędkość', min: 0.2, max: 1.5, step: 0.05, def: 0.6, suffix: ' m/s' },
          { k: 'mat', type: 'select', label: 'Materiał rury', def: 'copper',
            options: PIPE_MATERIALS.map(m => ({ value: m[0], label: m[1] })) },
          { k: 'kociol', type: 'select', label: 'Przyłącze kotła', def: 'g34',
            options: PRZYLACZA_KOTLA.map(x => ({ value: x[0], label: x[1] })) },
          /* Do doboru pompy w schemacie kotłowni: długość trasy liczy się w oporach. */
          { k: 'dlZr', type: 'num', label: 'Rura od źródła do najdalszego grzejnika (w jedną stronę, z pionem)', unit: 'm', def: '', step: 1 },
        ]},
      ],
      tip: 'Parametry pracy: 75/65 to kocioł starego typu, 70/55 typowa instalacja grzejnikowa, 60/45 kocioł kondensacyjny, 55/45 instalacja niskotemperaturowa, 45/35 pompa ciepła z grzejnikami, 35/28 ogrzewanie podłogowe. Grzejniki wpisuj w kolejności od kotła: pierwszy na liście jest najbliżej. Aplikacja policzy każdy odcinek osobno — na odcinku przed pierwszym grzejnikiem płynie woda do wszystkich, przed ostatnim już tylko do niego. Uwaga na drugą stronę medalu: zbyt cienka rura hałasuje, ale zbyt wolny przepływ nie wynosi powietrza z instalacji i grzejnik potrafi zapowietrzać się w kółko. Sama temperatura zasilania nie zmienia doboru średnicy — robi to wyłącznie Δt.\n\nGałęzi od kotła bywa kilka: w mieszkaniu typowo jedna idzie w lewo, druga w prawo. Przełącznik na górze otwiera przy każdym grzejniku wybór gałęzi, a aplikacja liczy wtedy każdą osobno i dokłada odcinek wspólny — ten kawałek od kotła do rozwidlenia, którym płynie woda do wszystkich grzejników naraz. To on wychodzi najgrubszy i to on decyduje o rurze w kotłowni. Rysunek robi się osobny dla każdej gałęzi, bo rozgałęzienie na jednym obrazku robi się nieczytelne; średnica odcinka wspólnego stoi w tytule każdego z nich.\n\nPrzyłącze kotła dotyczy samego podejścia — tego metra rury, który jest wkręcony w króciec. Kocioł gazowy wiszący ma zwykle króćce 3/4\", więc cieńszej rury nie da się tam wpiąć bez przewężenia na samym wyjściu — i stąd bierze się to, co widać w projektach: przy kotle rura jest „o rozmiar większa\", niż wynikałoby z prędkości. To nie zapas projektanta, tylko narzucony wymiar. Ale obowiązuje krótko: na rozwinięciu widać Ø20 na czterdziestu centymetrach i zaraz za nim Ø18 na całej gałęzi, bo za króćcem nic już nie jest do kotła przykręcone. Dlatego aplikacja liczy całą instalację z prędkości, a przy wyniku dopisuje tylko, jaką rurę kupić na to podejście — licz około metra. Granicę mierzymy średnicą zewnętrzną, nie światłem: miedź 22×1 ma w środku 20 mm, stal zaciskowa 22×1,5 tylko 19, a obie wpina się w ten sam gwint 3/4\". Jeżeli nie chcesz tego ograniczenia, wybierz „Nie ograniczaj\".\n\nZasobnik c.w.u. liczy się osobno od instalacji grzewczej, bo kocioł ma dwie niezależne nastawy: jedną dla obiegu, drugą dla ciepłej wody. Ładując zasobnik przerzuca zawór trójdrogowy i pali na nastawie c.w.u. — grzejniki mogą chodzić na 55 °C, a wężownica dostawać 75. Dlatego moc wężownicy bierze się z pola „Nastawa c.w.u. w kotle", a nie z parametrów instalacji.',
      compute(v) {
        /* Pomieszczenie z dwoma grzejnikami liczy się jako dwie pozycje —
           każdy grzejnik ma swoje podejście i swój odcinek. */
        if (typeof rozwinPodzial === 'function') v = rozwinPodzial(v);
        const list = (v.rad || []).filter(x => x > 0);
        if (!list.length) return { error: 'Dodaj przynajmniej jeden grzejnik z mocą.' };

        const reg = Number(v.reg);
        const dt = reg === -1 ? v.dt : (REGIMES_CO[reg] || REGIMES_CO[1])[1];
        if (!(dt > 0)) return { error: 'Δt musi być większe od zera.' };

        /* Króciec kotła jest dolną granicą dla odcinka, który z kotła
           wychodzi — i tylko dla niego. Dalej gałąź schodzi normalnie, bo
           tam już nic nie jest przykręcone do kotła. */
        const przyl = PRZYLACZA_KOTLA.find(x => x[0] === v.kociol) || PRZYLACZA_KOTLA[0];
        const minKociol = przyl[2];

        const nazwy = nazwyGrzejnikow(v.radNazwy, list.length);
        /* Numer gałęzi leży w osobnej tablicy, pod tym samym indeksem co moc.
           Brak wpisu znaczy gałąź pierwszą — dzięki temu stare zapisy i dane
           dopisane z kalkulatora działają bez przerabiania. */
        const wiele = v.galezie === 'tak';
        const idx = (v.rad || []).map((x, i) => i).filter(i => Number(v.rad[i]) > 0);
        const galazPoz = i => wiele ? (Number((v.radGalaz || [])[idx[i]]) || 1) : 1;

        /* Grzejnik dobrany do każdej pozycji — typ i wymiar idą na rysunek,
           żeby monter wiedział, co gdzie wisi. Średnice liczą się dalej
           z zapotrzebowania pomieszczenia, nie z mocy wybranego grzejnika. */
        const grzRys = typeof grzDoRysunku === 'function' ? grzDoRysunku(v, idx) : [];
        const numery = [];
        list.forEach((w, i) => { const g = galazPoz(i); if (numery.indexOf(g) < 0) numery.push(g); });
        numery.sort((a, b) => a - b);

        /* Każda gałąź liczy się osobno, dokładnie tak jak liczyła się jedna:
           pierwszy odcinek niesie wodę do wszystkich grzejników tej gałęzi,
           każdy kolejny o jeden mniej. */
        const galezie = numery.map(g => {
          const poz = list.map((w, i) => ({ w, nazwa: nazwy[i], grz: grzRys[i] })).filter((x, i) => galazPoz(i) === g);
          const moce = poz.map(x => x.w);
          const suma = moce.reduce((a, b) => a + b, 0);
          const odcinki = [];
          let zostalo = suma;
          for (let i = 0; i < moce.length; i++) {
            const qq = pumpFlow(zostalo / 1000, dt);
            /* Gdy gałąź jest jedna, jej pierwszy odcinek wychodzi wprost
               z kotła i to jego dotyczy króciec. Gdy gałęzi jest kilka,
               z kotła wychodzi odcinek wspólny i granica należy do niego. */
            const ss = selectPipe(qq, v.mat, v.v);
            odcinki.push({ nr: i + 1, ile: moce.length - i, moc: zostalo, q: qq, s: ss });
            zostalo -= moce[i];
          }
          return { g, poz, moce, suma, odcinki };
        });

        const suma = list.reduce((a, b) => a + b, 0);
        /* Odcinek wspólny: wszystko, co kocioł wysyła, zanim rozejdzie się
           na gałęzie. Przy jednej gałęzi nie ma czego liczyć osobno. */
        const qWsp = pumpFlow(suma / 1000, dt);
        const wspolny = numery.length > 1
          ? { moc: suma, q: qWsp, s: selectPipe(qWsp, v.mat, v.v) } : null;
        const przyKotle = wspolny || galezie[0].odcinki[0];

        /* Króciec kotła narzuca rozmiar samemu podejściu — temu metrowi rury,
           który jest w niego wkręcony. Dalej instalacja schodzi tak, jak każe
           prędkość, i tak to robią projektanci: na rozwinięciu widać Ø20 na
           czterdziestu centymetrach, a zaraz za nim Ø18 na całej gałęzi.
           Wcześniej liczyliśmy w rozmiarze króćca cały odcinek przy kotle,
           co potrafiło dołożyć kilka metrów grubszej rury do zamówienia. */
        const sPod = selectPipe(przyKotle.q, v.mat, v.v, minKociol);
        const podejscie = sPod && sPod.zPrzylacza ? sPod : null;

        const wszystkie = galezie.reduce((a, b) => a.concat(b.odcinki.map(o =>
          Object.assign({ gal: b.g }, o))), []);
        const wolne = wszystkie.filter(o => o.s.vAct < V_MIN_CO)
          .concat(wspolny && wspolny.s.vAct < V_MIN_CO ? [{ gal: 0, nr: 0, s: wspolny.s }] : []);
        const opisOdc = o => (wiele && numery.length > 1 ? o.gal + '.' : '') + o.nr;

        const tabelaGal = b => b.odcinki.map((o, i) => {
          const zmiana = i > 0 && o.s.pick[0] !== b.odcinki[i - 1].s.pick[0];
          const powoli = o.s.vAct < V_MIN_CO;
          return `<div class="seg-row${zmiana ? ' seg-change' : ''}">
            <span class="seg-n">${o.nr}</span>
            <span class="seg-t"><strong>${o.s.pick[0]}</strong>
              <span>do ${o.ile} ${o.ile === 1 ? 'grzejnika' : 'grzejników'} · ${fmt(o.moc, 0)} W</span></span>
            <span class="seg-v${powoli ? ' slow' : ''}">${fmt(o.s.vAct, 2)}<span>m/s</span></span>
          </div>`;
        }).join('');

        const extra = (wspolny
          ? `<div class="subhead">Odcinek wspólny od kotła</div><div class="segs">`
            + `<div class="seg-row"><span class="seg-n">K</span>`
            + `<span class="seg-t"><strong>${wspolny.s.pick[0]}</strong>`
            + `<span>do wszystkich ${list.length} grzejników · ${fmt(suma, 0)} W</span></span>`
            + `<span class="seg-v${wspolny.s.vAct < V_MIN_CO ? ' slow' : ''}">`
            + `${fmt(wspolny.s.vAct, 2)}<span>m/s</span></span></div></div>`
          : '')
          + galezie.map(b => `<div class="subhead">`
            + (numery.length > 1 ? `Gałąź ${b.g} — ${fmt(b.suma, 0)} W` : 'Średnica odcinek po odcinku')
            + `</div><div class="segs">${tabelaGal(b)}</div>`).join('');

        /* Wszystkie gałęzie na jednym rysunku, jedna pod drugą, związane
           wspólnym pionem przy kotle — tak jak na rozwinięciu w projekcie.
           Osobne arkusze na gałąź byłyby łatwiejsze do narysowania, ale
           instalator musiałby je sobie składać w głowie. */
        const doRysunku = b => b.odcinki.map((o, i) => ({
          nazwa: b.poz[i].nazwa,
          nr: i + 1,
          wlasna: fmt(b.moce[i], 0) + ' W',
          srednica: o.s.pick[0],
          opis: fmt(o.moc, 0) + ' W',
          grz: b.poz[i].grz || null,
        }));
        const rezimRys = typeof grzRezim === 'function' ? grzRezim(v) : null;
        const zestawienie = (() => {
          const m = {};
          grzRys.forEach(g => { if (g) { if (!m[g.opis]) m[g.opis] = { opis: g.opis, ile: 0, drab: !!g.drab }; m[g.opis].ile++; } });
          return Object.keys(m).map(k => m[k]);
        })();
        const schemat = numery.length > 1 ? {
          rodzaj: 'co', uklad: 'galezie',
          tytul: `Instalacja grzejnikowa — ${numery.length} gałęzie`,
          galazka: pipeList(v.mat)[0][0],
          wspolny: { srednica: wspolny.s.pick[0], opis: fmt(suma, 0) + ' W' },
          podejscie: podejscie ? podejscie.pick[0] : null,
          rezim: rezimRys ? rezimRys.etykieta : null,
          zestawienie,
          galezie: galezie.map(b => ({
            nr: b.g,
            opis: fmt(b.suma, 0) + ' W',
            odcinki: doRysunku(b),
          })),
        } : {
          rodzaj: 'co', tytul: 'Gałąź grzejnikowa',
          galazka: pipeList(v.mat)[0][0],
          zasobnik: null,
          podejscie: podejscie ? podejscie.pick[0] : null,
          rezim: rezimRys ? rezimRys.etykieta : null,
          zestawienie,
          odcinki: doRysunku(galezie[0]),
        };

        return {
          /* Na rysunku każdy grzejnik ma numer, nazwę pomieszczenia i swoją
             własną moc — po to, żeby monter rozpakowujący dostawę wiedział,
             który grzejnik gdzie idzie. Pod magistralą zostaje moc, jaką
             ten odcinek jeszcze niesie, bo to co innego. */
          schemat,
          results: [
            { label: wspolny ? 'Odcinek wspólny przy kotle' : 'Odcinek przy kotle',
              icon: 'check', value: przyKotle.s.pick[0], unit: '',
              foot: `${list.length} grzejników · ${fmt(przyKotle.moc, 0)} W · Δt ${fmt(dt, 0)} °C · przepływ ${fmt(przyKotle.q, 3)} m³/h`
                + (podejscie ? ` · samo podejście przy kotle ${podejscie.pick[0]}` : '') },
            { label: 'Prędkość rzeczywista', icon: 'gauge', value: fmt(przyKotle.s.vAct, 2), unit: 'm/s', small: true },
          ].concat(coPompaKarta(pompaGrzejnikowa(przyKotle.q, przyKotle.s, v.mat, Number(v.dlZr) || 0, false))),
          extra,
          rows: [
            ['Δt przyjęte do obliczeń', fmt(dt, 0) + ' °C'],
          ].concat(minKociol > 0 ? [
            ['Przyłącze kotła', przyl[1] + (podejscie
              ? ' — podejście przy kotle ' + podejscie.pick[0]
                + ', dalej ' + przyKotle.s.pick[0] + ' (licz ok. 1 m grubszej rury)'
              : ' — prędkość i tak wymagała grubszej rury')],
          ] : []).concat(numery.length > 1
            ? galezie.map(b => ['Gałąź ' + b.g,
                b.moce.length + (b.moce.length === 1 ? ' grzejnik · ' : ' grzejniki · ')
                + fmt(b.suma, 0) + ' W · od ' + b.odcinki[0].s.pick[0]
                + ' do ' + b.odcinki[b.odcinki.length - 1].s.pick[0]])
            : []).concat([
            ['Zmiana średnicy', (() => {
              const op = galezie.map(b => {
                const z = b.odcinki.filter((o, i) => i > 0 && o.s.pick[0] !== b.odcinki[i - 1].s.pick[0]);
                return z.length ? (numery.length > 1 ? 'gałąź ' + b.g + ': ' : 'na odcinku ')
                  + z.map(x => x.nr).join(', ') : '';
              }).filter(Boolean);
              return op.length ? op.join(' · ')
                : 'nie ma gdzie zejść — jedna średnica na całej gałęzi';
            })()],
            ['Zbyt wolny przepływ', wolne.length
              ? (wolne.length === 1 ? 'odcinek ' : 'odcinki ')
                + wolne.map(o => o.nr === 0 ? 'wspólny' : opisOdc(o)).join(', ')
                + ' (poniżej ' + fmt(V_MIN_CO, 2) + ' m/s)'
              : 'nie występuje'],
          ]),
          warn: [wolne.length
            ? `Na ${wolne.length === 1 ? 'odcinku' : 'odcinkach'} ${wolne.map(o => o.nr === 0 ? 'wspólnym' : opisOdc(o)).join(', ')} woda płynie wolniej niż ${fmt(V_MIN_CO, 2)} m/s. Tam rura jest już najcieńsza z typoszeregu, więc nie ma jak przyspieszyć — pilnuj odpowietrzenia, bo tak wolny przepływ nie wynosi pęcherzyków powietrza.`
            : ''].filter(Boolean).join(' ') || null,
        };
      },
    },
    /* ---------- ROZDZIELACZOWY (c.o.) ----------
       W rozdzielaczu nie ma magistrali, więc nie ma czego dzielić na odcinki.
       Do każdego grzejnika idzie osobna nitka i w praktyce zawsze jest to
       PE-X 16×2 — więc nie dobieramy jej średnicy, tylko sprawdzamy, czy
       przy tej mocy 16 wystarcza. Liczy się za to średnica dojścia od źródła
       do rozdzielacza, bo ta wynika z sumy mocy wszystkich obiegów. */
    { key: 'rozdz', label: 'Rozdzielaczowy',
      cards: [
        { title: 'Grzejniki na rozdzielaczu', icon: 'layers', fields: [
          { k: 'rad', type: 'numlist', label: 'Moc grzejnika', unit: 'W', def: [900, 1200, 750, 1400],
            addLabel: 'Dodaj grzejnik', nazwy: true, nazwaPrzyklad: 'np. Kuchnia', zbierane: true },
        ]},
        { title: 'Dojście od źródła do rozdzielacza', icon: 'tune', fields: [
          { k: 'reg', type: 'select', label: 'Parametry pracy instalacji', def: 1,
            options: opts(REGIMES_CO, r => r[0] + '  ·  Δt ' + r[1] + ' K')
              .concat([{ value: -1, label: 'Własne Δt' }]) },
          { k: 'dt', type: 'num', label: 'Δt (zasilanie − powrót)', unit: '°C', def: 15,
            when: v => Number(v.reg) === -1 },
          { k: 'v', type: 'slider', label: 'Zalecana prędkość', min: 0.2, max: 1.5, step: 0.05, def: 0.6, suffix: ' m/s' },
          { k: 'mat', type: 'select', label: 'Materiał rury dojścia', def: 'copper',
            options: PIPE_MATERIALS.map(m => ({ value: m[0], label: m[1] })) },
          { k: 'kociol', type: 'select', label: 'Przyłącze kotła', def: 'g34',
            options: PRZYLACZA_KOTLA.map(x => ({ value: x[0], label: x[1] })) },
          /* Do doboru pompy w schemacie kotłowni: długość trasy liczy się w oporach. */
          { k: 'dlZr', type: 'num', label: 'Rura od źródła do najdalszego grzejnika (w jedną stronę, z pionem)', unit: 'm', def: '', step: 1 },
        ]},
      ],
      tip: 'W układzie rozdzielaczowym każdy grzejnik ma własną nitkę prosto z rozdzielacza i własny zawór — można go odciąć albo wyregulować bez ruszania reszty. Nitki kładzie się jedną średnicą, PE-X 16×2, i dlatego aplikacja ich nie dobiera, tylko sprawdza: przy Δt 15 °C rura 16 przenosi około pięciu i pół kilowata, zanim prędkość zrobi się kłopotliwa, więc w domu jednorodzinnym wystarcza praktycznie zawsze. Ostrzeżenie pojawi się dopiero przy naprawdę dużym grzejniku albo przy małym Δt.\n\nDobiera się za to dojście od źródła ciepła do rozdzielacza — tamtędy płynie woda do wszystkich obiegów naraz, więc ta jedna rura decyduje o całości. Liczba wyjść to liczba grzejników; przy zakupie warto wziąć rozdzielacz o jedno wyjście większy, bo dołożenie grzejnika po latach jest wtedy kwestią godziny, a nie przebijania ściany.\n\nDługości pętli nie pytamy, bo do doboru średnicy nic nie wnosi — wpływa na opory i na dobór pompy, a to liczy osobny kalkulator.',
      compute(v) {
        /* Pomieszczenie z dwoma grzejnikami liczy się jako dwie pozycje —
           każdy grzejnik ma swoje podejście i swój odcinek. */
        if (typeof rozwinPodzial === 'function') v = rozwinPodzial(v);
        const list = (v.rad || []).filter(x => x > 0);
        if (!list.length) return { error: 'Dodaj przynajmniej jeden grzejnik z mocą.' };

        const reg = Number(v.reg);
        const dt = reg === -1 ? v.dt : (REGIMES_CO[reg] || REGIMES_CO[1])[1];
        if (!(dt > 0)) return { error: 'Δt musi być większe od zera.' };

        const nitka = NITKA_ROZDZ;
        const nazwy = nazwyGrzejnikow(v.radNazwy, list.length);
        const nazwa = i => nazwy[i];

        /* Każda pętla osobno: przepływ z mocy tego jednego grzejnika,
           prędkość w rurze 16×2. Za szybko znaczy szum i duże opory. */
        const petle = list.map((moc, i) => {
          const q = pumpFlow(moc / 1000, dt);
          const vAct = (q / 3600) / (Math.PI * Math.pow(pipeInner(nitka) / 1000, 2) / 4);
          return { nr: i + 1, nazwa: nazwa(i), moc, q, vAct, zaSzybko: vAct > V_MAX_NITKA };
        });

        const suma = list.reduce((a, b) => a + b, 0);
        /* Rura do rozdzielacza niesie wszystkie obiegi grzejnikowe, a jeżeli
           zasobnik stoi dalej od kotła — także ładowanie wężownicy. */
        const qDoj = pumpFlow(suma / 1000, dt);
        /* Dojście wychodzi wprost z kotła, więc jego króciec jest dolną
           granicą tak samo jak przy gałęzi trójnikowej. */
        const przyl = PRZYLACZA_KOTLA.find(x => x[0] === v.kociol) || PRZYLACZA_KOTLA[0];
        const doj = selectPipe(qDoj, v.mat, v.v);
        /* Króciec kotła obowiązuje samo podejście, nie całe dojście — tak samo
           jak przy gałęzi trójnikowej. */
        const sPod = selectPipe(qDoj, v.mat, v.v, przyl[2]);
        const podejscie = sPod && sPod.zPrzylacza ? sPod : null;
        const szybkie = petle.filter(p => p.zaSzybko);

        const tabela = petle.map(p => `<div class="seg-row${p.zaSzybko ? ' seg-change' : ''}">
          <span class="seg-n">${p.nr}</span>
          <span class="seg-t"><strong>${esc(p.nazwa)}</strong>
            <span>${esc(nitka[0])} PE-X · ${fmt(p.moc, 0)} W · ${fmt(p.q, 3)} m³/h</span></span>
          <span class="seg-v${p.zaSzybko ? ' slow' : ''}">${fmt(p.vAct, 2)}<span>m/s</span></span>
        </div>`).join('');

        return {
          schemat: {
            rodzaj: 'co', uklad: 'rozdzielacz', tytul: 'Rozdzielacz c.o.',
            galazka: nitka[0],
            dojscie: doj.pick[0],
            zasobnik: null,
            odcinki: petle.map(p => ({
              nazwa: p.nazwa, nr: p.nr, wlasna: fmt(p.moc, 0) + ' W',
              srednica: nitka[0], opis: fmt(p.q, 3) + ' m³/h',
            })),
          },
          results: [
            { label: 'Dojście do rozdzielacza', icon: 'check', value: doj.pick[0], unit: '',
              foot: `${list.length} ${list.length === 1 ? 'obieg' : 'obiegów'} · ${fmt(suma, 0)} W`
                + ` · Δt ${fmt(dt, 0)} °C · przepływ ${fmt(qDoj, 3)} m³/h`
                + (podejscie ? ` · samo podejście przy kotle ${podejscie.pick[0]}` : '') },
            { label: 'Rozdzielacz', icon: 'list', value: String(list.length), unit: odmianaWyjsc(list.length), small: true,
              foot: 'przy zakupie warto wziąć o jedno wyjście więcej — na grzejnik dołożony później' },
          ].concat(coPompaKarta(pompaGrzejnikowa(qDoj, doj, v.mat, Number(v.dlZr) || 0, true))),
          extra: `<div class="subhead">Pętle z rozdzielacza — wszystkie ${esc(nitka[0])}</div>`
            + `<div class="segs">${tabela}</div>`,
          rows: [
            ['Δt przyjęte do obliczeń', fmt(dt, 0) + ' °C'],
            ['Nitka do grzejnika', nitka[0] + ' PE-X  ·  Ø wewn. ' + fmt(pipeInner(nitka), 1) + ' mm'],
            ['Prędkość w dojściu', fmt(doj.vAct, 2) + ' m/s'],
          ].concat(przyl[2] > 0 ? [
            ['Przyłącze kotła', przyl[1] + (podejscie
              ? ' — podejście przy kotle ' + podejscie.pick[0]
                + ', dalej ' + doj.pick[0] + ' (licz ok. 1 m grubszej rury)'
              : ' — prędkość i tak wymagała grubszej rury')],
          ] : []).concat([
            ['Łączna moc obiegów', fmt(suma, 0) + ' W', true],
          ]),
          warn: [szybkie.length
            ? `Na ${szybkie.length === 1 ? 'pętli' : 'pętlach'} ${szybkie.map(p => p.nr).join(', ')} woda w rurze ${nitka[0]} płynie szybciej niż ${fmt(V_MAX_NITKA, 1)} m/s. Przy takim grzejniku daj grubszą nitkę albo podnieś Δt.`
            : (doj.tooSmall
              ? 'Nawet największa rura z tego typoszeregu jest za mała na dojście do rozdzielacza — podziel instalację na dwa rozdzielacze.'
              : '')].filter(Boolean).join(' ') || null,
        };
      },
    },

  ],
},

/* ---------------- 7b. ŚREDNICE DO ROZDZIELACZY ---------------- */
{
  id: 'rozdz_dia', cat: 'pipes', icon: 'floor',
  title: 'Ogrzewanie podłogowe',
  desc: 'Średnice do rozdzielaczy i zawór mieszający',
  sub: 'Doprowadzenia od źródła ciepła',
  cards: [
    { title: 'Rozdzielacze w budynku', icon: 'list', fields: [
      /* Dwa rozdzielacze na start, ale wyraźnie opisane jako przykład —
         i znikające przy pierwszym prawdziwym ruchu. Wcześniej wyglądały
         jak dane: instalator dopisywał pokój o dwóch pętlach do Parteru,
         który „już miał" sześć, widział osiem i miał pełne prawo sądzić,
         że jego wynik przepadł. Rozdzielacz ma mieć tyle mocy i tyle wyjść,
         ile mu naprawdę dołożono, i ani wata więcej. */
      { k: 'rozdz', type: 'rozdzlist', addLabel: 'Dodaj rozdzielacz', zbierane: true,
        def: [
          { nazwa: 'Parter', w: 6000, wyj: 6, dl: 8, dp: 15, przyklad: true },
          { nazwa: 'Piętro', w: 4500, wyj: 5, dl: 14, dp: 18, przyklad: true },
        ] },
    ]},
    { title: 'Źródło ciepła', icon: 'therm', fields: [
      { k: 'mie', type: 'seg', def: 'mieszacz', options: [
        { value: 'mieszacz', label: 'Z zaworem mieszającym' },
        { value: 'nisko', label: 'Zasilanie niskim parametrem' },
      ]},
      /* Gdzie stoi mieszacz, zmienia dobór zaworu: wspólny przepuszcza cały
         obieg podłogowy, a przy każdym rozdzielaczu — tylko jego wodę. */
      { k: 'mieGdzie', type: 'seg', def: 'osob', options: [
        { value: 'wsp', label: 'Jeden mieszacz w kotłowni' },
        { value: 'osob', label: 'Mieszacz przy każdym rozdzielaczu' },
      ], when: v => v.mie !== 'nisko' && (v.rozdz || []).length > 1 },
      { k: 'dtp', type: 'select', label: 'Δt obiegu podłogowego', def: 0,
        options: opts(DT_PODLOGOWKA, x => x[0]) },
      /* Parametry kotła mają sens tylko wtedy, gdy przy rozdzielaczu stoi
         mieszacz. Bez niego źródło pracuje wprost na parametrach podłogówki
         i jest to jeden i ten sam obieg — dwa pola opisujące to samo tylko
         pozwalałyby wpisać dwie sprzeczne liczby. */
      { k: 'reg', type: 'select', label: 'Na czym pracuje kocioł', def: 1,
        options: opts(REGIMES_CO, r => r[0] + '  ·  Δt ' + r[1] + ' K')
          .concat([{ value: -1, label: 'Własne Δt' }]),
        when: v => v.mie !== 'nisko' },
      { k: 'dt', type: 'num', label: 'Własne Δt kotła (zasilanie − powrót)', unit: '°C', def: 15,
        when: v => v.mie !== 'nisko' && Number(v.reg) === -1 },
    ]},
    { title: 'Rura od źródła do rozdzielaczy', icon: 'pipe', fields: [
      { k: 'v', type: 'slider', label: 'Prędkość wody w rurze',
        min: 0.2, max: 1.5, step: 0.05, def: 0.6, suffix: ' m/s' },
      { k: 'mat', type: 'select', label: 'Z czego jest rura', def: 'copper',
        options: PIPE_MATERIALS.map(m => ({ value: m[0], label: m[1] })) },
      /* Zapas na kształtki i armaturę, której nie wpisaliśmy z osobna.
         Domyślnie dziesięć procent, bo trochę zawsze się znajdzie, ale
         suwak zostaje — narzut ma być świadomy, a nie wbudowany po cichu. */
      { k: 'zapas', type: 'slider', label: 'Zapas na kształtki i armaturę',
        min: 0, max: 50, step: 5, def: 10, suffix: '%' },
    ]},
  ],
  tip: 'Karta „Źródło ciepła" opisuje to, co jest przed rozdzielaczem. Parametry pracy kotła pokazują się tylko przy grupie mieszającej — i wtedy robią dwie rzeczy naraz: z ich Δt wychodzi średnica rury od kotła, bo płynie nią woda kotłowa, a nie zmieszana, a z temperatury zasilania moc wężownicy zasobnika.\n\nPrzy zasilaniu niskim parametrem tych pól nie ma i nie ma ich po co mieć: źródło pracuje wprost na parametrach podłogówki, więc rura od niego niesie tę samą wodę co pętle i liczy się ją tym samym Δt. To jeden obieg, nie dwa.\n\nZasobnik c.w.u. jest osobną sprawą i dlatego ma własne pole „Nastawa c.w.u. w kotle". Kocioł ma dwie niezależne nastawy: jedną dla obiegu grzewczego, drugą dla ciepłej wody. Gdy ładuje zasobnik, przerzuca zawór trójdrogowy i pali na tej drugiej — podłogówka może chodzić na 39 °C, a wężownica w tym samym kotle dostawać 79. To nie są naczynia połączone i zmiana parametrów ogrzewania nie rusza mocy wężownicy ani o wat.\n\nRura do rozdzielacza podłogówki jest grubsza, niż większości się wydaje, i powód jest jeden: Δt. Instalacja grzejnikowa pracuje na piętnastu kelwinach, podłogówka na pięciu do siedmiu — przy tej samej mocy przepływ wychodzi więc dwa, trzy razy większy, a rura o rozmiar albo dwa grubsza.\n\nAle to obowiązuje tylko wtedy, gdy rozdzielacz jest zasilany wprost niskim parametrem — z pompy ciepła albo z bufora. Jeżeli przy rozdzielaczu stoi grupa mieszająca, a przy kotle gazowym stoi tam prawie zawsze, to rura od kotła jest po stronie pierwotnej: płynie nią gorąca woda z Δt kotła, więc przepływ jest mały i rura cienka. Ta jedna decyzja potrafi zmienić wynik o dwa rozmiary, dlatego pytamy o nią osobno.\n\nZawór mieszający dobieramy tak, jak każe producent: z przepływu, który naprawdę przez niego płynie — bo pompa stoi za zaworem i przepycha przez niego wszystko, co idzie dalej. Przy jednym mieszaczu w kotłowni to cały obieg podłogowy wszystkich rozdzielaczy, a przy mieszaczu w każdej szafce tylko woda jej rozdzielacza, więc każdy dostaje własny, mniejszy zawór. Szukamy Kvs, przy którym spadek na zaworze mieści się w paśmie od 3 do 15 kPa, i bierzemy mniejszą z pasujących wartości. Mniejszy zawór lepiej reguluje: pracuje na większym otwarciu, więc drobny ruch siłownika nie wywraca temperatury podłogi. Kvs to przepływ w metrach sześciennych na godzinę przy jednym barze różnicy ciśnień, a spadek przy innym przepływie liczy się ze wzoru Δp = (Q / Kvs)². Podana średnica to najmniejszy korpus, w którym dany Kvs występuje — ten sam Kvs bywa też w większym korpusie i wtedy warto go wziąć, jeśli rura jest grubsza od gwintu zaworu.\n\nKorpus rozdzielacza sprawdzamy przy Δt obiegu podłogowego, bo belką płynie już woda zmieszana, po stronie wtórnej. Calowa belka wystarcza w domu jednorodzinnym niemal zawsze; pięć czwartych przydaje się przy kilkunastu obiegach albo bardzo małym Δt.\n\nZasobnik c.w.u. ładuje się wprost od źródła, gorącą wodą, obok grupy mieszającej — więc nie wchodzi ani w belkę, ani w dobór zaworu. Wchodzi natomiast w moc, którą musi mieć kocioł, a jeżeli stoi dalej niż kilka metrów, to także w średnicę odcinka wspólnego.\n\nWysokość rozdzielacza nad źródłem — rozdzielacz na piętrze, kocioł w kotłowni — nie obciąża pompy ani o metr. Instalacja jest zamknięta i pełna: słup wody w rurze zasilającej ciągnie w dół dokładnie tyle samo, ile waży słup na powrocie, więc pion się znosi. Pompa pokonuje wyłącznie opory przepływu, tak samo na parterze, jak na trzecim piętrze. Pompa, która musi „podnieść wodę na piętro”, to najczęstsze nieporozumienie przy doborze i powód, dla którego w domach jednorodzinnych stoją pompy o dwa numery za duże. Na średnicę rury wysokość też nie ma wpływu: przekrój wychodzi z przepływu i z dopuszczalnej prędkości, a te od wysokości nie zależą.\n\nPion liczy się natomiast w metrach rury — to też rura i jego opory są jak najbardziej realne. Dlatego pole „Rura od źródła” ma obejmować całą trasę razem z wyjściem na górę, a nie odległość zmierzoną po rzucie. I liczy się w ciśnieniu: w najwyższym punkcie musi zostać nadwyżka ponad zero, bo inaczej odpowietrznik zamiast wypuszczać powietrze zaczyna je zasysać. Ciśnienie napełnienia i nastawę naczynia policzysz w kalkulatorze „Naczynie wzbiorcze” — tam jest pole wysokości statycznej i tablice producenta. Warto też pamiętać, że najwyższy rozdzielacz zbiera powietrze z całej instalacji i musi mieć czym je oddać.\n\nInaczej jest tylko w instalacji otwartej, ze zbiornikiem przelewowym na poddaszu — ale tych się dziś nie buduje i ta aplikacja ich nie liczy.\n\nRozdzielacz grzejnikowy licz w kalkulatorze ogrzewania grzejnikowego, w trybie rozdzielaczowym — tutaj są same obiegi podłogowe, bo jedne i drugie pracują na innych parametrach i mieszanie ich w jednej tabeli tylko myli.',
  compute(v) {
    const lista = (v.rozdz || []).filter(r => Number(r.w) > 0);
    if (!lista.length) {
      return { error: (v.rozdz || []).length
        ? 'Rozdzielacz jest pusty. Wpisz jego moc albo dopisz pomieszczenia z kalkulatora '
          + 'ogrzewania podłogowego — guzik „Dopisz do rozdzielaczy" pod wynikiem.'
        : 'Nie ma jeszcze żadnego rozdzielacza. Policz podłogówkę pomieszczenie po pomieszczeniu '
          + 'i dopisuj wyniki guzikiem „Dopisz do rozdzielaczy", albo dodaj rozdzielacz ręcznie '
          + 'i wpisz jego moc.' };
    }

    const mieszacz = v.mie !== 'nisko';
    const dtPod = (DT_PODLOGOWKA[Number(v.dtp)] || DT_PODLOGOWKA[0])[1];
    const reg = Number(v.reg);

    /* Bez mieszacza źródło pracuje na parametrach podłogówki — rura od niego
       niesie tę samą wodę, co pętle, więc Δt jest jedno i to samo. Osobno
       zostaje tylko temperatura ładowania zasobnika, bo przy niej pompa
       ciepła podnosi zasilanie. */
    const dtCo = mieszacz
      ? (reg === -1 ? Number(v.dt) : (REGIMES_CO[reg] || REGIMES_CO[1])[1])
      : dtPod;
    if (!(dtCo > 0)) return { error: 'Δt źródła musi być większe od zera.' };

    /* Zasobnik ładuje się wprost od źródła, parametrami źródła i obok grupy
       mieszającej — więc wchodzi w odcinek wspólny i w moc kotła, ale nigdy
       w belkę rozdzielacza ani w dobór zaworu mieszającego. */
    const sumaPod = lista.reduce((a, x) => a + (Number(x.w) || 0), 0);

    const wspMie = mieszacz && v.mieGdzie === 'wsp' && lista.length > 1;
    const r = dojsciaRozdzielaczy(lista, {
      dtCo, dtPod, mieszacz, wspolnyMieszacz: wspMie, mat: v.mat, v: v.v, zapas: v.zapas,
    });
    /* Pompa po ludzku: jaką kupić i na ile ją nastawić. Samo „l/h przy m”
       instalatorowi w sklepie nic nie mówi. */
    const pompaKarta = (label, q, H) => {
      const kl = ktKlasaPompy(q, H);
      return { label, icon: 'gauge', value: kl, unit: kl.startsWith('25') ? 'rura 1″' : kl.startsWith('32') ? 'rura 5/4″' : 'DN40',
        foot: ktOpisPompy(kl) + '.\nNastaw: ' + fmt(H, 1) + ' m (tryb stałej różnicy ciśnień), przepływ ' + fmt(q, 2) + ' m³/h = ' + fmt(q * 1000, 0) + ' l/h.'
          + '\nOznaczenie „' + kl + '”: ' + kl.split('-')[0] + ' to przyłącze, ' + kl.split('-')[1] + ' to maksymalna wysokość podnoszenia w decymetrach — pompa ma zapas, więc pracuje w środku swojego zakresu.' };
    };
    const zawory = r.zawor ? [{ nazwa: '', z: r.zawor }] : r.pozycje.filter(p => p.zawor).map(p => ({ nazwa: p.nazwa, z: p.zawor }));
    if (!r.wspolny) return { error: 'Uzupełnij moce rozdzielaczy.' };

    const tabela = r.pozycje.map(p => `<div class="seg-row${p.rura.tooSmall ? ' seg-change' : ''}">
      <span class="seg-n">${p.nr}</span>
      <span class="seg-t"><strong>${esc(p.nazwa)} — ${esc(p.rura.pick[0])}</strong>
        <span>${fmt(p.w / 1000, 1)} kW ·
          ${fmt(p.qDoj, 3)} m³/h przy Δt ${fmt(p.dtDoj, 0)} K${p.przezMieszacz ? ' (strona kotła)' : ''}</span></span>
      <span class="seg-v">${fmt(p.rura.vAct, 2)}<span>m/s</span></span>
    </div>`).join('');

    const pompy = r.pozycje.map(p => `<div class="seg-row${p.pompa.brakPetli ? ' seg-change' : ''}">
      <span class="seg-n">${p.nr}</span>
      <span class="seg-t"><strong>${esc(p.nazwa)} — ${fmt(p.pompa.q * 1000, 0)} l/h przy ${fmt(p.pompa.H, 2)} m${!p.pompa.brakPetli && typeof ktKlasaPompy === 'function' ? ' · pompa ' + ktKlasaPompy(p.pompa.q, p.pompa.H) : ''}</strong>
        <span>${p.pompa.brakPetli
          ? 'wpisz opory najdłuższej pętli albo dopisz pomieszczenia z podłogówki'
          : `pętla ${fmt(p.pompa.dpPetli, 1)}${p.pompa.dpPetliZr === 'wpisane' ? '' : ' (' + (p.pompa.dpPetliZr === 'typowa' ? 'typowa ' : p.pompa.dpPetliZr === 'srednia' ? 'ok. ' : '') + fmt(p.pompa.dlPetliUzyta, 0) + ' m)'} + przepływomierz ${fmt(p.pompa.dpPrzeplywomierz, 1)}`
            + ` + belka ${fmt(p.pompa.dpBelki, 2)}`
            + (p.pompa.dpZaworu > 0 ? ` + zawór ${fmt(p.pompa.dpZaworu, 1)}` : '')
            + (p.pompa.dpRury > 0 ? ` + rura ${fmt(p.pompa.dpRury, 1)}` : '')
            + ` = ${fmt(p.pompa.suma, 1)} kPa`}</span></span>
      <span class="seg-v">${fmt(p.pompa.zZapasem, 1)}<span>kPa</span></span>
    </div>`).join('');

    const korpusy = r.pozycje.map(p => `<div class="seg-row${p.korpusZaMaly ? ' seg-change' : ''}">
      <span class="seg-n">${p.nr}</span>
      <span class="seg-t"><strong>${esc(p.nazwa)} — belka ${esc(p.korpus)}</strong>
        <span>${p.wyj ? p.wyj + ' ' + odmianaWyjsc(p.wyj) + ' · ' : ''}${fmt(p.qBelka, 3)} m³/h
          przy Δt ${fmt(p.dtBelka, 0)} K${p.wyj
            ? ' · pętla ' + fmt(p.vPetla, 2) + ' m/s · rotametr średnio '
              + fmt(p.qPetla * 1000 / 60, 1) + ' l/min'
            : ''}${
          p.metrow > 0 ? ' · ' + fmt(p.metrow, 0) + ' m rury'
            + (p.rury.length === 1 ? ' ' + esc(p.rury[0]) : '') : ''}</span></span>
      <span class="seg-v${p.korpusZaMaly ? ' slow' : ''}">${fmt(p.vKorpus, 2)}<span>m/s</span></span>
    </div>`).join('');

    /* Nastawy rotametrów — wiersz na każde pomieszczenie dopisane
       z kalkulatora podłogówki. Przepływ pomieszczenia dzieli się po równo
       na jego pętle, więc wszystkie rotametry tego pomieszczenia stoją
       na tej samej kresce. Bierze się z mocy i z Δt, nie z długości pętli:
       dłuższa pętla zwykle leży w większym pomieszczeniu i dlatego dostaje
       więcej wody, ale to moc o tym decyduje, a nie metry. */
    const minPetla = przeplywZPredkosci(V_MIN_PETLA_POD, pipeInner(NITKA_ROZDZ)) / 60;
    const nastawy = [];
    r.pozycje.forEach(p => {
      const w = p.wklady;
      if (!w) return;
      Object.keys(w).forEach(pokoj => {
        const x = w[pokoj];
        const petle = Math.max(1, Math.round(Number(x.petle) || 1));
        const lmin = pumpFlow((Number(x.moc) || 0) / 1000, dtPod) * 1000 / 60 / petle;
        if (!(lmin > 0)) return;
        /* Nastawa jest projektowa i tyle. Osobno zaznaczamy pętle bardzo
           wolne i te, które mogą nie zmieścić się na skali przepływomierza. */
        nastawy.push({ rozdz: p.nazwa, pokoj, petle, lmin,
                       wolna: lmin < minPetla, pozaSkala: lmin > ROTAMETR_SKALA_MALA,
                       moc: Number(x.moc) || 0, m: Number(x.m) || 0 });
      });
    });
    const wolne = nastawy.filter(n => n.wolna);
    const pozaSkala = nastawy.filter(n => n.pozaSkala);
    const nastawyHtml = nastawy.length
      ? `<div class="subhead">Nastawy rotametrów przy Δt ${fmt(dtPod, 0)} K</div><div class="segs">`
        + nastawy.map((n, i) => `<div class="seg-row${
            n.wolna || n.pozaSkala ? ' seg-change' : ''}">
          <span class="seg-n">${i + 1}</span>
          <span class="seg-t"><strong>${esc(n.pokoj)} — ${esc(n.rozdz)}</strong>
            <span>${fmt(n.moc, 0)} W · ${n.petle} ${odmiana(n.petle, 'pętla', 'pętle', 'pętli')}
              ${n.petle > 1 ? '· każda tak samo' : ''}${
              n.m > 0 ? ' · ' + fmt(n.m / n.petle, 0) + ' m na pętlę' : ''}${
              n.wolna ? ' · bardzo wolno' : ''}${
              n.pozaSkala ? ' · sprawdź zakres wkładki' : ''}</span></span>
          <span class="seg-v">${fmt(n.lmin, n.lmin < 1 ? 2 : 1)}<span>l/min</span></span>
        </div>`).join('') + '</div>'
      : '';

    /* Rysunek rozdzielacza — po jednym na każdy. Grzebień z nitkami, przy
       każdej nazwa pomieszczenia i kreska do ustawienia na rotametrze.
       To jest kartka na budowę: monter nie musi przeliczać ani pamiętać,
       która pętla jest która, bo numer na rysunku to numer wyjścia na belce.

       Kiedy pomieszczenia zostały dopisane z kalkulatora podłogówki, każde
       dostaje swój wiersz i swoją nastawę. Przy rozdzielaczu wpisanym ręcznie
       znamy tylko moc i liczbę wyjść, więc nitki są bezimienne, a nastawa
       jest podziałem po równo — i wtedy tak jest podpisana, żeby nikt nie
       wziął średniej za wynik doboru. */
    /* Co stoi przy rozdzielaczu na rysunku: zawór mieszający i pompa. Przy
       wspólnym mieszaczu w kotłowni grupa jest jedna, przy źródle. */
    const kvsTxt = z => 'Kvs ' + String(z.kvs).replace('.', ',') + ' ' + z.pick.dn.replace(' ', '');
    const pompaTxt = (q, H) => (typeof ktKlasaPompy === 'function' ? ktKlasaPompy(q, H) + ' · ' : '') + fmt(H, 1) + ' m';
    const grupaRozdz = p => {
      if (r.zawor) return null;
      const g = { mieszacz: p.zawor ? kvsTxt(p.zawor) : '', pompa: p.pompa && !p.pompa.brakPetli ? pompaTxt(p.pompa.q, p.pompa.H) : '' };
      return g.mieszacz || g.pompa ? g : null;
    };
    const grupaZrodla = r.zawor ? { mieszacz: kvsTxt(r.zawor), pompa: r.pompaWsp && !r.pozycje.some(p => p.pompa.brakPetli) ? pompaTxt(r.pompaWsp.q, r.pompaWsp.H) : '' } : null;
    const schematyRozdz = r.pozycje.map(p => {
      const ile = p.wyj > 0 ? p.wyj : 0;
      if (!ile) return null;
      const srednio = p.qPetla * 1000 / 60;
      const nitki = [];

      const w = p.wklady || null;
      if (w) {
        Object.keys(w).forEach(pokoj => {
          const x = w[pokoj];
          const petle = Math.max(1, Math.round(Number(x.petle) || 1));
          const lmin = pumpFlow((Number(x.moc) || 0) / 1000, dtPod) * 1000 / 60 / petle;
          for (let i = 0; i < petle; i++) {
            nitki.push({
              /* Podpis krótki, bo na telefonie rysunek i tak jest szerszy
                 od ekranu — „Salon 1/2" czyta się tak samo dobrze jak
                 „Salon, pętla pierwsza z dwóch", a mieści się bez przewijania. */
              nazwa: petle > 1 ? `${pokoj} ${i + 1}/${petle}` : pokoj,
              wlasna: fmt(lmin, lmin < 1 ? 2 : 1) + ' l/min'
                + (x.m > 0 ? ' · ' + fmt(x.m / petle, 0) + ' m' : ''),
              srednica: x.rura || NITKA_ROZDZ[0],
            });
          }
        });
      }
      /* Wyjścia, o których nic nie wiemy — bo rozdzielacz ma ich więcej,
         niż dopisano pomieszczeń, albo nie dopisano żadnego. */
      while (nitki.length < ile) {
        nitki.push({
          nazwa: 'Pętla ' + (nitki.length + 1),
          wlasna: fmt(srednio, 1) + ' l/min' + (w ? '' : ' (po równo)'),
          srednica: NITKA_ROZDZ[0],
        });
      }

      return {
        rodzaj: 'co', uklad: 'rozdzielacz',
        grupa: grupaRozdz(p),
        tytul: 'Rozdzielacz podłogówki — ' + p.nazwa,
        nazwa: p.nazwa,
        /* Po lewej stoi to, co naprawdę zasila belkę: z grupą mieszającą
           jest nią mieszacz, a nie kocioł — on jest dopiero za nim. */
        zrodlo: 'źródło',
        guzik: 'Projekt poglądowy — ' + p.nazwa,
        galazka: NITKA_ROZDZ[0],
        dojscie: p.rura && p.rura.pick ? p.rura.pick[0] : '',
        zasobnik: null,
        odcinki: nitki.slice(0, Math.max(ile, nitki.length))
          .map((n, i) => Object.assign({ nr: i + 1 }, n)),
      };
    }).filter(Boolean);

    const ostrz = [];
    if (wolne.length) ostrz.push(`Bardzo wolny przepływ w: ${wolne.map(n => n.pokoj).join(', ')}. `
      + `Liczby są poprawne, ale wypadają poniżej ${fmt(V_MIN_PETLA_POD, 2)} m/s, czyli około `
      + `${fmt(minPetla, 1)} l/min dla rury ${NITKA_ROZDZ[0]} — tyle przyjmują wytyczne `
      + 'projektowania jako dolną granicę. Sprawdź, czy przepływomierz pokaże tak małą wartość '
      + 'i czy pętla da się odpowietrzyć.');
    if (pozaSkala.length) ostrz.push(`Nastawa powyżej ${fmt(ROTAMETR_SKALA_MALA, 0)} l/min w: `
      + `${pozaSkala.map(n => n.pokoj + ' ' + fmt(n.lmin, 1)).join(', ')}. Wkładki przepływomierzy `
      + `bywają na ${ROTAMETR_SKALE.join(', ')} l/min — sprawdź, jaką masz na belce. `
      + 'To także sygnał, że na jedną pętlę przypada dużo mocy: typowy obieg to 500–1000 W.');
    const ciasne = r.pozycje.filter(p => p.rura.tooSmall);
    if (ciasne.length) ostrz.push(`Do ${ciasne.map(p => p.nazwa).join(', ')} nawet największa rura z tego `
      + 'typoszeregu jest za mała — podziel na dwa rozdzielacze albo daj grubszy materiał.');
    const szybkie = r.pozycje.filter(p => p.petlaZaSzybko);
    if (szybkie.length) ostrz.push(`W ${szybkie.map(p => p.nazwa).join(', ')} na jedną pętlę wypada za dużo mocy — `
      + `woda w rurze ${NITKA_ROZDZ[0]} płynie szybciej niż ${fmt(V_MAX_PETLA_POD, 1)} m/s. Podziel na więcej obiegów.`);
    if (r.wspolny.tooSmall) ostrz.push('Odcinek wspólny nie mieści się w typoszeregu — '
      + 'prowadź do rozdzielaczy osobnymi rurami wprost od źródła.');
    const bezPetli = r.pozycje.filter(p => p.pompa.szacPetli);
    if (bezPetli.length) ostrz.push(`Pompę dla ${bezPetli.map(p => p.nazwa).join(', ')} liczę z typowej najdłuższej pętli 80 m, `
      + 'bo nie ma długości pętli. Dopisz pomieszczenia z kalkulatora „Ogrzewanie podłogowe” guzikiem albo wpisz opory najdłuższej pętli — wtedy policzę dokładnie.');
    zawory.forEach(({ nazwa, z }) => {
      const gdzie = nazwa ? ` (${nazwa})` : '';
      if (z.overRange) ostrz.push(`Przepływ${gdzie} przekracza największy zawór `
        + 'z typoszeregu — podziel podłogówkę na dwie grupy mieszające.');
      else if (z.belowBand) ostrz.push(`Spadek na zaworze${gdzie} `
        + `${fmt(z.dp * 100, 1)} kPa jest poniżej zalecanego minimum `
        + `${fmt(DP_VALVE_MIN * 100, 0)} kPa — to najmniejszy zawór z typoszeregu, `
        + 'więc mniejszego nie ma, ale regulacja będzie ostra.');
      if (z.fast) ostrz.push(`W przyłączu zaworu${gdzie} ${z.pick.dn} woda płynie `
        + `${fmt(z.velocity, 2)} m/s — weź ten sam Kvs w większym korpusie.`);
    });

    return {
      results: [
        { label: wspMie ? 'Odcinek wspólny od mieszacza' : 'Odcinek wspólny od źródła', icon: 'check', value: r.wspolny.pick[0], unit: '',
          foot: `${r.pozycje.length} ${odmiana(r.pozycje.length, 'rozdzielacz', 'rozdzielacze', 'rozdzielaczy')} · `
            + `${fmt(r.sumaW / 1000, 1)} kW · `
            + `${fmt(r.qWspolny + r.qZasobnik, 3)} m³/h · ${fmt(r.wspolny.vAct, 2)} m/s` },
      ].concat(zawory.length ? zawory.map(({ nazwa, z }) => (
        { label: nazwa ? 'Zawór mieszający — ' + nazwa : (wspMie ? 'Zawór mieszający — wspólny w kotłowni' : 'Zawór mieszający'), icon: 'tune',
          value: 'Kvs ' + String(z.kvs).replace('.', ','), unit: z.pick.dn,
          foot: `gwint ${z.pick.thread} · przez zawór ${fmt(z.q, 3)} m³/h · `
            + `spadek ${fmt(z.dp * 100, 1)} kPa`
            + (wspMie ? ' · przepuszcza cały obieg podłogowy wszystkich rozdzielaczy' : nazwa ? ' · tylko woda tego rozdzielacza' : '') })) : [
        { label: 'Bez zaworu mieszającego', icon: 'therm', value: fmt(dtPod, 0), unit: 'K Δt', small: true,
          foot: 'źródło pracuje wprost na parametrach podłogówki — rura od niego niesie tę samą '
            + 'wodę co pętle, więc liczy się ją tym samym Δt' },
      ]).concat(typeof ktKlasaPompy !== 'function' ? [] : r.pompaWsp
        ? (r.pozycje.some(p => p.pompa.brakPetli) ? [] : [pompaKarta('Pompa obiegowa — jedna w kotłowni', r.pompaWsp.q, r.pompaWsp.H)])
        : r.pozycje.filter(p => !p.pompa.brakPetli).map(p => pompaKarta('Pompa obiegowa' + (r.pozycje.length > 1 ? ' — ' + p.nazwa : ''), p.pompa.q, p.pompa.H))),
      /* Jeden rysunek na całą podłogówkę: grzebienie jeden pod drugim,
         związane pionem od źródła. Przy jednym rozdzielaczu nie ma czego
         wiązać, więc zostaje rysunek pojedynczy — ten sam co dotąd. */
      schemat: schematyRozdz.length > 1 ? {
        rodzaj: 'co', uklad: 'rozdzielacze',
        tytul: 'Rozdzielacze podłogówki — ' + schematyRozdz.length,
        zrodlo: 'źródło',
        grupaZrodla,
        galazka: NITKA_ROZDZ[0],
        wspolny: { srednica: r.wspolny.pick[0], opis: fmt(r.sumaW / 1000, 1) + ' kW' },
        rozdzielacze: schematyRozdz.map(x => ({
          nazwa: x.nazwa,
          grupa: x.grupa,
          dojscie: x.dojscie,
          odcinki: x.odcinki,
        })),
      } : (schematyRozdz[0] || null),
      extra: `<div class="subhead">Doprowadzenie do każdego rozdzielacza</div><div class="segs">${tabela}</div>`
        + `<div class="subhead">Korpus rozdzielacza i pętle</div><div class="segs">${korpusy}</div>`
        + nastawyHtml
        + `<div class="subhead">Pompa obiegowa ${wspMie
              ? '— jedna, za wspólnym mieszaczem w kotłowni'
              : mieszacz ? '— w grupie mieszającej przy każdym rozdzielaczu'
              : '— jeśli każdy rozdzielacz ma własną'}</div>`
        + `<div class="segs">${pompy}${r.pompaWsp ? `<div class="seg-row"><span class="seg-n">Σ</span>
            <span class="seg-t"><strong>Jedna pompa — ${fmt(r.pompaWsp.q * 1000, 0)} l/h przy ${fmt(r.pompaWsp.H, 2)} m${typeof ktKlasaPompy === 'function' ? ' · pompa ' + ktKlasaPompy(r.pompaWsp.q, r.pompaWsp.H) : ''}</strong>
            <span>suma przepływów wszystkich rozdzielaczy, wysokość podnoszenia najgorszego z nich (z rurą w obie strony i zaworem)</span></span>
            <span class="seg-v">${fmt(r.pompaWsp.H, 2)}<span>m</span></span></div>` : ''}</div>`,
      rows: [
        ['Δt obiegu podłogowego', fmt(dtPod, 0) + ' °C'],
      ].concat(mieszacz ? [
        ['Δt kotła', fmt(dtCo, 0) + ' °C'],
        ['Rura od źródła', 'strona kotła — woda kotłowa, Δt ' + fmt(dtCo, 0) + ' K'],
      ] : [
        ['Rura od źródła', 'to samo Δt co pętle — źródło pracuje na parametrach podłogówki'],
      ]).concat([
        ['Belka rozdzielacza', 'sprawdzana przy Δt ' + fmt(dtPod, 0) + ' K, do ' + fmt(V_MAX_KORPUS, 1) + ' m/s'],
        ['Co pokonuje pompa', wspMie
          ? 'pętle, przepływomierz, belka, rura do rozdzielacza w obie strony i wspólny zawór'
          : mieszacz
          ? 'obieg wtórny: pętle, przepływomierz, belka i zawór mieszający'
          : 'cały obieg: rura od źródła w obie strony, belka, przepływomierz i pętle'],
        ['Opory pętli', 'liczy się najgorsza z nich, a nie ich suma — wiszą równolegle'],
      ]).concat(zawory.length ? [
        ['Dobór zaworu', 'spadek w paśmie ' + fmt(DP_VALVE_MIN * 100, 0) + '–'
          + fmt(DP_VALVE_MAX * 100, 0) + ' kPa, mniejszy z pasujących'],
      ].concat(zawory.map(({ nazwa, z }) => ['Przepływ przez zawór' + (nazwa ? ' — ' + nazwa : ''),
        fmt(z.q, 3) + ' m³/h  ·  ' + fmt(z.velocity, 2) + ' m/s w przyłączu ' + z.pick.dn])) : []).concat(r.sumaMetrow > 0 ? [
        ['Rura pętli — razem do zamówienia', fmt(r.sumaMetrow, 0) + ' m'
          + (r.rury.length ? '  ·  ' + r.rury.join(' i ') : '')],
      ] : []).concat([
        ['Łączna moc rozdzielaczy', fmt(r.sumaW / 1000, 1) + ' kW', true],
      ]),
      warn: ostrz.length ? ostrz.join(' ') : null,
    };
  },
},

/* ---------------- 7a. ŚREDNICE WODY UŻYTKOWEJ ---------------- */
{
  id: 'woda_dia', cat: 'pipes', icon: 'drop',
  title: 'Średnice wody użytkowej',
  desc: 'Trójnikowo albo z rozdzielacza',
  sub: 'Dobór średnic instalacji wodociągowej',
  modes: [
    { key: 'troj', label: 'Trójnikowy',
      cards: [
        { title: 'Przybory na odcinku', icon: 'drop', fields: [
          { k: 'tryb', type: 'seg', def: 'ile', options: [
            { value: 'ile', label: 'Ile przyborów' }, { value: 'galaz', label: 'Cała gałąź' },
          ]},
          { k: 'fx', type: 'counters', options: FIXTURES.map(f => ({ label: f[0], qn: f[1] })),
            def: { 0: 1, 3: 1, 4: 1 }, when: v => v.tryb !== 'galaz' },
          { k: 'kol', type: 'fxlist', def: [5, 3, 0, 1], addLabel: 'Dodaj przybór',
            when: v => v.tryb === 'galaz' },
        ]},
        { title: 'Parametry przewodu', icon: 'tune', fields: [
          { k: 'v', type: 'slider', label: 'Zalecana prędkość', min: 0.5, max: 2.5, step: 0.05, def: 1.5, suffix: ' m/s' },
          { k: 'mat', type: 'select', label: 'Materiał rury', def: 'pp16',
            options: PIPE_MATERIALS.map(m => ({ value: m[0], label: m[1] })) },
        ]},
      ],
      tip: 'Tryb „cała gałąź" liczy każdy odcinek osobno: pierwszy zasila wszystkie przybory, ostatni tylko ten na końcu. Kolejność ma znaczenie — odcinek przy pionie wyjdzie tak samo niezależnie od niej, ale dalsze już nie, bo zależą od tego, jakie przybory zostały za nimi. Wpisuj więc przybory w takiej kolejności, w jakiej faktycznie są na gałęzi. Współczynnik jednoczesności wg PN-92/B-01706 dla budynków mieszkalnych: q = 0,682 × (Σqn)^0,45 − 0,14. Dlatego przepływ obliczeniowy jest mniejszy niż suma wypływów — nikt nie odkręca wszystkiego naraz. Prędkość w instalacji wodociągowej nie powinna przekraczać 2 m/s.\n\nCyrkulacja. Warunki techniczne (§ 120) każą zapewnić stały obieg wody na odcinkach o objętości wewnętrznej powyżej 3 dm³ prowadzących do punktów czerpalnych — ale wyłączają z tego budynki jednorodzinne, zagrodowe i rekreacji indywidualnej. W domku jednorodzinnym cyrkulacja jest więc kwestią komfortu, nie obowiązku.\n\nTrzy litry to mniej rury, niż się wydaje: w dwudziestce (16 mm w środku) mieszczą się po piętnastu metrach, w rurze 25 już po dwunastu, a w nitce 16×2 z rozdzielacza dopiero po dwudziestu siedmiu. Tyle zimnej zleci z kranu, zanim dojdzie ciepła — przy trzech litrach to kilkanaście sekund czekania. Kto chce mieć ciepłą wodę od razu, robi cyrkulację przy dwóch razy krótszym odcinku.',
      compute(v) {
        /* Tryb „cała gałąź": przybory w kolejności od pionu. Każdy odcinek
           zasila te przybory, które są za nim, więc przepływ obliczeniowy
           trzeba wyliczać od nowa dla każdego odcinka — jednoczesność nie
           jest dodawaniem i nie da się jej po prostu odjąć. */
        if (v.tryb === 'galaz') {
          const lista = (v.kol || []).map(i => FIXTURES[i]).filter(Boolean);
          if (!lista.length) return { error: 'Dodaj przynajmniej jeden przybór do gałęzi.' };

          const odcinki = [];
          for (let i = 0; i < lista.length; i++) {
            const dalej = lista.slice(i);
            const sumQ = dalej.reduce((a, f) => a + f[1], 0);
            const maxQ = Math.max(...dalej.map(f => f[1]));
            const qls = waterDesignFlow(sumQ, maxQ);
            const ss = selectPipe(qls * 3.6, v.mat, v.v);
            odcinki.push({ nr: i + 1, ile: dalej.length, qls, s: ss, nazwa: lista[i][0] });
          }

          const pierwszy = odcinki[0];
          const zmiany = odcinki.filter((o, i) => i > 0 && o.s.pick[0] !== odcinki[i - 1].s.pick[0]);
          const szybkie = odcinki.filter(o => o.s.vAct > 2);

          const tabela = odcinki.map((o, i) => {
            const zmiana = i > 0 && o.s.pick[0] !== odcinki[i - 1].s.pick[0];
            return `<div class="seg-row${zmiana ? ' seg-change' : ''}">
              <span class="seg-n">${o.nr}</span>
              <span class="seg-t"><strong>${o.s.pick[0]}</strong>
                <span>do ${o.ile} ${o.ile === 1 ? 'przyboru' : 'przyborów'} · q = ${fmt(o.qls, 3)} l/s</span></span>
              <span class="seg-v${o.s.vAct > 2 ? ' slow' : ''}">${fmt(o.s.vAct, 2)}<span>m/s</span></span>
            </div>`;
          }).join('');

          return {
            /* Zasilanie zasobnika prowadzi całą ciepłą wodę do przyborów,
               więc jest to ta sama średnica, co pierwszy odcinek gałęzi.
               Dokładamy też, ile metrów takiej rury mieści 3 dm³ — bo to
               jest granica, od której robi się cyrkulację. */
            schemat: {
              rodzaj: 'woda', tytul: 'Gałąź wody użytkowej',
              zasobnik: { srednica: pierwszy.s.pick[0] },
              cyrkulacja: { rura: pierwszy.s.pick[0], metrow: fmt(3 / pipeLitersPerM(pierwszy.s.pick), 0) },
              odcinki: odcinki.map(o => ({
                nazwa: o.nazwa, srednica: o.s.pick[0], opis: fmt(o.qls, 3) + ' l/s',
              })),
            },
            results: [
              { label: 'Odcinek przy pionie', icon: 'check', value: pierwszy.s.pick[0], unit: '',
                foot: `${lista.length} przyborów · przepływ obliczeniowy ${fmt(pierwszy.qls, 3)} l/s` },
              { label: 'Prędkość rzeczywista', icon: 'gauge', value: fmt(pierwszy.s.vAct, 2), unit: 'm/s', small: true },
            ],
            extra: `<div class="subhead">Średnica odcinek po odcinku</div><div class="segs">${tabela}</div>`,
            rows: [
              ['Zmiana średnicy', zmiany.length
                ? 'na odcinku ' + zmiany.map(z => z.nr).join(', ')
                : 'nie ma gdzie zejść — jedna średnica na całej gałęzi'],
              ['Ostatni przybór', odcinki[odcinki.length - 1].nazwa],
              ['Wzór', 'q = 0,682 × (Σqn)^0,45 − 0,14'],
            ],
            warn: szybkie.length
              ? `Na ${szybkie.length === 1 ? 'odcinku' : 'odcinkach'} ${szybkie.map(o => o.nr).join(', ')} prędkość przekracza 2 m/s — instalacja będzie hałasować. Weź większą średnicę albo zmniejsz zalecaną prędkość.`
              : null,
          };
        }

        let sum = 0, maxS = 0, count = 0;
        FIXTURES.forEach((f, i) => {
          const c = v.fx[i] || 0;
          if (c > 0) { sum += c * f[1]; maxS = Math.max(maxS, f[1]); count += c; }
        });
        if (!count) return { error: 'Dodaj przynajmniej jeden przybór sanitarny.' };
        const qls = waterDesignFlow(sum, maxS);
        const qm3h = qls * 3.6;
        const s = selectPipe(qm3h, v.mat, v.v);
        return {
          results: [
            { label: 'Zalecana średnica przewodu', icon: 'check', value: s.pick[0], unit: '',
              foot: `przepływ obliczeniowy ${fmt(qls, 3)} l/s · wymagane min. Ø wewn. ${fmt(s.needMm, 1)} mm` },
            { label: 'Prędkość rzeczywista', icon: 'gauge', value: fmt(s.vAct, 2), unit: 'm/s', small: true },
          ],
          rows: [
            ['Liczba przyborów', count + ' szt'],
            ['Suma wypływów normatywnych Σqn', fmt(sum, 2) + ' l/s'],
            ['Przepływ obliczeniowy q', fmt(qls, 3) + ' l/s'],
            ['Redukcja przez jednoczesność', fmt((1 - qls / sum) * 100, 0) + '%'],
          ],
          warn: s.vAct > 2 ? 'Prędkość powyżej 2 m/s — instalacja będzie hałasować i szybciej się zużyje. Wybierz większą średnicę.' : null,
        };
      },
    },
    /* ---------- ROZDZIELACZOWY (woda) ----------
       Tak samo jak w c.o.: do każdego przyboru osobna nitka 16×2, więc
       nie ma czego dobierać poza dojściem do rozdzielacza. Różnica jest
       w przepływie — przy wodzie liczy się go z jednoczesności, bo nikt
       nie odkręca wszystkich kranów naraz. */
    { key: 'rozdz', label: 'Rozdzielaczowy',
      cards: [
        { title: 'Przybory na rozdzielaczu', icon: 'drop', fields: [
          { k: 'kol', type: 'fxlist', def: [1, 0, 5, 7], addLabel: 'Dodaj przybór' },
        ]},
        { title: 'Dojście od pionu do rozdzielacza', icon: 'tune', fields: [
          { k: 'v', type: 'slider', label: 'Zalecana prędkość', min: 0.5, max: 2.5, step: 0.05, def: 1.5, suffix: ' m/s' },
          { k: 'mat', type: 'select', label: 'Materiał rury dojścia', def: 'pp16',
            options: PIPE_MATERIALS.map(m => ({ value: m[0], label: m[1] })) },
        ]},
      ],
      tip: 'Rozdzielacz do wody: od pionu jedna rura do rozdzielacza, a stamtąd osobna nitka do każdego kranu. Nitki kładzie się jedną średnicą, PE-X 16×2, więc aplikacja ich nie dobiera — sprawdza tylko prędkość przy pełnym wypływie danego przyboru i odzywa się, gdy wyjdzie za szybko.\n\nDobiera się dojście do rozdzielacza i to jest tu jedyna licząca się średnica. Przepływ obliczeniowy bierze się z jednoczesności wg PN-92/B-01706: q = 0,682 × (Σqn)^0,45 − 0,14, i nigdy nie jest mniejszy niż wypływ największego pojedynczego przyboru.\n\nCiepłą i zimną liczy się osobno — to dwa rozdzielacze i dwa dojścia. Wpisz najpierw przybory zimnej wody, zanotuj wynik, potem to samo dla ciepłej; przyborów bez ciepłej wody, jak spłuczka czy zawór ogrodowy, po prostu nie wpisuj za drugim razem.\n\nZaleta układu jest taka sama jak w c.o.: każdy kran można odciąć osobno, a pod tynkiem nie ma ani jednego złącza — nitka idzie w całości od rozdzielacza do przyboru.\n\nCyrkulacja. Warunki techniczne (§ 120) każą zapewnić stały obieg wody na odcinkach o objętości wewnętrznej powyżej 3 dm³ prowadzących do punktów czerpalnych — ale wyłączają z tego budynki jednorodzinne, zagrodowe i rekreacji indywidualnej. W domku jednorodzinnym cyrkulacja jest więc kwestią komfortu, nie obowiązku.\n\nTrzy litry to mniej rury, niż się wydaje: w dwudziestce (16 mm w środku) mieszczą się po piętnastu metrach, w rurze 25 już po dwunastu, a w nitce 16×2 z rozdzielacza dopiero po dwudziestu siedmiu. Tyle zimnej zleci z kranu, zanim dojdzie ciepła — przy trzech litrach to kilkanaście sekund czekania. Kto chce mieć ciepłą wodę od razu, robi cyrkulację przy dwóch razy krótszym odcinku.',
      compute(v) {
        const lista = (v.kol || []).map(i => FIXTURES[i]).filter(Boolean);
        if (!lista.length) return { error: 'Dodaj przynajmniej jeden przybór.' };

        const nitka = NITKA_ROZDZ;
        const pole = Math.PI * Math.pow(pipeInner(nitka) / 1000, 2) / 4;

        const nitki = lista.map((f, i) => {
          const vAct = (f[1] / 1000) / pole;          /* qn jest w l/s */
          const zaSzybko = vAct > 2;
          /* Przy zbyt szybkiej wodzie nie zostawiamy samej czerwonej liczby,
             tylko od razu piszemy, jaką rurę wziąć zamiast szesnastki —
             to jest informacja, którą monter może wykorzystać na miejscu. */
          const lepsza = zaSzybko ? nitkaDoWyplywu(f[1], 2) : null;
          return { nr: i + 1, nazwa: f[0], qn: f[1], vAct, zaSzybko,
                   lepsza: lepsza ? lepsza[0] : null };
        });

        const sumQ = lista.reduce((a, f) => a + f[1], 0);
        const maxQ = Math.max(...lista.map(f => f[1]));
        const qls = waterDesignFlow(sumQ, maxQ);
        const doj = selectPipe(qls * 3.6, v.mat, v.v);
        const szybkie = nitki.filter(n => n.zaSzybko);

        const tabela = nitki.map(n => `<div class="seg-row${n.zaSzybko ? ' seg-change' : ''}">
          <span class="seg-n">${n.nr}</span>
          <span class="seg-t"><strong>${esc(n.nazwa)}</strong>
            <span>${n.zaSzybko && n.lepsza
              ? 'daj ' + esc(n.lepsza) + ' zamiast ' + esc(nitka[0])
              : esc(nitka[0]) + ' PE-X'} · wypływ ${fmt(n.qn, 2)} l/s</span></span>
          <span class="seg-v${n.zaSzybko ? ' slow' : ''}">${fmt(n.vAct, 2)}<span>m/s</span></span>
        </div>`).join('');

        return {
          schemat: {
            rodzaj: 'woda', uklad: 'rozdzielacz', tytul: 'Rozdzielacz wody',
            galazka: nitka[0], dojscie: doj.pick[0],
            zasobnik: { srednica: doj.pick[0] },
            cyrkulacja: { rura: NITKA_ROZDZ[0], metrow: fmt(3 / pipeLitersPerM(NITKA_ROZDZ), 0) },
            odcinki: nitki.map(n => ({
              nazwa: n.nazwa, nr: n.nr, wlasna: fmt(n.qn, 2) + ' l/s',
              srednica: nitka[0], opis: '',
            })),
          },
          results: [
            { label: 'Dojście do rozdzielacza', icon: 'check', value: doj.pick[0], unit: '',
              foot: `${lista.length} ${lista.length === 1 ? 'przybór' : 'przyborów'} · `
                + `Σqn ${fmt(sumQ, 2)} l/s · przepływ obliczeniowy ${fmt(qls, 3)} l/s` },
            { label: 'Rozdzielacz', icon: 'list', value: String(lista.length), unit: odmianaWyjsc(lista.length), small: true,
              foot: 'osobno na zimną i osobno na ciepłą wodę' },
          ],
          extra: `<div class="subhead">Nitki z rozdzielacza — wszystkie ${esc(nitka[0])}</div>`
            + `<div class="segs">${tabela}</div>`,
          rows: [
            ['Nitka do przyboru', nitka[0] + ' PE-X  ·  Ø wewn. ' + fmt(pipeInner(nitka), 1) + ' mm'],
            ['Suma wypływów Σqn', fmt(sumQ, 2) + ' l/s'],
            ['Przepływ obliczeniowy q', fmt(qls, 3) + ' l/s'],
            ['Redukcja przez jednoczesność', fmt((1 - qls / sumQ) * 100, 0) + '%'],
            ['Prędkość w dojściu', fmt(doj.vAct, 2) + ' m/s', true],
          ],
          warn: szybkie.length
            ? `Przy ${szybkie.length === 1 ? 'przyborze' : 'przyborach'} ${szybkie.map(n => esc(n.nazwa)).join(', ')} `
              + `woda w nitce ${nitka[0]} rozpędza się powyżej 2 m/s przy pełnym otwarciu — będzie szumieć. `
              + szybkie.map(n => n.lepsza ? `Do przyboru „${esc(n.nazwa)}" daj ${esc(n.lepsza)}.` : '').filter(Boolean).join(' ')
              + ` Wypływ normatywny to wartość z normy, przyjmowana do obliczeń — pralka nabiera wodę przez chwilę, nie bez przerwy, więc przy krótkiej nitce szesnastka zwykle uchodzi. Przy dłuższym odcinku albo przy wrażliwym kliencie lepiej dać grubszą.`
            : (doj.vAct > 2
              ? 'Prędkość w dojściu powyżej 2 m/s — instalacja będzie hałasować. Weź większą średnicę albo zmniejsz zalecaną prędkość.'
              : null),
        };
      },
    },
  ],
},

/* ---------------- 7b. ŚREDNICE INSTALACJI GAZOWEJ ---------------- */
{
  id: 'gas', cat: 'pipes', icon: 'fire',
  title: 'Średnice gazu',
  desc: 'Instalacja gazowa odcinek po odcinku',
  sub: 'Dobór średnic przewodów gazowych',
  /* Kalkulator, przy którym pomyłka kosztuje więcej niż źle dobrana rura,
     dostaje ostrzeżenie o uprawnieniach: okno przy każdym wejściu
     i stały pasek nad formularzem. Treść trzymamy w jednym miejscu,
     żeby obie te rzeczy nigdy się nie rozjechały. */
  law: GAS_WARN_TEXT,
  cards: [
    { title: 'Gałąź od gazomierza', icon: 'fire', fields: [
      { k: 'pkt', type: 'gazlist', def: [
        { u: 2, kw: 9,  len: 5,  wys: 0, kol: 3 },
        { u: 0, kw: 24, len: 9,  wys: 2, kol: 4 },
      ], addLabel: 'Dodaj urządzenie' },
    ]},
    { title: 'Warunki obliczeniowe', icon: 'tune', fields: [
      { k: 'ksz', type: 'seg', def: 'ryczalt', options: [
        { value: 'ryczalt', label: 'Kształtki ryczałtem' }, { value: 'dokladnie', label: 'Liczę kolanka' },
      ]},
      { k: 'pod', type: 'num', label: 'Długość podejścia do urządzenia', unit: 'm', def: GAS_DROP_DEF },
      { k: 'lim', type: 'select', label: 'Dopuszczalny spadek ciśnienia', def: 200,
        options: GAS_DP_LIMITS.map(x => ({ value: x, label: x + ' Pa  ·  ' + fmt(x / 100, 1) + ' mbar' })) },
    ]},
  ],
  tip: 'Gaz dobiera się inaczej niż wodę. Przy wodzie średnica wynika wprost z prędkości. Przy gazie prędkość jest tylko sprawdzeniem (granica 6 m/s), a decyduje suma spadków ciśnienia na całej drodze od gazomierza do urządzenia — dlatego ta sama rura wystarczy przy 4 metrach, a przy 25 będzie już za cienka.\n\nWynik dzieli się na dwie tabele, bo to dwie różne rzeczy. Gałąź główna niesie gaz do wszystkich urządzeń, które są za nią: odcinek przy gazomierzu obsługuje całą instalację i dlatego jest najgrubszy, a dalej średnica schodzi. Podejście to krótki odcinek spod gałęzi do samego urządzenia i liczy się je z mocy tego jednego urządzenia — to ta średnica, którą kupujesz pod kocioł czy pod kuchenkę. Średnica gałęzi nigdy nie rośnie wzdłuż przepływu: jeżeli któryś dalszy odcinek musi być grubszy, wszystko przed nim też idzie w górę.\n\nUrządzenia wpisuj w kolejności od gazomierza: pierwsze na liście jest najbliżej. Długość to odcinek od poprzedniego punktu do tego, a nie od gazomierza. Wzniesienie liczy się w górę — i działa na Twoją korzyść, bo gaz ziemny jest lżejszy od powietrza i płynąc do góry zyskuje 5,4 Pa na każdym metrze. Kocioł na poddaszu ma więc łatwiej niż kocioł w piwnicy.\n\nKształtki: w trybie ryczałtowym opory miejscowe przyjmujemy jako 25% strat na długości — to uproszczenie dopuszczalne przy prostym prowadzeniu rur. W trybie dokładnym podajesz liczbę kolanek na odcinkach gałęzi, a aplikacja zamienia je na długości zastępcze zależne od średnicy (kolano DN15 to 0,5 m rury, ale DN20 już 1,3 m). Resztę dokłada sama: odcinek gałęzi dostaje trójnik przelotowy, a każde podejście trójnik odgałęźny, jedno kolano i kurek odcinający — bo są tam zawsze i nie ma po co o nie pytać.\n\nJeżeli suma spadków przekroczy limit, aplikacja sama powiększa o jeden stopień ten odcinek, który zjada najwięcej ciśnienia, i przelicza wszystko od nowa — bo długości zastępcze kształtek też zmieniają się razem ze średnicą.\n\nZakres: gaz ziemny grupy E (dawny GZ-50), instalacja niskiego ciśnienia, rury stalowe. Propan-butan wymaga innych wartości i odwrotnego znaku przy pionach, więc nie jest tu liczony. Wynik jest doborem wstępnym — projekt instalacji gazowej robi uprawniony projektant.',
  compute(v) {
    const lista = (v.pkt || []).filter(p => p && p.kw > 0);
    if (!lista.length) return { error: 'Dodaj przynajmniej jedno urządzenie gazowe z mocą.' };

    const dokl = v.ksz === 'dokladnie';
    const g = gasDesign({
      points: lista.map(p => ({ kw: +p.kw || 0, len: +p.len || 0, wys: +p.wys || 0, kol: +p.kol || 0 })),
      limit: Number(v.lim) || 200, dokladnie: dokl, drop: +v.pod,
    });
    if (!g) return { error: 'Uzupełnij moce urządzeń.' };

    const pierwszy = g.secs[0];
    const nazwa = i => (GAS_APPLIANCES[lista[i].u] || ['urządzenie', 0, 'urządzenie'])[0];
    const krotko = i => (GAS_APPLIANCES[lista[i].u] || ['urządzenie', 0, 'urządzenie'])[2];

    /* Dwie tabele, bo to dwie różne rzeczy. Gałąź główna niesie gaz do
       WSZYSTKICH urządzeń za sobą, więc przy gazomierzu jest najgrubsza
       i schodzi dalej. Podejście to krótki odcinek pod jedno urządzenie
       i liczy się je z mocy tego jednego urządzenia. Wrzucenie obu do
       jednej tabeli i podpisanie odcinka nazwą urządzenia czytało się
       odwrotnie, niż jest naprawdę: wyglądało, jakby gruba rura szła
       do kuchenki, a cienka do kotła. */
    const tabela = g.secs.map((s, i) => {
      const zmiana = i > 0 && s.rura[0] !== g.secs[i - 1].rura[0];
      const skad = i === 0 ? 'gazomierz' : krotko(i - 1);
      const dl = dokl && s.lRown > 0
        ? `${fmt(s.len, 1)} m + ${fmt(s.lRown, 1)} m zast.`
        : `${fmt(s.len, 1)} m`;
      return `<div class="seg-row${zmiana ? ' seg-change' : ''}">
        <span class="seg-n">${s.nr}</span>
        <span class="seg-t"><strong>${esc(s.rura[0])}</strong>
          <span>${esc(skad)} → ${esc(krotko(i))} · zasila ${s.ile} ${s.ile === 1 ? 'urządzenie' : 'urządzenia'} (${fmt(s.kW, 1)} kW)<br>${dl} · ${fmt(s.V, 2)} m³/h · Δp ${fmt(s.dp, 0)} Pa (razem ${fmt(s.cum, 0)})</span></span>
        <span class="seg-v${s.v > GAS_V_MAX ? ' slow' : ''}">${fmt(s.v, 1)}<span>m/s</span></span>
      </div>`;
    }).join('');

    const tabPod = g.pod.map((s, i) => `<div class="seg-row${i === g.maxAt ? ' seg-change' : ''}">
        <span class="seg-n">${s.nr}</span>
        <span class="seg-t"><strong>${esc(s.rura[0])}</strong>
          <span>${esc(nazwa(i))} · tylko ${fmt(s.kW, 1)} kW · ${fmt(s.V, 2)} m³/h<br>${fmt(s.len, 1)} m · Δp ${fmt(s.dp, 0)} Pa · razem do urządzenia ${fmt(g.secs[i].cum + s.dp, 0)} Pa</span></span>
        <span class="seg-v${s.v > GAS_V_MAX ? ' slow' : ''}">${fmt(s.v, 1)}<span>m/s</span></span>
      </div>`).join('');

    const zapas = g.limit - g.max;
    const rows = [
      ['Łączna moc urządzeń', fmt(g.kWtotal, 1) + ' kW'],
      ['Przepływ przy gazomierzu', fmt(g.Vtotal, 2) + ' m³/h'],
      ['Zalecany gazomierz', g.meter[0] + '  ·  Qn ' + fmt(g.meter[1], 0) + ' m³/h'],
      ['Długość gałęzi głównej', fmt(g.dlugosc, 1) + ' m'],
      ['Podejścia', lista.length + ' × ' + fmt(g.dlPod, 1) + ' m'],
      [dokl ? 'Długość zastępcza kształtek' : 'Opory miejscowe (ryczałt)',
        dokl ? fmt(g.lRown, 1) + ' m' : fmt(GAS_FIT_PCT * 100, 0) + '% strat na długości'],
      ['Straty na długości', fmt(g.lin, 0) + ' Pa'],
      ['Opory miejscowe', fmt(g.mie, 0) + ' Pa'],
      ['Zysk z pionów', fmt(-g.wys, 0) + ' Pa'],
      ['Spadek na krytycznej drodze', fmt(g.max, 0) + ' Pa z ' + fmt(g.limit, 0) + ' Pa', true],
    ];
    if (g.kroki > 0) rows.splice(rows.length - 1, 0, ['Powiększenia średnicy', g.kroki + (g.kroki === 1 ? ' raz' : ' razy')]);

    let warn = null;
    if (!g.ok) {
      warn = `Nawet na największych rurach z typoszeregu spadek ciśnienia wynosi ${fmt(g.max, 0)} Pa i przekracza dopuszczalne ${fmt(g.limit, 0)} Pa. Gałąź jest za długa albo za mocno obciążona — skróć trasę, rozdziel urządzenia na dwie gałęzie od gazomierza albo poproś dostawcę gazu o wyższe ciśnienie zasilania.`;
    } else if (g.szybkie.length) {
      warn = `Na ${g.szybkie.length === 1 ? 'odcinku' : 'odcinkach'} ${g.szybkie.map(s => s.nr).join(', ')} prędkość gazu przekracza ${fmt(GAS_V_MAX, 0)} m/s. Weź większą średnicę — przy takiej prędkości instalacja szumi.`;
    } else if (zapas < 20) {
      warn = `Zostaje tylko ${fmt(zapas, 0)} Pa zapasu do limitu. Jeżeli trasa wyjdzie na budowie dłuższa niż na papierze albo dojdzie kilka kolanek, wynik przestanie się mieścić — rozważ o stopień większą rurę na pierwszym odcinku.`;
    }

    return {
      schemat: {
        rodzaj: 'gaz', tytul: 'Gałąź gazowa od gazomierza',
        odcinki: g.secs.map((s, i) => ({
          nazwa: krotko(i), srednica: s.rura[0],
          pod: (g.pod[i] || {}).rura ? g.pod[i].rura[0] : null,
          opis: fmt(s.kW, 1) + ' kW',
        })),
      },
      results: [
        { label: 'Średnica przy gazomierzu', icon: 'check', value: pierwszy.rura[0], unit: '',
          foot: `${lista.length} ${lista.length === 1 ? 'urządzenie' : 'urządzenia'} · ${fmt(g.kWtotal, 1)} kW · ${fmt(g.Vtotal, 2)} m³/h` },
        { label: 'Spadek ciśnienia', icon: 'gauge', value: fmt(g.max, 0), unit: 'Pa', small: true,
          foot: `limit ${fmt(g.limit, 0)} Pa · najgorzej wychodzi ${nazwa(g.maxAt).toLowerCase()}` },
      ],
      extra: `<div class="subhead">Gałąź główna odcinek po odcinku</div><div class="segs">${tabela}</div>`
        + `<div class="subhead">Podejścia do urządzeń</div><div class="segs">${tabPod}</div>`,
      rows,
      warn,
    };
  },
},

/* ---------------- 8. POJEMNOŚĆ INSTALACJI ---------------- */
{
  id: 'capacity', cat: 'water', icon: 'water',
  title: 'Pojemność instalacji',
  desc: 'Pojemność wodna rurociągów i instalacji',
  sub: 'Ile wody mieści instalacja',
  modes: [
    { key: 'pipes', label: 'Wg rurociągów',
      cards: [{ title: 'Odcinek rurociągu', icon: 'pipe', fields: [
        { k: 'mat', type: 'select', label: 'Materiał rury', def: 'copper',
          options: PIPE_MATERIALS.map(m => ({ value: m[0], label: m[1] })) },
        { k: 'dia', type: 'select', label: 'Średnica', def: '', dynamic: 'pipeDia' },
        { k: 'len', type: 'num', label: 'Długość odcinka', unit: 'm', def: 40 },
      ]}],
      tip: 'Policz kolejne odcinki o różnych średnicach i zsumuj wyniki. Do pojemności instalacji doliczyć trzeba jeszcze grzejniki, kocioł i zasobnik.',
      compute(v) {
        const list = pipeList(v.mat);
        const p = list.find(x => x[0] === v.dia) || list[0];
        const lpm = pipeLitersPerM(p);
        return {
          results: [{ label: 'Pojemność wodna odcinka', icon: 'drop', value: fmt(v.len * lpm, 2), unit: 'l',
            foot: `${fmt(v.len, 1)} m × ${fmt(lpm, 3)} l/m` }],
          rows: [
            ['Średnica wewnętrzna', fmt(pipeInner(p), 1) + ' mm'],
            ['Pojemność na metr', fmt(lpm, 3) + ' l/m'],
          ],
        };
      },
    },
    { key: 'quick', label: 'Szybki szacunek',
      cards: [{ title: 'Szacunek wg mocy instalacji', icon: 'bolt', fields: [
        { k: 'power', type: 'num', label: 'Moc instalacji', unit: 'kW', def: 20 },
        { k: 'em', type: 'select', label: 'Rodzaj odbiornika ciepła', def: 2,
          options: opts(EMITTERS, e => `${e[0]} (${e[1]} l/kW)`) },
        { k: 't', type: 'select', label: 'Maks. temperatura zasilania', def: 70,
          options: Object.keys(TEMP_MULT).map(t => ({ value: +t, label: t + ' °C' })) },
      ]}],
      tip: 'Metoda szacunkowa z Twojego poradnika — dobry punkt startowy do doboru naczynia wzbiorczego, gdy instalacja nie jest jeszcze rozrysowana.',
      compute(v) {
        const lpk = EMITTERS[v.em][1], m = TEMP_MULT[v.t];
        return {
          results: [{ label: 'Szacunkowa pojemność instalacji', icon: 'drop', value: fmt(v.power * lpk * m, 0), unit: 'l',
            foot: `${fmt(v.power, 1)} kW × ${lpk} l/kW × ${fmt(m, 2)}` }],
          jump: { calc: 'vessel', fields: { vol: Math.round(v.power * lpk * m) }, label: 'Dobierz naczynie wzbiorcze' },
        };
      },
    },
  ],
},

/* ---------------- 9. ZAWÓR BEZPIECZEŃSTWA ---------------- */
{
  id: 'valve', cat: 'safety', icon: 'shield',
  title: 'Zawór bezpieczeństwa',
  desc: 'Dobór zaworu c.o. / c.w.u.',
  sub: 'Dobór zaworu bezpieczeństwa',
  modes: [
    { key: 'co', label: 'Centralne ogrzewanie',
      cards: [{ title: 'Parametry kotła', icon: 'fire', fields: [
        { k: 'power', type: 'num', label: 'Moc kotła', unit: 'kW', def: 24 },
        { k: 'p', type: 'seg', def: '2.5', options: [{ value: '2.5', label: 'Nastawa 2,5 bar' }, { value: '3.0', label: 'Nastawa 3,0 bar' }] },
      ]}],
      tip: 'Dane orientacyjne na przykładzie zaworów typu 1915 (SYR). Zawsze zweryfikuj z instrukcją producenta kotła — część kotłów ma zawór bezpieczeństwa wbudowany fabrycznie.',
      compute(v) {
        const hi = v.p === '3.0', idx = hi ? 3 : 2;
        const row = SV_CO.find(r => v.power <= r[idx]);
        if (!row) return { error: 'Moc przekracza zakres tabeli — dobierz zawór indywidualnie wg DTR kotła.' };
        return { results: [{ label: 'Zalecane przyłącze zaworu', icon: 'plumb', value: row[0], unit: '',
          foot: `min. średnica kanału wylotowego: ${row[1]} mm\nmoc maks. przy ${hi ? '3,0' : '2,5'} bar: ${row[idx]} kW` }],
          addTo: { name: `Zawór bezpieczeństwa c.o. ${row[0]}, nastawa ${hi ? '3,0' : '2,5'} bar`,
                   tag: 'zawor_bezp', unit: 'szt', cat: 'mat' } };
      },
    },
    { key: 'cwu', label: 'Ciepła woda (c.w.u.)',
      cards: [{ title: 'Parametry podgrzewacza', icon: 'drop', fields: [
        { k: 'cap', type: 'num', label: 'Pojemność zasobnika c.w.u.', unit: 'l', def: 150 },
      ]}],
      tip: 'Dane orientacyjne na przykładzie zaworów typu 2115 (SYR). Zweryfikuj z DTR podgrzewacza.',
      compute(v) {
        const row = SV_CWU.find(r => r[3] !== null && v.cap <= r[3]) || SV_CWU[SV_CWU.length - 1];
        return { results: [{ label: 'Zalecane przyłącze zaworu', icon: 'plumb', value: row[0], unit: '',
          foot: `min. średnica kanału dolotowego: ${row[1]} mm\nzakres: ${row[2]}` }],
          addTo: { name: `Zawór bezpieczeństwa c.w.u. ${row[0]}`,
                   tag: 'zawor_bezp_cwu', unit: 'szt', cat: 'mat' } };
      },
    },
  ],
},

/* ---------------- 10. ZAWÓR MIESZAJĄCY (Kvs) ---------------- */
{
  id: 'mixvalve', cat: 'pumps', icon: 'wrench',
  title: 'Zawór mieszający (Kvs)',
  desc: 'Dobór zaworu do obiegu grzejnikowego i podłogówki',
  sub: 'Dobór Kvs zaworu mieszającego',
  modes: [
    { key: 'grzejniki', label: 'Obieg grzejnikowy',
      cards: [
        { title: 'Obieg grzejnikowy', icon: 'layers', fields: [
          { k: 'src', type: 'seg', def: 'moc', options: [
            { value: 'moc', label: 'Znam moc' }, { value: 'litry', label: 'Znam pojemność' },
          ]},
          { k: 'power', type: 'num', label: 'Moc obiegu', unit: 'kW', def: 12, step: 0.5,
            when: v => v.src === 'moc' },
          { k: 'vol', type: 'num', label: 'Pojemność wodna instalacji', unit: 'l', def: 150, step: 5,
            when: v => v.src === 'litry' },
          { k: 'emit', type: 'select', label: 'Rodzaj odbiorników', def: 2,
            options: opts(EMITTERS, e => e[0] + ' — ' + e[1] + ' l/kW'), when: v => v.src === 'litry' },
          { k: 'tmax', type: 'select', label: 'Maks. temperatura zasilania', def: 75,
            options: Object.keys(TEMP_MULT).map(t => ({ value: +t, label: t + ' °C' })),
            when: v => v.src === 'litry' },
          { k: 'dt', type: 'num', label: 'Δt obiegu (zasilanie − powrót)', unit: '°C', def: 15, step: 1 },
          { row: [
            { k: 'tsup', type: 'num', label: 'Zasilanie obiegu', unit: '°C', def: 70, step: 1 },
            { k: 'tprim', type: 'num', label: 'Zasilanie ze źródła', unit: '°C', def: 80, step: 1 },
          ]},
        ]},
        { title: 'Zawór', icon: 'tune', fields: [
          { k: 'dp', type: 'slider', label: 'Górna granica spadku ciśnienia',
            min: 3, max: 15, step: 0.5, def: 15, suffix: ' kPa' },
        ]},
      ],
      tip: 'Katalogi ESBE i AFRISO zalecają, żeby spadek ciśnienia na zaworze mieszającym mieścił się w przedziale 3–15 kPa, i każą brać najmniejszy zawór, który się w tym polu mieści. Przewymiarowanie to najczęstszy błąd doboru: siłownik przechodzi wtedy cały zakres na kilku stopniach obrotu i temperatura obiegu oscyluje o kilka stopni wokół zadanej. Opór zaworu dolicz do wysokości podnoszenia pompy obiegowej. Dla grzejników zalecane Δt to 15 lub 20 °C.',
      compute(v) {
        if (v.dt <= 0) return { error: 'Δt obiegu musi być większe od zera.' };

        /* Pojemność wodna przeliczana na moc odwrotnością wskaźnika
           z kalkulatora pojemności instalacji: V = P · wskaźnik · multiplikator. */
        let kW = v.power, skad = null;
        if (v.src === 'litry') {
          if (!(v.vol > 0)) return { error: 'Podaj pojemność wodną instalacji.' };
          const wsk = (EMITTERS[v.emit] || EMITTERS[2])[1];
          const mult = TEMP_MULT[v.tmax] || 1;
          kW = v.vol / (wsk * mult);
          skad = fmt(v.vol, 0) + ' l ÷ (' + wsk + ' l/kW × ' + fmt(mult, 2) + ')';
        }
        if (!(kW > 0)) return { error: 'Podaj moc obiegu.' };

        const q = circuitFlow(kW, v.dt);
        const s = selectMixingValve(q, v.dp / 100);
        if (!s) return { error: 'Uzupełnij dane obiegu.' };
        const r = mixResult(v, q, s, v.tsup, v.tsup - v.dt, v.tprim, 'grzejnikowy');
        r.rows.unshift(['Moc obiegu', fmt(kW, 2) + ' kW']);
        if (skad) {
          r.rows.splice(1, 0, ['Oszacowana z pojemności', skad]);
          r.warn = r.warn || 'Moc policzona z pojemności wodnej to tylko oszacowanie — wskaźnik l/kW zależy od typu grzejników i rozległości rurociągów. Jeśli znasz moc obiegu, podaj ją wprost.';
        }
        return r;
      },
    },

    { key: 'podlogowka', label: 'Ogrzewanie podłogowe',
      cards: [
        { title: 'Obieg podłogowy', icon: 'floor', fields: [
          { k: 'src', type: 'seg', def: 'pow', options: [
            { value: 'pow', label: 'Znam powierzchnię' }, { value: 'moc', label: 'Znam moc' },
          ]},
          { k: 'area', type: 'num', label: 'Powierzchnia ogrzewania podłogowego', unit: 'm²', def: 80, step: 1,
            when: v => v.src === 'pow' },
          { k: 'q', type: 'slider', label: 'Obciążenie cieplne podłogi',
            min: 20, max: 100, step: 5, def: 60, suffix: ' W/m²', when: v => v.src === 'pow' },
          { k: 'power', type: 'num', label: 'Moc obiegu podłogowego', unit: 'kW', def: 5, step: 0.5,
            when: v => v.src === 'moc' },
          { k: 'dt', type: 'num', label: 'Δt obiegu (zasilanie − powrót)', unit: '°C', def: 7, step: 1 },
          { row: [
            { k: 'tsup', type: 'num', label: 'Zasilanie podłogówki', unit: '°C', def: 35, step: 1 },
            { k: 'tprim', type: 'num', label: 'Zasilanie ze źródła', unit: '°C', def: 70, step: 1 },
          ]},
        ]},
        { title: 'Zawór', icon: 'tune', fields: [
          { k: 'dp', type: 'slider', label: 'Górna granica spadku ciśnienia',
            min: 3, max: 15, step: 0.5, def: 15, suffix: ' kPa' },
        ]},
      ],
      tip: 'Obciążenie cieplne podłogi bierz z kalkulatora strat ciepła: strata pomieszczenia podzielona przez powierzchnię. 60 W/m² to typowa wartość dla domu ocieplonego po 2000 roku, 30–40 W/m² dla budynku energooszczędnego, 80–100 W/m² dla starego budownictwa — przy takim obciążeniu sprawdź jeszcze temperaturę powierzchni w kalkulatorze podłogówki. Podłogówka pracuje na małym Δt — AFRISO podaje jako optymalne 5 °C — więc przepływ wychodzi duży i zawór wypada większy niż przy grzejnikach o tej samej mocy.',
      compute(v) {
        if (v.dt <= 0) return { error: 'Δt obiegu musi być większe od zera.' };

        let kW, skad = null;
        if (v.src === 'moc') {
          if (!(v.power > 0)) return { error: 'Podaj moc obiegu podłogowego.' };
          kW = v.power;
        } else {
          if (!(v.area > 0)) return { error: 'Podaj powierzchnię ogrzewania podłogowego.' };
          kW = v.area * v.q / 1000;
          skad = fmt(v.area, 0) + ' m² × ' + fmt(v.q, 0) + ' W/m²';
        }

        const q = circuitFlow(kW, v.dt);
        const s = selectMixingValve(q, v.dp / 100);
        if (!s) return { error: 'Uzupełnij dane obiegu.' };
        const r = mixResult(v, q, s, v.tsup, v.tsup - v.dt, v.tprim, 'podłogowy');
        r.rows.unshift(['Moc obiegu', fmt(kW, 2) + ' kW']);
        if (skad) r.rows.splice(1, 0, ['Policzona z powierzchni', skad]);
        return r;
      },
    },

  ],
},
];

/* Wspólne złożenie wyniku dla obu trybów doboru zaworu. */
function mixResult(v, q, s, tsup, tret, tprim, circuit) {
  const kpa = x => fmt(x * 100, 1) + ' kPa';
  const kv = k => String(k).replace('.', ',');

  const rows = [
    ['Przepływ obiegu', fmt(q, 3) + ' m³/h'],
    ['Przepływ obiegu w l/min', fmt(q * 1000 / 60, 1) + ' l/min'],
    ['Kvs wymagane', fmt(s.required, 2) + ' m³/h'],
    ['Spadek na dobranym zaworze', kpa(s.dp)],
  ];

  /* Ta sama przepustowość w kilku wielkościach przyłącza — pokazujemy
     wszystkie z prędkością, bo spadek ciśnienia jest w nich identyczny
     i wybór korpusu należy do instalatora. */
  s.sizes.forEach(z => {
    rows.push([`Wariant ${z.dn} (${z.thread}) — prędkość`, fmt(z.v, 2) + ' m/s']);
  });

  if (s.alt) rows.push([`Zawór o stopień większy — Kvs ${kv(s.alt.kvs)}`, kpa(s.alt.dp)]);

  const mix = (tprim != null) ? mixingRatio(q, tsup, tret, tprim) : null;
  if (mix) {
    rows.push(['Przepływ ze źródła', fmt(mix.primary, 3) + ' m³/h']);
    rows.push(['Udział wody ze źródła', fmt(mix.share * 100, 0) + '%']);
    rows.push(['Domieszka z powrotu obiegu', fmt((1 - mix.share) * 100, 0) + '%']);
  } else if (tprim != null) {
    rows.push(['Stosunek mieszania', 'źródło nie jest cieplejsze']);
  }
  rows.push(['Wzór', 'Kvs = G / √Δp']);

  let warn = null;
  if (s.overRange) {
    warn = 'Przepływ przekracza największy zawór z typoszeregu (Kvs 40) — podziel obieg albo dobierz zawór z katalogu producenta poza tą serią.';
  } else if (s.aboveBand) {
    warn = `Nawet największy zawór daje spadek ${kpa(s.dp)}, powyżej zalecanego pola 3–15 kPa. Zawór będzie dławił obieg — zmniejsz przepływ, zwiększając Δt.`;
  } else if (s.belowBand) {
    warn = `Spadek na zaworze to tylko ${kpa(s.dp)}, poniżej zalecanego pola 3–15 kPa. To już najmniejszy zawór z serii, ale przy tak małym obiegu regulacja i tak będzie ostra — rozważ zawór termostatyczny zamiast mieszającego z siłownikiem.`;
  } else if (s.fast) {
    warn = `Przy przepływie ${fmt(q, 3)} m³/h prędkość w największym dostępnym przyłączu (${s.pick.dn}) wynosi ${fmt(s.velocity, 2)} m/s. Sam dobór Kvs jest zgodny z metodą katalogową — to tylko sygnał, że obieg jest mocno obciążony jak na ten rozmiar zaworu.`;
  }

  return {
    results: [
      { label: 'Wymagane Kvs', icon: 'calc', value: fmt(s.required, 2), unit: 'm³/h',
        foot: `przepływ obiegu ${fmt(q, 3)} m³/h (${fmt(q * 1000 / 60, 1)} l/min) przy granicy spadku ${fmt(v.dp, 1)} kPa` },
      { label: 'Dobrany zawór', icon: 'check', value: `Kvs ${kv(s.kvs)} · ${s.pick.dn}`, unit: '', small: true,
        foot: `${s.pick.thread} · spadek na zaworze ${kpa(s.dp)} · prędkość ${fmt(s.pick.v, 2)} m/s`
            + (s.sizes.length > 1 ? `\nto Kvs jest dostępne też jako ${s.sizes.filter(z => z.dn !== s.pick.dn).map(z => z.dn).join(', ')}` : '') },
    ],
    rows,
    warn,
    addTo: { name: `Zawór mieszający 3-drogowy ${s.pick.dn} (${s.pick.thread}), Kvs ${kv(s.kvs)}`
                 + (circuit ? ` — obieg ${circuit}` : ''),
             tag: 'zawor_mieszajacy', unit: 'szt', cat: 'mat' },
  };
}

/* ============================================================
   STAN I RENDEROWANIE
   ============================================================ */
/* Dane wpisane w kalkulatorach zapisujemy w telefonie tak samo jak oferty.
   Bez tego każde zamknięcie aplikacji albo odświeżenie strony kasowało
   wszystko, co użytkownik wpisał. */
const CALC_KEY = 'ai_kalkulatory_v1';
function loadCalcValues() {
  try {
    const raw = localStorage.getItem(CALC_KEY);
    if (raw) { const o = JSON.parse(raw); if (o && typeof o === 'object') return o; }
  } catch (e) { /* prywatne okno albo zablokowane dane — startujemy od domyślnych */ }
  return {};
}
function saveCalcValues() {
  try { localStorage.setItem(CALC_KEY, JSON.stringify(state.values)); } catch (e) { /* bez zapisu też działa */ }
}

const state = { tab: 'calc', screen: 'home', calc: null, mode: {},
                values: loadCalcValues(), query: '', gasWarn: false, coNowego: null };

const vkey = (id, mk) => id + '::' + (mk || '_');
function activeMode(calc) {
  if (!calc.modes) return { key: '_', cards: calc.cards, tip: calc.tip, compute: calc.compute };
  const k = state.mode[calc.id] || calc.modes[0].key;
  return calc.modes.find(m => m.key === k) || calc.modes[0];
}
function fieldList(mode) {
  const out = [];
  (mode.cards || []).forEach(c => c.fields.forEach(f => {
    if (f.row) f.row.forEach(x => out.push(x)); else out.push(f);
  }));
  return out;
}
function getValues(calc, mode) {
  const key = vkey(calc.id, mode.key);
  const def = {};
  fieldList(mode).forEach(f => {
    def[f.k] = (f.def && typeof f.def === 'object') ? JSON.parse(JSON.stringify(f.def)) : f.def;
    if (f.dynamic === 'pipeDia') def[f.k] = '';
  });
  if (!state.values[key]) {
    state.values[key] = def;
  } else {
    // Zapis mógł powstać w starszej wersji aplikacji, w której danego pola
    // jeszcze nie było — uzupełniamy braki wartościami domyślnymi, zamiast
    // liczyć na undefined i dostać NaN w wyniku.
    Object.keys(def).forEach(k => {
      if (state.values[key][k] === undefined) state.values[key][k] = def[k];
    });
  }
  return state.values[key];
}
/* średnica zależna od materiału — pilnujemy poprawnej wartości */
function ensurePipeDia(v, key) {
  const list = pipeList(v.mat);
  if (!list.some(p => p[0] === v[key])) v[key] = list[Math.min(3, list.length - 1)][0];
  return list;
}

/* ---------- Ekran główny ---------- */
function renderHome() {
  const q = state.query.trim().toLowerCase();
  const list = CALCS.filter(c => !q || c.title.toLowerCase().includes(q) || c.desc.toLowerCase().includes(q));
  const groups = {};
  list.forEach(c => (groups[c.cat] = groups[c.cat] || []).push(c));

  let html = '<header class="hdr hdr--home"><span class="blob a"></span><span class="blob b"></span>' +
    '<span class="ghost">' + svg('plumb') + '</span>' +
    '<div class="hdr-row"><div><h1>Asystent Instalatora</h1>' +
    '<p>Kalkulatory, oferty i wsparcie AI w jednym miejscu</p></div>' +
    '<button class="hdr-act" data-reset title="Wyczyść wyniki" aria-label="Wyczyść wyniki kalkulatorów">' +
    svg('restore') + '</button></div></header><div class="body">' +
    '<div class="search">' + svg('search') +
    '<input id="q" type="search" placeholder="Szukaj kalkulatora…" value="' + esc(state.query) + '" aria-label="Szukaj kalkulatora"></div>';

  if (!list.length) html += '<p class="empty">Brak kalkulatora pasującego do „' + esc(state.query) + '”.</p>';

  Object.keys(groups).forEach(cat => {
    html += '<div class="cat-head" style="--c:' + CATS[cat].c + '"><span class="cat-dot"></span>' + CATS[cat].label + '</div><div class="tiles">';
    groups[cat].forEach(c => {
      html += '<button class="tile" style="--c:' + CATS[c.cat].c + '" data-calc="' + c.id + '">' +
        '<span class="tile-ico">' + svg(c.icon) + '</span>' +
        '<span class="tile-txt"><strong>' + esc(c.title) + '</strong><span>' + esc(c.desc) + '</span></span>' +
        '<span class="tile-chev">' + svg('chev') + '</span></button>';
    });
    html += '</div>';
  });
  return html + '</div>';
}

/* ---------- Ekran kalkulatora ---------- */
function renderCalc() {
  const calc = CALCS.find(c => c.id === state.calc);
  const mode = activeMode(calc);
  const c = CATS[calc.cat].c;

  let html = '<header class="hdr hdr--cat" style="--c:' + c + '"><span class="blob a"></span><span class="blob b"></span>' +
    '<div class="hdr-row"><button class="back" id="back" aria-label="Wróć">' + svg('back') + '</button>' +
    '<div><h1>' + esc(calc.title) + '</h1><p>' + esc(calc.sub) + '</p></div></div></header><div class="body">';

  /* Kalkulator płatny bez abonamentu: pasek mówiący, że to podgląd.
     Pola zostają na miejscu i wyglądają normalnie — blokadę trzyma pro.js. */
  if (typeof proPasek === 'function') html += proPasek(calc.id);

  /* Stały pasek dla kalkulatorów, przy których prawo wymaga uprawnień.
     Zostaje na ekranie także po zamknięciu okna z ostrzeżeniem. */
  if (calc.law) {
    html += '<div class="tip tip--law">' + svg('alert') +
      '<div><strong>Uprawnienia gazowe.</strong> ' + esc(calc.law) + '</div></div>';
  }

  if (calc.modes) {
    html += '<div class="seg" role="group" aria-label="Wariant">';
    calc.modes.forEach(m => html += '<button type="button" data-mode="' + m.key + '" aria-pressed="' + (m.key === mode.key) + '">' + esc(m.label) + '</button>');
    html += '</div>';
  }

  (mode.cards || []).forEach(card => {
    html += '<div class="card"><div class="card-head">' + svg(card.icon || 'tune') + esc(card.title) + '</div>' +
      '<div class="fields">' + renderFields(calc, mode, card) + '</div></div>';
  });

  return html + '<div id="out"></div></div>';
}

function renderFields(calc, mode, card) {
  const v = getValues(calc, mode);
  const cc = CATS[calc.cat].c;

  const one = f => {
    if (f.type === 'num') {
      return '<div class="field"><label for="f-' + f.k + '">' + esc(f.label) + '</label>' +
        '<input id="f-' + f.k + '" type="number" inputmode="decimal" step="' + (f.step || 'any') + '" data-k="' + f.k + '" value="' + v[f.k] + '">' +
        (f.unit ? '<span class="unit">' + esc(f.unit) + '</span>' : '') + '</div>';
    }
    if (f.type === 'select') {
      let o = f.options;
      if (f.dynamic === 'pipeDia') {
        const list = ensurePipeDia(v, f.k);
        o = list.map(p => ({ value: p[0], label: p[0] + '  ·  Ø wewn. ' + fmt(pipeInner(p), 1) + ' mm' }));
      }
      const nota = typeof f.note === 'function' ? f.note(v) : f.note;
      return '<div class="field"><label for="f-' + f.k + '">' + esc(f.label)
        + (nota ? ' <span class="lbl-nota">(' + esc(nota) + ')</span>' : '') + '</label>' +
        '<select id="f-' + f.k + '" data-k="' + f.k + '">' +
        o.map(x => '<option value="' + esc(x.value) + '"' + (String(x.value) === String(v[f.k]) ? ' selected' : '') + '>' + esc(x.label) + '</option>').join('') +
        '</select><span class="chev">' + svg('chevDown') + '</span></div>';
    }
    if (f.type === 'seg') {
      return '<div class="seg" role="group">' + f.options.map(o =>
        '<button type="button" data-k="' + f.k + '" data-v="' + esc(o.value) + '" aria-pressed="' + (String(o.value) === String(v[f.k])) + '">' + esc(o.label) + '</button>').join('') + '</div>';
    }
    if (f.type === 'slider') {
      /* Suwak zaprasza do kręcenia, a wartość domyślna jest zwykle tą właściwą —
         to ona pochodzi z normy albo z praktyki opisanej w karcie. Bez drogi
         powrotnej jedno nieuważne przeciągnięcie zostaje w telefonie na zawsze,
         bo wartości zapisują się same. Stąd przycisk przy samym suwaku,
         a nie zbiorcze „przywróć wszystko" gdzieś na dole ekranu. */
      const dom = fmt(f.def, 2) + (f.suffix || '');
      return '<div class="slider" style="--c:' + cc + '"><div class="slider-top"><span>' + esc(f.label) + '</span>' +
        '<span class="slider-right">' +
        '<span class="slider-val" id="sv-' + f.k + '">' + fmt(v[f.k], 2) + esc(f.suffix || '') + '</span>' +
        '<button type="button" class="sreset" id="sr-' + f.k + '" data-sreset="' + f.k + '"' +
        (Number(v[f.k]) === Number(f.def) ? ' hidden' : '') +
        ' title="Przywróć domyślne: ' + esc(dom) + '" aria-label="Przywróć wartość domyślną ' + esc(dom) + '">' +
        svg('restore') + '</button></span></div>' +
        '<input id="f-' + f.k + '" type="range" data-k="' + f.k + '" min="' + f.min + '" max="' + f.max + '" step="' + f.step + '" value="' + v[f.k] + '" aria-label="' + esc(f.label) + '"></div>';
    }
    if (f.type === 'counters') {
      return f.options.map((o, i) => {
        const n = v[f.k][i] || 0;
        return '<div class="cnt' + (n ? ' on' : '') + '"><div class="cnt-l">' + esc(o.label) +
          '<small>qn = ' + fmt(o.qn, 2) + ' l/s</small></div>' +
          '<div class="cnt-c"><button type="button" data-cnt="' + f.k + '" data-i="' + i + '" data-d="-1" aria-label="Mniej">−</button>' +
          '<b>' + n + '</b>' +
          '<button type="button" data-cnt="' + f.k + '" data-i="' + i + '" data-d="1" aria-label="Więcej">+</button></div></div>';
      }).join('');
    }
    /* Lista przyborów w kolejności na gałęzi. Różni się od numlist tym,
       że wiersz jest wyborem z listy, a nie liczbą — kolejność ma tu
       znaczenie, bo decyduje, ile przyborów zasila każdy odcinek. */
    if (f.type === 'fxlist') {
      const rows = (v[f.k] || []).map((val, i) =>
        '<div class="nrow"><div class="field"><label>' + (i + 1) + '. przybór od pionu</label>' +
        '<select data-fx="' + f.k + '" data-i="' + i + '">' +
        FIXTURES.map((x, j) => '<option value="' + j + '"' + (j === Number(val) ? ' selected' : '') + '>' +
          esc(x[0]) + '  ·  ' + fmt(x[1], 2) + ' l/s</option>').join('') +
        '</select><span class="chev">' + svg('chevDown') + '</span></div>' +
        '<button class="del" type="button" data-delfx="' + f.k + '" data-i="' + i + '" aria-label="Usuń">' + svg('trash') + '</button></div>').join('');
      return '<div class="nlist">' + rows +
        '<button class="addbtn" type="button" data-addfx="' + f.k + '" style="--c:' + cc + '">' + svg('plus') + esc(f.addLabel || 'Dodaj przybór') + '</button></div>';
    }
    /* Punkt na gałęzi gazowej. Jedna pozycja to cztery liczby naraz, bo
       przy gazie nie da się dobrać odcinka bez jego długości i kształtek.
       Żeby to nie było ścianą pól, każdy punkt dostaje własną ramkę:
       u góry urządzenie, pod spodem liczby po dwie w rzędzie. Moc podpowiada
       się z listy urządzeń, ale zostaje do poprawienia — z tabliczki
       znamionowej wyjdzie dokładniejsza niż z katalogowego „środka półki". */
    if (f.type === 'gazlist') {
      const num = (k, i, pole, etyk, jedn, val, step) =>
        '<div class="field"><label>' + esc(etyk) + '</label>' +
        '<input type="number" inputmode="decimal" step="' + (step || 'any') + '" data-gz="' + k + '" data-i="' + i +
        '" data-p="' + pole + '" value="' + val + '">' +
        (jedn ? '<span class="unit">' + esc(jedn) + '</span>' : '') + '</div>';

      const rows = (v[f.k] || []).map((p, i) =>
        '<div class="gpt">' +
          '<div class="gpt-h"><span class="gpt-n" style="--c:' + cc + '">' + (i + 1) + '</span>' +
          '<div class="field"><label>Urządzenie</label><select data-gzu="' + f.k + '" data-i="' + i + '">' +
          GAS_APPLIANCES.map((x, j) => '<option value="' + j + '"' + (j === Number(p.u) ? ' selected' : '') + '>' +
            esc(x[0]) + '</option>').join('') +
          '</select><span class="chev">' + svg('chevDown') + '</span></div>' +
          '<button class="del" type="button" data-delgz="' + f.k + '" data-i="' + i + '" aria-label="Usuń">' + svg('trash') + '</button></div>' +
          '<div class="row2">' + num(f.k, i, 'kw', 'Moc', 'kW', p.kw) +
            num(f.k, i, 'len', i === 0 ? 'Od gazomierza' : 'Od punktu ' + i, 'm', p.len) + '</div>' +
          '<div class="row2">' + num(f.k, i, 'wys', 'Wzniesienie', 'm', p.wys) +
            num(f.k, i, 'kol', 'Kolanek', 'szt', p.kol, '1') + '</div>' +
        '</div>').join('');

      return '<div class="nlist">' + rows +
        '<p class="gpt-lead">Kolejność od gazomierza. Długość to odcinek od poprzedniego punktu, nie od gazomierza. Wzniesienie w górę wpisuj dodatnie, w dół ze znakiem minus.</p>' +
        '<button class="addbtn" type="button" data-addgz="' + f.k + '" style="--c:' + cc + '">' + svg('plus') + esc(f.addLabel || 'Dodaj urządzenie') + '</button></div>';
    }
    /* Wiersz rozdzielacza: nazwa, rodzaj obiegu, moc i liczba wyjść.
       Cztery rzeczy naraz, więc każdy dostaje własną ramkę jak przy gazie —
       inaczej na telefonie zrobiłaby się ściana pól bez początku i końca.
       Rodzaj jest przełącznikiem, a nie listą, bo są tylko dwa i wybór
       zmienia całą matematykę: podłogówka liczy się na innym Δt. */
    if (f.type === 'oblist') return ktObListaHtml(f, v, cc);
    if (f.type === 'rozdzlist') {
      const num = (i, p, etyk, jedn, val, step) =>
        '<div class="field"><label>' + esc(etyk) + '</label>' +
        '<input type="number" inputmode="numeric" step="' + (step || 'any') + '" data-rz="' + f.k +
        '" data-i="' + i + '" data-p="' + p + '" value="' + val + '">' +
        (jedn ? '<span class="unit">' + esc(jedn) + '</span>' : '') + '</div>';

      const rows = (v[f.k] || []).map((r, i) => {
        const nm = String(r.nazwa || '');
        const lista = ROZDZIELACZE.concat(nm && ROZDZIELACZE.indexOf(nm) < 0 ? [nm] : []);
        return '<div class="gpt">' +
          '<div class="gpt-h"><span class="gpt-n" style="--c:' + cc + '">' + (i + 1) + '</span>' +
          '<div class="field"><label>Rozdzielacz' +
          (r.przyklad ? '<span class="tagmini">przykład</span>' : '') +
          '</label><select data-rznm="' + f.k + '" data-i="' + i + '">' +
          lista.map(x => '<option value="' + esc(x) + '"' + (x === nm ? ' selected' : '') + '>' +
            esc(x) + '</option>').join('') +
          '</select><span class="chev">' + svg('chevDown') + '</span></div>' +
          '<button class="del" type="button" data-delrz="' + f.k + '" data-i="' + i + '" aria-label="Usuń">' + svg('trash') + '</button></div>' +
          '<div class="row2">' + num(i, 'w', 'Moc rozdzielacza', 'W', r.w) +
            num(i, 'wyj', 'Pętli', 'szt', r.wyj, '1') + '</div>' +
          '<div class="row2">' + num(i, 'dl', 'Rura od źródła, z pionem', 'm', r.dl, '0.5') +
            num(i, 'dp', 'Opory najdłuższej pętli', 'kPa', r.dp, '0.5') + '</div>' +
        '</div>';
      }).join('');

      return '<div class="nlist">' + rows +
        '<button class="addbtn" type="button" data-addrz="' + f.k + '" style="--c:' + cc + '">' +
        svg('plus') + esc(f.addLabel || 'Dodaj rozdzielacz') + '</button></div>';
    }
    if (f.type === 'numlist') {
      /* Z opcją `nazwy` każda pozycja dostaje jeszcze pole na nazwę
         pomieszczenia. Nazwa jest dobrowolna, ale bardzo się przydaje:
         wchodzi na rysunek poglądowy, więc monter rozpakowujący grzejniki
         wie, który jest który, zamiast liczyć po kolei od kotła. */
      const nazwy = f.nazwy ? (v[f.k + 'Nazwy'] || []) : null;
      /* Numer gałęzi pokazujemy tylko wtedy, gdy instalator powiedział, że
         gałęzi jest kilka — inaczej lista rośnie o pole, którego nikt nie
         używa. Dajemy trzy gałęzie, bo w domu jednorodzinnym więcej od kotła
         nie wychodzi; przy większej instalacji liczy się ją rozdzielaczami. */
      const galList = f.galezie && v.galezie === 'tak' ? (v[f.k + 'Galaz'] || []) : null;
      /* Dwa pokoje albo dwie kuchnie: na rysunku dostają numery „Pokój 1",
         „Pokój 2" — i ten sam numer musi być widać tu, na liście, inaczej
         instalator nie wie, który wiersz to który pokój z rysunku. */
      const wyswietlane = nazwy ? nazwyGrzejnikow(nazwy, (v[f.k] || []).length) : [];
      const rows = (v[f.k] || []).map((val, i) => {
        const nm = nazwy ? String(nazwy[i] || '') : '';
        const gl = galList ? (Number(galList[i]) || 1) : 0;
        const poleGalezi = galList
          ? '<div class="field field--sm"><label>Gałąź</label>' +
            '<select data-nlgz="' + f.k + '" data-i="' + i + '">' +
            [1, 2, 3].map(x => '<option value="' + x + '"' + (x === gl ? ' selected' : '') + '>'
              + x + '</option>').join('') +
            '</select><span class="chev">' + svg('chevDown') + '</span></div>'
          : '';
        /* Przy trzech kolumnach „Moc grzejnika 3" łamie się na dwie linie
           i wiersz robi się wyższy od sąsiednich — wtedy skracamy etykietę. */
        const etykietaMocy = (galList ? 'Moc' : esc(f.label)) + ' ' + (i + 1);
        const polePmocy = '<div class="field field--sm"><label>' + etykietaMocy + '</label>' +
          '<input type="number" inputmode="decimal" data-nl="' + f.k + '" data-i="' + i + '" value="' + val + '">' +
          '<span class="unit">' + esc(f.unit || '') + '</span></div>';
        /* Pomieszczenie wybiera się z listy, nie wpisuje: na budowie, w rękawicach,
           klikanie jest szybsze od pisania, a nazwy i tak powtarzają się w kółko.
           Nazwę spoza listy — z wcześniejszego zapisu — dokładamy na koniec,
           żeby wybór jej nie skasował. */
        let poleNazwy = '';
        if (nazwy) {
          const lista = POMIESZCZENIA.concat(nm && POMIESZCZENIA.indexOf(nm) < 0 ? [nm] : []);
          poleNazwy = '<div class="field field--sm"><label>Pomieszczenie</label>' +
            '<select data-nlnm="' + f.k + '" data-i="' + i + '">' +
            '<option value=""' + (nm ? '' : ' selected') + '>— bez nazwy —</option>' +
            lista.map(x => '<option value="' + esc(x) + '"' + (x === nm ? ' selected' : '') + '>'
              + esc(x === nm ? wyswietlane[i] : x) + '</option>').join('') +
            '</select><span class="chev">' + svg('chevDown') + '</span></div>';
        }
        const chip = f.grzejnik ? grzChipyHtml(f.k, i, Number(val), v, nm) : '';
        return '<div class="nrow' + (chip ? ' nrow--grz' : '') + '">' +
          (nazwy
            ? '<div class="npair' + (galList ? ' npair--gal' : '') + '">'
              + poleNazwy + polePmocy + poleGalezi + '</div>'
            : polePmocy) +
          '<button class="del" type="button" data-del="' + f.k + '" data-i="' + i + '" aria-label="Usuń">' + svg('trash') + '</button>'
          + chip + '</div>';
      }).join('');
      return '<div class="nlist">' + rows +
        '<button class="addbtn" type="button" data-add="' + f.k + '" style="--c:' + cc + '">' + svg('plus') + esc(f.addLabel || 'Dodaj') + '</button></div>';
    }
    return '';
  };

  /* Pola z warunkiem `when` pokazujemy tylko wtedy, gdy warunek jest spełniony —
     dzięki temu jeden tryb przyjmuje dane na kilka sposobów, a instalator widzi
     tylko te rubryki, które faktycznie ma czym wypełnić. */
  const widoczne = f => !f.when || f.when(v);
  return card.fields.filter(widoczne).map(f => f.row
    ? '<div class="row2">' + f.row.filter(widoczne).map(one).join('') + '</div>'
    : one(f)).join('');
}

/* ---------- Wyniki ---------- */
/* Opis pod wynikiem. Krótki stoi od razu, dłuższy chowa się pod
   „Opis”, żeby na ekranie zostały same duże liczby. Rozwinięcie
   pamiętamy, bo każda zmiana pola przerysowuje wyniki. */
state.wynikOtw = {};
/* Opis pod wynikiem. Do trzech linijek stoi od razu; dłuższy chowa się,
   a w prawym górnym rogu karty jest strzałka do rozwinięcia. Rozwinięcie
   pamiętamy, bo każda zmiana pola przerysowuje wyniki. */
function stopkaWyniku(calcId, r) {
  const tekst = String(r.foot);
  const html = '<div class="result-foot">' + esc(tekst).replace(/\n/g, '<br>') + '</div>';
  const linie = tekst.split('\n').reduce((a, l) => a + Math.max(1, Math.ceil(l.length / 46)), 0);
  if (linie <= 3) return html;
  const k = calcId + '|' + r.label, otw = !!state.wynikOtw[k];
  return '<button class="result-tog' + (otw ? ' on' : '') + '" data-wynikotw="' + esc(k) + '" aria-label="' + (otw ? 'Zwiń opis' : 'Rozwiń opis') + '">'
    + svg('chevDown') + '</button><div class="result-more' + (otw ? ' on' : '') + '" data-wynikotw="' + esc(k) + '">' + html + '</div>';
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-wynikotw]');
  if (!b) return;
  // dotknięcie strzałki albo samego opisu
  const k = b.dataset.wynikotw; state.wynikOtw[k] = !state.wynikOtw[k];
  const karta = b.closest('.result') || b.parentElement;
  karta.querySelectorAll('.result-tog, .result-more').forEach(x => x.classList.toggle('on', state.wynikOtw[k]));
});

/* ------------------------------------------------------------
   SUWAKI ODSTAJĄCE OD DOMYŚLNYCH
   Suwak da się ruszyć przypadkiem przy przewijaniu ekranu, a wartość
   zapisuje się sama i zostaje na zawsze. Sama strzałka powrotu przy
   suwaku nie wystarczy — trzeba ją zauważyć. Dlatego nad wynikiem
   staje pasek z tym, co zostało zmienione, i jednym przyciskiem
   przywracającym normowe wartości.
   ------------------------------------------------------------ */
function suwakiZmienione(calc, mode, v) {
  return fieldList(mode).filter(f =>
    f && f.type === 'slider' && f.def !== undefined && Number(v[f.k]) !== Number(f.def));
}
function paskaSuwakow(calc, mode, v) {
  const zm = suwakiZmienione(calc, mode, v);
  if (!zm.length) return '';
  const opis = zm.map(f => esc(f.label) + ' ' + fmt(v[f.k], 2) + esc(f.suffix || '')
    + ' zamiast ' + fmt(f.def, 2) + esc(f.suffix || '')).join(' · ');
  return '<div class="tip tip--warn">' + svg('alert')
    + '<div><strong>Zmienione ustawienie.</strong> ' + opis
    + '<br>Wynik liczy się z Twojej wartości, nie z domyślnej.</div>'
    + '<button class="pro-btn" data-suwakireset>Przywróć</button></div>';
}

function renderOutput() {
  const calc = CALCS.find(c => c.id === state.calc);
  const mode = activeMode(calc);
  const v = getValues(calc, mode);
  const c = CATS[calc.cat].c;
  let res;
  try { res = mode.compute(v); }
  catch (e) { res = { error: 'Uzupełnij poprawnie dane wejściowe.' }; }

  let html = '<div style="display:flex;flex-direction:column;gap:14px;margin-top:14px">';

  html += paskaSuwakow(calc, mode, v);

  if (res.error) {
    html += '<div class="tip tip--warn">' + svg('shield') + '<div>' + esc(res.error) + '</div></div>';
  } else {
    (res.results || []).forEach(r => {
      html += '<div class="result' + (r.small ? ' result--sm' : '') + '" style="--c:' + c + '">' +
        '<div class="result-label">' + svg(r.icon || 'check') + esc(r.label) + '</div>' +
        '<div class="result-val"><b>' + esc(r.value) + '</b>' + (r.unit ? '<span>' + esc(r.unit) + '</span>' : '') + '</div>' +
        (r.foot ? stopkaWyniku(calc.id, r) : '') + '</div>';
    });
    if (res.top) html += res.top;   // np. powrót do schematu kotłowni — od razu pod wynikiem
    if (res.warn) html += '<div class="tip tip--warn">' + svg('shield') + '<div>' + esc(res.warn) + '</div></div>';
    if (res.rows) {
      html += '<div class="subhead">Szczegóły obliczenia</div><div class="rows">' +
        /* Krótka wartość stoi w tej samej linii co etykieta, dłuższa schodzi
           pod nią. Bez tego zdanie w kolumnie wartości wpychało się na
           etykietę i obie były nieczytelne. */
        res.rows.map(r => {
          const dlugie = String(r[1]).length > 26;
          return '<div class="r' + (r[2] ? ' tot' : '') + (dlugie ? ' r--long' : '') + '">'
            + '<span>' + esc(r[0]) + '</span><b>' + esc(r[1]) + '</b></div>';
        }).join('') + '</div>';
    }
    if (res.extra) html += res.extra;
    if (typeof ktPrzyciskPrzenies === 'function') html += ktPrzyciskPrzenies(calc.id, v);
    if (typeof kalkZestBtn === 'function') html += kalkZestBtn(calc.id, res);
    /* Rysunek gałęzi. Dane trzymamy w stanie, a nie w atrybucie przycisku —
       są w nich nazwy z cudzysłowami (DN15 (1/2")) i całe tablice odcinków.
       Guzik rysunku stoi w jednym rzędzie z „Przenieś do projektu” — to dwie
       rzeczy, które robi się z gotowym wynikiem, więc mają leżeć obok siebie. */
    let rysBtny = '';
    const maRysunek = res.schemat && ((res.schemat.odcinki || []).length
      || (res.schemat.galezie || []).some(g => g && (g.odcinki || []).length)
      || (res.schemat.rozdzielacze || []).some(x => x && (x.odcinki || []).length));
    if (maRysunek) {
      state.pendingSchemat = res.schemat;
      rysBtny += '<button class="btn2" data-schemat>' + svg('list') + 'Projekt poglądowy</button>';
    }
    /* Kilka rysunków naraz — po jednym na rozdzielacz. Każdy dostaje
       własny guzik z nazwą, bo „Projekt poglądowy" razy trzy nie mówi
       nic o tym, który jest który. */
    const schematy = (res.schematy || []).filter(x => x && (x.odcinki || []).length);
    if (schematy.length) {
      state.pendingSchematy = schematy;
      schematy.forEach((x, i) => {
        rysBtny += '<button class="btn2" data-schematy="' + i + '">' + svg('list')
          + esc(x.guzik || x.tytul || 'Projekt poglądowy') + '</button>';
      });
    }
    const pasekProj = typeof projPasekKalk === 'function' ? projPasekKalk(calc.id, mode.key, v, res, rysBtny) : '';
    if (pasekProj) html += pasekProj;
    // kalkulator bez projektu (woda, gaz) — rysunek sam, na całą szerokość
    else if (rysBtny) html += '<div class="proj-btny">' + rysBtny + '</div>';
    const jumps = res.jump ? (Array.isArray(res.jump) ? res.jump : [res.jump]) : [];
    if (jumps.length) {
      state.pendingJumps = jumps;
      jumps.forEach((j, i) => {
        html += i === 0
          ? `<button class="jump" style="--c:${c}" data-jumpidx="${i}">${esc(j.label)}${svg('arrow')}</button>`
          : `<button class="btn2" style="width:100%" data-jumpidx="${i}">${esc(j.label)}${svg('arrow')}</button>`;
      });
    }
    /* Dobrany grzejnik idzie prosto na listę w kalkulatorze średnic —
       tam, gdzie i tak trzeba by go wpisać ręcznie. */
    if (res.doSrednic) {
      state.pendingSrednice = res.doSrednic;
      html += '<button class="btn2" style="width:100%" data-doSrednic>'
        + svg('pipe') + 'Dopisz do średnic c.o.</button>';
    }
    /* To samo dla podłogówki, tyle że celem jest rozdzielacz, a nie gałąź. */
    if (res.doRozdzielacza) {
      state.pendingRozdz = res.doRozdzielacza;
      html += '<button class="btn2" style="width:100%" data-doRozdz>'
        + svg('list') + 'Dopisz do rozdzielaczy</button>';
    }
    // Dobrana pozycja trafia prosto do oferty. Treść trzymamy w stanie,
    // a nie w atrybutach — nazwy zawierają cudzysłowy (½") i ucieczki.
    if (res.addTo) {
      state.pendingAdd = res.addTo;
      html += '<button class="jump" style="--c:var(--flame)" data-addoffer>' +
        svg('plus') + 'Dodaj do oferty</button>';
    }
  }
  if (mode.tip) html += '<div class="tip">' + svg('spark') + '<div>' + esc(mode.tip) + '</div></div>';
  return html + '</div>';
}

/* Przykładowe wiersze znikają przy pierwszym własnym ruchu — dopisaniu
   z kalkulatora, dodaniu własnego rozdzielacza albo poprawieniu wiersza.
   Trzymanie ich obok prawdziwych danych kończyło się tym, że sumy przestawały
   cokolwiek znaczyć. */
function usunPrzyklady(v, k) {
  if (!v || !Array.isArray(v[k])) return false;
  const przed = v[k].length;
  v[k] = v[k].filter(x => !x.przyklad);
  return v[k].length !== przed;
}

/* ---------- Wyczyszczenie wyników ----------
   Jedno dotknięcie kasuje pracę całego dnia, więc pytamy — ale pytamy
   konkretnie, wymieniając, co zniknie, a co zostaje. „Czy na pewno?" bez
   treści i tak odklikuje się bez czytania.

   Czyścimy wyłącznie to, co wpisane w kalkulatorach. Oferty, faktury, ceny
   w katalogu i dane firmy zostają: to nie są „wyniki doboru", tylko dorobek,
   a przycisk w nagłówku nie jest miejscem, w którym wolno go skasować. */
function resetHtml() {
  const ile = Object.keys(state.values || {}).length;
  return `<div class="sheet" data-closereset role="dialog" aria-label="Wyczyścić wyniki">
    <div class="sheet-in" data-stop>
      <div class="sheet-h">${svg('restore')}<strong>Wyczyścić wyniki?</strong>
        <button class="item-x" data-closereset aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        <p class="hint" style="margin:0 0 12px">Wszystkie kalkulatory wrócą do wartości domyślnych.
          Zniknie to, co policzyłeś: wymiary pomieszczeń i wybrane grzejniki. Listy, które
          aplikacja sama zapełnia — grzejniki w średnicach i rozdzielacze z pętlami —
          zostaną puste.</p>
        <div class="tip">${svg('spark')}<div>Zostają oferty, faktury, Twoje ceny w katalogu
          i dane firmy — tego ten przycisk nie rusza.</div></div>
        <button class="jump" style="--c:var(--cat-heat);margin-top:12px" data-resetok>
          ${svg('trash')}Wyczyść ${ile ? 'wszystkie ' + ile + ' ' + odmiana(ile, 'kalkulator', 'kalkulatory', 'kalkulatorów') : 'wyniki'}</button>
        <button class="btn2" style="width:100%;margin-top:8px" data-closereset>Zostaw jak jest</button>
      </div>
    </div></div>`;
}

/* Pola, które aplikacja sama zapełnia guzikiem „Dopisz" — lista grzejników
   w średnicach i lista rozdzielaczy. Po wyczyszczeniu mają zostać puste,
   a nie wrócić do przykładowych wartości fabrycznych: instalator widziałby
   wtedy trzy grzejniki, których nie wpisał, i słusznie uznał, że nic się
   nie skasowało. Reszta pól — wymiary, Δt, prędkości, materiały — wraca
   do domyślnych, bo to są nastawy, a nie zebrane dane. */
function polaZbierane() {
  const out = [];
  CALCS.forEach(c => {
    const tryby = c.modes || [{ key: null, cards: c.cards }];
    tryby.forEach(m => (m.cards || []).forEach(card => (card.fields || []).forEach(f => {
      (f.row || [f]).forEach(x => {
        if (x.zbierane) out.push({ klucz: vkey(c.id, m.key), k: x.k, nazwy: !!x.nazwy,
          galezie: !!x.galezie, grzejnik: !!x.grzejnik });
      });
    })));
  });
  return out;
}

function wyczyscWyniki() {
  state.values = {};
  state.mode = {};
  polaZbierane().forEach(p => {
    if (!state.values[p.klucz]) state.values[p.klucz] = {};
    state.values[p.klucz][p.k] = [];
    if (p.nazwy) state.values[p.klucz][p.k + 'Nazwy'] = [];
    if (p.galezie) state.values[p.klucz][p.k + 'Galaz'] = [];
    if (p.grzejnik) { state.values[p.klucz][p.k + 'Grz'] = []; state.values[p.klucz][p.k + 'Grz2'] = []; state.values[p.klucz][p.k + 'Dziel'] = []; }
  });
  state.pendingSrednice = null;
  state.pendingRozdz = null;
  state.pytamPokoj = null;
  state.pytamRozdz = null;
  state.schemat = null;
  saveCalcValues();
  state.resetSheet = false;
  state.query = '';
  state.tab = 'calc';
  state.screen = 'home';
  state.calc = null;
  renderOverlay();
  render(true);
  toast('Wyczyszczono. Kalkulatory mają znowu wartości domyślne.');
}

/* ---------- Ekrany zapowiedzi ---------- */
function renderSoon(kind) {
  const cfg = kind === 'offers'
    ? { icon: 'doc', title: 'Oferty', sub: 'Twórz profesjonalne oferty w kilka minut', head: 'Moduł ofert — etap 3',
        text: 'Dodawanie pozycji, baza cenowa i generowanie PDF prosto z telefonu.',
        items: ['Pozycje oferty: materiały, robocizna, marża', 'Własna baza cenowa produktów', 'Generowanie i wysyłka PDF do klienta', 'Szablony powtarzalnych ofert'] }
    : { icon: 'spark', title: 'Asystent AI', sub: 'Pytania techniczne, dobór urządzeń, kontrola ofert', head: 'Asystent AI — etap 5',
        text: 'Asystent zna kontekst Twojej oferty i kalkulacji, więc podpowiada konkretnie.',
        items: ['Odpowiedzi na pytania techniczne z placu budowy', 'Doradztwo przy doborze urządzeń', 'Kontrola kompletności oferty: „dodałeś rury — a izolacja?”', 'Podpowiedzi wprost przy kalkulatorach'] };

  return '<header class="hdr"><span class="blob a"></span><span class="blob b"></span>' +
    '<div class="hdr-row"><div class="hdr-ico">' + svg(cfg.icon) + '</div>' +
    '<div><h1>' + cfg.title + '</h1><p>' + cfg.sub + '</p></div></div></header>' +
    '<div class="soon"><div class="soon-ico">' + svg('wrench') + '</div>' +
    '<h3>' + cfg.head + '</h3><p>' + cfg.text + '</p><ul>' +
    cfg.items.map(i => '<li>' + svg('check') + '<span>' + esc(i) + '</span></li>').join('') + '</ul></div>';
}

/* ---------- Nawigacja ---------- */
const NAV = [
  { k: 'calc', label: 'Kalkulatory', icon: 'calc' },
  { k: 'offers', label: 'Biuro', icon: 'doc' },
  { k: 'ai', label: 'Asystent', icon: 'spark' },
  { k: 'settings', label: 'Ustawienia', icon: 'gear' },
];
function renderNav() {
  document.getElementById('nav').innerHTML = NAV.map(n =>
    '<button data-tab="' + n.k + '"' + (state.tab === n.k ? ' aria-current="page"' : '') + '>' +
    '<span class="pill">' + svg(n.icon) + '</span><span>' + n.label + '</span></button>').join('');
}

function render(animate) {
  const vp = document.getElementById('viewport');
  let html;
  if (state.tab === 'offers') html = renderOffersTab();
  else if (state.tab === 'settings') html = renderSettingsTab();
  else if (state.tab === 'ai') html = renderAssistTab();
  else html = state.screen === 'calc' ? renderCalc() : renderHome();

  vp.innerHTML = '<div class="' + (animate ? 'view-enter' : '') + '">' + html + '</div>';
  vp.scrollTop = 0;
  if (state.tab === 'calc' && state.screen === 'calc') document.getElementById('out').innerHTML = renderOutput();
  renderNav();
  renderOverlay();
  if (typeof autosizeAll === 'function') autosizeAll();
}
function update() {
  const out = document.getElementById('out');
  if (out) out.innerHTML = renderOutput();
  if (typeof grzOdswiez === 'function') grzOdswiez();
}
function curr() {
  const calc = CALCS.find(c => c.id === state.calc);
  const m = activeMode(calc);
  return { calc, m, v: getValues(calc, m) };
}

/* ---------- Zdarzenia ---------- */
document.addEventListener('change', e => {
  const t = e.target;
  if (state.calc !== 'pump' || !t.dataset || t.dataset.k !== 'cel') return;
  const { v } = curr(); const C = POMPA_CEL[t.value]; if (!C) return;
  v.cel = t.value;
  ['sup', 'ret', 'len', 'rb', 'rv', 'rr'].forEach(x => { v[x] = C[x]; });
  saveCalcValues(); render(false);
});
document.addEventListener('click', e => {
  const tab = e.target.closest('[data-tab]');
  if (tab) {
    state.tab = tab.dataset.tab; state.gasWarn = false;
    if (state.tab === 'calc') state.screen = 'home';
    /* Zakładka zawsze otwiera się od swojego ekranu głównego — inaczej
       powrót do Ustawień lądował w karcie informacyjnej sprzed godziny,
       a powrót do Ofert na fakturze zamiast na liście. */
    if (state.tab === 'settings') state.setScreen = 'main';
    if (state.tab === 'offers') state.offerScreen = 'list';
    if (state.tab === 'ai') state.kody = null;
    render(true); return;
  }

  const tile = e.target.closest('[data-calc]');
  if (tile) {
    state.calc = tile.dataset.calc; state.screen = 'calc';
    const otw = CALCS.find(c => c.id === state.calc);
    /* Dobór grzejnika otwarty z ekranu głównego nie wie, jakie to
       pomieszczenie — przełącznik płytowe/drabinkowe ma być widoczny. */
    if (otw && otw.id === 'radiator') {
      const vr = getValues(otw, activeMode(otw));
      if (vr.zrodlo) { vr.zrodlo = ''; saveCalcValues(); }
    }
    state.gasWarn = !!(otw && otw.law);
    render(true); return;
  }

  if (e.target.closest('[data-schpdf]')) { zapiszSchematPdf(); return; }
  const schy = e.target.closest('[data-schematy]');
  if (schy) {
    state.schemat = (state.pendingSchematy || [])[+schy.dataset.schematy] || null;
    renderOverlay(); return;
  }
  if (e.target.closest('[data-schemat]')) {
    state.schemat = state.pendingSchemat || null;
    renderOverlay(); return;
  }
  if (e.target.closest('[data-closeschemat]')
      && (!e.target.closest('.sheet-in') || e.target.closest('.sheet-h [data-closeschemat]'))) {
    state.schemat = null; renderOverlay(); return;
  }

  if (e.target.closest('[data-gasok]') && !e.target.closest('[data-stop]')) {
    state.gasWarn = false; renderOverlay(); return;
  }
  if (state.gasWarn && e.target.closest('[data-stop] [data-gasok]')) {
    state.gasWarn = false; renderOverlay(); return;
  }

  if (e.target.closest('#back')) { state.screen = 'home'; state.gasWarn = false; render(true); return; }

  const jump = e.target.closest('[data-jumpidx]');
  if (jump) {
    const j = (state.pendingJumps || [])[+jump.dataset.jumpidx];
    const target = j && CALCS.find(c => c.id === j.calc);
    if (!target) return;
    state.tab = 'calc'; state.calc = target.id; state.screen = 'calc';
    /* Skok z wyniku innego kalkulatora też jest wejściem do kalkulatora,
       więc ostrzeżenie musi się pokazać tak samo jak z ekranu głównego. */
    state.gasWarn = !!target.law;
    const v = getValues(target, activeMode(target));
    Object.keys(j.fields || {}).forEach(k => { v[k] = j.fields[k]; });
    saveCalcValues(); render(true); return;
  }

  const mode = e.target.closest('[data-mode]');
  if (mode) {
    const byl = state.mode[state.calc] || null;
    state.mode[state.calc] = mode.dataset.mode;
    /* Grzejniki są te same w obu systemach — przenosimy je za instalatorem,
       żeby nie wpisywał listy drugi raz. */
    let ile = 0;
    if (state.calc === 'co_dia') {
      ile = przeniesGrzejniki(byl || 'troj', mode.dataset.mode);
    }
    render(false);
    if (ile) toast(`Przeniesiono ${ile} ${odmiana(ile, 'grzejnik', 'grzejniki', 'grzejników')} `
      + 'z poprzedniego systemu — moce te same, zmienia się rozprowadzenie.');
    return;
  }

  if (e.target.closest('[data-reset]')) { state.resetSheet = true; renderOverlay(); return; }
  if (e.target.closest('[data-resetok]')) { wyczyscWyniki(); return; }
  if (e.target.closest('[data-closereset]')
      && (!e.target.closest('[data-stop]')
          || e.target.closest('.sheet-h [data-closereset]')
          || e.target.closest('.sheet-body [data-closereset]'))) {
    state.resetSheet = false; renderOverlay(); return;
  }

  const cnt = e.target.closest('[data-cnt]');
  if (cnt) {
    const { v } = curr();
    const k = cnt.dataset.cnt, i = cnt.dataset.i, d = +cnt.dataset.d;
    v[k][i] = Math.max(0, (v[k][i] || 0) + d);
    saveCalcValues(); render(false); return;
  }

  const add = e.target.closest('[data-add]');
  if (add) { const { v } = curr(); v[add.dataset.add].push(1000); saveCalcValues(); render(false); return; }

  const addfx = e.target.closest('[data-addfx]');
  if (addfx) { const { v } = curr(); v[addfx.dataset.addfx].push(0); saveCalcValues(); render(false); return; }

  const delfx = e.target.closest('[data-delfx]');
  if (delfx) { const { v } = curr(); v[delfx.dataset.delfx].splice(+delfx.dataset.i, 1); saveCalcValues(); render(false); return; }

  const addgz = e.target.closest('[data-addgz]');
  if (addgz) {
    const { v } = curr();
    /* Nowy punkt dziedziczy odległość po poprzednim, a nie zaczyna od zera —
       w domu kolejne urządzenia leżą zwykle w podobnych odstępach, więc
       mniej poprawiania. Moc bierzemy z domyślnego urządzenia. */
    const lista = v[addgz.dataset.addgz];
    const ost = lista[lista.length - 1];
    lista.push({ u: 0, kw: GAS_APPLIANCES[0][1], len: ost ? ost.len : 5, wys: 0, kol: 2 });
    saveCalcValues(); render(false); return;
  }

  const addrz = e.target.closest('[data-addrz]');
  if (addrz) {
    const { v } = curr();
    usunPrzyklady(v, addrz.dataset.addrz);
    const lista = v[addrz.dataset.addrz];
    /* Nowy rozdzielacz dostaje pierwszą wolną nazwę z listy, a nie „Parter"
       po raz trzeci — inaczej dwa wiersze nazywają się tak samo i wynik
       przestaje cokolwiek znaczyć. */
    const zajete = lista.map(x => x.nazwa);
    const nazwa = ROZDZIELACZE.find(x => zajete.indexOf(x) < 0) || ('Rozdzielacz ' + (lista.length + 1));
    lista.push({ nazwa, w: 0, wyj: 0, dl: 0, dp: 0, wklady: {} });
    saveCalcValues(); render(false); return;
  }

  const delrz = e.target.closest('[data-delrz]');
  if (delrz) { const { v } = curr(); v[delrz.dataset.delrz].splice(+delrz.dataset.i, 1); saveCalcValues(); render(false); return; }

  const delgz = e.target.closest('[data-delgz]');
  if (delgz) { const { v } = curr(); v[delgz.dataset.delgz].splice(+delgz.dataset.i, 1); saveCalcValues(); render(false); return; }

  const del = e.target.closest('[data-del]');
  if (del) {
    const { v } = curr();
    const k = del.dataset.del, i = +del.dataset.i;
    v[k].splice(i, 1);
    /* Nazwy pomieszczeń leżą w osobnej tablicy i muszą wypaść razem z mocą —
       inaczej po skasowaniu pierwszego grzejnika „Kuchnia" zostaje przy
       drugim i rysunek kłamie. */
    if (Array.isArray(v[k + 'Nazwy'])) v[k + 'Nazwy'].splice(i, 1);
    if (Array.isArray(v[k + 'Galaz'])) v[k + 'Galaz'].splice(i, 1);
    if (Array.isArray(v[k + 'Grz'])) v[k + 'Grz'].splice(i, 1);
    if (Array.isArray(v[k + 'Grz2'])) v[k + 'Grz2'].splice(i, 1);
    if (Array.isArray(v[k + 'Dziel'])) v[k + 'Dziel'].splice(i, 1);
    saveCalcValues(); render(false); return;
  }

  /* Wybór grzejnika z listy dopasowań. Zapisujemy wymiary, nie numer pozycji,
     i odświeżamy tylko blok wyniku — reszta ekranu zostaje na miejscu. */
  const rad = e.target.closest('[data-pickrad]');
  if (rad) {
    const { v, calc, m } = curr();
    const res = m.compute(getValues(calc, m));
    const lista = res && res._matches;
    /* Lista widoczna jest zawsze początkiem pełnej listy, więc numer pozycji
       na ekranie odpowiada numerowi w wynikach doboru. */
    const x = lista && lista[+rad.dataset.pickrad];
    if (x && x.drab) { v.pickD = { k: x.ksztalt, h: x.height, w: x.width }; saveCalcValues(); update(); }
    else if (x) { v.pick = { length: x.length, height: x.height, type: x.type }; saveCalcValues(); update(); }
    return;
  }
  if (e.target.closest('[data-radall]')) { const { v } = curr(); v.all = true; saveCalcValues(); update(); return; }
  if (e.target.closest('[data-radless]')) { const { v } = curr(); v.all = false; saveCalcValues(); update(); return; }

  /* Przywrócenie wartości domyślnej jednego suwaka. Przerysowujemy sam
     formularz, bo trzeba ruszyć i pozycję suwaka, i liczbę obok niego. */
  /* Przywrócenie wszystkich suwaków tego wariantu — przycisk z paska
     nad wynikiem. */
  if (e.target.closest('[data-suwakireset]')) {
    const { m, v } = curr();
    suwakiZmienione(null, m, v).forEach(f => { v[f.k] = f.def; });
    saveCalcValues(); render(false);
    toast('Przywrócono wartości domyślne.');
    return;
  }

  const sres = e.target.closest('[data-sreset]');
  if (sres) {
    const { calc, m, v } = curr();
    const f = fieldList(m).find(x => x.k === sres.dataset.sreset);
    if (f) { v[f.k] = f.def; saveCalcValues(); render(false); }
    return;
  }

  const seg = e.target.closest('.seg button[data-k]');
  if (seg) { const { v } = curr(); v[seg.dataset.k] = seg.dataset.v; saveCalcValues(); render(false); return; }
});

document.addEventListener('input', e => {
  const t = e.target;
  if (t.id === 'q') {
    state.query = t.value; const p = t.selectionStart; render(false);
    const nq = document.getElementById('q');
    if (nq) { nq.focus(); try { nq.setSelectionRange(p, p); } catch (_) {} }
    return;
  }
  if (t.dataset.fx !== undefined && t.dataset.i !== undefined && t.tagName === 'SELECT') {
    const { v } = curr();
    v[t.dataset.fx][+t.dataset.i] = parseInt(t.value, 10);
    saveCalcValues(); update(); return;
  }
  /* Wybór urządzenia podstawia jego typową moc. Przerysowujemy cały formularz,
     bo pole „Moc" musi pokazać nową wartość — sam przeliczony wynik by nie
     wystarczył i instalator widziałby starą liczbę przy nowym urządzeniu. */
  if (t.dataset.gzu !== undefined && t.tagName === 'SELECT') {
    const { v } = curr();
    const j = parseInt(t.value, 10);
    const p = v[t.dataset.gzu][+t.dataset.i];
    p.u = j;
    p.kw = (GAS_APPLIANCES[j] || [null, 0])[1];
    saveCalcValues(); render(false); return;
  }
  if (t.dataset.rznm !== undefined && t.tagName === 'SELECT') {
    const { v } = curr();
    const r = v[t.dataset.rznm][+t.dataset.i];
    r.nazwa = t.value;
    if (r.przyklad) { delete r.przyklad; saveCalcValues(); render(false); return; }
    saveCalcValues(); update(); return;
  }
  if (t.dataset.rz) {
    const { v } = curr();
    const r = v[t.dataset.rz][+t.dataset.i];
    r[t.dataset.p] = t.value === '' ? 0 : parseFloat(t.value);
    /* Poprawiony wiersz przestaje być przykładem — od tej chwili to dane. */
    if (r.przyklad) delete r.przyklad;
    saveCalcValues(); update(); return;
  }
  if (t.dataset.gz) {
    const { v } = curr();
    const p = v[t.dataset.gz][+t.dataset.i];
    /* Pusty znak zapisujemy jako zero, a nie jako pusty tekst — inaczej
       pierwszy backspace w polu długości robi z obliczenia NaN. */
    if (p) p[t.dataset.p] = t.value === '' || t.value === '-' ? 0 : parseFloat(t.value);
    saveCalcValues(); update(); return;
  }
  if (t.dataset.nl) {
    const { v } = curr();
    v[t.dataset.nl][+t.dataset.i] = t.value === '' ? 0 : parseFloat(t.value);
    saveCalcValues(); update(); return;
  }
  /* Nazwa pomieszczenia. Przerysowujemy tylko wynik, nie cały formularz —
     inaczej pole traciłoby ognisko po każdej literze. Etykietę nad mocą
     podmieniamy więc ręcznie, w miejscu. */
  if (t.dataset.nlnm) {
    const { v } = curr();
    const klucz = t.dataset.nlnm + 'Nazwy';
    if (!Array.isArray(v[klucz])) v[klucz] = [];
    v[klucz][+t.dataset.i] = t.value;
    /* Wybór z listy przerysowuje cały formularz: druga „Kuchnia" zmienia
       też napis przy pierwszej na „Kuchnia 1". Lista nie ma kursora,
       więc ognisko niczego tu nie traci. */
    saveCalcValues(); if (t.tagName === 'SELECT') render(false); else update(); return;
  }
  /* Numer gałęzi. Przerysowujemy sam wynik — formularz zostaje na miejscu,
     żeby lista nie skakała pod palcem przy przepinaniu grzejników. */
  if (t.dataset.nlgz) {
    const { v } = curr();
    const klucz = t.dataset.nlgz + 'Galaz';
    if (!Array.isArray(v[klucz])) v[klucz] = [];
    v[klucz][+t.dataset.i] = parseInt(t.value, 10) || 1;
    saveCalcValues(); update(); return;
  }
  if (!t.dataset.k) return;
  const { calc, m, v } = curr();
  if (!calc) return;
  const raw = t.value;
  v[t.dataset.k] = (t.type === 'number' || t.type === 'range')
    ? (raw === '' ? 0 : parseFloat(raw))
    : (/^-?\d+$/.test(raw) ? parseInt(raw, 10) : raw);

  const sv = document.getElementById('sv-' + t.dataset.k);
  if (sv) {
    const f = fieldList(m).find(x => x.k === t.dataset.k);
    sv.textContent = fmt(v[t.dataset.k], 2) + (f && f.suffix ? f.suffix : '');
    /* Przycisk powrotu do domyślnej pojawia się i znika w trakcie
       przeciągania. Przełączamy sam atrybut zamiast przerysowywać pole —
       przebudowa formularza zerwałaby gest w połowie ruchu. */
    const sr = document.getElementById('sr-' + t.dataset.k);
    if (sr && f) sr.hidden = Number(v[t.dataset.k]) === Number(f.def);
  }
  saveCalcValues();
  if (t.dataset.k === 'mat') { render(false); return; }   // zmiana materiału przebudowuje listę średnic
  update();
});

document.addEventListener('change', e => {
  if (e.target.tagName !== 'SELECT') return;
  /* Listy wyboru są też w ofertach i ustawieniach — tam nie ma żadnego
     kalkulatora i sięganie po jego tryb wywracało aplikację. */
  if (state.tab !== 'calc' || state.screen !== 'calc' || !state.calc) return;
  /* Jeśli w tym trybie któreś pole pojawia się zależnie od innego, sam
     przeliczony wynik nie wystarczy — trzeba przerysować także formularz,
     bo inaczej pole „Własne Δt" nigdy by się nie pokazało. */
  const { m } = curr();
  if (m && fieldList(m).some(f => f.when)) { render(false); return; }
  update();
});

/* ---------- Motyw ---------- */
const themeBtn = document.getElementById('themeBtn'), themeLabel = document.getElementById('themeLabel');
const systemDark = () => window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
function currentDark() {
  const set = document.documentElement.getAttribute('data-theme');
  return set ? set === 'dark' : systemDark();
}
const syncThemeLabel = () => themeLabel.textContent = currentDark() ? 'Jasny motyw' : 'Ciemny motyw';
themeBtn.addEventListener('click', () => {
  document.documentElement.setAttribute('data-theme', currentDark() ? 'light' : 'dark');
  syncThemeLabel();
});
syncThemeLabel();

