/* ===== ui_assist.js ===== */
/* ============================================================
   ASYSTENT OFFLINE
   Baza wiedzy + skrót do kontroli oferty. Nic nie wychodzi z telefonu.
   ============================================================ */
Object.assign(ICO, {
  book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M4 20.5A2.5 2.5 0 0 1 6.5 18H20v3H6.5A2.5 2.5 0 0 1 4 20.5z"/>',
  bug: '<path d="M8 6.5a4 4 0 0 1 8 0"/><rect x="7" y="6.5" width="10" height="13" rx="5"/><path d="M3.5 11h3.5M17 11h3.5M3.5 17h3.5M17 17h3.5M12 6.5v13"/>',
  table: '<rect x="3" y="4.5" width="18" height="15" rx="2"/><path d="M3 9.5h18M3 14.5h18M9 9.5V19.5"/>',
  cash: '<path d="M3 7.5h18v9H3z"/><circle cx="12" cy="12" r="2.4"/><path d="M6.5 5.5h11"/>',
});

const KB_CATS = [
  { k: 'dobor', label: 'Dobór i obliczenia', icon: 'calc' },
  { k: 'bledy', label: 'Częste błędy', icon: 'bug' },
  { k: 'dane', label: 'Parametry i tabele', icon: 'table' },
  { k: 'oferty', label: 'Oferty i wycena', icon: 'cash' },
];

/* Wpisy oparte na materiałach użytkownika (poradnik instalatora),
   na wzorach zweryfikowanych testami i na powszechnej praktyce.
   Tam, gdzie coś jest reguła kciuka albo zależy od przepisów,
   jest to powiedziane wprost. */
const KB = [
/* ---------- DOBÓR I OBLICZENIA ---------- */
{ c: 'dobor', calc: 'heat_loss', q: 'Jak dobrać moc kotła?',
  a: 'Zsumuj straty ciepła wszystkich ogrzewanych pomieszczeń — to jest moc potrzebna na ogrzewanie. '
   + 'Nie sumuj mocy grzejników: grzejniki dobiera się z zapasem, więc ich suma zawsze wyjdzie większa od realnej potrzeby i skończy się przewymiarowanym kotłem.\n\n'
   + 'Kocioł przewymiarowany taktuje, czyli włącza się i wyłącza co chwilę. Zużywa wtedy więcej gazu i szybciej się zużywa, więc „z zapasem" działa tu na Twoją niekorzyść.\n\n'
   + 'Przy zasobniku c.w.u. zwykle nie dodaje się pełnej mocy na podgrzew, bo pracuje on w trybie priorytetu — krótko i nie równocześnie z ogrzewaniem.' },

{ c: 'dobor', calc: 'radiator', q: 'Dlaczego przy 55/45 °C grzejnik musi być większy?',
  a: 'Bo moc grzejnika zależy od różnicy między temperaturą wody a temperaturą pomieszczenia. Im niższe parametry, tym mniejsza ta różnica i tym mniej ciepła grzejnik odda.\n\n'
   + 'Konkret z tabeli, którą masz w aplikacji — grzejnik typ 22 o wymiarach 600 × 1000 mm:\n'
   + '• przy 75/65/20 °C daje 1713 W\n'
   + '• przy 70/55/20 °C daje 1377 W\n'
   + '• przy 55/45/20 °C daje 863 W\n\n'
   + 'Czyli przy niskich parametrach ten sam grzejnik oddaje dokładnie połowę tego, co przy wysokich. Dlatego przy pompie ciepła grzejniki muszą być wyraźnie większe albo trzeba iść w ogrzewanie podłogowe.' },

{ c: 'dobor', calc: 'pump', q: 'Jak dobrać pompę obiegową?',
  a: 'Potrzebujesz dwóch liczb. Wydajność q liczysz ze wzoru q = Q / (1,163 × Δt), gdzie Q to moc obiegu w kW, a Δt to różnica między zasilaniem a powrotem.\n\n'
   + 'Wysokość podnoszenia H wynika z oporów przepływu najbardziej niekorzystnego obiegu — czyli najdłuższej pętli, zwykle do najdalszego grzejnika. Sumujesz opory rur, kotła, zaworów, filtra i grzejnika.\n\n'
   + 'Mając q i H, porównujesz je z charakterystyką konkretnej pompy z katalogu producenta. Punkt pracy to miejsce, gdzie te dwie wartości spotykają się na jej wykresie.' },

{ c: 'dobor', calc: 'pump', q: 'Czy wysokość budynku dolicza się do pompy?',
  a: 'Nie, w instalacji zamkniętej nie. To jeden z najczęstszych błędów.\n\n'
   + 'Obieg zamknięty jest zrównoważony: woda, która idzie w górę pionem, wraca w dół drugim. Te słupy się znoszą i pompa nie musi nic „podnosić" — pokonuje wyłącznie opory przepływu.\n\n'
   + 'Wysokość instalacji liczy się gdzie indziej: przy ciśnieniu statycznym, ciśnieniu napełnienia i nastawie wstępnej naczynia wzbiorczego.' },

{ c: 'dobor', calc: 'vessel', q: 'Jakie ciśnienie napełnienia instalacji?',
  a: 'Zacznij od ciśnienia statycznego: wysokość od kotła do najwyższego punktu instalacji podzielona przez 10 daje wynik w barach. Osiem metrów to 0,8 bara.\n\n'
   + 'Ciśnienie napełnienia ustawia się zwykle o 0,2–0,3 bara wyżej niż statyczne, żeby w najwyższym punkcie nie zrobiło się podciśnienie i żeby instalacja nie zasysała powietrza.\n\n'
   + 'Ciśnienie wstępne naczynia wzbiorczego ustaw co najmniej równe statycznemu — sprawdź je przed montażem, bo fabryczna nastawa rzadko pasuje do konkretnej instalacji.' },

{ c: 'dobor', calc: 'vessel', q: 'Czy do c.w.u. może być to samo naczynie co do c.o.?',
  a: 'Nie. To muszą być dwa osobne naczynia i nie jest to kwestia wygody, tylko dopuszczenia.\n\n'
   + 'Naczynie do ciepłej wody użytkowej musi mieć przeponę przeznaczoną do kontaktu z wodą pitną i atest higieniczny. Naczynie od c.o. takiego dopuszczenia nie ma — woda z instalacji grzewczej nie jest przeznaczona do spożycia.\n\n'
   + 'Różnią się też parametrami: c.w.u. pracuje przy wyższym ciśnieniu wodociągowym, z zaworem bezpieczeństwa zwykle 6 bar, podczas gdy c.o. ma najczęściej 2,5 lub 3 bary.' },

{ c: 'dobor', calc: 'pipe', q: 'Jaka prędkość wody w rurach jest właściwa?',
  a: 'Zależy od miejsca w instalacji:\n'
   + '• 0,3–0,6 m/s — instalacje grawitacyjne i odcinki w sypialniach czy salonach, gdzie szum przeszkadza\n'
   + '• 0,6–1,0 m/s — typowe instalacje pompowe, najczęstszy zakres\n'
   + '• do 1,5 m/s — piony i odcinki przy rozdzielaczu\n\n'
   + 'W instalacji wodociągowej dopuszcza się więcej, ale powyżej 2 m/s instalacja zaczyna szumieć i szybciej się zużywa.\n\n'
   + 'Wyższa prędkość pozwala dać cieńszą rurę, ale płacisz za to hałasem i większymi oporami, czyli mocniejszą pompą.' },

{ c: 'dobor', calc: 'valve', q: 'Jak dobrać zawór bezpieczeństwa?',
  a: 'Dla c.o. dobiera się go według mocy źródła ciepła i ciśnienia otwarcia — im wyższa nastawa, tym większą moc obsłuży ten sam zawór.\n\n'
   + 'Dla c.w.u. kryterium jest pojemność zasobnika, nie moc.\n\n'
   + 'Zanim zamówisz: sprawdź dokumentację kotła. Wiele kotłów ma zawór bezpieczeństwa wbudowany fabrycznie i wtedy osobny jest zbędny.' },

/* ---------- CZĘSTE BŁĘDY ---------- */
{ c: 'bledy', q: 'Pominięta izolacja przewodów',
  a: 'Najczęściej zapominana pozycja w wycenie i jednocześnie taka, której brak widać dopiero po sezonie — w rachunkach.\n\n'
   + 'Izolacji wymagają przewody prowadzone w bruzdach, w posadzce, przez pomieszczenia nieogrzewane, przez garaże i piwnice. W c.w.u. izolacja ogranicza straty na cyrkulacji, która potrafi pracować całą dobę.\n\n'
   + 'Grubość otuliny dobiera się do średnicy przewodu i miejsca prowadzenia — sprawdź aktualne Warunki Techniczne, bo wymagania bywały zmieniane.' },

{ c: 'bledy', q: 'Brak zaworów odcinających przy grzejnikach',
  a: 'Bez zaworu odcinającego na powrocie każdy demontaż grzejnika — przy malowaniu, wymianie, awarii — oznacza spuszczenie wody z całej instalacji, a potem napełnianie i odpowietrzanie.\n\n'
   + 'To pozycja za kilkadziesiąt złotych, która przy pierwszej wizycie serwisowej zwraca się wielokrotnie. Klient tego nie wie, więc sam o to nie poprosi.' },

{ c: 'bledy', q: 'Naczynie wzbiorcze dobrane na oko',
  a: 'Za małe naczynie objawia się tak: przy każdym mocniejszym nagrzaniu zawór bezpieczeństwa upuszcza wodę, po ostygnięciu ciśnienie spada i trzeba dolewać. Po kilku cyklach instalacja jest napowietrzona, a klient dzwoni.\n\n'
   + 'Naczynie liczy się z pojemności wodnej instalacji, maksymalnej temperatury zasilania oraz ciśnień: wstępnego i otwarcia zaworu bezpieczeństwa. Ogrzewanie podłogowe ma dużo większą pojemność wodną niż grzejnikowe, więc tam naczynie wychodzi wyraźnie większe.' },

{ c: 'bledy', q: 'Mylenie ciśnienia statycznego z wysokością podnoszenia',
  a: 'To dwie różne wielkości wyrażane w podobnych jednostkach i stąd pomyłka.\n\n'
   + 'Ciśnienie statyczne to ciężar słupa wody w instalacji — zależy od wysokości budynku i decyduje o ciśnieniu napełnienia oraz nastawie naczynia.\n\n'
   + 'Wysokość podnoszenia pompy to opór, jaki pompa musi pokonać, żeby przepchnąć wodę przez obieg. Z wysokością budynku nie ma nic wspólnego w instalacji zamkniętej.' },

{ c: 'bledy', q: 'Za małe średnice przy ogrzewaniu podłogowym',
  a: 'Podłogówka pracuje na niskich parametrach, czyli na małym Δt, a to oznacza duży przepływ przy tej samej mocy. Ten sam błąd co przy pompie ciepła.\n\n'
   + 'Drugi element to pętle: zbyt długie dają duże opory i nierównomierne grzanie. Dłuższe pętle wymagają większej średnicy albo podziału na dwie.\n\n'
   + 'Zawsze z rozdzielaczem z możliwością regulacji przepływu na każdej pętli — bez tego nie da się tego wyrównać po uruchomieniu.' },

{ c: 'bledy', q: 'Próba szczelności pominięta w wycenie',
  a: 'Wykonasz ją i tak, bo bez niej nie zamkniesz instalacji pod tynk. Jeśli nie ma jej w ofercie, robisz ją za darmo.\n\n'
   + 'To jedna z pozycji, których klienci praktycznie nigdy nie kwestionują, bo brzmi jak oczywisty element fachowej roboty. Warto ją wpisywać zawsze.' },

/* ---------- PARAMETRY I TABELE ---------- */
{ c: 'dane', calc: 'heat_loss', q: 'Strefy klimatyczne Polski',
  a: 'Temperatury obliczeniowe powietrza zewnętrznego wg PN-EN 12831:\n'
   + '• Strefa I — −16 °C — zachodnia i centralna Polska, m.in. Poznań, Wrocław, Szczecin\n'
   + '• Strefa II — −18 °C — m.in. Warszawa, Łódź, Kraków, Gdańsk\n'
   + '• Strefa III — −20 °C — m.in. Lublin, Rzeszów, Katowice\n'
   + '• Strefa IV — −22 °C — m.in. Białystok, Suwałki\n'
   + '• Strefa V — −24 °C — rejon Suwałk i tereny górskie\n\n'
   + 'Różnica między strefą I a V to 8 stopni, co przy typowym domu przekłada się na kilkanaście procent mocy grzewczej.' },

{ c: 'dane', q: 'Reżimy temperaturowe — który kiedy',
  a: '• 75/65/20 °C — stare instalacje grzejnikowe, kotły stałopalne\n'
   + '• 70/55/20 °C — typowy reżim dla kotłów gazowych\n'
   + '• 55/45/20 °C — instalacje niskotemperaturowe, kotły kondensacyjne, pompy ciepła\n\n'
   + 'Im niższe parametry, tym sprawniej pracuje kocioł kondensacyjny, bo dopiero przy niskim powrocie faktycznie kondensuje. Ceną są większe grzejniki.\n\n'
   + 'Pierwsza liczba to zasilanie, druga powrót, trzecia temperatura pomieszczenia.' },

{ c: 'dane', calc: 'heat_loss', q: 'Typowe współczynniki U ścian',
  a: 'Przykłady policzone metodą warstwową, którą stosuje kalkulator strat ciepła:\n'
   + '• cegła pełna 38 cm bez ocieplenia — ok. 1,51 W/(m²·K)\n'
   + '• ta sama ściana z 10 cm styropianu — ok. 0,32 W/(m²·K)\n'
   + '• beton komórkowy 400, 24 cm bez ocieplenia — ok. 0,50 W/(m²·K)\n\n'
   + 'Czyli 10 cm styropianu na starej ścianie zmniejsza straty przez nią blisko pięciokrotnie. To zwykle najtańszy sposób na zmniejszenie zapotrzebowania przed wymianą źródła ciepła.' },

{ c: 'dane', calc: 'capacity', q: 'Ile wody mieści instalacja?',
  a: 'Szacunkowo, na każdy kilowat mocy, w zależności od odbiornika:\n'
   + '• grzejniki konwektorowe — 6 l/kW\n'
   + '• wentylacja, nagrzewnice — 8 l/kW\n'
   + '• grzejniki płytowe — 11 l/kW\n'
   + '• grzejniki radiatorowe — 14 l/kW\n'
   + '• rozbudowany system rur — 20 l/kW\n'
   + '• ogrzewanie podłogowe — 23 l/kW\n\n'
   + 'Wartości odnoszą się do maksymalnej temperatury 90 °C; przy niższych trzeba je przemnożyć przez współczynnik, który kalkulator stosuje automatycznie.\n\n'
   + 'Widać tu od razu, dlaczego podłogówka potrzebuje znacznie większego naczynia wzbiorczego niż ta sama moc na grzejnikach.' },

/* ---------- OFERTY I WYCENA ---------- */
{ c: 'oferty', q: 'Co powinno znaleźć się w ofercie instalacyjnej?',
  a: 'Materiały: rury, kształtki, izolacja, grzejniki z zaworami i zestawami przyłączeniowymi, źródło ciepła, naczynia wzbiorcze osobno dla c.o. i c.w.u., zawory bezpieczeństwa, pompa, filtr lub odmulacz, rozdzielacze.\n\n'
   + 'Robocizna: montaż rurociągów, montaż grzejników, montaż i podłączenie źródła ciepła, bruzdowanie, próba szczelności, uruchomienie i regulacja, dojazd.\n\n'
   + 'Formalnie: termin ważności oferty, termin realizacji, warunki płatności, zakres gwarancji oraz wyraźne wskazanie, czego oferta NIE obejmuje — to ostatnie oszczędza najwięcej nieporozumień.' },

{ c: 'oferty', q: '8% czy 23% VAT?',
  a: 'Stawka 8% dotyczy robót budowlano-montażowych w obiektach objętych społecznym programem mieszkaniowym, przy czym są limity powierzchni: mieszkania do 150 m² i domy do 300 m². Powyżej tych progów stawka 8% obejmuje tylko część wartości.\n\n'
   + 'Stawka 23% dotyczy pozostałych przypadków, w tym obiektów użytkowych.\n\n'
   + 'Znaczenie ma też, czy sprzedajesz usługę z materiałem jako całość, czy osobno sam materiał. To rozróżnienie potrafi zdecydować o stawce.\n\n'
   + 'Aplikacja podaje mechanizm, nie poradę podatkową — konkretną stawkę potwierdź ze swoją księgowością.' },

{ c: 'oferty', q: 'Jak liczyć marżę?',
  a: 'W tej aplikacji marża naliczana jest wyłącznie na materiałach, bo robocizna jest już wyceniona Twoją stawką godzinową lub ryczałtem. Podwójne narzucanie oznaczałoby liczenie zysku dwa razy od tej samej pracy.\n\n'
   + 'W dokumencie dla klienta marża jest wtopiona w ceny jednostkowe materiałów, więc nie widzi jej jako osobnej pozycji.\n\n'
   + 'Przy wycenie pamiętaj o kosztach, które łatwo przeoczyć: dojazdy na pomiary i odbiór, gwarancja i ewentualne poprawki, czas na uzgodnienia z klientem, zamrożone pieniądze w materiale kupionym przed zapłatą.' },
];

/* ---------- Wyszukiwanie ---------- */
function kbSearch(q) {
  const s = q.trim().toLowerCase();
  if (!s) return KB;
  const words = s.split(/\s+/).filter(Boolean);
  return KB.filter(e => {
    const hay = (e.q + ' ' + e.a).toLowerCase();
    return words.every(w => hay.includes(w));
  });
}

/* ============================================================
   EKRAN ASYSTENTA
   ============================================================ */
/* ---------- Zapowiedź modułu AI ----------
   Moduł AI będzie potrzebował internetu i wysyłania zdjęć na serwer, a cała
   aplikacja obiecuje dziś coś odwrotnego. Dlatego zapowiedź mówi wprost, że
   to dodatek do włączenia i że przed nim zmieni się polityka prywatności.
   Przycisk otwiera pocztę instalatora z wiadomością do autora — wysyła ją on
   sam, a autor dowiaduje się, czego ludzie naprawdę potrzebują na budowie. */
const AI_POMYSL_TEMAT = 'Asystent Instalatora — pomysł na asystenta AI';

/* Limit pomysłów: pięć na telefon. Wiadomość wysyła instalator ze swojej
   poczty, więc aplikacja nie wie, czy ją faktycznie wysłał — liczymy
   otwarcia poczty tym przyciskiem. Po piątym przycisk gaśnie. */
const AI_POMYSL_KEY = 'ai_pomysly_v1';
const AI_POMYSL_MAX = 5;
function aiPomyslIle() {
  try { const d = JSON.parse(localStorage.getItem(AI_POMYSL_KEY) || 'null'); return d && d.ile > 0 ? d.ile : 0; }
  catch (e) { return 0; }
}
function aiPomyslZapisz(ile) {
  try { localStorage.setItem(AI_POMYSL_KEY, JSON.stringify({ ile })); } catch (e) { /* bez zapisu też działa */ }
}
const aiPomyslTresc = () => 'Na budowie przydałoby mi się, żeby asystent AI umiał:\n\n- \n\n'
  + '(wersja aplikacji ' + (typeof APP_WERSJA === 'string' ? APP_WERSJA : '') + ')';
const mailtoPomyslu = () => 'mailto:' + KONTAKT_EMAIL
  + '?subject=' + encodeURIComponent(AI_POMYSL_TEMAT)
  + '&body=' + encodeURIComponent(aiPomyslTresc());

function aiPomyslPrzycisk() {
  const ile = aiPomyslIle();
  if (ile >= AI_POMYSL_MAX) {
    return `<p class="ai-zap-dzieki">${svg('ok2')}Dzięki za ${AI_POMYSL_MAX} pomysłów — to limit na jeden telefon.</p>`;
  }
  const zostalo = AI_POMYSL_MAX - ile;
  return `<button type="button" class="ai-zap-btn" data-aipomysl>${svg('doc')}Podpowiedz, co ma umieć</button>`
    + (ile ? `<p class="ai-zap-lim">Możesz wysłać jeszcze ${zostalo} ${odmiana(zostalo, 'pomysł', 'pomysły', 'pomysłów')}.</p>` : '');
}

/* Zwinięta do jednego wiersza, żeby nie spychała w dół kontroli oferty
   i bazy wiedzy. Rozwija się dotknięciem; stan pamiętamy do końca sesji,
   bo po kliknięciu „Podpowiedz" ekran się przerysowuje. */
function aiZapowiedzHtml() {
  return `<details class="ai-zap"${state.aiZapOtwarte ? ' open' : ''}>
      <summary class="ai-zap-sum">
        <span class="ai-zap-ico">${svg('spark')}</span>
        <span class="ai-zap-t"><b>Asystent AI na budowę</b><span class="ai-zap-tag">W przygotowaniu</span></span>
        <span class="ai-zap-chev">${svg('chevDown')}</span>
      </summary>
      <div class="ai-zap-body">
        <p>Szykujemy moduł AI do analizy tego, co zastajesz na budowie. Robisz zdjęcie kotłowni,
          rozdzielacza albo starej instalacji i opisujesz problem po swojemu — asystent podpowie,
          na co zwrócić uwagę, co sprawdzić przed wyceną i którym kalkulatorem to policzyć.</p>
        <p class="ai-zap-mn">Będzie to dodatek do włączenia, nie obowiązek. Do działania będzie potrzebował
          internetu, więc zanim się pojawi, zaktualizujemy politykę prywatności i zapytamy Cię o zgodę.
          Wszystko, co działa dziś, dalej będzie działać bez internetu.</p>
        ${aiPomyslPrzycisk()}
      </div>
    </details>`;
}

function renderAssistTab() {
  if (state.kody && typeof renderKody === 'function') return renderKody();
  const q = state.kbQuery || '';
  const found = kbSearch(q);

  // skrót do kontroli najświeższej oferty
  const offers = state.offers || [];
  const last = offers[offers.length - 1];
  const issues = last ? offerChecks(last).length : 0;
  const checkCard = last ? `
    <button class="ocard" data-checklast>
      <span class="ocard-n" style="background:color-mix(in srgb,${issues ? 'var(--flame)' : 'var(--cat-pipe)'} 14%,transparent);
        color:${issues ? 'var(--flame)' : 'var(--cat-pipe)'}">${issues ? issues : svg('ok2')}</span>
      <span class="ocard-t"><strong>Sprawdź ostatnią ofertę</strong>
        <span>${esc(last.client.name || last.number)} — ${issues ? issues + ' rzeczy do sprawdzenia' : 'nie znalazłem braków'}</span></span>
      <span class="tile-chev">${svg('chev')}</span>
    </button>` : '';

  const groups = KB_CATS.map(c => {
    const items = found.filter(e => e.c === c.k);
    if (!items.length) return '';
    return `<div class="cat-head" style="--c:var(--flame)"><span class="cat-dot"></span>${c.label}</div>
      <div class="kb">${items.map(e => `
        <details class="kb-item">
          <summary>${esc(e.q)}<span class="kb-mark">${svg('chevDown')}</span></summary>
          <div class="kb-a">${e.a.split('\n').map(l => l ? `<p>${esc(l)}</p>` : '').join('')}
            ${e.calc ? `<button class="kb-link" data-kbcalc="${e.calc}">${svg('calc')}Otwórz kalkulator${svg('arrow')}</button>` : ''}
          </div>
        </details>`).join('')}</div>`;
  }).join('');

  return `<header class="hdr"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><div class="hdr-ico">${svg('spark')}</div>
      <div><h1>Asystent</h1><p>Wiedza techniczna i kontrola ofert — bez internetu</p></div></div></header>
    <div class="body">
      ${aiZapowiedzHtml()}
      ${typeof kodyKartaHtml === 'function' ? kodyKartaHtml() : ''}
      ${checkCard}
      <div class="search">${svg('search')}
        <input id="kbq" type="search" placeholder="Szukaj — np. naczynie, pompa, VAT…"
          value="${esc(q)}" aria-label="Szukaj w bazie wiedzy"></div>
      ${found.length ? groups : `<p class="empty">Nic nie znalazłem dla „${esc(q)}”.<br>Spróbuj innego słowa — np. „pompa”, „izolacja”, „naczynie”.</p>`}
      <div class="tip">${svg('spark')}<div>Asystent działa w całości na telefonie. Żadne dane Twoje ani Twoich klientów
        nie są nigdzie wysyłane, więc odpowiada też w piwnicy bez zasięgu.</div></div>
    </div>`;
}

/* ---------- Zdarzenia ---------- */
document.addEventListener('click', e => {
  const kc = e.target.closest('[data-kbcalc]');
  if (kc) {
    state.tab = 'calc'; state.screen = 'calc'; state.calc = kc.dataset.kbcalc;
    render(true); return;
  }
  if (e.target.closest('[data-aipomysl]')) {
    const ile = aiPomyslIle();
    if (ile >= AI_POMYSL_MAX) { render(false); return; }
    aiPomyslZapisz(ile + 1);
    const vp = document.getElementById('viewport'), y = vp ? vp.scrollTop : 0;
    render(false); if (vp) vp.scrollTop = y;
    try { window.location.href = mailtoPomyslu(); } catch (er) {
      toast('Nie udało się otworzyć programu pocztowego. Napisz na ' + KONTAKT_EMAIL + '.');
    }
    return;
  }
  if (e.target.closest('[data-checklast]')) {
    const offers = state.offers || [];
    const last = offers[offers.length - 1];
    if (last) { state.tab = 'offers'; state.offerId = last.id; state.offerScreen = 'edit'; render(true); }
    return;
  }
});

document.addEventListener('toggle', e => {
  if (e.target.classList && e.target.classList.contains('ai-zap')) state.aiZapOtwarte = e.target.open;
}, true);

document.addEventListener('input', e => {
  if (e.target.id !== 'kbq') return;
  state.kbQuery = e.target.value;
  const pos = e.target.selectionStart;
  render(false);
  const n = document.getElementById('kbq');
  if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (_) {} }
});

