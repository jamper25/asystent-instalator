/* ===== ui_offers.js ===== */
/* ============================================================
   INTERFEJS MODUŁU OFERT
   ============================================================ */
Object.assign(ICO, {
  user: '<circle cx="12" cy="8" r="4"/><path d="M4.5 20.5a7.5 7.5 0 0 1 15 0"/>',
  eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/>',
  money: '<rect x="2.5" y="6" width="19" height="12" rx="2.5"/><circle cx="12" cy="12" r="2.8"/><path d="M6 10v4M18 10v4"/>',
  pen: '<path d="M4 20l4-1 10.5-10.5a2.1 2.1 0 0 0-3-3L5 16z"/><path d="M14.5 5.5l3 3"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  alert: '<path d="M12 4.5l8.5 15h-17z"/><path d="M12 10v4M12 17h.01"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3.6 6.8L12 13l8.4-6.2"/>',
  ok2: '<circle cx="12" cy="12" r="8.5"/><path d="M8.5 12.2l2.5 2.5 4.5-5"/>',
});

/* --- Formatowanie kwot --- */
function zl(n) {
  const v = (Number(n) || 0).toFixed(2);
  const [a, b] = v.split('.');
  return a.replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ',' + b + ' zł';
}
const plDate = iso => { const [y, m, d] = String(iso).split('-'); return `${d}.${m}.${y}`; };

/* --- Stan modułu --- */
state.offers = loadOffers();
state.cofnij = null;   /* ostatnie skasowanie, do cofnięcia przez pasek na dole */
state.offerId = null;
state.offerScreen = 'list';
state.salesScreen = 'list';
state.salesRecords = (() => { try { return JSON.parse(localStorage.getItem('ai_sales_register_v1') || '[]'); } catch (_) { return []; } })();
state.salesEditId = null;
state.inventoryItems = (() => { try { return JSON.parse(localStorage.getItem('ai_inventory_items_v1') || '[]'); } catch (_) { return []; } })();
state.inventoryMoves = (() => { try { return JSON.parse(localStorage.getItem('ai_inventory_moves_v1') || '[]'); } catch (_) { return []; } })();
state.inventoryScreen = 'list';
state.inventoryEditId = null;
state.inventoryMoveId = null;
state.purchaseDocs = (() => { try { return JSON.parse(localStorage.getItem('ai_purchase_docs_v1') || '[]'); } catch (_) { return []; } })();
state.purchaseDocScreen = 'list'; state.purchaseDocDraft = null;

state.picker = false;
/* Miejsce, w którym stoi wybór pozycji: dział, rozmiar i wpisana fraza. */
state.pickGrp = null;
state.pickDn = null;
state.pickQ = '';
/* Zaznaczone pozycje, gdy działa wybieranie kilku naraz. null = tryb wyłączony. */
state.pickSel = null;
/* Rozwinięta grupa wariantów (np. długości przedłużki). */
state.pickWar = null;

/* Baza klientów. `klientId` to klient otwarty do edycji, `pickKlient`
   mówi, że na wierzchu stoi arkusz wyboru klienta do oferty. */
state.klienci = loadKlienci();
state.klientId = null;
state.klientQ = '';
state.pickKlient = false;

const currentOffer = () => state.offers.find(o => o.id === state.offerId);
const persist = () => saveOffers(state.offers);
const persistKlienci = () => saveKlienci(state.klienci);
const currentKlient = () => state.klienci.find(k => k.id === state.klientId);

/* ============================================================
   EKRAN: LISTA OFERT
   ============================================================ */
/* Ekran zakładki: najpierw oferty w toku, pod nimi wystawione faktury.
   Rozdzielone, a nie wymieszane, bo to dwa różne stany tej samej sprawy:
   oferta czeka na decyzję klienta, faktura jest już dokumentem księgowym.
   Oferta, do której wystawiono fakturę, schodzi na dół — do faktur — żeby
   nie licytować się o to samo w dwóch miejscach listy. */
function renderOffersList() {
  const wToku = state.offers.filter(o => !o.invoice);
  const zFaktura = fakturyLista();

  /* Kafelek to teraz wiersz z dwoma przyciskami: cały kafelek otwiera,
     a mały kosz z boku kasuje. Kasowanie jest natychmiastowe, ale przez
     pięć sekund da się je cofnąć z paska na dole — na telefonie to lepsze
     niż okno „czy na pewno", które i tak się odklikuje bez czytania,
     a przy pomyłce nie daje już nic. */
  const kosz = (id, co) => `<button class="ocard-x" data-delrow="${id}" data-what="${co}"
      aria-label="Usuń ${co === 'inv' ? 'fakturę' : 'ofertę'}"
      title="Usuń ${co === 'inv' ? 'fakturę' : 'ofertę'}">${svg('trash')}</button>`;

  const kartaOferty = o => {
    const t = offerTotals(o);
    const issues = offerChecks(o).length;
    return `<div class="orow">
      <button class="ocard" data-openoffer="${o.id}">
        <span class="ocard-n">${esc(String(o.number).split('/')[0])}</span>
        <span class="ocard-t">
          <strong>${esc(o.client.name || 'Oferta bez nazwy')}${o.sample ? '<span class="tagmini">przykład</span>' : ''}</strong>
          <span>${o.projektId && typeof projNazwa === 'function' && projNazwa(o.projektId) ? 'projekt: ' + esc(projNazwa(o.projektId)) + ' · ' : ''}${plDate(o.date)} · ${t.count} poz.${issues ? ' · ' + issues + ' do sprawdzenia' : ''}</span>
        </span>
        <span class="ocard-v"><b>${zl(t.gross)}</b><span>brutto</span></span>
      </button>${kosz(o.id, 'off')}</div>`;
  };

  const kartaFaktury = o => {
    const f = o.invoice;
    const d = docLines(o);
    const kl = o.client || {};
    const firma = kl.type === 'firma';
    return `<div class="orow">
      <button class="ocard" data-openinv="${o.id}">
        <span class="ocard-n ocard-n--inv">${svg('doc')}</span>
        <span class="ocard-t">
          <strong>${esc(f.number)}</strong>
          <span>${esc(kl.name || 'bez nabywcy')} · ${firma ? 'firma' : 'osoba prywatna'}${o.projektId && typeof projNazwa === 'function' && projNazwa(o.projektId) ? ' · projekt: ' + esc(projNazwa(o.projektId)) : ''}<br>
            wystawiona ${plDate(f.issue)} · termin ${plDate(terminPlatnosci(f))}</span>
        </span>
        <span class="ocard-v"><b>${zl(d.docGross)}</b>
          <span class="${f.paid ? 'ok-txt' : ''}">${f.paid ? 'zapłacona' : 'brutto'}</span></span>
      </button>${kosz(o.id, 'inv')}</div>`;
  };

  const pusto = t => `<p class="empty">${esc(t)}</p>`;

  return `<header class="hdr"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><div class="hdr-ico">${svg('doc')}</div>
      <div><h1>Biuro</h1><p>${state.projekty ? state.projekty.length + ' ' + odmiana(state.projekty.length, 'projekt', 'projekty', 'projektów') + ' · ' : ''}${wToku.length} ${odmiana(wToku.length, 'oferta', 'oferty', 'ofert')}
        · ${zFaktura.length} ${odmiana(zFaktura.length, 'faktura', 'faktury', 'faktur')} w telefonie</p></div></div></header>
    <div class="body">
      <button class="jump" style="--c:var(--flame)" data-newoffer>${svg('plus')}Nowa oferta</button>
      <button class="btn2" style="width:100%;margin-top:8px" data-klienci>${svg('user')}Klienci${
        state.klienci.length ? ' <span class="tagmini">' + state.klienci.length + '</span>' : ''}</button>
      <button class="btn2" style="width:100%;margin-top:8px" data-budcatalog>${svg('therm')}Katalog kotłów Buderus</button>
      <button class="btn2" style="width:100%;margin-top:8px" data-salesregister>${svg('money')}Rejestr sprzedaży i dostaw <span class="tagmini">${state.salesRecords.length}</span></button>
      <button class="btn2" style="width:100%;margin-top:8px" data-inventory>${svg('money')}Magazyn i zakupy <span class="tagmini">${state.inventoryItems.length}</span></button>
      ${typeof notatnikPrzyciskHtml === 'function' ? notatnikPrzyciskHtml() : ''}

      ${typeof projektySekcjaHtml === 'function' ? projektySekcjaHtml() : ''}
      <div class="sechead">${svg('doc')}Oferty<span>${wToku.length}</span></div>
      ${wToku.length ? `<div class="olist">${wToku.map(kartaOferty).join('')}</div>`
                     : pusto('Nie ma ofert w toku. Nowa oferta zaczyna się przyciskiem u góry albo dodaniem pozycji z kalkulatora.')}

      <div class="sechead">${svg('money')}Faktury<span>${zFaktura.length}</span></div>
      ${zFaktura.length ? `<div class="olist">${zFaktura.map(kartaFaktury).join('')}</div>`
                        : pusto('Nie ma jeszcze wystawionych faktur. Fakturę wystawia się z gotowej oferty, po jej zatwierdzeniu przez klienta.')}

      <div class="tip">${svg('spark')}<div>Wszystko zapisuje się w telefonie i działa bez internetu.
        Fakturę zapisujesz i wysyłasz z jej własnego ekranu — wejdź w nią z listy.</div></div>
    </div>`;
}

/* ============================================================
   LISTA FAKTUR
   ------------------------------------------------------------
   Faktura mieszka w ofercie, z której powstała, więc lista faktur to po
   prostu te oferty, które ją mają.
   ============================================================ */

const fakturyLista = () => state.offers.filter(o => o && o.invoice);

/* Termin płatności = data wystawienia + liczba dni */
function terminPlatnosci(f) {
  if (!f || !f.issue) return '';
  const d = new Date(f.issue + 'T00:00:00Z');
  if (isNaN(d)) return '';
  d.setUTCDate(d.getUTCDate() + (Number(f.dueDays) || 0));
  return d.toISOString().slice(0, 10);
}

/* ============================================================
   WYSYŁKA DOKUMENTU DO KLIENTA
   ------------------------------------------------------------
   Klient dostaje gotowy plik PDF, a nie ofertę przepisaną w treści maila.
   Aplikacja składa ten plik sama (patrz pdf.js), więc jest gotowy od razu,
   bez przechodzenia przez okno drukowania.

   Na telefonie plik idzie przez systemowe okno wysyłki: użytkownik wybiera
   pocztę, WhatsAppa albo cokolwiek innego, a dokument jest tam prawdziwym
   załącznikiem. Temat i treść wiadomości aplikacja wpisuje za niego.

   W przeglądarce takiej drogi nie ma — żadna strona nie może sama dopiąć
   pliku do wiadomości. Dlatego tam PDF się pobiera, a program pocztowy
   otwiera się z wpisanym adresem i tematem; plik zostaje do dołączenia
   ręcznie. Mówimy o tym wprost, zamiast udawać, że poszedł sam. */

/* Skopiowanie tekstu do schowka. Nowoczesne API bywa zablokowane —
   w przeglądarce bez bezpiecznego połączenia, a czasem i w WebView —
   więc zostaje stary sposób przez ukryte pole. Wynik oddajemy przez
   funkcję zwrotną, bo nowe API jest asynchroniczne, a wywołujący musi
   wiedzieć, czy ma o czym napisać użytkownikowi. */
function doSchowka(tekst, gotowe) {
  const koniec = w => { if (gotowe) gotowe(w); };
  const t = String(tekst || '');
  if (!t) { koniec(false); return; }

  const naPiechote = () => {
    try {
      const pole = document.createElement('textarea');
      pole.value = t;
      pole.setAttribute('readonly', '');
      pole.style.position = 'fixed';
      pole.style.top = '-1000px';
      document.body.appendChild(pole);
      pole.select();
      const ok = document.execCommand && document.execCommand('copy');
      pole.remove();
      koniec(!!ok);
    } catch (e) { koniec(false); }
  };

  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t).then(() => koniec(true)).catch(naPiechote);
      return;
    }
  } catch (e) { /* lecimy starą drogą */ }
  naPiechote();
}

function wyslijDokument(faktura) {
  const o = currentOffer();
  if (!o) return;
  if (faktura && !o.invoice) { toast('Najpierw wystaw fakturę.'); return; }

  const adres = (o.client.email || '').trim();
  if (!adres) {
    toast('Nie ma adresu e-mail klienta — wpisz go w danych klienta, w ofercie albo na fakturze.');
    return;
  }

  const st = state.settings || DEFAULT_SETTINGS;
  const temat = (faktura ? 'Faktura ' + o.invoice.number : 'Oferta ' + o.number)
    + (st.company ? ' — ' + st.company : '');
  const wstep = (o.client.name ? 'Dzień dobry, ' + o.client.name + '.\n\n' : 'Dzień dobry.\n\n')
    + (faktura
      ? 'W załączniku przesyłam fakturę ' + o.invoice.number + '.'
      : 'W załączniku przesyłam ofertę ' + o.number + '.'
        + (st.validDays ? ' Oferta ważna ' + st.validDays + ' dni.' : ''))
    + '\n\nPozdrawiam\n' + (st.company || '')
    + (st.phone ? '\ntel. ' + st.phone : '');

  let plik;
  try { plik = pdfDokument(o, faktura); } catch (e) {
    toast('Nie udało się przygotować pliku PDF.');
    return;
  }
  const nazwa = pdfNazwa(o, faktura);

  /* Telefon: plik jako prawdziwy załącznik w oknie wysyłki.

     Okno udostępniania Androida nie przyjmuje adresata — przekazuje tylko
     plik, temat i treść. Program pocztowy otwiera się więc z pustym polem
     „Do" i adres trzeba wpisać ręcznie, co przy dłuższym mailu jest zwykłą
     udręką. Dlatego tuż przed otwarciem okna wrzucamy adres do schowka:
     w poczcie wystarczy przytrzymać pole „Do" i wkleić. */
  if (typeof naTelefonie === 'function' && naTelefonie()) {
    doSchowka(adres, skopiowano => {
      wyslijPdfZTelefonu(nazwa, pdfDoB64(plik), { temat, tresc: wstep, okno: 'Wyślij ' + nazwa },
        w => toast(w.ok
          ? (w.wyslane
            ? (skopiowano
              ? 'Wysłano ' + nazwa + '. Adres ' + adres + ' jest w schowku — wklej w polu „Do".'
              : 'Wysłano ' + nazwa + '.')
            : 'Plik ' + nazwa + ' zapisany w Dokumentach.')
          : w.powod));
    });
    return;
  }

  /* Przeglądarka: pobranie pliku i poczta osobno — inaczej się nie da. */
  pobierzPdfWPrzegladarce(nazwa, plik);
  const url = 'mailto:' + encodeURIComponent(adres)
    + '?subject=' + encodeURIComponent(temat)
    + '&body=' + encodeURIComponent(wstep);
  setTimeout(() => {
    try { window.location.href = url; } catch (e) { /* brak programu pocztowego */ }
  }, 400);
  toast('Pobrano ' + nazwa + ' — dołącz go do otwartej wiadomości.');
}

/* ============================================================
   KASOWANIE Z MOŻLIWOŚCIĄ COFNIĘCIA
   ------------------------------------------------------------
   Skasowana oferta nie znika od razu na dobre: ląduje w state.cofnij razem
   ze swoim miejscem na liście, a pasek na dole przez pięć sekund proponuje
   przywrócenie. Po tym czasie pasek gaśnie i sprawa jest zamknięta.

   Usunięcie faktury zostawia ofertę — bo to dwie różne rzeczy i skasowanie
   pomyłkowo wystawionej faktury nie powinno kasować całej wyceny razem
   z pozycjami, których się nie odtworzy.
   ============================================================ */

state.usunPyt = null;          // { co: 'oferta' | 'faktura', id }

function usunPytHtml(q) {
  const o = state.offers.find(x => x.id === q.id);
  if (!o) return '';
  const faktura = q.co === 'faktura';
  const numer = faktura ? (o.invoice && o.invoice.number || '') : o.number;
  const kto = o.client && o.client.name ? ' dla ' + esc(o.client.name) : '';
  return `<div class="sheet" data-usunnie role="dialog" aria-label="${faktura ? 'Usunąć fakturę?' : 'Usunąć ofertę?'}">
    <div class="sheet-in" data-stop>
      <div class="sheet-h">${svg('trash')}<strong>${faktura ? 'Usunąć fakturę?' : 'Usunąć ofertę?'}</strong>
        <button class="item-x" data-usunnie aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        <p class="hint" style="margin:0 0 14px">${faktura
          ? 'Faktura ' + esc(numer) + kto + ' zniknie z listy. Oferta i jej pozycje zostają.'
          : 'Oferta ' + esc(numer) + kto + ' zniknie razem ze wszystkimi pozycjami'
            + (o.invoice ? ' i wystawioną do niej fakturą ' + esc(o.invoice.number) : '') + '.'}</p>
        <button class="jump" style="--c:#C62828" data-usuntak>${svg('trash')}${faktura ? 'Usuń fakturę' : 'Usuń ofertę'}</button>
        <button class="btn2 usun-nie" style="width:100%;margin-top:8px" data-usunnie>Anuluj</button>
      </div></div></div>`;
}

function usunOferte(id) {
  const i = state.offers.findIndex(o => o.id === id);
  if (i < 0) return;
  const o = state.offers[i];
  state.cofnij = { typ: 'oferta', poz: i, dane: o, opis: o.number };
  state.offers.splice(i, 1);
  if (state.offerId === id) { state.offerId = null; state.offerScreen = 'list';
 }
  persist(); render(false);
  toast('Usunięto ofertę ' + o.number + '.', 'Cofnij');
}

function usunFakture(id) {
  const o = state.offers.find(x => x.id === id);
  if (!o || !o.invoice) return;
  state.cofnij = { typ: 'faktura', id, dane: o.invoice, opis: o.invoice.number };
  o.invoice = null;
  if (state.offerId === id && state.offerScreen === 'invoice') state.offerScreen = 'list';

  persist(); render(false);
  toast('Usunięto fakturę ' + state.cofnij.opis + '. Oferta została.', 'Cofnij');
}

function cofnijUsuniecie() {
  const c = state.cofnij;
  if (!c) return;

  /* Cofnięcie zmiany w katalogu. Pozycja w ofercie zostaje taka, jaka była —
     cofamy tylko wpis w cenniku, bo o to prosi pasek. Zrywamy przy tym
     powiązanie z katalogiem, inaczej następne wyjście z pola dopisałoby
     ją z powrotem i przycisk „Cofnij" wyglądałby na zepsuty. */
  if (c.typ === 'ceny') {
    try {
      if (c.dane && c.dane.ceny !== null) localStorage.setItem(CENY_KEY, c.dane.ceny);
      if (c.dane && c.dane.wlasne !== null) localStorage.setItem(CATALOG_KEY, c.dane.wlasne);
    } catch (e) { /* jw. */ }
    state.catalog = loadCatalog();
    state.cofnij = null;
    render(false);
    toast('Przywrócono Twoje ceny.');
    return;
  }

  if (c.typ === 'katalog' || c.typ === 'katalogCena') {
    const i = state.catalog.findIndex(x => x.id === c.id);
    if (i >= 0) {
      if (c.typ === 'katalog') state.catalog.splice(i, 1);
      else state.catalog[i].price = c.dane;
    }
    const o = currentOffer();
    if (o && c.typ === 'katalog') o.items.forEach(it => { if (it.katId === c.id) delete it.katId; });
    state.cofnij = null;
    persist(); persistCatalog();
    toast(c.typ === 'katalog'
      ? 'Usunięto „' + c.opis + '" z katalogu.'
      : 'Przywrócono poprzednią cenę „' + c.opis + '" w katalogu.');
    return;
  }

  if (c.typ === 'klient') {
    state.klienci.splice(Math.min(c.poz, state.klienci.length), 0, c.dane);
    state.cofnij = null;
    persistKlienci(); render(false);
    toast('Przywrócono ' + c.opis + ' w bazie.');
    return;
  }

  if (c.typ === 'oferta') {
    state.offers.splice(Math.min(c.poz, state.offers.length), 0, c.dane);
  } else {
    const o = state.offers.find(x => x.id === c.id);
    if (o) o.invoice = c.dane;
  }
  state.cofnij = null;
  persist(); render(false);
  toast('Przywrócono ' + (c.typ === 'oferta' ? 'ofertę ' : 'fakturę ') + c.opis + '.');
}

/* ============================================================
   BAZA KLIENTÓW
   ------------------------------------------------------------
   Dwa guziki pod danymi klienta w ofercie i osobny ekran w zakładce Oferty.
   Zasada jest taka, że baza nie robi nic sama z siebie: nie dopisuje
   klienta po cichu przy zapisie oferty i nie podmienia danych, których
   instalator nie kazał podmienić. Wszystko dzieje się po dotknięciu guzika,
   bo przy wycenie u klienta w domu niespodzianki są najgorsze.
   ============================================================ */

function klientPaskiHtml(o) {
  const k = klientZOferty(o);
  const zBazy = state.klienci.find(x => klientTenSam(x, k));
  const ile = state.klienci.length;
  /* Napis na guziku mówi, co się stanie: przy nowym kliencie „dodaj",
     przy znanym — „uaktualnij", bo to dwie różne rzeczy i tylko jedna
     z nich nadpisuje to, co już w bazie jest. */
  const podpis = zBazy && !klientPusty(k) ? 'Uaktualnij go w bazie' : 'Dodaj klienta do bazy';
  return `<div class="klient-akcje">
      <button class="btn2" data-klientzapisz${klientPusty(k) ? ' disabled' : ''}>${svg('user')}${podpis}</button>
      <button class="btn2" data-klientwybierz${ile ? '' : ' disabled'}>${svg('list')}Wybierz z bazy${
        ile ? ' <span class="tagmini">' + ile + '</span>' : ''}</button>
    </div>`;
}

/* Jeden wiersz klienta. `wybor` rozróżnia dwa zastosowania tej samej listy:
   w arkuszu dotknięcie wstawia dane do oferty, na ekranie bazy — otwiera
   klienta do poprawienia i dokłada kosz. */
function klientWierszHtml(k, wybor) {
  const inicjal = esc(String(k.name || '?').trim().slice(0, 1).toUpperCase());
  const srodek = `<span class="ocard-n">${inicjal}</span>
      <span class="ocard-t"><strong>${esc(k.name || 'bez nazwy')}${
        k.type === 'firma' ? '<span class="tagmini">firma</span>' : ''}</strong>
        <span>${esc(klientOpis(k))}</span></span>`;
  if (wybor) return `<button class="ocard" data-klientbierz="${k.id}">${srodek}</button>`;
  return `<div class="orow"><button class="ocard" data-openklient="${k.id}">${srodek}</button>
      <button class="ocard-x" data-delklient="${k.id}" aria-label="Usuń klienta"
        title="Usuń klienta">${svg('trash')}</button></div>`;
}

function klientListaHtml(wybor) {
  const lista = klienciSzukaj(state.klienci, state.klientQ);
  if (!lista.length) {
    return `<div class="olist"><p class="empty">${state.klientQ
      ? 'Nikogo takiego nie ma w bazie.'
      : (wybor ? 'Baza jest pusta. Wpisz dane klienta w ofercie i dotknij „Dodaj klienta do bazy".'
               : 'Baza jest pusta. Dodasz klienta tutaj albo prosto z oferty, guzikiem pod jego danymi.')}</p></div>`;
  }
  return '<div class="olist">' + lista.map(k => klientWierszHtml(k, wybor)).join('') + '</div>';
}

/* --- Arkusz wyboru klienta do oferty --- */
function klientSheetHtml() {
  return `<div class="sheet" data-closeklient role="dialog" aria-label="Wybierz klienta">
    <div class="sheet-in" data-stop>
      <div class="sheet-h">${svg('user')}<strong>Wybierz klienta</strong>
        <button class="item-x" data-closeklient aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-find">
        <div class="search">${svg('search')}
          <input type="search" data-klientq placeholder="Szukaj: nazwisko, adres, NIP…"
            value="${esc(state.klientQ)}" autocapitalize="off" autocorrect="off" spellcheck="false">
        </div>
      </div>
      <div class="sheet-body">${klientListaHtml(true)}</div>
    </div></div>`;
}

/* --- Ekran: lista klientów --- */
function renderKlienciList() {
  return `<header class="hdr hdr--cat" style="--c:var(--flame)"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" data-klienciback aria-label="Wróć">${svg('back')}</button>
      <div><h1>Klienci</h1><p>${state.klienci.length} ${
        odmiana(state.klienci.length, 'klient', 'klientów', 'klientów')} w telefonie</p></div></div></header>
    <div class="body">
      <button class="jump" style="--c:var(--flame)" data-nowyklient>${svg('plus')}Dodaj klienta</button>
      ${state.klienci.length > 4 ? `<div class="field"><label for="kl-q">Szukaj</label>
        <input id="kl-q" type="search" value="${esc(state.klientQ)}" data-klientq
          placeholder="nazwa, adres, telefon albo NIP" autocapitalize="off" spellcheck="false"></div>` : ''}
      ${klientListaHtml(false)}
      <div class="tip">${svg('spark')}<div>Klient zapisany raz wchodzi do następnej oferty jednym dotknięciem —
        razem z adresem, telefonem, e-mailem i NIP-em. Baza jedzie w kopii zapasowej, więc przy zmianie telefonu
        nie trzeba jej przepisywać.</div></div>
    </div>`;
}

/* --- Ekran: jeden klient --- */
function renderKlientEdit() {
  const k = currentKlient();
  if (!k) { state.klientScreen = 'list'; return renderKlienciList(); }
  const firma = k.type === 'firma';
  const uzyty = state.offers.filter(o => klientTenSam(klientZOferty(o), k));

  return `<header class="hdr hdr--cat" style="--c:var(--flame)"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" data-klientback aria-label="Wróć">${svg('back')}</button>
      <div><h1>${esc(k.name || 'Nowy klient')}</h1><p>${uzyty.length
        ? uzyty.length + ' ' + odmiana(uzyty.length, 'dokument', 'dokumenty', 'dokumentów') + ' na jego dane'
        : 'jeszcze bez dokumentów'}</p></div></div></header>
    <div class="body">
      <div class="card"><div class="card-head">${svg('user')}Dane klienta</div><div class="fields">
        <div class="field"><label for="kl-name">Imię i nazwisko / firma</label>
          <input id="kl-name" type="text" autocapitalize="words" data-kl="name" value="${esc(k.name || '')}"></div>
        <div class="field"><label for="kl-addr">Adres</label>
          <input id="kl-addr" type="text" autocapitalize="words" data-kl="address" value="${esc(k.address || '')}"></div>
        <div class="field"><label for="kl-tel">Telefon</label>
          <input id="kl-tel" type="text" inputmode="tel" data-kl="phone" value="${esc(k.phone || '')}"></div>
        <div class="field"><label for="kl-mail">E-mail</label>
          <input id="kl-mail" type="email" inputmode="email" autocapitalize="off" autocorrect="off"
            spellcheck="false" data-kl="email" value="${esc(k.email || '')}"></div>
        <div class="field"><label for="kl-typ">Rodzaj</label>
          <select id="kl-typ" data-kl="type">
            <option value="osoba"${firma ? '' : ' selected'}>Osoba prywatna</option>
            <option value="firma"${firma ? ' selected' : ''}>Firma</option>
          </select><span class="chev">${svg('chevDown')}</span></div>
        ${firma ? `<div class="field"><label for="kl-nip">NIP</label>
          <input id="kl-nip" type="text" inputmode="numeric" data-kl="nip" value="${esc(k.nip || '')}"></div>` : ''}
        <div class="field"><label for="kl-not">Notatka</label>
          <input id="kl-not" type="text" data-kl="notatka" value="${esc(k.notatka || '')}"
            placeholder="np. kocioł Vaillant, kod do bramy 1234"></div>
      </div></div>
      ${uzyty.length ? `<div class="card"><div class="card-head">${svg('doc')}Dokumenty tego klienta</div>
        <div class="olist">${uzyty.map(o => `<button class="ocard" data-openoffer="${o.id}">
          <span class="ocard-n">${esc(String(o.number).split('/')[0])}</span>
          <span class="ocard-t"><strong>${esc(o.number)}</strong>
            <span>${plDate(o.date)}${o.invoice ? ' · faktura ' + esc(o.invoice.number) : ''}</span></span>
          <span class="ocard-v"><b>${zl(offerTotals(o).gross)}</b><span>brutto</span></span>
        </button>`).join('')}</div></div>` : ''}
      <div class="card"><div class="card-head">${svg('building')}Urządzenia i instalacje klienta</div>
        <p class="hint">Ewidencja urządzeń przypisana do klienta. Numer seryjny i daty pomagają szybko rozpoznać sprzęt przy kolejnym zgłoszeniu.</p>
        <div class="fields">
          <div class="field"><label>Producent</label><input data-kleq="brand" placeholder="np. Buderus"></div>
          <div class="field"><label>Model / typ</label><input data-kleq="model" placeholder="np. Logamax plus GB172"></div>
          <div class="field"><label>Numer seryjny</label><input data-kleq="serial" placeholder="Numer z tabliczki znamionowej"></div>
          <div class="field"><label>Miejsce montażu</label><input data-kleq="location" placeholder="np. kotłownia, lokal usługowy"></div>
          <div class="field"><label>Data montażu</label><input type="date" data-kleq="installedAt"></div>
          <div class="field"><label>Gwarancja do</label><input type="date" data-kleq="warrantyUntil"></div>
          <div class="field"><label>Następny przegląd</label><input type="date" data-kleq="nextServiceDate"></div>
          <div class="field"><label>Uwagi</label><input data-kleq="notes" placeholder="np. moc, rodzaj instalacji"></div>
        </div>
        <button class="btn2" data-kleqadd>Dodaj urządzenie</button>
        ${(Array.isArray(k.equipment)&&k.equipment.length)?`<div class="olist">${k.equipment.map(q=>`<article class="orow"><div class="ocard" style="display:block"><strong>${esc([q.brand,q.model].filter(Boolean).join(' ')||'Urządzenie')}</strong><span>${esc(q.serial?'S/N: '+q.serial:'Brak numeru seryjnego')} · ${esc(q.location||'Nie podano miejsca')}</span><small>${q.installedAt?'Montaż: '+esc(q.installedAt):''}${q.warrantyUntil?' · Gwarancja do: '+esc(q.warrantyUntil):''}${q.nextServiceDate?' · Przegląd: '+esc(q.nextServiceDate):''}</small>${q.notes?`<p>${esc(q.notes)}</p>`:''}</div><button class="ocard-x" data-kleqdelete="${esc(q.id)}" title="Usuń urządzenie">${svg('trash')}</button></article>`).join('')}</div>`:'<p class="empty">Nie dodano jeszcze urządzeń tego klienta.</p>'}
      </div>
      <div class="card"><div class="card-head">${svg('doc')}Historia obsługi klienta</div>
        <p class="hint">Wizyty, przeglądy, naprawy, rozmowy i ustalenia — przypisane do tego klienta.</p>
        <div class="fields">
          <div class="field"><label>Data</label><input type="date" data-klcrm="date" value="${new Date().toISOString().slice(0,10)}"></div>
          <div class="field"><label>Rodzaj zdarzenia</label><select data-klcrm="type"><option>Serwis</option><option>Przegląd</option><option>Montaż</option><option>Wycena</option><option>Kontakt telefoniczny</option><option>Reklamacja</option><option>Inne</option></select></div>
          <div class="field"><label>Urządzenie / instalacja</label><input data-klcrm="equipment" placeholder="np. Buderus Logamax plus GB172"></div>
          <div class="field"><label>Opis czynności i ustaleń</label><textarea data-klcrm="description" rows="3" placeholder="Objawy, wykonane prace, części, zalecenia, termin kolejnej wizyty"></textarea></div>
          <div class="field"><label>Koszt usługi brutto (opcjonalnie)</label><input type="number" min="0" step="0.01" data-klcrm="amount" placeholder="0,00"></div>
        </div>
        <button class="btn2" data-klcrmadd>Dodaj wpis do historii</button>
        ${(Array.isArray(k.serviceHistory)&&k.serviceHistory.length)?`<div class="olist">${[...k.serviceHistory].sort((a,b)=>(b.date||'').localeCompare(a.date||'')).map(h=>`<article class="orow"><div class="ocard" style="display:block"><strong>${esc(h.type||'Zdarzenie')} · ${esc(plDate(h.date)||'bez daty')}</strong><span>${esc(h.equipment||'Bez wskazanego urządzenia')}</span><p>${esc(h.description||'')}</p>${h.amount!==''&&h.amount!=null?`<b>${zl(Number(h.amount)||0)} brutto</b>`:''}</div><button class="ocard-x" data-klcrmdelete="${esc(h.id)}" title="Usuń wpis">${svg('trash')}</button></article>`).join('')}</div>`:'<p class="empty">Brak wpisów w historii obsługi.</p>'}
      </div>
      <div class="card"><div class="card-head">${svg('money')}Powiązana sprzedaż</div>
        ${(()=>{const rows=(state.salesRecords||[]).filter(x=>klientTenSam({name:x.client,nip:x.nip},{name:k.name,nip:k.nip}));return rows.length?`<div class="olist">${rows.map(x=>`<div class="orow"><div class="ocard" style="display:block"><strong>${esc(x.site||x.documentNo||'Sprzedaż')}</strong><span>${esc(x.saleDate||'')} · ${zl(Number(x.gross)||0)}</span><small>${esc(x.delivery||'')}</small></div></div>`).join('')}</div>`:'<p class="empty">Brak powiązanych wpisów sprzedaży.</p>';})()}
      </div>
      <div class="tip">${svg('spark')}<div>Zmiana danych tutaj nie rusza ofert ani faktur, które już powstały —
        tam dane są przepisane i zostają takie, jakie były w dniu wystawienia. To celowo: na dokumencie
        księgowym adres nie może się zmieniać po fakcie.</div></div>
    </div>`;
}

/* --- Kawałki ekranu, które odświeżamy osobno ---
   Przy pisaniu nazwy NIE przerysowujemy całego ekranu: gdyby to robić,
   przycisk pod palcem użytkownika znikałby w trakcie dotknięcia i kliknięcie
   przepadało. Zamiast tego podmieniamy tylko te dwa fragmenty. */
function checksBlockHtml(checks) {
  return checks.length
    ? `<div class="checks">
        <div class="checks-h">${svg('alert')}Sprawdzenie kompletności<span class="checks-n">${checks.length}</span></div>
        <ul>${checks.map(c => `<li>${svg('alert')}<span>${esc(c)}</span></li>`).join('')}</ul>
       </div>`
    : `<div class="checks ok">
        <div class="checks-h">${svg('ok2')}Sprawdzenie kompletności<span class="checks-n">OK</span></div>
        <ul><li>${svg('ok2')}<span>Nie znalazłem typowych braków w tej ofercie.</span></li></ul>
       </div>`;
}

/* Podpowiedź kategorii zamiast automatycznej zmiany — decyzja zostaje u użytkownika. */
function itemFootHtml(it, i) {
  let suggest = '';
  if (!it.catManual && String(it.name || '').length >= 4) {
    const g = guessCat(it.name);
    if (g !== it.cat) suggest = `<button class="cat-fix" data-icatfix="${i}">to ${g === 'rob' ? 'robocizna' : 'materiał'}?</button>`;
  }
  /* Znacznik „w katalogu" jest po to, żeby użytkownik wiedział, że
     poprawiając tu cenę, poprawia ją także w swoim cenniku — a nie
     dowiadywał się o tym dopiero przy następnej ofercie. */
  const wKatalogu = it.katId
    ? `<span class="tag-note" title="Ta pozycja jest w Twoim katalogu cen">${svg('ok2')}w katalogu</span>`
    : '';
  return `<button class="pill-cat ${it.cat === 'rob' ? 'pill-rob' : 'pill-mat'}" data-icat="${i}"
      title="Przełącz materiał / robocizna">${svg('pen')}${it.cat === 'rob' ? 'robocizna' : 'materiał'}</button>
    ${suggest}${wKatalogu}
    <span class="item-sum">${zl((it.qty || 0) * (it.price || 0))}</span>`;
}

function refreshChecks() {
  const o = currentOffer();
  if (!o || state.tab !== 'offers' || state.offerScreen !== 'edit') return;
  const el = document.querySelector('.checks');
  if (el) el.outerHTML = checksBlockHtml(offerChecks(o));
}
function refreshItemFoot(i) {
  const o = currentOffer();
  if (!o || !o.items[i]) return;
  const el = document.querySelector(`.item[data-idx="${i}"] .item-foot`);
  if (el) el.innerHTML = itemFootHtml(o.items[i], i);
}

/* ============================================================
   EKRAN: EDYTOR OFERTY
   ============================================================ */
function renderOfferEdit() {
  const o = currentOffer();
  if (!o) { state.offerScreen = 'list';
 return renderOffersList(); }
  const t = offerTotals(o);
  const checks = offerChecks(o);

  const units = it => UNITS.concat(UNITS.includes(it.unit) ? [] : [it.unit])
    .map(u => `<option value="${esc(u)}"${u === it.unit ? ' selected' : ''}>${esc(u)}</option>`).join('');

  const items = o.items.length ? o.items.map((it, i) => `
    <div class="item" data-idx="${i}">
      <div class="item-top">
        <div class="mini grow"><label for="it-n${i}">Nazwa pozycji</label>
          <textarea id="it-n${i}" rows="1" autocapitalize="sentences" enterkeyhint="done" data-iname="${i}">${esc(it.name)}</textarea></div>
        <button class="item-x" data-delitem="${i}" aria-label="Usuń pozycję">${svg('x')}</button>
      </div>
      <div class="item-in">
        <div class="mini"><label for="it-q${i}">Ilość</label>
          <input id="it-q${i}" type="number" inputmode="decimal" step="any" data-iq="${i}" value="${it.qty}"></div>
        <div class="mini unit"><label for="it-u${i}">Jedn.</label>
          <select id="it-u${i}" data-iu="${i}">${units(it)}</select></div>
        <div class="mini"><label for="it-p${i}">Cena jedn.</label>
          <input id="it-p${i}" type="number" inputmode="decimal" step="any" data-ip="${i}" value="${it.price}"></div>
      </div>
      <div class="item-foot">${itemFootHtml(it, i)}</div>
    </div>`).join('')
    : '<p class="empty">Brak pozycji. Dodaj pierwszą z katalogu.</p>';

  const checksBlock = checksBlockHtml(checks);

  return `<header class="hdr hdr--cat" style="--c:var(--flame)"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" id="backoffers" aria-label="Wróć">${svg('back')}</button>
      <div><h1>Oferta ${esc(o.number)}</h1><p>${zl(t.gross)} brutto · ${t.count} pozycji</p></div></div></header>
    <div class="body">
      <div class="card"><div class="card-head">${svg('user')}Dane klienta</div><div class="fields">
        <div class="field"><label for="of-name">Imię i nazwisko / firma</label>
          <input id="of-name" type="text" autocapitalize="words" autocomplete="name" data-of="name" value="${esc(o.client.name)}"></div>
        <div class="field"><label for="of-addr">Adres inwestycji</label>
          <input id="of-addr" type="text" autocapitalize="words" autocomplete="street-address" data-of="address" value="${esc(o.client.address)}"></div>
        <div class="field"><label for="of-tel">Telefon</label>
          <input id="of-tel" type="text" inputmode="tel" data-of="phone" value="${esc(o.client.phone)}"></div>
        <div class="field"><label for="of-mail">E-mail klienta</label>
          <input id="of-mail" type="email" inputmode="email" autocapitalize="off" autocorrect="off"
            spellcheck="false" data-of="email" value="${esc(o.client.email || '')}"></div>
      </div>
      ${klientPaskiHtml(o)}</div>

      <details class="card of-poz" data-ofpoz${!o.items.length || state.ofPozOtw ? ' open' : ''}>
        <summary class="card-head">${svg('list')}<span>Pozycje oferty</span><em>${t.count} poz. · ${zl(t.net)} netto</em>${svg('chevDown')}</summary>
        <div class="items" style="margin-top:10px">${items}</div>
        <div style="height:10px"></div>
        <button class="addbtn" data-additem style="--c:var(--flame)">${svg('plus')}Dodaj z katalogu</button>
      </details>

      ${checksBlock}

      <div class="card"><div class="card-head">${svg('money')}Podsumowanie</div><div class="fields">
        <div class="field"><label for="of-mar">Marża na materiałach</label>
          <input id="of-mar" type="number" inputmode="decimal" step="1" data-of="marginPct" value="${o.marginPct}">
          <span class="unit">%</span></div>
        <div class="field"><label for="of-vat">Stawka VAT</label>
          <select id="of-vat" data-of="vatRate">
            ${VAT_RATES.map(r => `<option value="${r.value}"${Number(o.vatRate) === r.value ? ' selected' : ''}>${esc(r.label)}</option>`).join('')}
          </select><span class="chev">${svg('chevDown')}</span></div>
      </div></div>

      <div class="rows">
        <div class="r"><span>Materiały netto</span><b>${zl(t.netMat)}</b></div>
        <div class="r"><span>Marża ${o.marginPct}% na materiałach</span><b>${zl(t.margin)}</b></div>
        <div class="r"><span>Robocizna netto</span><b>${zl(t.netRob)}</b></div>
        <div class="r"><span>Razem netto</span><b>${zl(t.net)}</b></div>
        <div class="r"><span>VAT ${Math.round(o.vatRate * 100)}%</span><b>${zl(t.vat)}</b></div>
        <div class="r tot"><span>Do zapłaty brutto</span><b>${zl(t.gross)}</b></div>
      </div>

      <div class="actions">
        <button class="jump" style="--c:var(--flame)" data-showdoc>${svg('eye')}Podgląd oferty</button>
        <button class="btn2" data-deloffer aria-label="Usuń ofertę">${svg('trash')}</button>
      </div>

      <div class="tip">${svg('spark')}<div>Katalog uczy się od Ciebie: pozycja wpisana ręcznie trafia do niego,
        gdy ma nazwę i cenę, a poprawiona cena podmienia tę w cenniku. Cały katalog poprawisz
        w <button class="cat-fix" data-opencat>Ustawieniach → Katalog cen</button></div></div>
    </div>`;
}

/* ============================================================
   EKRAN: DOKUMENT OFERTY
   ============================================================ */
/* Wiersze i kwoty dokumentu. Liczone raz i używane zarówno przez ofertę,
   jak i przez fakturę — inaczej faktura mogłaby opiewać na inną kwotę niż
   oferta, którą klient zatwierdził, i to o grosze, których nikt nie znajdzie.
   Kwoty zaokrąglamy do grosza na poziomie wiersza, żeby kolumna „wartość"
   zsumowana przez klienta dała dokładnie kwotę końcową. */
function docLines(o) {
  const t = offerTotals(o);
  const matMargin = t.netMat ? (1 + (Number(o.marginPct) || 0) / 100) : 1;
  const r2 = x => Math.round(x * 100) / 100;
  const lines = (o.items || []).map(it => {
    const unit = r2(it.cat === 'rob' ? it.price : it.price * matMargin);
    return { name: it.name, cat: it.cat, unit, qty: it.qty || 0, jm: it.unit, val: r2(unit * (it.qty || 0)) };
  });
  const mats = lines.filter(l => l.cat !== 'rob');
  const robs = lines.filter(l => l.cat === 'rob');
  const sumOf = arr => r2(arr.reduce((a, l) => a + l.val, 0));
  const docMat = sumOf(mats), docRob = sumOf(robs);
  const docNet = r2(docMat + docRob);
  const docVat = r2(docNet * (Number(o.vatRate) || 0));
  return { lines, mats, robs, docMat, docRob, docNet, docVat, docGross: r2(docNet + docVat) };
}

function renderOfferDoc() {
  const o = currentOffer();
  if (!o) { state.offerScreen = 'list';
 return renderOffersList(); }
  const st = state.settings || DEFAULT_SETTINGS;
  const D = docLines(o);
  const { mats, robs, docMat, docRob, docNet, docVat, docGross } = D;

  let lp = 0;
  const section = (title, arr) => arr.length ? `
    <tr class="sec"><td colspan="5">${title}</td></tr>
    ${arr.map(l => `<tr>
      <td class="n">${++lp}</td>
      <td>${esc(l.name)}</td>
      <td class="n">${fmt(l.qty, 2)} ${esc(l.jm)}</td>
      <td class="n">${zl(l.unit)}</td>
      <td class="n">${zl(l.val)}</td>
    </tr>`).join('')}` : '';
  const rows = section('Materiały', mats) + section('Robocizna', robs);

  return `<header class="hdr hdr--cat" style="--c:var(--flame)"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" id="backedit" aria-label="Wróć">${svg('back')}</button>
      <div><h1>Podgląd oferty</h1><p>Tak zobaczy ją klient</p></div></div></header>
    <div class="body">
      <div class="doc">
        <div class="doc-top">
          <div class="doc-brand">
            ${st.logo ? `<img class="doc-logo" src="${st.logo}" alt="">` : ''}
            <div>
              <h2>Oferta ${esc(o.number)}</h2>
              <div class="doc-firm">${esc(st.company || 'Uzupełnij dane firmy w Ustawieniach')}
                ${st.nip ? `<br>NIP ${esc(st.nip)}` : ''}
                ${st.address ? `<br>${esc(st.address)}` : ''}
                ${st.phone || st.email ? `<br>${esc([st.phone, st.email].filter(Boolean).join(' · '))}` : ''}
              </div>
            </div>
          </div>
          <div class="doc-meta">Data: ${plDate(o.date)}<br>Ważna ${st.validDays} dni</div>
        </div>
        <div class="doc-party">
          <b>Dla</b>
          ${esc(o.client.name || '—')}<br>
          ${esc(o.client.address || '')}${o.client.phone ? '<br>tel. ' + esc(o.client.phone) : ''}
        </div>
        <table>
          <thead><tr><th class="n">Lp</th><th>Nazwa</th><th class="n">Ilość</th><th class="n">Cena</th><th class="n">Wartość</th></tr></thead>
          <tbody>${rows || '<tr><td colspan="5">Brak pozycji</td></tr>'}</tbody>
        </table>
        <div class="doc-tot">
          ${docMat ? `<div class="tr"><span>Materiały netto</span><span>${zl(docMat)}</span></div>` : ''}
          ${docRob ? `<div class="tr"><span>Robocizna netto</span><span>${zl(docRob)}</span></div>` : ''}
          <div class="tr mid"><span>Razem netto</span><span>${zl(docNet)}</span></div>
          <div class="tr"><span>VAT ${Math.round(o.vatRate * 100)}%</span><span>${zl(docVat)}</span></div>
          <div class="tr big"><span>Do zapłaty</span><span>${zl(docGross)}</span></div>
        </div>
        ${o.notes ? `<div class="doc-note">${esc(o.notes)}</div>` : ''}
      </div>
      <button class="jump" style="--c:var(--flame)" data-pdf>${svg('doc')}Zapisz ofertę jako PDF</button>
      <button class="btn2" style="width:100%" data-mailoffer>${svg('mail')}Wyślij ofertę klientowi w PDF</button>
      <button class="jump" style="--c:var(--flame)" data-registersale>${svg('money')}Klient zaakceptował — zarejestruj sprzedaż</button>
      <button class="jump" style="--c:var(--flame)" data-makeinvoice>${svg('doc')}${
        o.invoice ? 'Otwórz fakturę ' + esc(o.invoice.number) : 'Wystaw fakturę do tej oferty'}</button>
      <div class="tip">${svg('spark')}<div>Klient dostaje gotowy plik PDF z Twoimi danymi — jako załącznik,
        nie jako tekst w wiadomości. Marża jest doliczona do cen materiałów, więc klient jej nie widzi osobno.</div></div>
    </div>`;
}


/* ============================================================
   FAKTURA
   ------------------------------------------------------------
   Ekran faktury pokazuje najpierw braki, potem pola do uzupełnienia,
   a na końcu gotowy dokument. Kolejność jest celowa: dopóki czegoś
   brakuje, nie ma sensu patrzeć na dokument, bo i tak nie wolno go wydać.
   ============================================================ */




/* Pobranie gotowych bajtów PDF w przeglądarce. */
function pobierzPdfWPrzegladarce(nazwa, bajty) {
  try {
    const url = URL.createObjectURL(new Blob([bajty], { type: 'application/pdf' }));
    const a = document.createElement('a');
    a.href = url; a.download = nazwa;
    document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
    return true;
  } catch (e) { return false; }
}

/* Dopisanie pozycji z kalkulatora do oferty. Pusta oferta oznacza
   „załóż nową" — tą samą drogą idzie i pierwsza pozycja w aplikacji,
   i świadomy wybór „Nowa oferta" z listy. */
function dodajPozycjeDoOferty(o, p) {
  let utworzona = false;
  if (!o) {
    o = blankOffer(state.offers, state.settings); state.offers.push(o); utworzona = true;
    // nowa oferta z projektu dostaje od razu klienta i adres
    if (p.klient) ['name', 'address', 'phone', 'email'].forEach(k => { if (p.klient[k]) o.client[k] = p.klient[k]; });
  }
  /* Kilka pozycji naraz (np. wszystkie grzejniki z kalkulatora) przychodzi
     jako p.lista — z cenami z cennika tam, gdzie dało się je dopasować. */
  const lista = p.lista || [p];
  lista.forEach(x => o.items.push({ name: x.name, unit: x.unit || 'szt', cat: x.cat || 'mat',
                 price: Number(x.price) || 0, tag: x.tag || null, katId: x.katId, qty: x.qty || 1 }));
  state.offerId = o.id;
  persist();
  renderOverlay();
  const bez = lista.filter(x => !(Number(x.price) > 0)).length;
  const co = lista.length === 1 ? 'pozycję' : lista.length + ' ' + odmiana(lista.length, 'pozycję', 'pozycje', 'pozycji');
  toast((utworzona ? `Nowa oferta ${o.number} — dodano ${co}.` : `Dodano ${co} do oferty ${o.number}.`)
    + (bez ? (lista.length === 1 ? ' Uzupełnij cenę.' : ` ${bez} z ceną do uzupełnienia.`) : ''), 'Pokaż');
}

/* Arkusz wyboru oferty. Pokazuje to samo, co lista ofert — klienta,
   datę, liczbę pozycji i kwotę — bo po samym numerze nikt nie pozna,
   która oferta jest która. */
function wyborOfertyHtml(p) {
  const wToku = state.offers.filter(o => !o.invoice);
  const wiersze = wToku.map(o => {
    const t = offerTotals(o);
    const teraz = o.id === state.offerId;
    return `<button class="ocard" data-addto="${o.id}" style="margin-bottom:8px;width:100%">
      <span class="ocard-n">${esc(String(o.number).split('/')[0])}</span>
      <span class="ocard-t">
        <strong>${esc(o.client.name || 'Oferta bez nazwy')}</strong>
        <span>${plDate(o.date)} · ${t.count} poz.${teraz ? ' · ostatnio otwarta' : ''}</span>
      </span>
      <span class="ocard-v"><b>${zl(t.gross)}</b><span>brutto</span></span>
    </button>`;
  }).join('');

  return `<div class="sheet" data-closewyb role="dialog" aria-label="Do której oferty dodać">
    <div class="sheet-in" data-stop>
      <div class="sheet-h">${svg('plus')}<strong>Do której oferty?</strong>
        <button class="item-x" data-closewyb aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        <p class="hint" style="margin:0 0 10px">Dodajesz: <b>${esc(p.name)}</b></p>
        ${wiersze}
        <button class="btn2" style="width:100%;margin-top:4px" data-addtonew>
          ${svg('plus')}Nowa oferta</button>
      </div>
    </div></div>`;
}

/* Zapis schematu gałęzi do PDF. Ta sama droga, co przy ofercie:
   na telefonie plik ląduje w Dokumentach i od razu otwiera się okno
   udostępniania, w przeglądarce po prostu się pobiera. */
function zapiszSchematPdf() {
  const d = state.schemat;
  if (!d) { toast('Nie ma czego zapisać.'); return; }

  let plik;
  try { plik = schematPdf(d); } catch (e) { plik = null; }
  if (!plik) { toast('Nie udało się przygotować rysunku.'); return; }

  const nazwa = schematNazwa(d);
  if (typeof naTelefonie === 'function' && naTelefonie()) {
    wyslijPdfZTelefonu(nazwa, pdfDoB64(plik), { okno: 'Wyślij ' + nazwa },
      w => toast(w.ok ? 'Zapisano ' + nazwa + ' w Dokumentach.' : w.powod));
    return;
  }
  toast(pobierzPdfWPrzegladarce(nazwa, plik)
    ? 'Pobrano ' + nazwa + '.'
    : 'Przeglądarka nie pozwoliła zapisać pliku.');
}

/* Zapis dokumentu do PDF.
   Plik składa sama aplikacja — nie przechodzimy przez okno drukowania
   systemu, bo tamtędy dokument wychodzi dopiero po kilku pytaniach
   i nie wiadomo, gdzie ląduje. Tutaj powstaje od razu, z tekstem, który
   da się zaznaczyć i przeszukać, i z polskimi ogonkami. */
function zapiszPdf() {
  const o = currentOffer();
  if (!o) { toast('Nie ma czego zapisać — otwórz dokument.'); return; }
  const faktura = state.offerScreen === 'invoice' && !!o.invoice;

  let plik;
  try { plik = pdfDokument(o, faktura); } catch (e) {
    toast('Nie udało się przygotować pliku PDF.');
    return;
  }
  const nazwa = pdfNazwa(o, faktura);

  /* Na telefonie zapisujemy w Dokumentach i od razu proponujemy wysłanie —
     bez tego użytkownik musiałby szukać pliku w menedżerze plików. */
  if (typeof naTelefonie === 'function' && naTelefonie()) {
    wyslijPdfZTelefonu(nazwa, pdfDoB64(plik), { okno: 'Wyślij ' + nazwa },
      w => toast(w.ok ? 'Zapisano ' + nazwa + ' w Dokumentach.' : w.powod));
    return;
  }
  toast(pobierzPdfWPrzegladarce(nazwa, plik)
    ? 'Pobrano ' + nazwa + '.'
    : 'Przeglądarka nie pozwoliła zapisać pliku.');
}

/* Przycisk pobrania danych z wykazu. Pojawia się dopiero, gdy NIP ma
   dziesięć cyfr — wcześniej i tak nie byłoby czego szukać. */
function gusBtnHtml(o) {
  const n = String(o.client.nip || '').replace(/[^0-9]/g, '');
  if (n.length !== 10) return '';
  return `<button class="btn2" style="width:100%" data-gus>${svg('search')}Pobierz dane z wykazu VAT</button>`;
}

/* Pobranie danych firmy po NIP-ie z wykazu podatników VAT Ministerstwa
   Finansów. API jest publiczne i nie wymaga klucza, ale wymaga internetu —
   aplikacja ma działać też bez niego, więc to udogodnienie, nie podstawa.

   Uwaga na nazwy pól: dla spółek adres siedzi w workingAddress,
   dla jednoosobowych działalności bywa w residenceAddress. Bierzemy
   pierwszy niepusty. */
function pobierzZWykazu(nip, gotowe) {
  const n = String(nip || '').replace(/[^0-9]/g, '');
  if (!nipValid(n)) { gotowe({ err: 'Ten NIP ma błędną sumę kontrolną — sprawdź, czy nie ma literówki.' }); return; }
  const url = 'https://wl-api.mf.gov.pl/api/search/nip/' + n + '?date=' + todayISO();
  let skonczone = false;
  const koniec = w => { if (!skonczone) { skonczone = true; gotowe(w); } };
  setTimeout(() => koniec({ err: 'Wykaz nie odpowiedział w 10 sekund. Wpisz dane ręcznie.' }), 10000);

  try {
    fetch(url, { headers: { Accept: 'application/json' } })
      .then(r => r.ok ? r.json() : Promise.reject(new Error('HTTP ' + r.status)))
      .then(j => {
        const s = j && j.result && j.result.subject;
        if (!s) { koniec({ err: 'Nie ma takiego NIP-u w wykazie podatników VAT.' }); return; }
        koniec({
          name: s.name || '',
          addr: s.workingAddress || s.residenceAddress || '',
          status: s.statusVat || '',
          regon: s.regon || '',
        });
      })
      .catch(e => koniec({ err: 'Nie udało się połączyć z wykazem (' + e.message + '). Sprawdź internet albo wpisz dane ręcznie.' }));
  } catch (e) {
    koniec({ err: 'Pobieranie danych nie jest tu dostępne — wpisz dane ręcznie.' });
  }
}

/* Zebranie danych faktury w postaci, jakiej oczekuje generator FA(3).
   Stawka podatku: przy zwolnieniu z VAT wszystkie pozycje idą jako „zw",
   w przeciwnym razie stawka z oferty. */
function ksefPayload(o, st) {
  const D = docLines(o);
  const zwolniony = st.vatStatus === 'zwolniony';
  const f = o.invoice;
  return {
    seller: { nip: st.nip, name: st.company, addr1: st.address },
    buyer: {
      nip: o.client.type === 'firma' ? o.client.nip : '',
      name: o.client.name,
      addr1: o.client.address,
    },
    inv: {
      number: f.number, issue: f.issue, sale: f.sale,
      method: f.method, due: addDaysISO(f.issue, f.dueDays),
      bank: st.bank,
      /* Zapłata idzie do pliku tylko z datą — bez niej generator ją pomija,
         bo schemat wiąże oba pola w parę. */
      paid: !!f.paid, paidAt: f.paid ? (f.paidAt || '') : '',
    },
    lines: D.lines,
    stawka: zwolniony ? 'zw' : String(Math.round((Number(o.vatRate) || 0) * 100)),
    zwPodstawa: st.zwPodstawa,
  };
}

/* Zapis pliku. Zwykłe pobranie (Blob + link z atrybutem download) działa
   w aplikacji na telefonie i w pliku HTML otwartym z dysku — bez internetu
   i bez żadnej biblioteki.

   W podglądzie osadzonym na stronie przeglądarka blokuje takie pobranie,
   bo strona działa w ramce bez uprawnienia do zapisu. Jest tam osobna
   droga — zapis przez gospodarza strony — więc próbujemy najpierw jej,
   a dopiero potem zwykłego pobrania. Wynik oddajemy przez funkcję zwrotną,
   bo ta pierwsza droga pyta użytkownika o zgodę i trwa. */
function pobierzPlik(nazwa, tresc, typ, gotowe) {
  const koniec = w => { if (gotowe) gotowe(w); };

  const zwykle = () => {
    try {
      const blob = new Blob([tresc], { type: (typ || 'text/plain') + ';charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = nazwa;
      document.body.appendChild(a); a.click();
      setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
      koniec({ ok: true });
    } catch (e) { koniec({ ok: false, powod: 'Przeglądarka nie pozwoliła zapisać pliku.' }); }
  };

  /* Na telefonie plik zapisujemy w Dokumentach i od razu proponujemy
     wysłanie go klientowi — to jest właściwa droga, nie „pobieranie". */
  if (typeof naTelefonie === 'function' && naTelefonie()) {
    zapiszNaTelefonie(nazwa, tresc, typ, w => koniec(w.ok
      ? { ok: true, gdzie: w.gdzie }
      : { ok: false, powod: w.powod }));
    return;
  }

  const host = (typeof window !== 'undefined') && window.claude && window.claude.use;
  if (!host) { zwykle(); return; }

  Promise.resolve(window.claude.use('downloads')).then(d => {
    if (!d) { zwykle(); return; }
    return d.save({ filename: nazwa, data: tresc })
      .then(() => koniec({ ok: true }))
      .catch(err => {
        const kod = err && err.code;
        if (kod === 'declined') { koniec({ ok: false, powod: 'Zapis anulowany.' }); return; }
        if (kod === 'rejected_extension' || kod === 'extension_not_enabled') {
          koniec({ ok: false, powod: 'W podglądzie w przeglądarce nie da się zapisać pliku XML — '
            + 'skopiuj treść z okna albo użyj aplikacji na telefonie.' });
          return;
        }
        zwykle();
      });
  }).catch(() => zwykle());
}


/* Dwa bloki ekranu faktury, które zmieniają się w trakcie wpisywania danych:
   lista braków i informacja o KSeF. Trzymamy je w osobnych funkcjach, bo
   odświeżamy je punktowo — przerysowanie całego ekranu przy każdym znaku
   wyrzucałoby kursor z pola. */
function invIssuesHtml(o, st) {
  const issues = invoiceIssues(o, st);
  if (!issues.length) return '';
  const blok = issues.filter(i => i.level === 'blok');
  return `<div class="tip ${blok.length ? 'tip--warn' : ''}">${svg(blok.length ? 'shield' : 'spark')}<div>
      <b>${blok.length ? 'Zanim wystawisz fakturę' : 'Do sprawdzenia'}</b>
      <ul style="margin:6px 0 0;padding-left:18px">
        ${issues.map(i => `<li>${esc(i.text)}</li>`).join('')}
      </ul></div></div>`;
}

/* Plik XML w strukturze FA(3) robimy dla każdej faktury — również dla osoby
   prywatnej. Obowiązek i możliwość to dwie różne rzeczy: faktury konsumenckie
   są wyłączone z obowiązku KSeF (art. 106ga ust. 2 ustawy o VAT), ale nic nie
   stoi na przeszkodzie, żeby wystawić je tą samą drogą albo po prostu trzymać
   w tym samym formacie co resztę. Schemat to przewiduje — zamiast NIP-u
   nabywcy wchodzi znacznik BrakID. Dlatego przycisk jest zawsze, a zmienia
   się tylko zdanie obok: przy firmie „musi", przy osobie prywatnej „można". */
function invKsefHtml(o, st) {
  const ksef = ksefApplies(o);
  const blok = invoiceIssues(o, st).filter(i => i.level === 'blok');
  const info = `<div class="tip">${svg(ksef ? 'shield' : 'spark')}<div>${ksef
    ? '<b>Ta faktura podlega KSeF.</b> Nabywca jest firmą, więc faktura musi trafić do Krajowego Systemu e-Faktur. Zapisz plik XML i wgraj go w Aplikacji Podatnika KSeF — plik jest w strukturze FA(3) i nie wymaga żadnych certyfikatów w telefonie.'
    : '<b>Ta faktura nie musi iść do KSeF.</b> Nabywca to osoba prywatna, a faktury konsumenckie są wyłączone z obowiązku (art. 106ga ust. 2 ustawy o VAT). Plik XML i tak możesz zapisać — w strukturze FA(3), z zaznaczonym brakiem NIP-u nabywcy, tak jak przewiduje schemat.'}</div></div>`;
  return info + (blok.length
    ? `<div class="tip tip--warn">${svg('shield')}<div>Plik XML będzie do zapisania, kiedy uzupełnisz braki wypisane wyżej — schemat odrzuca fakturę bez nazwy i adresu nabywcy.</div></div>`
    : `<button class="jump" style="--c:var(--flame)" data-ksefxml>${svg('doc')}Zapisz plik XML do KSeF</button>`);
}

/* Odświeżenie obu bloków w miejscu, bez ruszania reszty ekranu. */
function refreshInvoiceBlocks() {
  const o = currentOffer();
  if (!o || state.tab !== 'offers' || state.offerScreen !== 'invoice') return;
  const st = state.settings || DEFAULT_SETTINGS;
  const a = document.getElementById('invissues');
  const b = document.getElementById('invksef');
  if (a) a.innerHTML = invIssuesHtml(o, st);
  if (b) b.innerHTML = invKsefHtml(o, st);
}

function renderInvoice() {
  const o = currentOffer();
  if (!o) { state.offerScreen = 'list';
 return renderOffersList(); }
  if (!o.invoice) { o.invoice = makeInvoice(o, state.offers, state.settings); persist(); }
  const st = state.settings || DEFAULT_SETTINGS;
  const f = o.invoice;
  const D = docLines(o);
  const zwolniony = st.vatStatus === 'zwolniony';
  const vatPct = Math.round((Number(o.vatRate) || 0) * 100);
  const due = addDaysISO(f.issue, f.dueDays);

  const issueBlock = invIssuesHtml(o, st);
  const ksefBlock = invKsefHtml(o, st);
  let lp = 0;
  const section = (title, arr) => arr.length ? `
    <tr class="sec"><td colspan="6">${title}</td></tr>
    ${arr.map(l => `<tr>
      <td class="n">${++lp}</td>
      <td>${esc(l.name)}</td>
      <td class="n">${fmt(l.qty, 2)} ${esc(l.jm)}</td>
      <td class="n">${zl(l.unit)}</td>
      <td class="n">${zwolniony ? 'zw' : vatPct + '%'}</td>
      <td class="n">${zl(l.val)}</td>
    </tr>`).join('')}` : '';

  return `<header class="hdr hdr--cat" style="--c:var(--flame)"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" id="backdoc" aria-label="Wróć">${svg('back')}</button>
      <div><h1>Faktura ${esc(f.number)}</h1><p>Wystawiona na podstawie oferty ${esc(o.number)}</p></div></div></header>
    <div class="body">
      <!-- Pozycje i ceny mieszkają w ofercie, nie na fakturze: faktura pokazuje
           to samo wyliczenie w innej formie. Kto chce poprawić cenę albo dopisać
           materiał, musi więc wrócić do oferty — i to zdanie mówi mu, gdzie.
           Numer faktury zostaje przy tym bez zmian, żeby numeracja była ciągła;
           dziury w niej tłumaczy się potem księgowej. -->
      <button class="wroc" data-doedycji>${svg('back')}
        <span><strong>Cofnij, aby poprawić</strong>
          <span>Pozycje, ceny i dane klienta zmienia się w ofercie ${esc(o.number)}.
            Numer faktury zostanie ten sam.</span></span></button>
      <div id="invissues">${issueBlock}</div>
      <div class="card"><div class="card-head">${svg('doc')}Dane faktury</div><div class="fields">
        <div class="field"><label for="in-num">Numer faktury</label>
          <input id="in-num" type="text" data-inv="number" value="${esc(f.number)}"></div>
        <div class="row2">
          <div class="field"><label for="in-issue">Data wystawienia</label>
            <input id="in-issue" type="date" data-inv="issue" value="${esc(f.issue)}"></div>
          <div class="field"><label for="in-sale">Data sprzedaży</label>
            <input id="in-sale" type="date" data-inv="sale" value="${esc(f.sale)}"></div>
        </div>
        <div class="row2">
          <div class="field"><label for="in-due">Termin płatności</label>
            <input id="in-due" type="number" inputmode="numeric" step="1" data-inv="dueDays" value="${f.dueDays}">
            <span class="unit">dni</span></div>
          <div class="field"><label for="in-met">Sposób płatności</label>
            <select id="in-met" data-inv="method">
              ${PAY_METHODS.map(m => `<option value="${m}"${m === f.method ? ' selected' : ''}>${m}</option>`).join('')}
            </select><span class="chev">${svg('chevDown')}</span></div>
        </div>
      </div></div>

      <div class="card"><div class="card-head">${svg('home')}Nabywca</div><div class="fields">
        <div class="seg" role="group">
          <button type="button" data-ctype="osoba" aria-pressed="${o.client.type !== 'firma'}">Osoba prywatna</button>
          <button type="button" data-ctype="firma" aria-pressed="${o.client.type === 'firma'}">Firma</button>
        </div>
        <div class="field"><label for="in-cn">Nazwa / imię i nazwisko</label>
          <input id="in-cn" type="text" autocapitalize="words" autocomplete="name" data-of="name" value="${esc(o.client.name)}"></div>
        <div class="field"><label for="in-ca">Adres</label>
          <input id="in-ca" type="text" autocapitalize="words" autocomplete="street-address" data-of="address" value="${esc(o.client.address)}"></div>
        <div class="row2">
          <div class="field"><label for="in-ctel">Telefon</label>
            <input id="in-ctel" type="text" inputmode="tel" data-of="phone" value="${esc(o.client.phone || '')}"></div>
          <div class="field"><label for="in-cmail">E-mail</label>
            <input id="in-cmail" type="email" inputmode="email" autocapitalize="off" autocorrect="off"
              spellcheck="false" data-of="email" value="${esc(o.client.email || '')}"></div>
        </div>
        ${o.client.type === 'firma' ? `<div class="field"><label for="in-cnip">NIP nabywcy</label>
          <input id="in-cnip" type="text" inputmode="numeric" data-of="nip" value="${esc(o.client.nip || '')}"></div>
        <div id="gusbox">${gusBtnHtml(o)}</div>` : ''}
      </div>
      ${klientPaskiHtml(o)}</div>

      <div class="card"><div class="card-head">${svg('doc')}Stopka faktury</div><div class="fields">
        <div class="mini grow"><label for="in-foot">Tekst pod tabelą</label>
          <textarea id="in-foot" rows="2" autocapitalize="sentences" data-inv="footer" placeholder="np. podziękowanie, warunki gwarancji, numer zlecenia">${esc(f.footer || '')}</textarea></div>
      </div></div>

      <div class="card"><label class="chk">
        <input type="checkbox" data-paid${f.paid ? ' checked' : ''}>
        <span><b>Faktura zapłacona</b><br>
          Widać to na liście faktur i w zestawieniu dla księgowej. W pliku XML
          zapłata wchodzi razem z datą — schemat KSeF wymaga obu naraz.</span>
      </label>
      ${f.paid ? `<div class="field" style="margin-top:12px"><label for="in-paidat">Data zapłaty</label>
        <input id="in-paidat" type="date" data-inv="paidAt" value="${esc(f.paidAt || '')}"></div>` : ''}
      </div>

      <button class="jump" style="--c:var(--flame)" data-pdf>${svg('doc')}Zapisz fakturę jako PDF</button>
      <button class="btn2" style="width:100%" data-mailinv>${svg('mail')}Wyślij fakturę klientowi w PDF</button>

      <div id="invksef">${ksefBlock}</div>

      <div class="doc">
        <div class="doc-top">
          <div class="doc-brand">
            ${st.logo ? `<img class="doc-logo" src="${st.logo}" alt="">` : ''}
            <div>
              <h2>Faktura ${esc(f.number)}</h2>
              <div class="doc-firm">${esc(st.company || 'Uzupełnij dane firmy w Ustawieniach')}
                ${st.nip ? `<br>NIP ${esc(st.nip)}` : ''}
                ${st.address ? `<br>${esc(st.address)}` : ''}
                ${st.bank ? `<br>Konto: ${esc(st.bank)}` : ''}
              </div>
            </div>
          </div>
          <div class="doc-meta">Wystawiono: ${plDate(f.issue)}<br>Sprzedaż: ${plDate(f.sale)}<br>Termin: ${plDate(due)}</div>
        </div>
        <div class="doc-party">
          <b>Nabywca</b>
          ${esc(o.client.name || '—')}<br>
          ${esc(o.client.address || '')}${o.client.type === 'firma' && o.client.nip ? '<br>NIP ' + esc(o.client.nip) : ''}
        </div>
        <table>
          <thead><tr><th class="n">Lp</th><th>Nazwa</th><th class="n">Ilość</th><th class="n">Cena</th><th class="n">VAT</th><th class="n">Wartość</th></tr></thead>
          <tbody>${section('Materiały', D.mats) + section('Robocizna', D.robs) || '<tr><td colspan="6">Brak pozycji</td></tr>'}</tbody>
        </table>
        <div class="doc-tot">
          <div class="tr mid"><span>Razem netto</span><span>${zl(D.docNet)}</span></div>
          <div class="tr"><span>${zwolniony ? 'VAT — zwolnienie' : 'VAT ' + vatPct + '%'}</span><span>${zwolniony ? '—' : zl(D.docVat)}</span></div>
          <div class="tr big"><span>Do zapłaty</span><span>${zl(zwolniony ? D.docNet : D.docGross)}</span></div>
        </div>
        <div class="doc-note">Sposób płatności: ${esc(f.method)} · termin ${plDate(due)}
          ${zwolniony ? '<br>Zwolnienie z VAT: ' + esc(st.zwPodstawa) : ''}
          ${st.bank && f.method === 'przelew' ? '<br>Numer konta: ' + esc(st.bank) : ''}</div>
        <div id="docfoot">${f.footer ? `<div class="doc-note">${esc(f.footer).replace(/\n/g, '<br>')}</div>` : ''}</div>
      </div>

      <div class="tip">${svg('spark')}<div>Faktura bierze pozycje i kwoty wprost z oferty — te same wiersze, ta sama suma co do grosza. Zmiana w ofercie od razu przechodzi na fakturę, dopóki jej nie wyślesz.</div></div>
    </div>`;
}


/* ============================================================
   KATALOG BUDERUS — nowy ekran oparty na osobnej warstwie danych
   ============================================================ */
state.buderusQuery = state.buderusQuery || '';
state.buderusEditId = state.buderusEditId || null;
state.buderusPendingProduct = state.buderusPendingProduct || null;
state.buderusConfigSelection = state.buderusConfigSelection || {};

function buderusCategoryLabel(key) {
  const labels = {
    kociol: 'Kotły', zasobnik: 'Zasobniki CWU', regulator: 'Regulatory',
    modul: 'Moduły', czujnik: 'Czujniki', hydraulika: 'Hydraulika',
    komin: 'Systemy kominowe', akcesorium: 'Akcesoria',
    czesc_zamienna: 'Części zamienne', inne: 'Pozostałe'
  };
  return labels[key] || 'Pozostałe';
}
function buderusMoney(value, vat) {
  if (value == null || value === '') return '—';
  return zl(value) + (vat != null ? ' netto' : '');
}
function buderusListHtml() {
  const api = window.BuderusCatalog;
  if (!api) return '<p class="empty">Nie załadowano modułu katalogu Buderus.</p>';
  const products = api.list({ query: state.buderusQuery, activeOnly: false });
  if (!products.length) return '<p class="empty">Nie ma jeszcze produktów Buderus. Dodaj pierwszy produkt albo zaimportuj katalog.</p>';
  return products.map(p => {
    const sale = p.prices && p.prices.saleNet;
    const purchase = p.prices && p.prices.purchaseNet;
    const vat = p.prices && p.prices.vatRate;
    return `<article class="bud-card">
      <div class="bud-card-main">
        <div class="bud-card-top"><span class="tagmini">${esc(buderusCategoryLabel(p.category))}</span>
          <span class="bud-sku">${esc(p.sku)}</span></div>
        <strong>${esc(p.name)}</strong>
        <small>${esc(p.description || (p.source === 'official' ? 'Dane producenta' : p.source === 'import' ? 'Import danych' : 'Wpis własny'))}</small>
        <div class="bud-prices">
          <span>Zakup: <b>${purchase == null ? 'nie ustawiono' : zl(purchase) + ' netto'}</b></span>
          <span>Sprzedaż: <b>${sale == null ? 'nie ustawiono' : zl(sale) + ' netto'}</b></span>
          <span>Brutto sprzedaży: <b>${sale == null ? '—' : zl(api.gross(sale, vat))}</b></span>
        </div>
        <small class="bud-source">Źródło: ${esc(p.source || 'manual')}${p.sourceDate ? ' · ' + esc(p.sourceDate) : ''}${p.active === false ? ' · nieaktywny' : ''}</small>
      </div>
      <div class="bud-actions">
        <button class="btn2" data-budedit="${esc(p.id)}">Edytuj</button>
        <button class="btn2" data-budadd="${esc(p.id)}">Do oferty</button>
      </div>
    </article>`;
  }).join('');
}
function buderusFormHtml(product) {
  const p = product || {
    sku: '', name: '', category: 'kociol', description: '', source: 'manual',
    sourceReference: '', sourceDate: '',
    prices: { catalogNet: '', purchaseNet: '', purchaseDiscountPct: '', saleNet: '', vatRate: 0.23 },
    active: true
  };
  const pr = p.prices || {};
  const opts = window.BuderusCatalog.categories.map(k =>
    `<option value="${k}" ${p.category === k ? 'selected' : ''}>${esc(buderusCategoryLabel(k))}</option>`
  ).join('');
  return `<section class="bud-form">
    <div class="bud-form-head"><h2>${product ? 'Edytuj produkt' : 'Nowy produkt Buderus'}</h2>
      <button class="btn2" data-budback>Wróć do katalogu</button></div>
    <label>Symbol katalogowy *<input data-budfield="sku" maxlength="80" value="${esc(p.sku || '')}" placeholder="np. symbol z etykiety producenta"></label>
    <label>Nazwa produktu *<input data-budfield="name" maxlength="180" value="${esc(p.name || '')}" placeholder="Nazwa urządzenia lub akcesorium"></label>
    <label>Kategoria<select data-budfield="category">${opts}</select></label>
    <label>Opis<textarea data-budfield="description" rows="3" maxlength="2000" placeholder="Opis i podstawowe informacje">${esc(p.description || '')}</textarea></label>
    <div class="bud-form-grid">
      <label>Cena katalogowa netto<input data-budfield="catalogNet" type="number" min="0" step="0.01" value="${pr.catalogNet == null ? '' : esc(pr.catalogNet)}"></label>
      <label>Cena zakupu netto<input data-budfield="purchaseNet" type="number" min="0" step="0.01" value="${pr.purchaseNet == null ? '' : esc(pr.purchaseNet)}"></label>
      <label>Rabat zakupowy %<input data-budfield="purchaseDiscountPct" type="number" min="0" max="100" step="0.01" value="${pr.purchaseDiscountPct == null ? '' : esc(pr.purchaseDiscountPct)}"></label>
      <label>Cena sprzedaży netto<input data-budfield="saleNet" type="number" min="0" step="0.01" value="${pr.saleNet == null ? '' : esc(pr.saleNet)}"></label>
      <label>VAT (np. 0,23)<input data-budfield="vatRate" type="number" min="0" max="1" step="0.01" value="${pr.vatRate == null ? 0.23 : esc(pr.vatRate)}"></label>
    </div>
    <label>Źródło danych<select data-budfield="source">
      <option value="manual" ${p.source === 'manual' ? 'selected' : ''}>Wpis własny</option>
      <option value="official" ${p.source === 'official' ? 'selected' : ''}>Dane producenta</option>
      <option value="import" ${p.source === 'import' ? 'selected' : ''}>Import</option>
    </select></label>
    <label>Źródło / link / numer dokumentu<input data-budfield="sourceReference" maxlength="500" value="${esc(p.sourceReference || '')}" placeholder="Skąd pochodzą dane"></label>
    <label>Data danych katalogowych<input data-budfield="sourceDate" type="date" value="${esc(p.sourceDate || '')}"></label>
    <label class="bud-check"><input data-budfield="active" type="checkbox" ${p.active !== false ? 'checked' : ''}> Produkt aktywny</label>
    <div class="bud-form-actions">
      <button class="jump" data-budsave>${svg('check')}Zapisz produkt</button>
      ${product ? `<button class="btn2" data-buddelete="${esc(product.id)}">Usuń produkt</button>` : ''}
    </div>
    <p class="tip">${svg('alert')}<span>Nie wprowadzamy przykładowych cen ani niepotwierdzonej kompatybilności. Ceny zakupu i marża pozostają danymi wewnętrznymi.</span></p>
  </section>`;
}
function buderusConfigHtml() {
  const api = window.BuderusCatalog;
  const groups = [
    ['kociol', 'Kocioł'], ['zasobnik', 'Zasobnik CWU'], ['regulator', 'Regulator'],
    ['modul', 'Moduł'], ['czujnik', 'Czujnik'], ['hydraulika', 'Hydraulika'],
    ['komin', 'System kominowy'], ['akcesorium', 'Akcesoria']
  ];
  const all = api.list({ activeOnly: true });
  const selected = groups.map(([key, label]) => {
    const products = all.filter(p => p.category === key);
    const current = state.buderusConfigSelection[key] || '';
    return `<label class="bud-config-field">${esc(label)}<select data-budconfigcategory="${key}">
      <option value="">— Nie wybieram —</option>
      ${products.map(p => `<option value="${esc(p.id)}" ${current === p.id ? 'selected' : ''}>${esc(p.name)} · ${esc(p.sku)}</option>`).join('')}
    </select>${products.length ? '' : '<small>Brak produktów w tej kategorii — dodaj je do katalogu.</small>'}</label>`;
  }).join('');
  const chosen = groups.map(([key]) => state.buderusConfigSelection[key]).filter(Boolean)
    .map(id => api.get(id)).filter(Boolean);
  const priced = chosen.filter(p => p.prices && p.prices.saleNet != null);
  const totalNet = priced.reduce((sum, p) => sum + Number(p.prices.saleNet), 0);
  const vatRates = [...new Set(chosen.map(p => Number(p.prices && p.prices.vatRate)).filter(Number.isFinite))];
  const vatConsistent = vatRates.length <= 1;
  const totalGross = vatConsistent && priced.length === chosen.length && chosen.length
    ? api.gross(totalNet, vatRates[0]) : null;
  return `<header class="hdr"><div class="hdr-row"><div class="hdr-ico">${svg('layers')}</div><div><h1>Konfigurator zestawu</h1><p>Dobierz elementy instalacji Buderus</p></div></div></header>
    <div class="body"><button class="btn2" data-budconfigback>Wróć do katalogu</button>
      <p class="tip">${svg('info')}<span>Wybieraj wyłącznie produkty dodane do katalogu. Konfigurator nie potwierdza automatycznie kompatybilności — przed sprzedażą sprawdź dokumentację producenta.</span></p>
      <div class="bud-config-grid">${selected}</div>
      <div class="bud-config-summary"><h3>Wybrany zestaw (${chosen.length})</h3>
        ${chosen.length ? chosen.map(p => `<div class="bud-config-row"><span><b>${esc(p.name)}</b><small>${esc(p.sku)}</small></span><span>${p.prices.saleNet == null ? 'brak ceny' : zl(p.prices.saleNet) + ' netto'}</span></div>`).join('') : '<p class="empty">Wybierz produkty powyżej.</p>'}
        <div class="bud-config-total"><span>Razem netto (wycenione pozycje)</span><b>${zl(totalNet)}</b></div>
        <div class="bud-config-total"><span>Razem brutto</span><b>${totalGross == null ? '—' : zl(totalGross)}</b></div>
        ${!vatConsistent ? '<p class="bud-config-warning">Wybrane produkty mają różne stawki VAT. Nie można jeszcze utworzyć z nich jednej oferty.</p>' : ''}
        ${priced.length !== chosen.length ? '<p class="bud-config-warning">Uzupełnij ceny sprzedaży wszystkich wybranych produktów, aby utworzyć ofertę.</p>' : ''}
      </div>
      <div class="bud-form-actions"><button class="jump" data-budconfigoffer ${!chosen.length || priced.length !== chosen.length || !vatConsistent ? 'disabled' : ''}>${svg('doc')}Utwórz ofertę z zestawu</button><button class="btn2" data-budconfigclear>Wyczyść wybór</button></div>
    </div>`;
}

function renderBuderusCatalog() {
  if (state.buderusConfigOpen) return buderusConfigHtml();
  if (state.buderusPendingProduct) {
    const p = state.buderusPendingProduct;
    const offers = state.offers.filter(o => !o.invoice);
    return `<header class="hdr"><div class="hdr-row"><div class="hdr-ico">${svg('doc')}</div><div><h1>Dodaj do oferty</h1><p>${esc(p.name)} · ${esc(p.sku)}</p></div></div></header>
      <div class="body"><button class="btn2" data-budcancel>Wróć do katalogu</button>
      <div class="sechead">Wybierz ofertę</div>
      ${offers.map(o => `<button class="btn2 bud-choice" data-budtarget="${esc(o.id)}">${esc(o.number)} · ${esc(o.client && o.client.name || 'bez klienta')}</button>`).join('')}
      <button class="jump" data-budnewoffer>${svg('plus')}Utwórz nową ofertę</button></div>`;
  }
  if (state.buderusEditId !== null) {
    const product = state.buderusEditId === '__new__' ? null : window.BuderusCatalog.get(state.buderusEditId);
    return `<header class="hdr"><div class="hdr-row"><div class="hdr-ico">${svg('therm')}</div><div><h1>Katalog Buderus</h1><p>Produkt i dane handlowe</p></div></div></header><div class="body">${buderusFormHtml(product)}</div>`;
  }
  const products = window.BuderusCatalog.list({ activeOnly: false });
  return `<header class="hdr"><div class="hdr-row"><div class="hdr-ico">${svg('therm')}</div><div><h1>Katalog Buderus</h1><p>${products.length} ${odmiana(products.length, 'produkt', 'produkty', 'produktów')} · własne ceny i dane katalogowe</p></div></div></header>
    <div class="body">
      <button class="btn2" data-budback>${svg('arrow')}Powrót do Biura</button>
      <button class="jump" data-budconfigure>${svg('layers')}Konfigurator zestawu Buderus</button>
      <button class="btn2" data-budnew>${svg('plus')}Dodaj produkt Buderus</button>
      <div class="bud-import-export"><button class="btn2" data-budexport>Eksportuj JSON</button><label class="btn2 bud-import-label">Importuj JSON<input type="file" data-budimport accept=".json,application/json" hidden></label></div>
      <div class="bud-import-export"><button class="btn2" data-budcsvexport>Eksportuj CSV (Excel)</button><label class="btn2 bud-import-label">Importuj CSV<input type="file" data-budcsvimport accept=".csv,text/csv" hidden></label></div>
      <label class="bud-search">Szukaj po nazwie lub symbolu<input data-budq value="${esc(state.buderusQuery)}" placeholder="np. symbol kotła, zasobnik, regulator"></label>
      <div class="bud-list" id="bud-list">${buderusListHtml()}</div>
      <div class="bud-official-links">
        <a href="https://www.buderus.com/pl/pl/wsparcie/cennik/" target="_blank" rel="noopener">Oficjalny cennik Buderus</a>
        <a href="https://buderus-pl.boschhc-documents.com/td/" target="_blank" rel="noopener">Dokumentacja techniczna produktów</a>
      </div>
      <div class="tip">${svg('info')}<span>Katalog jest na razie pusty. Cenniki producenta są przeznaczone dla Partnerów Handlowych i mogą się zmieniać. Wprowadzaj datę oraz źródło danych; ceny własnego zakupu uzupełniaj oddzielnie. Kompatybilność akcesoriów musi być potwierdzona dokumentacją.</span></div>
    </div>`;
}


function saveSalesRecords() {
  localStorage.setItem('ai_sales_register_v1', JSON.stringify(state.salesRecords));
}
function salesPaidTotal(sale) {
  return (Number(sale && sale.paid) || 0) +
    (Array.isArray(sale && sale.payments) ? sale.payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0) : 0);
}
function salesRemaining(sale) {
  return Math.max(0, (Number(sale && sale.gross) || 0) - salesPaidTotal(sale));
}
function salesCostSummary(sale) {
  const moveIds = Array.isArray(sale.stockIssueMoves) ? sale.stockIssueMoves : [];
  const moves = moveIds.map(id => state.inventoryMoves.find(m => m.id === id)).filter(Boolean);
  const materialCost = moves.reduce((sum,m) => sum + (Number(m.purchaseUnitNet) || 0) * (Number(m.qty) || 0), 0);
  const laborCost = Number(sale.laborCostNet) || 0;
  const revenueNet = Number(sale.revenueNet) || 0;
  const hasRevenue = Number.isFinite(revenueNet) && revenueNet > 0;
  const hasStockLines = Array.isArray(sale.lines) && sale.lines.length > 0;
  const fullyIssued = hasStockLines && sale.stockIssued === true && moves.length > 0;
  const margin = revenueNet - materialCost - laborCost;
  return { materialCost, laborCost, revenueNet, margin, complete: hasRevenue && fullyIssued };
}

function renderSalesRegister() {
  const editing = state.salesEditId ? state.salesRecords.find(r => r.id === state.salesEditId) : null;
  const r = editing || {};
  if (state.salesScreen === 'form') {
    return `<header class="hdr"><div class="hdr-row"><div class="hdr-ico">${svg('money')}</div><div><h1>${editing ? 'Edytuj sprzedaż' : 'Nowa sprzedaż'}</h1><p>Rejestr urządzeń, dostaw i rozliczeń</p></div></div></header>
      <div class="body sales-form">
        <button class="btn2" data-salesback>Wróć do rejestru</button>
        <label>Klient / nabywca *<input data-salesfield="client" value="${esc(r.client || '')}" placeholder="Imię i nazwisko lub firma"></label>
        <label>Miejsce montażu / adres<input data-salesfield="site" value="${esc(r.site || '')}" placeholder="Adres inwestycji"></label>
        <label>Telefon / kontakt<input data-salesfield="contact" value="${esc(r.contact || '')}" placeholder="Telefon lub e-mail"></label>
        <label>Sprzedane urządzenia / towary *<textarea data-salesfield="items" rows="3" placeholder="Nazwa, symbol, ilość">${esc(r.items || '')}</textarea></label>
        <div class="sales-grid">
          <label>Wartość brutto (zł)<input data-salesfield="gross" type="number" min="0" step="0.01" value="${r.gross ?? ''}"></label>
          <label>Przychód netto (zł)<input data-salesfield="revenueNet" type="number" min="0" step="0.01" value="${r.revenueNet ?? ''}" placeholder="Kwota netto ze sprzedaży"></label>
          <label>Koszt robocizny netto (zł)<input data-salesfield="laborCostNet" type="number" min="0" step="0.01" value="${r.laborCostNet ?? 0}" placeholder="Własny koszt robocizny"></label>
          <label>Data sprzedaży<input data-salesfield="saleDate" type="date" value="${esc(r.saleDate || new Date().toISOString().slice(0,10))}"></label>
          <label>Zapłacono (zł)<input data-salesfield="paid" type="number" min="0" step="0.01" value="${r.paid ?? 0}"></label>
          <label>Termin płatności<input data-salesfield="dueDate" type="date" value="${esc(r.dueDate || '')}"></label>
        </div>
        <label>Status dostawy<select data-salesfield="delivery">
          ${['Do zamówienia','Zamówione','Wysłane','Dostarczone','Odebrane osobiście','Anulowane'].map(v=>`<option ${r.delivery===v?'selected':''}>${v}</option>`).join('')}
        </select></label>
        <label>Dokument sprzedaży<select data-salesfield="document">
          ${['Nie wystawiono','Faktura','Paragon','Inny dokument','Nie dotyczy'].map(v=>`<option ${r.document===v?'selected':''}>${v}</option>`).join('')}
        </select></label>
        <label>Numer dokumentu<input data-salesfield="documentNo" value="${esc(r.documentNo || '')}" placeholder="Numer faktury / paragonu"></label>
        <label>Uwagi<textarea data-salesfield="notes" rows="3">${esc(r.notes || '')}</textarea></label>
        <div class="bud-form-actions"><button class="jump" data-salessave>${svg('check')}Zapisz sprzedaż</button><button class="btn2" data-salesback>Anuluj</button></div>
        <p class="tip">${svg('info')}<span>Rejestr jest lokalny na tym urządzeniu. Nie zastępuje faktury ani ewidencji księgowej.</span></p>
      </div>`;
  }
  const rows = [...state.salesRecords].sort((a,b)=>(b.saleDate||'').localeCompare(a.saleDate||''));
  const total = rows.reduce((n,x)=>n+(Number(x.gross)||0),0);
  const outstanding = rows.reduce((n,x)=>n+salesRemaining(x),0);
  const overdue = rows.filter(x=>salesRemaining(x)>0 && x.dueDate && x.dueDate<new Date().toISOString().slice(0,10));
  const overdueTotal = overdue.reduce((n,x)=>n+salesRemaining(x),0);
  const profitability = rows.map(x=>salesCostSummary(x));
  const completeProfit = profitability.filter(x=>x.complete).reduce((n,x)=>n+x.margin,0);
  const incompleteProfitCount = profitability.filter(x=>!x.complete).length;
  return `<header class="hdr"><div class="hdr-row"><div class="hdr-ico">${svg('money')}</div><div><h1>Sprzedaż i dostawy</h1><p>${rows.length} pozycji w rejestrze</p></div></div></header>
    <div class="body">
      <button class="btn2" data-salesbackoffice>Powrót do Biura</button>
      <button class="jump" data-salesnew>${svg('plus')}Dodaj sprzedaż / zamówienie</button><button class="btn2" data-salesexport>Eksportuj sprzedaż i marżę CSV (Excel)</button><button class="btn2" data-salesbackup>Utwórz kopię rejestru JSON</button><label class="btn2 bud-import-label">Przywróć kopię rejestru JSON<input type="file" data-salesrestore accept=".json,application/json" hidden></label>
      <div class="sales-stats"><div><small>Wartość sprzedaży</small><b>${zl(total)}</b></div><div><small>Do zapłaty</small><b>${zl(outstanding)}</b></div></div>
      <div class="sales-stats"><div><small>Zaległe płatności</small><b>${zl(overdueTotal)}</b></div><div><small>Liczba zaległych</small><b>${overdue.length}</b></div></div>
      <div class="sales-stats"><div><small>Marża z kompletnych rozliczeń</small><b>${zl(completeProfit)}</b></div><div><small>Wpisy z niepełnymi danymi</small><b>${incompleteProfitCount}</b></div></div>
      ${rows.length ? rows.map(x=>`<article class="sales-card">
        <div class="sales-card-head"><strong>${esc(x.client || 'Bez nazwy')}</strong><span class="tagmini">${esc(x.delivery || '—')}</span></div>
        <div>${esc(x.items || '')}</div>
        <small>${esc(x.site || 'Brak adresu montażu')} · ${x.saleDate ? plDate(x.saleDate) : '—'}</small>
        <div class="sales-card-foot"><span>${zl(x.gross)} brutto</span><span>Zapłacono: ${zl(salesPaidTotal(x))} · Pozostało: ${zl(salesRemaining(x))}</span></div>
        ${x.dueDate ? `<small>Termin płatności: ${plDate(x.dueDate)}${salesRemaining(x)>0 && x.dueDate<new Date().toISOString().slice(0,10) ? ' · ZALEGŁOŚĆ' : ''}</small>` : ''}
        ${(Array.isArray(x.payments)&&x.payments.length) ? `<div class="payment-history"><small>Historia wpłat:</small>${x.payments.map((p,i)=>`<div class="sales-card-foot"><small>${p.date?plDate(p.date):'—'} — ${zl(p.amount)}</small><button class="btn2" data-salespaymentdelete="${esc(x.id)}" data-salespaymentindex="${i}" aria-label="Usuń wpłatę">Usuń wpłatę</button></div>`).join('')}</div>` : ''}
        ${salesRemaining(x)>0 ? `<div class="sales-actions"><input type="number" min="0.01" step="0.01" placeholder="Kwota wpłaty" data-salespayamount="${esc(x.id)}" style="max-width:130px"><input type="date" data-salespaydate="${esc(x.id)}" style="max-width:145px"><button class="btn2" data-salespay="${esc(x.id)}">Zarejestruj wpłatę</button></div>` : '<small class="ok-txt">Rozliczono w całości</small>'}
        <small>${x.sourceOfferNumber ? 'Oferta źródłowa: ' + esc(x.sourceOfferNumber) + ' · ' : ''}Dokument: ${esc(x.document || '—')}${x.documentNo ? ' · '+esc(x.documentNo) : ''}</small>
        ${x.lines && x.lines.length ? `<small>Pozycje: ${x.lines.map(l=>esc(l.name)+' × '+Number(l.qty||0)).join(' · ')}</small>` : ''}
        ${x.lines && x.lines.length && !x.stockIssued ? `<div class="sales-actions"><button class="btn2" data-salesissue="${esc(x.id)}">Wydaj z magazynu</button></div>` : ''}
        ${x.stockIssued ? `<small>Magazyn: wydano ${esc(x.stockIssuedAt ? plDate(x.stockIssuedAt.slice(0,10)) : '')} · ${Number(x.stockIssueMoves?.length||0)} ruchów</small>` : ''}
        ${(() => { const c=salesCostSummary(x); return `<small>Koszt materiałów: ${zl(c.materialCost)} netto · Robocizna: ${zl(c.laborCost)} netto</small><small>${c.complete ? 'Szacowana marża netto: ' + zl(c.margin) : 'Marża niepełna — uzupełnij przychód netto i wydaj wszystkie pozycje z magazynu'}</small>`; })()}
        <div class="sales-actions"><button class="btn2" data-salesedit="${esc(x.id)}">Edytuj</button><button class="btn2" data-salesdelete="${esc(x.id)}">Usuń</button></div>
      </article>`).join('') : '<p class="empty">Nie ma jeszcze sprzedaży. Dodaj pierwsze zamówienie lub sprzedaż.</p>'}
    </div>`;
}


function savePurchaseDocs() { localStorage.setItem('ai_purchase_docs_v1', JSON.stringify(state.purchaseDocs)); }
function renderPurchaseDocs() {
  if (state.purchaseDocScreen === 'form') {
    const r = state.purchaseDocDraft || {};
    return `<header class="hdr"><div class="hdr-row"><div class="hdr-ico">${svg('money')}</div><div><h1>Dokument zakupu</h1><p>Rejestr faktur i kosztów dostaw</p></div></div></header>
      <div class="body inventory-form"><button class="btn2" data-pdocback>Wróć do dokumentów</button>
        <label>Dostawca *<input data-pdoc="supplier" value="${esc(r.supplier||'')}" placeholder="Nazwa dostawcy"></label>
        <div class="sales-grid">
          <label>Numer dokumentu *<input data-pdoc="number" value="${esc(r.number||'')}" placeholder="Numer faktury"></label>
          <label>Data dokumentu<input data-pdoc="date" type="date" value="${esc(r.date||new Date().toISOString().slice(0,10))}"></label>
          <label>Netto (zł)<input data-pdoc="net" type="number" min="0" step="0.01" value="${r.net??''}"></label>
          <label>VAT (zł)<input data-pdoc="vat" type="number" min="0" step="0.01" value="${r.vat??''}"></label>
          <label>Brutto (zł)<input data-pdoc="gross" type="number" min="0" step="0.01" value="${r.gross??''}"></label>
          <label>Termin płatności<input data-pdoc="dueDate" type="date" value="${esc(r.dueDate||'')}"></label>
        </div>
        <div class="tip"><span>Status płatności jest wyliczany automatycznie na podstawie zarejestrowanych wpłat i kwoty brutto. Obecnie: <strong>${(r.payments||[]).reduce((n,p)=>n+(Number(p.amount)||0),Number(r.paid)||0)<=0?'Nieopłacona':(r.payments||[]).reduce((n,p)=>n+(Number(p.amount)||0),Number(r.paid)||0)>=Number(r.gross||0)-0.005?'Opłacona':'Częściowo opłacona'}</strong>.</span></div>
        <label>Załącz fakturę (PDF lub zdjęcie)<input data-pdocfile type="file" accept="application/pdf,image/jpeg,image/png"></label>
        ${r.attachment ? `<small>Załącznik: ${esc(r.attachment.name)} (${(r.attachment.size/1024).toFixed(0)} KB)</small>` : '<small>Nie dodano jeszcze pliku.</small>'}
        <label>Uwagi<textarea data-pdoc="notes" rows="3">${esc(r.notes||'')}</textarea></label>
        <p class="tip">${svg('info')}<span>Rejestr danych dokumentu. Skan PDF i księgowanie nie są jeszcze obsługiwane.</span></p>
        <button class="jump" data-pdocsave>${svg('check')}Zapisz dokument zakupu</button></div>`;
  }
  const docs=[...state.purchaseDocs].sort((a,b)=>(b.date||'').localeCompare(a.date||''));
  const total=docs.reduce((n,x)=>n+(Number(x.gross)||0),0);
  const paidOf=x=>(Array.isArray(x.payments)?x.payments:[]).reduce((n,p)=>n+(Number(p.amount)||0),Number(x.paid)||0);
  const remainingOf=x=>Math.max(0,(Number(x.gross)||0)-paidOf(x));
  const unpaid=docs.reduce((n,x)=>n+remainingOf(x),0);
  const today=new Date().toISOString().slice(0,10);
  const inSevenDays=new Date(Date.now()+7*86400000).toISOString().slice(0,10);
  const openDocs=docs.filter(x=>remainingOf(x)>0.005);
  const overdueDocs=openDocs.filter(x=>x.dueDate&&x.dueDate<today).sort((a,b)=>a.dueDate.localeCompare(b.dueDate));
  const upcomingDocs=openDocs.filter(x=>x.dueDate&&x.dueDate>=today&&x.dueDate<=inSevenDays).sort((a,b)=>a.dueDate.localeCompare(b.dueDate));
  const overdueAmount=overdueDocs.reduce((n,x)=>n+remainingOf(x),0);
  const upcomingAmount=upcomingDocs.reduce((n,x)=>n+remainingOf(x),0);
  const dueList=(items,caption)=>items.length?`<div class="sechead">${caption}</div>${items.map(x=>`<article class="sales-card"><div class="sales-card-head"><strong>${esc(x.supplier)}</strong><span class="tagmini">${plDate(x.dueDate)}</span></div><div>${esc(x.number)}</div><div class="sales-card-foot"><span>Pozostało do zapłaty</span><b>${zl(remainingOf(x))}</b></div></article>`).join('')}`:'';
  return `<header class="hdr"><div class="hdr-row"><div class="hdr-ico">${svg('money')}</div><div><h1>Dokumenty zakupowe</h1><p>${docs.length} zarejestrowanych dokumentów</p></div></div></header>
    <div class="body"><button class="btn2" data-pdocback>Wróć do magazynu</button><button class="jump" data-pdocnew>${svg('plus')}Dodaj fakturę / dokument</button><button class="btn2" data-pdocexport>Eksportuj rejestr CSV (Excel)</button><button class="btn2" data-pdocexportjson>Kopia zapasowa JSON</button><label class="btn2 bud-import-label">Przywróć kopię JSON<input type="file" data-pdocimportjson accept=".json,application/json" hidden></label>
    <div class="sales-stats"><div><small>Wartość brutto</small><b>${zl(total)}</b></div><div><small>Nieopłacone</small><b>${zl(unpaid)}</b></div></div>
    <div class="sales-stats"><div><small>Zaległe płatności</small><b>${zl(overdueAmount)}</b><small>${overdueDocs.length} dokumentów po terminie</small></div><div><small>Termin w 7 dni</small><b>${zl(upcomingAmount)}</b><small>${upcomingDocs.length} dokumentów</small></div></div>
    ${dueList(overdueDocs,'Zaległe płatności')}${dueList(upcomingDocs,'Nadchodzące płatności — 7 dni')}
    ${docs.length?docs.map(x=>`<article class="sales-card"><div class="sales-card-head"><strong>${esc(x.supplier)}</strong><span class="tagmini">${esc(x.status)}</span></div><div>${esc(x.number)} · ${x.date?plDate(x.date):'—'}</div><div class="sales-card-foot"><span>${zl(x.net)} netto</span><span>${zl(x.gross)} brutto</span></div><small>VAT ${zl(x.vat)}${x.dueDate?' · Termin: '+plDate(x.dueDate):''}</small><div class="sales-card-foot"><span>Zapłacono: ${zl((x.payments||[]).reduce((n,p)=>n+(Number(p.amount)||0),Number(x.paid)||0))}</span><span>Pozostało: ${zl(Math.max(0,(Number(x.gross)||0)-(x.payments||[]).reduce((n,p)=>n+(Number(p.amount)||0),Number(x.paid)||0)))}</span></div>
        <div class="sales-grid"><label>Kwota wpłaty<input type="number" min="0.01" step="0.01" data-pdocpayamount="${esc(x.id)}" placeholder="0,00"></label><label>Data wpłaty<input type="date" data-pdocpaydate="${esc(x.id)}" value="${new Date().toISOString().slice(0,10)}"></label></div>
        <button class="btn2" data-pdocpay="${esc(x.id)}">Zarejestruj wpłatę</button>
        ${(x.payments||[]).length?`<div class="payment-history"><small>Historia wpłat:</small>${(x.payments||[]).map((p,i)=>`<div class="sales-card-foot"><small>${p.date?plDate(p.date):'—'} — ${zl(p.amount)}</small><button class="btn2" data-pdocpaymentdelete="${esc(x.id)}" data-pdocpaymentindex="${i}" aria-label="Usuń wpłatę">Usuń wpłatę</button></div>`).join('')}</div>`:''}
        ${x.attachment?`<a href="${x.attachment.data}" download="${esc(x.attachment.name)}" target="_blank" rel="noopener">Otwórz / pobierz załącznik: ${esc(x.attachment.name)}</a>`:''}
        <div class="sales-actions"><button class="btn2" data-pdocedit="${esc(x.id)}">Edytuj dokument</button><button class="btn2" data-pdocdelete="${esc(x.id)}">Usuń dokument</button></div>
        ${x.notes?`<small>${esc(x.notes)}</small>`:''}</article>`).join(''):'<p class="empty">Brak dokumentów zakupowych.</p>'}</div>`;
}

function saveInventory() {
  localStorage.setItem('ai_inventory_items_v1', JSON.stringify(state.inventoryItems));
  localStorage.setItem('ai_inventory_moves_v1', JSON.stringify(state.inventoryMoves));
}
function renderInventoryScreen() {
  const editing = state.inventoryItems.find(x => x.id === state.inventoryEditId) || {};
  if (state.inventoryScreen === 'form') {
    return `<header class="hdr"><div class="hdr-row"><div class="hdr-ico">${svg('money')}</div><div><h1>${state.inventoryEditId ? 'Edytuj kartę towaru' : 'Nowy towar'}</h1><p>Indeks magazynowy i ceny zakupu</p></div></div></header>
      <div class="body inventory-form">
        <button class="btn2" data-invback>Wróć do magazynu</button>
        <label>Symbol / SKU<input data-invfield="sku" value="${esc(editing.sku || '')}" placeholder="Symbol producenta lub własny indeks"></label>
        <label>Nazwa towaru *<input data-invfield="name" value="${esc(editing.name || '')}" placeholder="Nazwa urządzenia lub materiału"></label>
        <div class="sales-grid">
          <label>Stan początkowy<input data-invfield="qty" type="number" min="0" step="0.001" value="${editing.qty ?? 0}"></label>
          <label>Stan minimalny<input data-invfield="minQty" type="number" min="0" step="0.001" value="${editing.minQty ?? 0}"></label>
          <label>Cena zakupu netto (zł)<input data-invfield="purchaseNet" type="number" min="0" step="0.01" value="${editing.purchaseNet ?? ''}"></label>
          <label>VAT<input data-invfield="vatRate" type="number" min="0" max="1" step="0.01" value="${editing.vatRate ?? 0.23}"></label>
        </div>
        <label>Dostawca<input data-invfield="supplier" value="${esc(editing.supplier || '')}"></label>
        <label>Lokalizacja w magazynie<input data-invfield="location" value="${esc(editing.location || '')}" placeholder="np. regał A2"></label>
        <label>Uwagi<textarea data-invfield="notes" rows="2">${esc(editing.notes || '')}</textarea></label>
        <div class="bud-form-actions"><button class="jump" data-invsave>${svg('check')}Zapisz kartę towaru</button><button class="btn2" data-invback>Anuluj</button></div>
      </div>`;
  }
  if (state.inventoryScreen === 'move') {
    const item = state.inventoryItems.find(x => x.id === state.inventoryMoveId);
    if (!item) return '<div class="body"><p class="empty">Nie znaleziono towaru.</p><button class="btn2" data-invback>Wróć</button></div>';
    return `<header class="hdr"><div class="hdr-row"><div class="hdr-ico">${svg('money')}</div><div><h1>${esc(item.name)}</h1><p>Stan obecny: ${Number(item.qty || 0)} szt.</p></div></div></header>
      <div class="body inventory-form">
        <button class="btn2" data-invback>Wróć do magazynu</button>
        <label>Rodzaj operacji<select data-movefield="type"><option value="in">Przyjęcie zakupu (+)</option><option value="out">Wydanie z magazynu (−)</option><option value="adjust">Korekta stanu (=)</option></select></label>
        <label>Ilość<input data-movefield="qty" type="number" min="0" step="0.001" value="1"></label>
        <label>Data operacji<input data-movefield="date" type="date" value="${new Date().toISOString().slice(0,10)}"></label>
        <label>Dostawca / odbiorca / powód<input data-movefield="party" placeholder="Nazwa dostawcy, klienta lub przyczyna"></label>
        <label>Numer dokumentu<input data-movefield="document" placeholder="Faktura zakupu / WZ / korekta"></label>
        <label>Uwagi<textarea data-movefield="notes" rows="2"></textarea></label>
        <button class="jump" data-invmovesave>${svg('check')}Zapisz ruch magazynowy</button>
      </div>`;
  }
  const low = state.inventoryItems.filter(x => Number(x.qty || 0) <= Number(x.minQty || 0) && Number(x.minQty || 0) > 0).length;
  const totalValue = state.inventoryItems.reduce((sum,x)=>sum+(Number(x.qty)||0)*(Number(x.purchaseNet)||0),0);
  const recent = [...state.inventoryMoves].sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,8);
  const monthKey = new Date().toISOString().slice(0,7);
  const purchases = state.inventoryMoves.filter(m=>m.type==='in');
  const purchasesMonth = purchases.filter(m=>(m.date||'').slice(0,7)===monthKey);
  const purchaseValue = m => Number(m.purchaseValueNet ?? ((Number(m.qty)||0)*(Number(m.purchaseUnitNet ?? (state.inventoryItems.find(i=>i.id===m.itemId)?.purchaseNet))||0)))||0;
  const purchaseMonthTotal = purchasesMonth.reduce((sum,m)=>sum+purchaseValue(m),0);
  const purchaseAllTotal = purchases.reduce((sum,m)=>sum+purchaseValue(m),0);
  return `<header class="hdr"><div class="hdr-row"><div class="hdr-ico">${svg('money')}</div><div><h1>Magazyn i zakupy</h1><p>${state.inventoryItems.length} kart towarowych · ${low} stanów minimalnych</p></div></div></header>
    <div class="body">
      <button class="btn2" data-invbackoffice>Powrót do Biura</button>
      <button class="jump" data-invnew>${svg('plus')}Dodaj towar</button>
      <button class="btn2" data-pdocopen style="width:100%;margin-top:8px">Dokumenty zakupowe (${state.purchaseDocs.length})</button>
      <div class="sales-stats"><div><small>Wartość magazynu netto</small><b>${zl(totalValue)}</b></div><div><small>Pozycje poniżej minimum</small><b>${low}</b></div></div>
      <div class="sechead">Zestawienie zakupów</div>
      <div class="sales-stats"><div><small>Zakupy w tym miesiącu (${monthKey})</small><b>${zl(purchaseMonthTotal)}</b></div><div><small>Zakupy łącznie</small><b>${zl(purchaseAllTotal)}</b></div></div>
      <small>${purchases.length} zarejestrowanych przyjęć · wartość liczona według ceny zakupu netto zapisanej przy ruchu</small>
      ${state.inventoryItems.length ? state.inventoryItems.map(x=>`<article class="sales-card">
        <div class="sales-card-head"><strong>${esc(x.name)}</strong><span class="tagmini">${Number(x.qty||0)} szt.</span></div>
        <small>${esc(x.sku || 'Bez SKU')} · ${esc(x.supplier || 'Bez dostawcy')}</small>
        <div class="sales-card-foot"><span>Zakup: ${x.purchaseNet == null ? '—' : zl(x.purchaseNet)+' netto'}</span><span>Min.: ${Number(x.minQty||0)}</span></div>
        ${Number(x.qty||0) <= Number(x.minQty||0) && Number(x.minQty||0)>0 ? '<small style="color:var(--flame)">Stan minimalny osiągnięty</small>' : ''}
        <div class="sales-actions"><button class="btn2" data-invmove="${esc(x.id)}">Przyjmij / wydaj</button><button class="btn2" data-invedit="${esc(x.id)}">Edytuj</button></div>
      </article>`).join('') : '<p class="empty">Magazyn jest pusty. Dodaj kartę towaru, a następnie rejestruj przyjęcia i wydania.</p>'}
      <div class="sechead">Ostatnie ruchy magazynowe</div>
      ${recent.length ? recent.map(m=>`<div class="sales-card"><div class="sales-card-head"><strong>${esc(m.itemName)}</strong><span class="tagmini">${m.type==='in'?'Przyjęcie':m.type==='out'?'Wydanie':'Korekta'}</span></div><small>${m.date ? plDate(m.date) : ''} · ${esc(m.party || '—')} · ${esc(m.document || 'bez dokumentu')}</small><b>${m.type==='in'?'+':m.type==='out'?'−':'='}${m.qty}</b></div>`).join('') : '<p class="empty">Brak ruchów magazynowych.</p>'}
    </div>`;
}

function renderOffersTab() {
  if (state.offerScreen === 'purchases') return renderPurchaseDocs();
  if (state.offerScreen === 'inventory') return renderInventoryScreen();
  if (state.offerScreen === 'sales') return renderSalesRegister();
  if (state.offerScreen === 'buderus') return renderBuderusCatalog();
  if (state.offerScreen === 'klienci') return state.klientId ? renderKlientEdit() : renderKlienciList();
  if (state.offerScreen === 'edit') return renderOfferEdit();
  if (state.offerScreen === 'doc') return renderOfferDoc();
  if (state.offerScreen === 'invoice') return renderInvoice();
  return renderOffersList();
}

/* ============================================================
   ARKUSZ WYBORU Z KATALOGU
   ============================================================ */
function renderOverlay() {
  const el = document.getElementById('overlay');
  if (!el) return;

  /* Co nowego po aktualizacji — pokazywane raz, zaraz po starcie, więc
     stoi przed resztą: przy starcie i tak nic innego nie jest otwarte. */
  if (state.coNowego) { el.innerHTML = coNowegoHtml(state.coNowego); return; }

  /* Pytanie przed usunięciem oferty albo faktury. Pasek „Cofnij" zostaje,
     ale sam nie wystarcza: kosz stoi tuż przy kafelku dokumentu i łatwo
     go trącić, a pasek gaśnie po pięciu sekundach. */
  if (state.usunPyt) { el.innerHTML = usunPytHtml(state.usunPyt); return; }

  /* Ostrzeżenie o uprawnieniach gazowych. Treść i wygląd okna są w ui.js,
     przy kalkulatorze, którego dotyczą — tutaj jest tylko miejsce, w którym
     aplikacja rysuje wszystkie okna nakładane na ekran. */
  if (state.gasWarn) { el.innerHTML = gasWarnHtml(); return; }

  /* Potwierdzenie wyczyszczenia wyników — pytanie zadaje nagłówek ekranu
     głównego, a treść arkusza stoi przy kalkulatorach, których dotyczy. */
  if (state.resetSheet) { el.innerHTML = resetHtml(); return; }

  /* Wybór konkretnego grzejnika pod pozycją w średnicach c.o. */
  if (state.grzWybor) { el.innerHTML = grzSheetHtml(state.grzWybor); return; }

  /* Schemat kotłowni na pełnym ekranie. */
  if (state.ktPelny) { el.innerHTML = ktPelnyHtml(); return; }

  /* Projekt poglądowy — rysunek gałęzi z kalkulatora średnic. */
  if (state.schemat) { el.innerHTML = schematHtml(state.schemat); return; }

  /* Wybór klienta z bazy — arkusz wywołany guzikiem spod danych klienta. */
  if (state.pickKlient) { el.innerHTML = klientSheetHtml(); return; }

  /* Wybór oferty przy dodawaniu pozycji z kalkulatora. */
  if (state.wybOferty) { el.innerHTML = wyborOfertyHtml(state.wybOferty); return; }

  /* Pytanie o pomieszczenie przy dopisywaniu grzejnika do listy średnic. */
  if (state.pytamPokoj) { el.innerHTML = wyborPokojuHtml(state.pytamPokoj); return; }
  /* Przy podłogówce pytamy dwa razy: najpierw o pomieszczenie, bo to ono
     rozstrzyga, czy wynik się dokłada, czy poprawia wcześniejszy wpis. */
  if (state.pytamRozdzPokoj) { el.innerHTML = wyborPokojuRozdzHtml(state.pytamRozdzPokoj); return; }
  if (state.pytamRozdz) { el.innerHTML = wyborRozdzielaczaHtml(state.pytamRozdz); return; }

  /* Podgląd pliku XML. Pokazujemy treść, bo w podglądzie w przeglądarce
     zapis pliku bywa zablokowany — wtedy zostaje zaznaczenie i skopiowanie. */
  if (state.xmlSheet) {
    el.innerHTML = `<div class="sheet" data-closexml>
      <div class="sheet-in" role="dialog" aria-label="Plik XML do KSeF">
        <div class="sheet-h">${svg('doc')}<strong>${esc(state.xmlSheet.name)}</strong>
          <button class="item-x" data-closexml aria-label="Zamknij">${svg('x')}</button></div>
        <div class="sheet-body">
          <div class="tip">${svg('spark')}<div>${esc(state.xmlSheet.note)}</div></div>
          <textarea readonly rows="14" style="width:100%;font:12px ui-monospace,monospace;
            border:none;border-radius:14px;padding:12px;background:var(--field);color:var(--ink);
            resize:vertical">${esc(state.xmlSheet.xml)}</textarea>
          <button class="jump" style="--c:var(--flame);margin-top:10px" data-xmlsave>
            ${svg('doc')}Zapisz plik na dysku</button>
          <button class="btn2" style="width:100%;margin-top:8px" data-xmlcopy>
            ${svg('list')}Kopiuj treść pliku</button>
        </div>
      </div></div>`;
    return;
  }
  if (!state.picker) { el.innerHTML = ''; return; }

  const w = pickerZawartosc();
  el.innerHTML = `<div class="sheet" data-closepicker>
    <div class="sheet-in" role="dialog" aria-label="Katalog pozycji">
      <div class="sheet-h">${pickerGlowka(w)}</div>
      <div class="sheet-find">
        <div class="search">${svg('search')}
          <input type="search" data-pickq placeholder="Szukaj: kolano 25, filtr 3/4…"
            value="${esc((state.pickQ || '').trim())}" autocapitalize="off" autocorrect="off" spellcheck="false">
        </div>
      </div>
      <div class="sheet-body">${w.tresc}</div>
      <div class="sheet-foot">${pickerStopka()}</div>
    </div></div>`;
}

/* Jeden wiersz katalogu — ten sam wygląd na każdym poziomie i w wynikach
   szukania. W trybie zaznaczania dostaje ramkę i ptaszka zamiast ceny,
   żeby było widać, co już wpadło do koszyka. */
function pickerWiersz(c) {
  const ile = ilePozycji(c.id);
  /* Cena schodzi do drugiego wiersza, a jej miejsce zajmuje licznik sztuk.
     Przy kompletowaniu materiału na łazienkę liczy się to, ile czego brać,
     a nie ile kosztuje sztuka — cena i tak jest widoczna obok jednostki. */
  return `<div class="citem${ile ? ' citem--zazn' : ''}">
      <button class="citem-go" data-pick="${c.id}">
        <span class="citem-t"><strong>${esc(c.name)}</strong>
          <span>${esc(c.unit)} · ${c.cat === 'rob' ? 'robocizna' : 'materiał'} · ${
            Number(c.price) ? esc(zl(c.price)) : '<b>brak ceny</b>'}</span></span>
      </button>
      <span class="qbox">
        <button class="qbtn qbtn--minus" data-qminus="${c.id}" aria-label="Odejmij 1 szt"${
          ile ? '' : ' disabled'}>−</button>
        <b class="qnum${ile ? '' : ' qnum--zero'}">${ile}</b>
        <button class="qbtn qbtn--plus" data-qplus="${c.id}" aria-label="Dodaj 1 szt">+</button>
      </span>
    </div>`;
}

/* Pasek pod listą. Pusty, dopóki nic nie jest zaznaczone — dzięki temu
   nie zabiera miejsca przy zwykłym wybieraniu pojedynczej pozycji. */
function pickerStopka() {
  if (!state.pickSel) return '';
  const ids = Object.keys(state.pickSel);
  const n = ids.length;
  const sztuk = ids.reduce((s, id) => s + state.pickSel[id], 0);
  return `<div class="pickbar">
      <button class="btn2" data-selcancel>Anuluj</button>
      <button class="jump" style="--c:var(--flame)" data-seladd${n ? '' : ' disabled'}>
        ${svg('plus')}Dodaj ${n ? n + (n === 1 ? ' pozycję' : (n < 5 ? ' pozycje' : ' pozycji'))
          + (sztuk > n ? ' · ' + sztuk + ' szt' : '') : ''}</button>
    </div>`;
}

/* ============================================================
   ZAZNACZANIE KILKU POZYCJI NARAZ
   ------------------------------------------------------------
   Przy wycenie łazienki z jednego działu bierze się naraz kolano,
   trójnik, mufę i redukcję. Dotychczas każda z nich oznaczała zamknięcie
   okna i przejście przez trzy poziomy od nowa.

   Tryb zaznaczania włącza przytrzymanie palca na pozycji — tak samo jak
   zaznaczanie zdjęć w galerii telefonu, więc nie trzeba się tego uczyć.
   Potem zwykłe dotknięcia dokładają kolejne, także z innych rozmiarów
   i działów, bo zaznaczenie przeżywa przechodzenie między poziomami.

   Dwie rzeczy są tu ważne i nieoczywiste. Ruch palcem przerywa odliczanie,
   bo inaczej przewijanie listy zaznaczałoby pozycje pod palcem. A po
   udanym przytrzymaniu połykamy następne kliknięcie — przeglądarka
   wysyła je po puszczeniu palca i bez tego pozycja zaznaczyłaby się
   i od razu odznaczyła.
   ============================================================ */
const DLUGIE_MS = 420;     /* tyle trzyma się palec, żeby włączyć zaznaczanie */
const DLUGIE_LUZ = 12;     /* na tyle pikseli wolno drgnąć, zanim uznamy to za przewijanie */
let dlugiTimer = null;
let dlugiPkt = null;
let dlugiZaszlo = false;

function przerwijDlugie() {
  clearTimeout(dlugiTimer);
  dlugiTimer = null;
  dlugiPkt = null;
}

/* Koszyk trzyma ilości, nie same identyfikatory: {'pp-kol90-25': 4}.
   Zero znaczy „nie ma w koszyku" i pozycja z niego wypada — inaczej lista
   zapełniłaby się wierszami po zero sztuk, które i tak nic nie wnoszą. */
const ilePozycji = id => (state.pickSel && state.pickSel[id]) || 0;

function zmienIlosc(id, o) {
  if (!state.pickSel) state.pickSel = {};
  const nowa = Math.max(0, ilePozycji(id) + o);
  if (nowa) state.pickSel[id] = nowa; else delete state.pickSel[id];
}

function zaznaczPozycje(id) {
  if (!state.pickSel) state.pickSel = {};
  if (ilePozycji(id)) delete state.pickSel[id]; else state.pickSel[id] = 1;
}

document.addEventListener('pointerdown', e => {
  const c = e.target.closest('[data-pick]');
  if (!c || !state.picker) return;
  dlugiZaszlo = false;
  dlugiPkt = { x: e.clientX, y: e.clientY };
  dlugiTimer = setTimeout(() => {
    dlugiZaszlo = true;
    zaznaczPozycje(c.dataset.pick);
    odswiezPicker();
    /* Krótkie drgnięcie potwierdza, że tryb się włączył — bez tego
       użytkownik nie wie, czy trzymał wystarczająco długo. */
    try { if (navigator.vibrate) navigator.vibrate(15); } catch (err) { /* nie wszędzie jest */ }
  }, DLUGIE_MS);
});

document.addEventListener('pointermove', e => {
  if (!dlugiPkt) return;
  if (Math.abs(e.clientX - dlugiPkt.x) > DLUGIE_LUZ
    || Math.abs(e.clientY - dlugiPkt.y) > DLUGIE_LUZ) przerwijDlugie();
});
['pointerup', 'pointercancel', 'scroll'].forEach(ev =>
  document.addEventListener(ev, przerwijDlugie, true));

/* Nagłówek okna: strzałka powrotu, tytuł, krzyżyk. Osobno, bo przy
   pisaniu w wyszukiwarce zmienia się razem z listą — strzałka musi
   wtedy cofać z szukania, a nie o poziom wyżej. */
function pickerGlowka(w) {
  return (w.wstecz
      ? `<button class="back back--sm" data-pickback="${w.wstecz}" aria-label="Wróć">${svg('back')}</button>`
      : svg('list'))
    + `<strong>${esc(w.tytul)}</strong>`
    + `<button class="item-x" data-closepicker aria-label="Zamknij">${svg('x')}</button>`;
}

/* Zawartość okna na bieżącym poziomie. Osobno od rysowania, bo przy
   pisaniu w wyszukiwarce podmieniamy samą listę — przerysowanie całego
   okna zabrałoby palcowi pole, w którym właśnie pisze. */
function pickerZawartosc() {
  const pozycja = pickerWiersz;
  const szukane = (state.pickQ || '').trim();
  const grupa = state.pickGrp;
  const menu = katalogMenu();
  const wybrana = menu.find(g => g.nazwa === grupa);

  let tytul = 'Katalog pozycji';
  let wstecz = '';
  let tresc;

  if (szukane) {
    const trafienia = katalogSzukajFrazy(szukane, 60);
    tytul = 'Szukanie';
    wstecz = 'q';
    tresc = trafienia.length
      ? `<div class="cgrp">${trafienia.length === 60 ? 'pierwsze 60 pozycji' : trafienia.length + ' pozycji'}</div>`
        + trafienia.map(pozycja).join('')
      : `<p class="empty">Nic nie pasuje do „${esc(szukane)}".<br>Spróbuj krócej, np. samo „kolano" albo „25".</p>`;

  } else if (wybrana && wybrana.rozmiary.length && !state.pickDn) {
    /* Poziom rozmiarów. Kafelki w siatce, bo to krótkie napisy —
       lista pionowa marnowałaby tu pół ekranu. */
    tytul = wybrana.nazwa;
    wstecz = 'grp';
    tresc = `<div class="cgrp">Wybierz rozmiar</div><div class="dnlist">`
      + wybrana.rozmiary.map(d => `<button class="dnbtn" data-pickdn="${esc(d)}">${esc(d)}</button>`).join('')
      + `</div>`
      + (wybrana.bezRozmiaru ? `<button class="citem" data-pickdn="${BEZ_ROZMIARU}">
          <span class="citem-t"><strong>Bez rozmiaru</strong>
            <span>${wybrana.bezRozmiaru} pozycji, które nie dzielą się na średnice</span></span>
          ${svg('chev')}</button>` : '')
      + `<button class="citem" data-pickdn="*">
          <span class="citem-t"><strong>Wszystkie rozmiary</strong>
            <span>${wybrana.ile} pozycji na jednej liście</span></span></button>`;

  } else if (wybrana && state.pickWar) {
    /* Rozwinięte warianty jednej kształtki — same długości, nic więcej. */
    const lista = katalogWGrupie(wybrana.nazwa, null).filter(c => c.wg === state.pickWar);
    tytul = (lista[0] && lista[0].wgNazwa) || wybrana.nazwa;
    wstecz = 'war';
    tresc = lista.map(pozycja).join('');

  } else if (wybrana) {
    tytul = wybrana.nazwa + (state.pickDn && state.pickDn !== '*' ? ' · ' + state.pickDn : '');
    wstecz = wybrana.rozmiary.length ? 'dn' : 'grp';
    const lista = katalogWGrupie(wybrana.nazwa, state.pickDn === '*' ? null : state.pickDn);
    /* Czego nie ma w bazie, dopisuje się na dole tej samej listy — i od razu
       ląduje w tym dziale w katalogu cen, a nie w worku „Moje pozycje".
       Inaczej hurtownia miałaby swój porządek, a aplikacja swój. */
    /* Warianty zwijamy w jeden wiersz. Dziesięć długości przedłużki
       zajmowałoby pół działu, a i tak najpierw wybiera się rodzaj
       kształtki, a dopiero potem długość. */
    const zwiniete = {};
    tresc = lista.map(c => {
      if (!c.wg) return pozycja(c);
      if (zwiniete[c.wg]) return '';
      zwiniete[c.wg] = 1;
      const ile = lista.filter(x => x.wg === c.wg).length;
      const zCena = lista.filter(x => x.wg === c.wg && Number(x.price) > 0).length;
      return `<button class="citem" data-pickwar="${esc(c.wg)}">
          <span class="citem-t"><strong>${esc(c.wgNazwa || c.name)}</strong>
            <span>${ile} długości${zCena ? ' · ' + zCena + ' z ceną' : ' · <b>brak cen</b>'}</span></span>
          ${svg('chev')}</button>`;
    }).join('')
      + `<button class="addbtn" data-newin style="--c:var(--flame);margin-top:10px">${svg('plus')}
          Nie ma tego na liście — dopisz do działu</button>`;

  } else {
    const custom = `<button class="citem custom" data-custom>
        <span class="citem-ico">${svg('plus')}</span>
        <span class="citem-t"><strong>Pozycja własna</strong>
          <span>wpisz swoją nazwę, jednostkę i cenę</span></span>
      </button>`;
    tresc = custom + `<div class="cgrp">Działy</div>` + menu.map(g => `
      <button class="citem" data-pickgrp="${esc(g.nazwa)}">
        <span class="citem-t"><strong>${esc(g.nazwa)}</strong>
          <span>${g.ile} pozycji${g.rozmiary.length ? ' · ' + g.rozmiary.length + ' rozmiarów' : ''}</span></span>
        ${svg('chev')}</button>`).join('');
  }

  return { tytul, wstecz, tresc };
}

/* Odświeżenie samej listy — używane przy pisaniu w wyszukiwarce. */
function odswiezPicker() {
  const body = document.querySelector('.sheet-body');
  if (!body) return;
  const w = pickerZawartosc();
  body.innerHTML = w.tresc;
  const h = document.querySelector('.sheet-h');
  if (h) h.innerHTML = pickerGlowka(w);
  const f = document.querySelector('.sheet-foot');
  if (f) f.innerHTML = pickerStopka();
}

/* ============================================================
   ZDARZENIA MODUŁU OFERT
   ============================================================ */
/* Pole nazwy rośnie wraz z tekstem, żeby zawsze było widać całą nazwę pozycji */
function autosize(el) {
  if (!el) return;
  el.style.height = 'auto';
  el.style.height = el.scrollHeight + 'px';
}
function autosizeAll() {
  document.querySelectorAll('textarea[data-iname]').forEach(autosize);
}

/* Krótkie powiadomienie na dole ekranu, żeby po dodaniu pozycji do oferty
   nie wyrzucać użytkownika z kalkulatora — może dobierać dalej. */
let toastTimer = null;
function toast(msg, action) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.innerHTML = `<div class="toast"><span>${esc(msg)}</span>`
    + (action ? `<button data-toastgo>${esc(action)}</button>` : '') + '</div>';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.innerHTML = '';
    /* Razem z paskiem przepada możliwość cofnięcia — inaczej „Cofnij"
       z poprzedniego kasowania odżyłoby przy następnym komunikacie. */
    state.cofnij = null;
    state.kopiaCofnij = null;
    state.dopisano = false;
    state.dopisanoRozdz = false;
  }, 5000);
}
function hideToast() {
  const el = document.getElementById('toast');
  if (el) el.innerHTML = '';
  clearTimeout(toastTimer);
}

/* Przerysowanie z zachowaniem pozycji przewijania — przy edycji pozycji
   w środku listy skok na górę ekranu byłby irytujący. */
function renderKeepScroll() {
  const vp = document.getElementById('viewport');
  const y = vp ? vp.scrollTop : 0;
  render(false);
  if (vp) vp.scrollTop = y;
}

/* Rozwinięcie listy pozycji pamiętamy — każda zmiana przerysowuje ekran. */
state.ofPozOtw = false;
document.addEventListener('click', e => {
  const sm = e.target.closest('.of-poz > summary');
  if (sm) state.ofPozOtw = !sm.parentElement.open;
  if (e.target.closest('[data-additem]')) state.ofPozOtw = true;
}, true);

document.addEventListener('click', async e => {
  if (e.target.closest('[data-inventory]')) { state.offerScreen='inventory'; state.inventoryScreen='list'; render(true); return; }
  const pdocPay = e.target.closest('[data-pdocpay]');
  if (pdocPay) {
    const id=pdocPay.dataset.pdocpay, doc=state.purchaseDocs.find(x=>x.id===id);
    const amountEl=document.querySelector(`[data-pdocpayamount="${id}"]`), dateEl=document.querySelector(`[data-pdocpaydate="${id}"]`);
    const amount=Number(amountEl && amountEl.value), date=dateEl && dateEl.value;
    if(!doc){toast('Nie znaleziono dokumentu.');return;}
    if(!Number.isFinite(amount)||amount<=0){toast('Wpisz kwotę wpłaty większą od zera.');return;}
    const paid=(doc.payments||[]).reduce((n,x)=>n+(Number(x.amount)||0),Number(doc.paid)||0);
    const remaining=Math.max(0,(Number(doc.gross)||0)-paid);
    if(amount>remaining+0.005){toast('Wpłata przekracza pozostałą kwotę: '+zl(remaining));return;}
    doc.payments=Array.isArray(doc.payments)?doc.payments:[];
    doc.payments.push({id:'payment_'+Date.now(),amount,date:date||new Date().toISOString().slice(0,10)});
    const totalPaid=doc.payments.reduce((n,x)=>n+(Number(x.amount)||0),Number(doc.paid)||0);
    doc.status=totalPaid<=0?'Nieopłacona':totalPaid>=Number(doc.gross||0)-0.005?'Opłacona':'Częściowo opłacona';
    doc.updatedAt=new Date().toISOString(); savePurchaseDocs(); render(true); toast('Zarejestrowano wpłatę.'); return;
  }
  if (e.target.closest('[data-pdocopen]')) { state.offerScreen='purchases'; state.purchaseDocScreen='list'; render(true); return; }
  const pdocPaymentDelete=e.target.closest('[data-pdocpaymentdelete]');
  if(pdocPaymentDelete){
    const doc=state.purchaseDocs.find(x=>x.id===pdocPaymentDelete.dataset.pdocpaymentdelete);
    const index=Number(pdocPaymentDelete.dataset.pdocpaymentindex);
    if(!doc||!Array.isArray(doc.payments)||!Number.isInteger(index)||index<0||index>=doc.payments.length){toast('Nie znaleziono wpłaty.');return;}
    const payment=doc.payments[index];
    if(!confirm('Usunąć wpłatę '+zl(payment.amount)+' z dnia '+(payment.date?plDate(payment.date):'—')+'?')) return;
    doc.payments.splice(index,1);
    const totalPaid=doc.payments.reduce((n,x)=>n+(Number(x.amount)||0),Number(doc.paid)||0);
    doc.status=totalPaid<=0?'Nieopłacona':totalPaid>=Number(doc.gross||0)-0.005?'Opłacona':'Częściowo opłacona';
    doc.updatedAt=new Date().toISOString();
    savePurchaseDocs();render(true);toast('Usunięto wpłatę i przeliczono saldo.');return;
  }
  const pdocEdit=e.target.closest('[data-pdocedit]');
  if(pdocEdit){const doc=state.purchaseDocs.find(x=>x.id===pdocEdit.dataset.pdocedit);if(!doc){toast('Nie znaleziono dokumentu.');return;}state.purchaseDocDraft={...doc,payments:[...(doc.payments||[])]};state.purchaseDocScreen='form';render(true);return;}
  const pdocDelete=e.target.closest('[data-pdocdelete]');
  if(pdocDelete){const doc=state.purchaseDocs.find(x=>x.id===pdocDelete.dataset.pdocdelete);if(!doc)return;if(confirm('Usunąć dokument '+doc.number+' od '+doc.supplier+' wraz z historią wpłat?')){state.purchaseDocs=state.purchaseDocs.filter(x=>x.id!==doc.id);savePurchaseDocs();render(true);toast('Usunięto dokument zakupowy.');}return;}
  if(e.target.closest('[data-pdocexportjson]')){
    const payload={schema:'asystent-instalatora-purchase-docs',version:1,exportedAt:new Date().toISOString(),documents:state.purchaseDocs};
    try{const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='kopia_dokumentow_zakupowych.json';document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(url);a.remove();},1000);toast('Utworzono kopię dokumentów wraz z załącznikami i wpłatami.');}catch(err){toast('Nie udało się utworzyć kopii JSON.');}return;
  }
  if(e.target.closest('[data-pdocexport]')){
    const quote=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
    const header=['Dostawca','Numer','Data','Netto','VAT','Brutto','Termin płatności','Status','Zapłacono','Pozostało','Liczba wpłat','Historia wpłat','Uwagi'];
    const rows=state.purchaseDocs.map(x=>{const payments=Array.isArray(x.payments)?x.payments:[],paid=payments.reduce((n,p)=>n+(Number(p.amount)||0),Number(x.paid)||0),status=paid<=0?'Nieopłacona':paid>=Number(x.gross||0)-0.005?'Opłacona':'Częściowo opłacona';return [x.supplier,x.number,x.date,x.net,x.vat,x.gross,x.dueDate,status,paid,Math.max(0,(Number(x.gross)||0)-paid),payments.length,payments.map(p=>(p.date||'')+': '+(Number(p.amount)||0)).join(' | '),x.notes];});
    const csv='\\uFEFF'+[header,...rows].map(row=>row.map(quote).join(';')).join('\\r\\n');
    try{const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='dokumenty_zakupowe.csv';document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(url);a.remove();},1000);toast('Przygotowano eksport CSV.');}catch(err){toast('Nie udało się wyeksportować rejestru.');}return;
  }
  if (e.target.closest('[data-pdocback]')) { state.offerScreen='inventory'; state.inventoryScreen='list'; state.purchaseDocScreen='list'; render(true); return; }
  if (e.target.closest('[data-pdocnew]')) { state.purchaseDocDraft={}; state.purchaseDocScreen='form'; render(true); return; }
  if (e.target.closest('[data-pdocsave]')) {
    const val=k=>{const el=document.querySelector(`[data-pdoc="${k}"]`);return el?el.value.trim():'';};
    const supplier=val('supplier'), number=val('number'), net=Number(val('net'))||0, vat=Number(val('vat'))||0, gross=Number(val('gross'))||0;
    if(!supplier||!number){toast('Uzupełnij dostawcę i numer dokumentu.');return;}
    if(net<0||vat<0||gross<0){toast('Kwoty nie mogą być ujemne.');return;}
    if(state.purchaseDocs.some(x=>x.id!==(state.purchaseDocDraft&&state.purchaseDocDraft.id)&&x.supplier.toLowerCase()===supplier.toLowerCase()&&x.number.toLowerCase()===number.toLowerCase())){toast('Dokument od tego dostawcy o takim numerze już istnieje.');return;}
    const draft=state.purchaseDocDraft||{}, record={...draft,id:draft.id||'pdoc_'+Date.now(),supplier,number,date:val('date'),net,vat,gross,dueDate:val('dueDate'),status:(()=>{const paid=(draft.payments||[]).reduce((n,p)=>n+(Number(p.amount)||0),Number(draft.paid)||0);return paid<=0?'Nieopłacona':paid>=gross-0.005?'Opłacona':'Częściowo opłacona';})(),notes:val('notes'),attachment:draft.attachment||null,createdAt:draft.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};
    const existingIndex=state.purchaseDocs.findIndex(x=>x.id===record.id);
    if(existingIndex>=0) state.purchaseDocs[existingIndex]=record; else state.purchaseDocs.push(record);
    savePurchaseDocs(); state.purchaseDocDraft=null; state.purchaseDocScreen='list'; render(true); toast('Zapisano dokument zakupowy.'); return;
  }
  if (e.target.closest('[data-invbackoffice]')) { state.offerScreen='list'; state.inventoryScreen='list'; render(true); return; }
  if (e.target.closest('[data-invback]')) { state.inventoryScreen='list'; state.inventoryEditId=null; state.inventoryMoveId=null; render(true); return; }
  if (e.target.closest('[data-invnew]')) { state.inventoryEditId=null; state.inventoryScreen='form'; render(true); return; }
  const invEdit=e.target.closest('[data-invedit]');
  if (invEdit) { state.inventoryEditId=invEdit.dataset.invedit; state.inventoryScreen='form'; render(true); return; }
  const invMove=e.target.closest('[data-invmove]');
  if (invMove) { state.inventoryMoveId=invMove.dataset.invmove; state.inventoryScreen='move'; render(true); return; }
  if (e.target.closest('[data-invsave]')) {
    const val=k=>{const el=document.querySelector(`[data-invfield="${k}"]`);return el?el.value.trim():'';};
    const name=val('name');
    if (!name) { toast('Podaj nazwę towaru.'); return; }
    const qty=Number(val('qty')), minQty=Number(val('minQty')), purchaseNet=val('purchaseNet')===''?null:Number(val('purchaseNet')), vatRate=Number(val('vatRate'));
    if (![qty,minQty,vatRate].every(Number.isFinite) || qty<0 || minQty<0 || vatRate<0 || vatRate>1 || (purchaseNet!==null && (!Number.isFinite(purchaseNet)||purchaseNet<0))) { toast('Sprawdź ilości, cenę i stawkę VAT.'); return; }
    const previous=state.inventoryItems.find(x=>x.id===state.inventoryEditId)||{};
    const item={...previous,id:state.inventoryEditId||('stock_'+Date.now()+'_'+Math.random().toString(36).slice(2,6)),
      sku:val('sku'),name,qty,minQty,purchaseNet,vatRate,supplier:val('supplier'),location:val('location'),notes:val('notes'),
      updatedAt:new Date().toISOString()};
    const i=state.inventoryItems.findIndex(x=>x.id===item.id);
    if(i>=0) state.inventoryItems[i]=item; else state.inventoryItems.push(item);
    saveInventory(); state.inventoryEditId=null; state.inventoryScreen='list'; render(true); toast('Zapisano kartę towaru.'); return;
  }
  if (e.target.closest('[data-invmovesave]')) {
    const item=state.inventoryItems.find(x=>x.id===state.inventoryMoveId);
    if (!item) { toast('Nie znaleziono towaru.'); return; }
    const val=k=>{const el=document.querySelector(`[data-movefield="${k}"]`);return el?el.value.trim():'';};
    const type=val('type'), qty=Number(val('qty'));
    if (!Number.isFinite(qty)||qty<=0) { toast('Ilość musi być większa od zera.'); return; }
    const before=Number(item.qty)||0;
    let after=type==='in'?before+qty:type==='out'?before-qty:qty;
    if (after<0) { toast('Brak wystarczającego stanu magazynowego.'); return; }
    const move={id:'move_'+Date.now(),itemId:item.id,itemName:item.name,type,qty,purchaseUnitNet:Number(item.purchaseNet)||0,purchaseValueNet:type==='in'?qty*(Number(item.purchaseNet)||0):0,date:val('date'),party:val('party'),document:val('document'),notes:val('notes'),before,after};
    item.qty=after; item.updatedAt=new Date().toISOString(); state.inventoryMoves.push(move);
    saveInventory(); state.inventoryScreen='list'; state.inventoryMoveId=null; render(true); toast('Zapisano ruch magazynowy.'); return;
  }
  if (e.target.closest('[data-salesregister]')) { state.offerScreen='sales'; state.salesScreen='list'; render(true); return; }
  if(e.target.closest('[data-salesbackup]')){
    const payload={schema:'asystent-instalatora-sales-register',version:1,exportedAt:new Date().toISOString(),records:state.salesRecords};
    try{
      const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
      const url=URL.createObjectURL(blob);const a=document.createElement('a');
      a.href=url;a.download='kopia_rejestru_sprzedazy.json';document.body.appendChild(a);a.click();
      setTimeout(()=>{URL.revokeObjectURL(url);a.remove();},1000);
      toast('Utworzono kopię rejestru sprzedaży wraz z wpłatami i danymi magazynowymi.');
    }catch(err){toast('Nie udało się utworzyć kopii rejestru.');}
    return;
  }
  if(e.target.closest('[data-salesexport]')){
    const quote=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
    const header=['Data sprzedaży','Klient','Adres inwestycji','Towar / urządzenie','Brutto','Przychód netto','Koszt materiałów netto','Koszt robocizny netto','Szacowana marża netto','Kompletność marży','Zapłacono','Pozostało','Termin płatności','Dostawa','Dokument','Numer dokumentu'];
    const lines=state.salesRecords.map(x=>{
      const c=salesCostSummary(x);
      return [x.saleDate,x.client,x.site,x.items,x.gross,x.revenueNet,c.materialCost,c.laborCost,c.complete?c.margin:'',c.complete?'Kompletne':'Niepełne',salesPaidTotal(x),salesRemaining(x),x.dueDate,x.delivery,x.document,x.documentNo].map(quote).join(';');
    });
    const csv='\\uFEFF'+[header.map(quote).join(';'),...lines].join('\\r\\n');
    try{
      const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
      const url=URL.createObjectURL(blob);const a=document.createElement('a');
      a.href=url;a.download='rejestr_sprzedazy_marza.csv';document.body.appendChild(a);a.click();
      setTimeout(()=>{URL.revokeObjectURL(url);a.remove();},1000);
      toast('Wyeksportowano sprzedaż, płatności i dane marży do CSV.'); 
    }catch(err){toast('Nie udało się wyeksportować rejestru sprzedaży.');}
    return;
  }
  if (e.target.closest('[data-salesbackoffice]')) { state.offerScreen='list'; state.salesScreen='list'; render(true); return; }
  if (e.target.closest('[data-salesback]')) { state.salesScreen='list'; state.salesEditId=null; render(true); return; }
  if (e.target.closest('[data-salesnew]')) { state.salesEditId=null; state.salesScreen='form'; render(true); return; }
  const salesIssue = e.target.closest('[data-salesissue]');
  if (salesIssue) {
    const sale = state.salesRecords.find(x => x.id === salesIssue.dataset.salesissue);
    if (!sale || sale.stockIssued) { toast('Nie znaleziono sprzedaży lub wydanie już wykonano.'); return; }
    const lines = Array.isArray(sale.lines) ? sale.lines : [];
    const plan = [];
    const missing = [];
    for (const line of lines) {
      const wanted = String(line.sku || line.name || '').trim().toLowerCase();
      const item = state.inventoryItems.find(x => {
        const sku = String(x.sku || '').trim().toLowerCase();
        const name = String(x.name || '').trim().toLowerCase();
        return wanted && (sku === wanted || name === wanted);
      });
      if (!item) { missing.push(line.name || 'Pozycja bez nazwy'); continue; }
      const qty = Number(line.qty) || 0;
      if (qty <= 0) continue;
      if (Number(item.qty || 0) < qty) { toast('Za mało towaru: ' + item.name + '. Stan: ' + Number(item.qty || 0) + ', wymagane: ' + qty); return; }
      plan.push({ item, qty, line });
    }
    if (missing.length) { toast('Nie znaleziono dokładnego dopasowania w magazynie: ' + missing.join(', ') + '. Uzupełnij SKU lub nazwę tak samo w magazynie i ofercie.'); return; }
    if (!plan.length) { toast('Brak pozycji do wydania.'); return; }
    if (!confirm('Wydać z magazynu ' + plan.map(x => x.item.name + ' × ' + x.qty).join('; ') + '? Tej operacji nie można wykonać ponownie dla tej sprzedaży.')) return;
    const now = new Date().toISOString();
    const moves = [];
    for (const entry of plan) {
      const before = Number(entry.item.qty) || 0;
      entry.item.qty = before - entry.qty;
      entry.item.updatedAt = now;
      const move = { id: 'move_' + Date.now() + '_' + Math.random().toString(36).slice(2,7), itemId: entry.item.id, itemName: entry.item.name, type: 'out', qty: entry.qty, purchaseUnitNet: Number(entry.item.purchaseNet) || 0, date: now.slice(0,10), party: sale.client || '', document: sale.documentNo || sale.sourceOfferNumber || '', notes: 'Wydanie do sprzedaży ' + sale.id, before, after: entry.item.qty, saleId: sale.id, createdAt: now };
      state.inventoryMoves.push(move); moves.push(move.id);
    }
    sale.stockIssued = true; sale.stockIssuedAt = now; sale.stockIssueMoves = moves; sale.updatedAt = now;
    saveInventory(); saveSalesRecords(); render(true); toast('Wydano pozycje z magazynu.'); return;
  }
  const salesPay = e.target.closest('[data-salespay]');
  if (salesPay) {
    const sale = state.salesRecords.find(x => x.id === salesPay.dataset.salespay);
    const amountEl = document.querySelector(`[data-salespayamount="${salesPay.dataset.salespay}"]`);
    const dateEl = document.querySelector(`[data-salespaydate="${salesPay.dataset.salespay}"]`);
    const amount = Number(amountEl && amountEl.value);
    if (!sale) { toast('Nie znaleziono sprzedaży.'); return; }
    if (!Number.isFinite(amount) || amount <= 0) { toast('Wpisz kwotę wpłaty większą od zera.'); return; }
    const remaining = salesRemaining(sale);
    if (amount > remaining + 0.005) { toast('Wpłata przekracza pozostałą kwotę: ' + zl(remaining)); return; }
    sale.payments = Array.isArray(sale.payments) ? sale.payments : [];
    sale.payments.push({ id: 'sale_payment_' + Date.now(), amount, date: (dateEl && dateEl.value) || new Date().toISOString().slice(0,10) });
    sale.updatedAt = new Date().toISOString();
    saveSalesRecords(); render(true); toast('Wpłatę zapisano w historii sprzedaży.'); return;
  }
  const salesPaymentDelete=e.target.closest('[data-salespaymentdelete]');
  if(salesPaymentDelete){
    const sale=state.salesRecords.find(x=>x.id===salesPaymentDelete.dataset.salespaymentdelete);
    const index=Number(salesPaymentDelete.dataset.salespaymentindex);
    if(!sale||!Array.isArray(sale.payments)||!Number.isInteger(index)||index<0||index>=sale.payments.length){toast('Nie znaleziono wpłaty.');return;}
    const payment=sale.payments[index];
    if(!confirm('Usunąć wpłatę '+zl(payment.amount)+' z dnia '+(payment.date?plDate(payment.date):'—')+'?')) return;
    sale.payments.splice(index,1);
    sale.updatedAt=new Date().toISOString();
    saveSalesRecords();render(true);toast('Usunięto wpłatę. Saldo sprzedaży przeliczono.');return;
  }
  const salesEdit = e.target.closest('[data-salesedit]');
  if (salesEdit) { state.salesEditId=salesEdit.dataset.salesedit; state.salesScreen='form'; render(true); return; }
  const salesDelete = e.target.closest('[data-salesdelete]');
  if (salesDelete) {
    if (confirm('Usunąć ten wpis rejestru sprzedaży?')) {
      state.salesRecords=state.salesRecords.filter(x=>x.id!==salesDelete.dataset.salesdelete);
      saveSalesRecords(); render(true);
    }
    return;
  }
  if (e.target.closest('[data-salessave]')) {
    const val = key => { const el=document.querySelector(`[data-salesfield="${key}"]`); return el ? el.value.trim() : ''; };
    const client=val('client'), items=val('items');
    if (!client || !items) { toast('Uzupełnij klienta i sprzedane urządzenia.'); return; }
    const gross=Number(val('gross'))||0, paid=Number(val('paid'))||0;
    if (gross<0 || paid<0) { toast('Kwoty nie mogą być ujemne.'); return; }
    const previous = state.salesRecords.find(x => x.id === state.salesEditId) || {};
    const record={...previous,id:state.salesEditId || ('sale_'+Date.now()+'_'+Math.random().toString(36).slice(2,7)),
      client,site:val('site'),contact:val('contact'),items,gross,paid,revenueNet:Number(val('revenueNet'))||0,laborCostNet:Number(val('laborCostNet'))||0,saleDate:val('saleDate'),
      dueDate:val('dueDate'),delivery:val('delivery'),document:val('document'),documentNo:val('documentNo'),notes:val('notes'),
      updatedAt:new Date().toISOString()};
    const i=state.salesRecords.findIndex(x=>x.id===record.id);
    if(i>=0) state.salesRecords[i]=record; else state.salesRecords.push(record);
    saveSalesRecords(); state.salesEditId=null; state.salesScreen='list'; render(true); toast('Zapisano wpis sprzedaży.'); return;
  }
  if (e.target.closest('[data-registersale]')) {
    const o = currentOffer();
    if (!o) { toast('Nie znaleziono oferty.'); return; }
    const existing = state.salesRecords.find(x => x.sourceOfferId === o.id);
    if (existing) {
      state.salesEditId = existing.id; state.salesScreen = 'form'; state.offerScreen = 'sales';
      render(true); toast('Ta oferta jest już w rejestrze sprzedaży. Otwieram istniejący wpis.'); return;
    }
    const totals = offerTotals(o);
    const record = {
      id: 'sale_' + Date.now() + '_' + Math.random().toString(36).slice(2,7),
      sourceOfferId: o.id, sourceOfferNumber: o.number,
      client: (o.client && o.client.name) || '',
      site: (o.client && o.client.address) || '',
      contact: [o.client && o.client.phone, o.client && o.client.email].filter(Boolean).join(' · '),
      items: (o.items || []).map(it => `${it.name} — ${it.qty || 0} ${it.unit || 'szt.'} × ${zl(it.price || 0)}`).join('\\n'),
      lines: (o.items || []).map(it => ({ name: it.name || '', qty: Number(it.qty) || 0, unit: it.unit || 'szt.', saleUnitNet: Number(it.price) || 0, category: it.category || '', sku: it.sku || '' })),
      gross: totals.gross, revenueNet: totals.net, laborCostNet: 0, paid: 0, payments: [],
      saleDate: new Date().toISOString().slice(0,10), dueDate: '',
      delivery: 'Do zamówienia',
      document: o.invoice ? 'Faktura' : 'Nie wystawiono',
      documentNo: o.invoice ? o.invoice.number : '',
      notes: 'Utworzono z zaakceptowanej oferty ' + o.number,
      updatedAt: new Date().toISOString()
    };
    state.salesRecords.push(record); saveSalesRecords();
    state.offerScreen = 'sales'; state.salesScreen = 'list'; state.salesEditId = null;
    render(true); toast('Oferta ' + o.number + ' została przeniesiona do rejestru sprzedaży.'); return;
  }
  if (e.target.closest('[data-budconfigure]')) { state.buderusConfigOpen = true; render(true); return; }
  if (e.target.closest('[data-budconfigback]')) { state.buderusConfigOpen = false; render(true); return; }
  if (e.target.closest('[data-budconfigclear]')) { state.buderusConfigSelection = {}; render(true); return; }
  if (e.target.closest('[data-budconfigoffer]')) {
    const keys = ['kociol','zasobnik','regulator','modul','czujnik','hydraulika','komin','akcesorium'];
    const products = keys.map(k => state.buderusConfigSelection[k]).filter(Boolean).map(id => window.BuderusCatalog.get(id)).filter(Boolean);
    if (!products.length || products.some(p => !p.prices || p.prices.saleNet == null)) { toast('Uzupełnij ceny wszystkich produktów.'); return; }
    const rates = [...new Set(products.map(p => Number(p.prices.vatRate)))];
    if (rates.length !== 1) { toast('Zestaw zawiera różne stawki VAT.'); return; }
    const offer = blankOffer(state.offers, state.settings);
    offer.vatRate = rates[0];
    offer.items = products.map(p => window.BuderusCatalog.toOfferItem(p));
    state.offers.push(offer); state.offerId = offer.id; state.offerScreen = 'edit'; state.buderusConfigOpen = false;
    persist(); render(true); toast('Utworzono ofertę z ' + products.length + ' produktów.'); return;
  }
  if (e.target.closest('[data-budcatalog]')) {
    state.offerScreen = 'buderus'; state.buderusEditId = null;
    state.buderusPendingProduct = null; state.buderusQuery = '';
    render(true); return;
  }
  if (e.target.closest('[data-budback]')) {
    state.offerScreen = 'list';
 state.buderusEditId = null; render(true); return;
  }
  if (e.target.closest('[data-budnew]')) { state.buderusEditId = '__new__'; render(true); return; }
  const editBud = e.target.closest('[data-budedit]');
  if (editBud) { state.buderusEditId = editBud.dataset.budedit; render(true); return; }
  if (e.target.closest('[data-budcancel]')) { state.buderusPendingProduct = null; render(true); return; }
  const addBud = e.target.closest('[data-budadd]');
  if (addBud) {
    const product = window.BuderusCatalog.get(addBud.dataset.budadd);
    if (!product) { toast('Nie znaleziono produktu.'); return; }
    if (product.prices.saleNet == null) { toast('Najpierw ustaw cenę sprzedaży netto produktu.'); return; }
    state.buderusPendingProduct = product; render(true); return;
  }
  const targetBud = e.target.closest('[data-budtarget]');
  if (targetBud) {
    const product = state.buderusPendingProduct;
    const offer = state.offers.find(o => o.id === targetBud.dataset.budtarget && !o.invoice);
    if (!product || !offer) { toast('Nie znaleziono oferty.'); return; }
    const productVat = Number(product.prices && product.prices.vatRate);
    if (!offer.items.length) offer.vatRate = productVat;
    if (Math.abs(Number(offer.vatRate) - productVat) > 0.000001) {
      toast('Ta oferta ma inną stawkę VAT. Obecny moduł ofert stosuje jedną stawkę dla całego dokumentu — nie dodano produktu, aby nie zaniżyć ani nie zawyżyć podatku.');
      return;
    }
    offer.items.push(window.BuderusCatalog.toOfferItem(product));
    state.offerId = offer.id; state.offerScreen = 'edit'; state.buderusPendingProduct = null;
    persist(); render(true); toast('Dodano produkt Buderus do oferty.'); return;
  }
  if (e.target.closest('[data-budnewoffer]')) {
    const product = state.buderusPendingProduct;
    if (!product) return;
    const offer = blankOffer(state.offers, state.settings);
    offer.vatRate = Number(product.prices && product.prices.vatRate);
    offer.items.push(window.BuderusCatalog.toOfferItem(product));
    state.offers.push(offer); state.offerId = offer.id; state.offerScreen = 'edit';
    state.buderusPendingProduct = null; persist(); render(true);
    toast('Utworzono ofertę z produktem Buderus.'); return;
  }
  if (e.target.closest('[data-budexport]')) {
    const payload = window.BuderusCatalog.exportJSON();
    const blob = new Blob([payload], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'buderus-katalog.json'; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast('Przygotowano eksport katalogu.');
    return;
  }
  if (e.target.closest('[data-budcsvexport]')) {
    const payload = window.BuderusCatalog.exportCSV();
    const blob = new Blob([payload], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'buderus-katalog.csv'; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast('Przygotowano eksport CSV do Excela.');
    return;
  }
  if (e.target.closest('[data-budsave]')) {
    const field = key => document.querySelector('[data-budfield="' + key + '"]');
    const val = key => field(key) ? field(key).value : '';
    const num = key => val(key) === '' ? null : Number(val(key).replace(',', '.'));
    const old = state.buderusEditId !== '__new__' ? window.BuderusCatalog.get(state.buderusEditId) : null;
    const payload = {
      id: old ? old.id : undefined, sku: val('sku'), name: val('name'),
      category: val('category'), description: val('description'), source: val('source'),
      sourceReference: val('sourceReference'), sourceDate: val('sourceDate'),
      active: !!(field('active') && field('active').checked),
      prices: { catalogNet:num('catalogNet'), purchaseNet:num('purchaseNet'),
        purchaseDiscountPct:num('purchaseDiscountPct'), saleNet:num('saleNet'),
        vatRate:num('vatRate') == null ? 0.23 : num('vatRate') }
    };
    try {
      const saved = window.BuderusCatalog.upsert(payload);
      state.buderusEditId = null; render(true); toast('Zapisano produkt ' + saved.sku + '.');
    } catch (err) { toast(err && err.message ? err.message : 'Nie udało się zapisać produktu.'); }
    return;
  }
  const delBud = e.target.closest('[data-buddelete]');
  if (delBud) {
    if (!window.confirm('Usunąć produkt z katalogu Buderus?')) return;
    window.BuderusCatalog.remove(delBud.dataset.buddelete);
    state.buderusEditId = null; render(true); toast('Usunięto produkt.'); return;
  }
  /* --- Dodanie wyniku kalkulatora do oferty --- */
  if (e.target.closest('[data-addoffer]')) {
    const p = state.pendingAdd;
    if (!p) return;
    /* Przy jednej ofercie w toku pytanie „do której?" byłoby zawracaniem
       głowy — pozycja idzie tam, gdzie i tak musiałaby trafić. Dopiero
       gdy ofert jest kilka, pytamy, bo inaczej grzejnik z kalkulatora
       ląduje po cichu u nie tego klienta. */
    const wToku = state.offers.filter(o => !o.invoice);
    if (wToku.length > 1) { state.wybOferty = p; renderOverlay(); return; }
    dodajPozycjeDoOferty(wToku[0] || null, p);
    return;
  }

  const doOferty = e.target.closest('[data-addto]');
  if (doOferty) {
    const p = state.wybOferty;
    state.wybOferty = null;
    if (p) dodajPozycjeDoOferty(state.offers.find(o => o.id === doOferty.dataset.addto) || null, p);
    else renderOverlay();
    return;
  }
  if (e.target.closest('[data-addtonew]')) {
    const p = state.wybOferty;
    state.wybOferty = null;
    if (p) dodajPozycjeDoOferty(null, p); else renderOverlay();
    return;
  }
  /* Zamknięcie krzyżykiem w nagłówku albo dotknięciem tła obok arkusza.
     Wnętrze arkusza ma data-stop, więc kliknięcie w nie nie zamyka —
     poza samym krzyżykiem, który jest w nim celowo. */
  if (e.target.closest('[data-closewyb]')
      && (!e.target.closest('[data-stop]') || e.target.closest('.sheet-h [data-closewyb]'))) {
    state.wybOferty = null; renderOverlay(); return;
  }
  if (e.target.closest('[data-toastgo]')) {
    hideToast();
    /* Ten sam przycisk obsługuje dwie sprawy: cofnięcie kasowania i skok
       do oferty po dodaniu pozycji z kalkulatora. Rozstrzyga to, czy jest
       co cofać — po pięciu sekundach pasek i tak znika razem z jednym
       i z drugim. */
    if (state.cofnij) { cofnijUsuniecie(); return; }
    /* Cofnięcie wczytanej kopii — jedyna operacja, która potrafi
       podmienić wszystko naraz, więc droga powrotna jest tuż obok. */
    if (state.kopiaCofnij) { cofnijWczytanie(); return; }
    /* Trzecia sprawa: skok do średnic po dopisaniu grzejnika. */
    if (state.dopisano) { state.dopisano = false; doSrednicCO(); return; }
    if (state.dopisanoRozdz) { state.dopisanoRozdz = false; doRozdzielaczy(); return; }
    state.tab = 'offers'; state.offerScreen = 'edit';
    render(true);
    // przewijamy na dół, bo nowa pozycja jest ostatnia na liście
    const vp = document.getElementById('viewport');
    if (vp) vp.scrollTop = vp.scrollHeight;
    return;
  }

  /* ---------- Baza klientów ---------- */
  if (e.target.closest('[data-klienci]')) {
    state.offerScreen = 'klienci'; state.klientId = null; state.klientQ = '';
    render(true); return;
  }
  if (e.target.closest('[data-klienciback]')) {
    state.offerScreen = 'list';
 state.klientQ = ''; render(true); return;
  }
  if (e.target.closest('[data-klientback]')) {
    /* Klient bez nazwy, dodany i porzucony, nie ma po co zostawać na liście. */
    const k = currentKlient();
    if (k && klientPusty(k)) {
      state.klienci = state.klienci.filter(x => x.id !== k.id);
      persistKlienci();
    }
    state.klientId = null; render(true); return;
  }
  if (e.target.closest('[data-nowyklient]')) {
    const k = blankKlient();
    state.klienci.push(k); state.klientId = k.id;
    persistKlienci(); render(true); return;
  }
  const otwKl = e.target.closest('[data-openklient]');
  if (otwKl) { state.klientId = otwKl.dataset.openklient; render(true); return; }
  const equipmentAdd=e.target.closest('[data-kleqadd]');
  if(equipmentAdd){
    const k=currentKlient();if(!k)return;
    const get=n=>document.querySelector(`[data-kleq="${n}"]`)?.value?.trim()||'';
    const brand=get('brand'),model=get('model');
    if(!brand&&!model){toast('Podaj producenta lub model urządzenia.');return;}
    k.equipment=Array.isArray(k.equipment)?k.equipment:[];
    const serial=get('serial');
    if(serial&&k.equipment.some(q=>String(q.serial||'').toLowerCase()===serial.toLowerCase())){toast('Urządzenie o takim numerze seryjnym jest już zapisane u tego klienta.');return;}
    k.equipment.push({id:'eq_'+Date.now().toString(36),brand,model,serial,location:get('location'),installedAt:get('installedAt'),warrantyUntil:get('warrantyUntil'),nextServiceDate:get('nextServiceDate'),notes:get('notes'),createdAt:new Date().toISOString()});
    persistKlienci();
    if(get('nextServiceDate')) {
      const when=new Date(get('nextServiceDate')+'T09:00:00');
      if(when>new Date() && typeof wtyczka==='function') {
        try { const ln=wtyczka('LocalNotifications'); if(ln){ const notifId=300000000+Math.abs(String(k.id+serial+get('nextServiceDate')).split('').reduce((a,c)=>a*31+c.charCodeAt(0)|0,7)); const permission=await ln.requestPermissions(); if(!permission||!permission.display||permission.display==='granted') await ln.schedule({notifications:[{id:notifId,title:'Przegląd urządzenia',body:[brand,model].filter(Boolean).join(' ')+' — '+(k.name||'klient'),schedule:{at:when,allowWhileIdle:true},extra:{clientId:k.id,equipmentId:k.equipment[k.equipment.length-1].id}}]}); } } catch(_) {}
      }
    }
    render(true);toast('Dodano urządzenie do karty klienta.');return;
  }
  const equipmentDelete=e.target.closest('[data-kleqdelete]');
  if(equipmentDelete){const k=currentKlient();if(!k)return;if(confirm('Usunąć urządzenie z karty klienta? Historia serwisowa pozostanie bez zmian.')){k.equipment=(k.equipment||[]).filter(q=>q.id!==equipmentDelete.dataset.kleqdelete);persistKlienci();render(true);toast('Usunięto urządzenie.');}return;}
  const crmAdd=e.target.closest('[data-klcrmadd]');
  if(crmAdd){
    const k=currentKlient(); if(!k)return;
    const get=n=>document.querySelector(`[data-klcrm="${n}"]`)?.value?.trim()||'';
    const description=get('description');
    if(!description){toast('Wpisz opis wizyty lub ustaleń.');return;}
    k.serviceHistory=Array.isArray(k.serviceHistory)?k.serviceHistory:[];
    k.serviceHistory.push({id:'crm_'+Date.now().toString(36),date:get('date')||new Date().toISOString().slice(0,10),type:get('type')||'Inne',equipment:get('equipment'),description,amount:get('amount'),createdAt:new Date().toISOString()});
    persistKlienci(); render(true); toast('Dodano wpis do historii klienta.'); return;
  }
  const crmDelete=e.target.closest('[data-klcrmdelete]');
  if(crmDelete){const k=currentKlient();if(!k)return;k.serviceHistory=(k.serviceHistory||[]).filter(x=>x.id!==crmDelete.dataset.klcrmdelete);persistKlienci();render(true);toast('Usunięto wpis historii.');return;}

  const delKl = e.target.closest('[data-delklient]');
  if (delKl) {
    const i = state.klienci.findIndex(x => x.id === delKl.dataset.delklient);
    if (i < 0) return;
    const k = state.klienci[i];
    state.cofnij = { typ: 'klient', poz: i, dane: k, opis: k.name || 'bez nazwy' };
    state.klienci.splice(i, 1);
    persistKlienci(); render(false);
    toast('Usunięto ' + (k.name || 'klienta') + ' z bazy. Oferty zostają.', 'Cofnij');
    return;
  }

  /* Zapisanie danych z oferty do bazy. Klient już znany jest uaktualniany,
     a nie dopisywany drugi raz — inaczej po trzech wizytach ta sama pani
     Kowalska byłaby na liście trzy razy, za każdym razem z innym telefonem. */
  if (e.target.closest('[data-klientzapisz]')) {
    const o = currentOffer();
    if (!o) return;
    const nowy = klientZOferty(o);
    if (klientPusty(nowy)) { toast('Najpierw wpisz dane klienta.'); return; }
    const stary = state.klienci.find(x => klientTenSam(x, nowy));
    if (stary) {
      KLIENT_POLA.forEach(p => { if (nowy[p]) stary[p] = nowy[p]; });
      persistKlienci(); render(false);
      toast('Uaktualniono ' + (stary.name || 'klienta') + ' w bazie.');
    } else {
      state.klienci.push(nowy);
      persistKlienci(); render(false);
      toast('Dodano ' + (nowy.name || 'klienta') + ' do bazy. Następnym razem wybierzesz go z listy.');
    }
    return;
  }

  if (e.target.closest('[data-klientwybierz]')) {
    if (!state.klienci.length) { toast('Baza jest pusta — najpierw dodaj klienta.'); return; }
    state.klientQ = ''; state.pickKlient = true; renderOverlay(); return;
  }
  if (e.target.closest('[data-closeklient]')
      && (!e.target.closest('[data-stop]') || e.target.closest('.sheet-h [data-closeklient]'))) {
    state.pickKlient = false; renderOverlay(); return;
  }
  const bierz = e.target.closest('[data-klientbierz]');
  if (bierz) {
    const o = currentOffer();
    const k = state.klienci.find(x => x.id === bierz.dataset.klientbierz);
    if (o && k) {
      klientDoOferty(o, k);
      persist();
      state.pickKlient = false;
      render(false);
      toast('Wstawiono dane: ' + (k.name || 'klient') + '.');
    }
    return;
  }

  if (e.target.closest('[data-newoffer]')) {
    const o = blankOffer(state.offers, state.settings);
    state.offers.push(o); state.offerId = o.id; state.offerScreen = 'edit';
    persist(); render(true); return;
  }
  const open = e.target.closest('[data-openoffer]');
  if (open) { state.offerId = open.dataset.openoffer; state.offerScreen = 'edit'; render(true); return; }

  if (e.target.closest('#backoffers')) { state.offerScreen = 'list';
 render(true); return; }
  if (e.target.closest('#backedit')) { state.offerScreen = 'edit'; render(true); return; }
  if (e.target.closest('[data-showdoc]')) { state.offerScreen = 'doc'; render(true); return; }
  if (e.target.closest('[data-pdf]')) { zapiszPdf(); return; }
  if (e.target.closest('[data-mailoffer]')) { wyslijDokument(false); return; }
  if (e.target.closest('[data-mailinv]')) { wyslijDokument(true); return; }
  if (e.target.closest('[data-makeinvoice]')) { state.offerScreen = 'invoice'; render(true); return; }

  /* Wejście prosto z listy faktur — pomija ekran oferty i otwiera dokument. */
  const del = e.target.closest('[data-delrow]');
  if (del) {
    state.usunPyt = { co: del.dataset.what === 'inv' ? 'faktura' : 'oferta', id: del.dataset.delrow };
    renderOverlay();
    return;
  }

  /* Odpowiedzi na pytanie o usunięcie. „Nie" łapiemy też kliknięciem w tło
     arkusza, dlatego sprawdzamy, czy kliknięcie nie padło w jego wnętrze. */
  if (state.usunPyt && e.target.closest('[data-usuntak]')) {
    const q = state.usunPyt; state.usunPyt = null;
    if (q.co === 'faktura') usunFakture(q.id); else usunOferte(q.id);
    return;
  }
  if (state.usunPyt && e.target.closest('[data-usunnie]')
      && (!e.target.closest('[data-stop]') || e.target.closest('.usun-nie')
          || e.target.closest('.sheet-h [data-usunnie]'))) {
    state.usunPyt = null; renderOverlay(); return;
  }

  const otwInv = e.target.closest('[data-openinv]');
  if (otwInv) {
    state.offerId = otwInv.dataset.openinv;
    state.offerScreen = 'invoice';
    render(true); return;
  }

  const zapl = e.target.closest('[data-paid]');
  if (zapl) {
    const o = currentOffer();
    if (o && o.invoice) {
      o.invoice.paid = !o.invoice.paid;
      /* Data podstawia się dzisiejsza, bo tak jest w dziewięciu przypadkach
         na dziesięć, ale zostaje do poprawienia — przelew potrafi wpaść
         w piątek, a fakturę odhacza się w poniedziałek. */
      if (o.invoice.paid && !o.invoice.paidAt) o.invoice.paidAt = todayISO();
      if (!o.invoice.paid) o.invoice.paidAt = '';
      persist(); render(false);
      toast(o.invoice.paid ? 'Oznaczono jako zapłaconą.' : 'Zdjęto oznaczenie zapłaty.');
    }
    return;
  }
  if (e.target.closest('[data-doedycji]')) {
    const o = currentOffer();
    if (!o) return;
    state.offerScreen = 'edit';
    render(true);
    toast('Poprawiasz ofertę ' + o.number + '. Faktura '
      + (o.invoice ? o.invoice.number : '') + ' przeliczy się sama.');
    return;
  }

  if (e.target.closest('[data-gus]')) {
    const o = currentOffer();
    if (!o) return;
    const btn = e.target.closest('[data-gus]');
    btn.disabled = true; btn.textContent = 'Pobieram…';
    pobierzZWykazu(o.client.nip, w => {
      if (w.err) { toast(w.err); const gb = document.getElementById('gusbox'); if (gb) gb.innerHTML = gusBtnHtml(o); return; }
      o.client.name = w.name || o.client.name;
      o.client.address = w.addr || o.client.address;
      persist();
      render(false);
      toast(w.status && w.status !== 'Czynny'
        ? 'Pobrano dane. Uwaga: status VAT tej firmy to „' + w.status + '".'
        : 'Pobrano dane z wykazu.');
    });
    return;
  }
  if (e.target.closest('[data-ksefxml]')) {
    const o = currentOffer();
    if (!o || !o.invoice) return;
    const st = state.settings || DEFAULT_SETTINGS;
    const xml = ksefInvoiceXml(ksefPayload(o, st));
    const nazwa = 'KSeF_' + String(o.invoice.number).replace(/[^\w-]+/g, '_') + '.xml';
    state.xmlSheet = { name: nazwa, xml,
      note: 'Plik w strukturze FA(3). Zapisz go na dysk albo zaznacz i skopiuj, a potem wgraj w Aplikacji Podatnika KSeF. W podglądzie w przeglądarce zapis pliku bywa zablokowany — w aplikacji na telefonie działa normalnie.' };
    renderOverlay();
    return;
  }
  if (e.target.closest('[data-xmlsave]')) {
    const d = state.xmlSheet;
    if (d) pobierzPlik(d.name, d.xml, 'application/xml',
      w => toast(w.ok
        ? 'Zapisano ' + d.name + (w.gdzie ? ' w folderze ' + w.gdzie : '')
        : w.powod));
    return;
  }
  if (e.target.closest('[data-xmlcopy]')) {
    const d = state.xmlSheet;
    const ta = document.querySelector('.sheet-body textarea');
    if (!d || !ta) return;
    /* Zaznaczenie zostawiamy nawet po skopiowaniu — gdyby schowek był
       zablokowany, użytkownik ma gotowy zaznaczony tekst do skopiowania ręcznie. */
    ta.focus(); ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch (err) { ok = false; }
    if (!ok && navigator.clipboard) {
      navigator.clipboard.writeText(d.xml)
        .then(() => toast('Skopiowano treść pliku.'))
        .catch(() => toast('Schowek zablokowany — tekst jest zaznaczony, skopiuj go ręcznie.'));
      return;
    }
    toast(ok ? 'Skopiowano treść pliku.' : 'Tekst jest zaznaczony — skopiuj go ręcznie.');
    return;
  }
  if (e.target.closest('[data-closexml]')) {
    state.xmlSheet = null; renderOverlay(); return;
  }
  if (e.target.closest('#backdoc')) { state.offerScreen = 'doc'; render(true); return; }
  const ct = e.target.closest('[data-ctype]');
  if (ct) {
    const o = currentOffer();
    if (o) { o.client.type = ct.dataset.ctype; persist(); render(false); }
    return;
  }

  if (e.target.closest('[data-deloffer]')) { state.usunPyt = { co: 'oferta', id: state.offerId }; renderOverlay(); return; }

  if (e.target.closest('[data-additem]')) {
    /* Otwieramy zawsze na liście działów. Wracanie do miejsca sprzed
       tygodnia byłoby zagadką, a nie ułatwieniem. */
    state.picker = true; state.pickGrp = null; state.pickDn = null;
    state.pickWar = null; state.pickQ = ''; state.pickSel = null;
    renderOverlay(); return;
  }

  const pgrp = e.target.closest('[data-pickgrp]');
  if (pgrp) { state.pickGrp = pgrp.dataset.pickgrp; state.pickDn = null; state.pickWar = null; renderOverlay(); return; }

  const pdn = e.target.closest('[data-pickdn]');
  if (pdn) { state.pickDn = pdn.dataset.pickdn; state.pickWar = null; renderOverlay(); return; }

  const pwar = e.target.closest('[data-pickwar]');
  if (pwar) { state.pickWar = pwar.dataset.pickwar; renderOverlay(); return; }

  const pback = e.target.closest('[data-pickback]');
  if (pback) {
    const dokad = pback.dataset.pickback;
    /* Z szukania wracamy tam, skąd użytkownik zaczął szukać — poziom
       zostaje, znika tylko wpisana fraza. */
    if (dokad === 'q') state.pickQ = '';
    else if (dokad === 'war') state.pickWar = null;
    else if (dokad === 'dn') { state.pickDn = null; state.pickWar = null; }
    else { state.pickGrp = null; state.pickDn = null; state.pickWar = null; }
    renderOverlay(); return;
  }

  if (e.target.closest('[data-custom]')) {
    const o = currentOffer();
    if (o) { o.items.push(blankItem()); persist(); }
    state.picker = false; renderKeepScroll();
    // od razu ustawiamy kursor w nazwie nowej pozycji i zaznaczamy tekst
    const inputs = document.querySelectorAll('[data-iname]');
    const last = inputs[inputs.length - 1];
    if (last) { last.focus(); last.select(); last.scrollIntoView({ block: 'center' }); }
    return;
  }

  /* Plus i minus działają zawsze — także wtedy, gdy koszyk jest jeszcze
     pusty. Pierwsze naciśnięcie plusa po prostu go otwiera. */
  const qp = e.target.closest('[data-qplus]');
  if (qp) { zmienIlosc(qp.dataset.qplus, +1); odswiezPicker(); return; }
  const qm = e.target.closest('[data-qminus]');
  if (qm) { zmienIlosc(qm.dataset.qminus, -1); odswiezPicker(); return; }

  const pick = e.target.closest('[data-pick]');
  if (pick) {
    /* Kliknięcie przychodzi po puszczeniu palca, więc po udanym
       przytrzymaniu trzeba je pominąć — inaczej od razu odznaczyłoby to,
       co właśnie zostało zaznaczone. */
    if (dlugiZaszlo) { dlugiZaszlo = false; return; }
    if (state.pickSel) { zaznaczPozycje(pick.dataset.pick); odswiezPicker(); return; }
    const c = catalogById(pick.dataset.pick);
    const o = currentOffer();
    if (c && o) { o.items.push(itemFromCatalog(c, 1)); persist(); }
    state.picker = false; state.pickQ = ''; renderKeepScroll(); return;
  }

  if (e.target.closest('[data-selcancel]')) {
    state.pickSel = null; odswiezPicker(); return;
  }

  if (e.target.closest('[data-seladd]')) {
    const o = currentOffer();
    const ids = Object.keys(state.pickSel || {});
    if (!o || !ids.length) { state.pickSel = null; odswiezPicker(); return; }
    ids.forEach(id => {
      const c = catalogById(id);
      if (c) o.items.push(itemFromCatalog(c, state.pickSel[id]));
    });
    const ile = ids.length;
    persist();
    state.pickSel = null; state.picker = false; state.pickQ = '';
    renderKeepScroll();
    toast('Dodano ' + ile + (ile === 1 ? ' pozycję' : (ile < 5 ? ' pozycje' : ' pozycji')) + ' do oferty.');
    return;
  }

  /* Pozycja, której nie ma w bazie. Nie zakładamy jej w katalogu od razu:
     wpis „Nowa pozycja" za 0 zł byłby śmieciem, gdyby użytkownik się
     rozmyślił. Zamiast tego zapamiętujemy przy niej, do jakiego działu
     ma trafić — a katalog przyjmie ją, gdy dostanie nazwę i cenę. */
  if (e.target.closest('[data-newin]')) {
    const o = currentOffer();
    if (!o) return;
    const it = blankItem();
    it.katGrp = state.pickGrp || null;
    if (state.pickDn && state.pickDn !== '*') it.katDn = state.pickDn;
    o.items.push(it); persist();
    state.picker = false; state.pickSel = null; state.pickQ = '';
    renderKeepScroll();
    const pola = document.querySelectorAll('[data-iname]');
    const ostatnie = pola[pola.length - 1];
    if (ostatnie) { ostatnie.focus(); ostatnie.select(); ostatnie.scrollIntoView({ block: 'center' }); }
    toast('Wpisz nazwę i cenę — pozycja trafi do działu „' + (it.katGrp || 'Moje pozycje') + '".');
    return;
  }

  const catFix = e.target.closest('[data-icatfix]');
  if (catFix) {
    const it = currentOffer().items[+catFix.dataset.icatfix];
    it.cat = guessCat(it.name); it.catManual = true;
    persist(); ucz(+catFix.dataset.icatfix); renderKeepScroll(); return;
  }

  const cat = e.target.closest('[data-icat]');
  if (cat) {
    const o = currentOffer();
    const it = o.items[+cat.dataset.icat];
    it.cat = it.cat === 'rob' ? 'mat' : 'rob';
    it.catManual = true;          // ręczny wybór wyłącza podpowiedzi
    /* Materiał czy robocizna decyduje o tym, gdzie pozycja stoi na dokumencie
       i czy dolicza się do niej marża — katalog musi wiedzieć to samo. */
    persist(); ucz(+cat.dataset.icat); renderKeepScroll(); return;
  }
  // zamknięcie arkusza: krzyżyk albo tło (ale nie klik w samą zawartość)
  const close = e.target.closest('[data-closepicker]');
  if (close && (close.classList.contains('sheet') ? e.target === close : true)) {
    state.picker = false; state.pickSel = null; renderOverlay(); return;
  }

  const di = e.target.closest('[data-delitem]');
  if (di) { const o = currentOffer(); o.items.splice(+di.dataset.delitem, 1); persist(); renderKeepScroll(); return; }
});

document.addEventListener('input', e => {
  const t = e.target;
  if (t.dataset && t.dataset.budq !== undefined) {
    state.buderusQuery = t.value;
    const list = document.getElementById('bud-list');
    if (list) list.innerHTML = buderusListHtml();
    return;
  }

  /* Wyszukiwarka katalogu żyje w oknie nakładki, a nie w ofercie —
     dlatego obsługujemy ją przed sprawdzeniem, czy oferta jest otwarta. */
  if (t.dataset && t.dataset.pickq !== undefined) {
    state.pickQ = t.value;
    odswiezPicker();
    return;
  }

  /* Szukanie w bazie klientów — i w arkuszu wyboru, i na ekranie listy.
     Przy arkuszu przerysowujemy samą listę pod polem, żeby kursor
     nie wyskakiwał z wyszukiwarki po każdej literze. */
  if (t.dataset && t.dataset.klientq !== undefined) {
    state.klientQ = t.value;
    const wybor = !!state.pickKlient;
    const gdzie = wybor ? document.querySelector('.sheet-body .olist')
                        : document.querySelector('.body .olist');
    if (gdzie) gdzie.outerHTML = klientListaHtml(wybor);
    return;
  }

  /* Pola klienta w bazie. Zapisujemy po każdej literze, ale ekranu nie
     przerysowujemy — poza przełącznikiem rodzaju, który odsłania NIP. */
  if (t.dataset && t.dataset.kl) {
    const k = currentKlient();
    if (!k) return;
    k[t.dataset.kl] = t.value;
    persistKlienci();
    return;
  }

  const o = currentOffer();
  if (!o) return;

  if (t.dataset.inv) {
    if (!o.invoice) o.invoice = makeInvoice(o, state.offers, state.settings);
    const k = t.dataset.inv;
    o.invoice[k] = k === 'dueDays' ? (t.value === '' ? 0 : parseInt(t.value, 10) || 0) : t.value;
    persist();
    /* Stopkę przepisujemy prosto do dokumentu — przerysowanie ekranu
       wyrzuciłoby kursor z pola w połowie zdania. */
    if (k === 'footer') {
      autosize(t);
      const d = document.getElementById('docfoot');
      if (d) d.innerHTML = t.value
        ? '<div class="doc-note">' + esc(t.value).replace(/\n/g, '<br>') + '</div>' : '';
      return;
    }
    /* Numer i daty przepisujemy na dokument bez przerysowania całego ekranu,
       żeby kursor nie wyskakiwał z pola w trakcie pisania. */
    if (state.offerScreen === 'invoice' && (k === 'dueDays' || k === 'method')) renderKeepScroll();
    return;
  }
  if (t.dataset.of) {
    const k = t.dataset.of;
    if (k === 'marginPct') o.marginPct = t.value === '' ? 0 : parseFloat(t.value);
    else if (k === 'vatRate') o.vatRate = parseFloat(t.value);
    else o.client[k] = t.value;
    persist();
    // kwoty przeliczamy bez przerysowania, żeby nie wyrzucało kursora z pola
    refreshOfferTotals();
    refreshInvoiceBlocks();
    const gb = document.getElementById('gusbox');
    if (gb && k === 'nip') gb.innerHTML = gusBtnHtml(o);
    return;
  }
  // Nazwa pozycji: kwoty się nie zmieniają, ale kontrola kompletności rozpoznaje
  // pozycję po nazwie, więc odświeżamy ją na żywo — bez ruszania reszty ekranu.
  if (t.dataset.iname !== undefined && t.dataset.cname === undefined) {
    const i = +t.dataset.iname;
    o.items[i].name = t.value;
    autosize(t); persist();
    refreshChecks(); refreshItemFoot(i);
    return;
  }
  // jednostka
  if (t.dataset.iu !== undefined) {
    o.items[+t.dataset.iu].unit = t.value;
    persist(); return;
  }
  if (t.dataset.iq !== undefined || t.dataset.ip !== undefined) {
    const idx = +(t.dataset.iq !== undefined ? t.dataset.iq : t.dataset.ip);
    const val = t.value === '' ? 0 : parseFloat(t.value);
    if (t.dataset.iq !== undefined) o.items[idx].qty = val; else o.items[idx].price = val;
    persist();
    const sum = t.closest('.item').querySelector('.item-sum');
    if (sum) sum.textContent = zl((o.items[idx].qty || 0) * (o.items[idx].price || 0));
    refreshOfferTotals();
  }
});

document.addEventListener('change', async e => {
  const input=e.target.closest('[data-salesrestore]');
  if(!input) return;
  const file=input.files && input.files[0];
  if(!file) return;
  try{
    const payload=JSON.parse(await file.text());
    const records=Array.isArray(payload)?payload:payload.records;
    if(!Array.isArray(records)||(!Array.isArray(payload)&&payload.schema!=='asystent-instalatora-sales-register')){
      toast('Plik nie jest kopią rejestru sprzedaży tej aplikacji.');input.value='';return;
    }
    if(!records.every(x=>x&&typeof x==='object'&&!Array.isArray(x)&&x.id)){
      toast('Kopia zawiera nieprawidłowe rekordy.');input.value='';return;
    }
    if(!confirm('Zastąpić obecny rejestr sprzedaży danymi z kopii? Aktualne wpisy zostaną nadpisane.')){input.value='';return;}
    state.salesRecords=records;saveSalesRecords();state.salesScreen='list';state.salesEditId=null;render(true);
    toast('Przywrócono rejestr sprzedaży z kopii JSON.');
  }catch(err){toast('Nie udało się odczytać kopii rejestru sprzedaży.');}
  input.value='';
});
document.addEventListener('change', e => {
  if(e.target.dataset && e.target.dataset.pdocimportjson!==undefined && e.target.files && e.target.files[0]){
    const file=e.target.files[0], reader=new FileReader();
    reader.onload=()=>{
      try{
        const data=JSON.parse(String(reader.result||''));
        if(!data||data.schema!=='asystent-instalatora-purchase-docs'||data.version!==1||!Array.isArray(data.documents)) throw new Error('Nieprawidłowy format kopii.');
        const valid=data.documents.every(x=>x&&typeof x.id==='string'&&typeof x.supplier==='string'&&typeof x.number==='string'&&Number.isFinite(Number(x.gross)));
        if(!valid) throw new Error('Kopia zawiera nieprawidłowe rekordy.');
        if(!confirm('Przywrócić '+data.documents.length+' dokumentów? Obecny rejestr zostanie zastąpiony.')) return;
        state.purchaseDocs=data.documents; savePurchaseDocs(); state.purchaseDocScreen='list'; render(true); toast('Przywrócono kopię dokumentów wraz z historią wpłat i załącznikami.');
      }catch(err){toast(err.message||'Nie udało się odczytać kopii JSON.');}
      finally{e.target.value='';}
    };
    reader.onerror=()=>{toast('Nie udało się odczytać pliku kopii.');e.target.value='';};
    reader.readAsText(file); return;
  }
  if (e.target.dataset && e.target.dataset.pdocfile !== undefined && e.target.files && e.target.files[0]) {
    const file=e.target.files[0];
    if (!/^application\/pdf$|^image\/(jpeg|png)$/.test(file.type)) { toast('Dozwolony jest PDF, JPG lub PNG.'); e.target.value=''; return; }
    if (file.size > 2*1024*1024) { toast('Plik jest za duży. Maksymalny rozmiar załącznika to 2 MB.'); e.target.value=''; return; }
    const reader=new FileReader();
    reader.onload=()=>{ state.purchaseDocDraft=state.purchaseDocDraft||{}; state.purchaseDocDraft.attachment={name:file.name,type:file.type,size:file.size,data:String(reader.result||'')}; render(true); toast('Dodano załącznik do dokumentu.'); };
    reader.onerror=()=>toast('Nie udało się odczytać załącznika.');
    reader.readAsDataURL(file); return;
  }
  if (e.target.dataset && e.target.dataset.budconfigcategory) {
    const key = e.target.dataset.budconfigcategory;
    if (e.target.value) state.buderusConfigSelection[key] = e.target.value; else delete state.buderusConfigSelection[key];
    render(true); return;
  }
  if (e.target.dataset && e.target.dataset.budimport !== undefined && e.target.files && e.target.files[0]) {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const result = window.BuderusCatalog.importJSON(String(reader.result || ''), { updateExisting: true });
        state.buderusEditId = null; state.buderusQuery = '';
        render(true); toast('Zaimportowano katalog. Liczba pozycji w pliku: ' + result.imported + '.');
      } catch (err) {
        toast(err && err.message ? err.message : 'Nie udało się zaimportować katalogu.');
      }
    };
    reader.onerror = () => toast('Nie udało się odczytać pliku.');
    reader.readAsText(file);
    e.target.value = '';
    return;
  }
  if (e.target.dataset && e.target.dataset.budcsvimport !== undefined && e.target.files && e.target.files[0]) {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const result = window.BuderusCatalog.importCSV(String(reader.result || ''), { updateExisting: true });
        state.buderusEditId = null; state.buderusQuery = '';
        render(true); toast('Zaimportowano CSV. Liczba pozycji w pliku: ' + result.imported + '.');
      } catch (err) {
        toast(err && err.message ? err.message : 'Nie udało się zaimportować pliku CSV.');
      }
    };
    reader.onerror = () => toast('Nie udało się odczytać pliku CSV.');
    reader.readAsText(file, 'UTF-8');
    e.target.value = '';
    return;
  }
  if (e.target.dataset && e.target.dataset.of === 'vatRate') render(false);

  /* Rodzaj klienta decyduje, czy w ogóle pokazujemy pole NIP. */
  if (e.target.dataset && e.target.dataset.kl === 'type') {
    const k = currentKlient();
    if (k) { k.type = e.target.value; persistKlienci(); render(false); }
    return;
  }

  /* Katalog zapisujemy dopiero tutaj, przy „change" — to zdarzenie przychodzi,
     gdy użytkownik skończy pisać i wyjdzie z pola, a nie przy każdej literze.
     Dzięki temu do cennika trafia „Montaż zlewu podtynkowego", a nie kilkanaście
     kolejnych początków tej nazwy. */
  const t = e.target;
  if (!t.dataset) return;
  const i = ['iname', 'ip', 'iu'].map(k => t.dataset[k]).find(v => v !== undefined);
  if (i === undefined || t.dataset.cname !== undefined) return;
  ucz(+i);
});

/* ============================================================
   NAUKA KATALOGU Z BIEŻĄCEJ POZYCJI
   ------------------------------------------------------------
   Nową pozycję zgłaszamy paskiem z możliwością cofnięcia, bo to zmiana
   w cenniku, której użytkownik nie prosił wprost — ma prawo wiedzieć,
   że zaszła, i wycofać ją jednym dotknięciem. Zmiany samej ceny nie
   ogłaszamy paskiem za każdym razem; wspominamy o niej tylko przy
   pozycji, żeby nie zasypywać ekranu komunikatami przy poprawianiu
   kilku cen z rzędu.
   ============================================================ */
function ucz(i) {
  const o = currentOffer();
  if (!o || !o.items[i]) return;
  const w = katalogZOferty(o.items[i], state.catalog);
  if (w.co === 'nic') return;

  persist(); persistCatalog();
  /* Pozycja dostała właśnie powiązanie z katalogiem — znacznik „w katalogu"
     ma się pojawić od razu, a nie dopiero przy następnym przerysowaniu. */
  refreshItemFoot(i);

  if (w.co === 'nowa') {
    state.cofnij = { typ: 'katalog', id: w.poz.id, opis: w.poz.name };
    toast('Dodano „' + w.poz.name + '" do katalogu cen.', 'Cofnij');
  } else {
    state.cofnij = { typ: 'katalogCena', id: w.poz.id, dane: w.poprzednia, opis: w.poz.name };
    toast('Zapisano nową cenę „' + w.poz.name + '" w katalogu.', 'Cofnij');
  }
}


/* Przeliczenie podsumowania i nagłówka bez przebudowy całego ekranu */
function refreshOfferTotals() {
  const o = currentOffer();
  if (!o || state.offerScreen !== 'edit') return;
  const t = offerTotals(o);
  const rows = document.querySelectorAll('.body > .rows .r b');
  if (rows.length === 6) {
    const vals = [t.netMat, t.margin, t.netRob, t.net, t.vat, t.gross];
    rows.forEach((b, i) => b.textContent = zl(vals[i]));
  }
  const sub = document.querySelector('.hdr--cat .hdr-row p');
  if (sub) sub.textContent = `${zl(t.gross)} brutto · ${t.count} pozycji`;
}

