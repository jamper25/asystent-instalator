/* ===== pdf.js ===== */
/* ============================================================
   SKŁADANIE PLIKÓW PDF
   ------------------------------------------------------------
   Aplikacja sama pisze plik PDF — bajt po bajcie — zamiast prosić
   system o wydruk ekranu. Powód jest prosty: wydruk ekranu daje plik
   dopiero wtedy, gdy użytkownik przejdzie przez okno drukowania
   i sam wybierze, gdzie go zapisać. Takiego pliku nie da się dołączyć
   do maila w tej samej chwili, w której klient go potrzebuje.

   Plik składany tutaj jest gotowy od razu: powstaje w pamięci, trafia
   do załącznika i idzie do klienta jednym naciśnięciem.

   PDF to nie obrazek. Tekst w środku jest prawdziwym tekstem — da się
   go zaznaczyć, skopiować i wyszukać, a przy powiększeniu nie rozmywa się.
   Żeby polskie ogonki w ogóle się pojawiły, w pliku siedzi wycinek
   czcionki DejaVu (patrz fonty.js): wbudowane czcionki formatu PDF
   nie mają ani ą, ani ę, ani ł.
   ============================================================ */

const PDF_STRONA = { w: 595.28, h: 841.89 };   /* A4 w punktach */
const PDF_MARG = 48;
const PDF_DOL = 56;                            /* miejsce na stopkę i numer strony */

/* --- Bajty i base64 -------------------------------------------------- */

function pdfZB64(b64) {
  if (typeof atob === 'function') {
    const s = atob(b64);
    const out = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
    return out;
  }
  return new Uint8Array(Buffer.from(b64, 'base64'));
}

function pdfDoB64(bajty) {
  if (typeof btoa === 'function') {
    let s = '';
    /* Porcjami, bo btoa na kilkuset kilobajtach naraz potrafi przepełnić stos. */
    for (let i = 0; i < bajty.length; i += 8192) {
      s += String.fromCharCode.apply(null, bajty.subarray(i, i + 8192));
    }
    return btoa(s);
  }
  return Buffer.from(bajty).toString('base64');
}

/* --- Miara tekstu ---------------------------------------------------- */

/* Znak, którego nie ma w wycinku czcionki, zastępujemy pytajnikiem —
   lepszy widoczny pytajnik niż pusty prostokąt albo dziura w zdaniu. */
function pdfGlif(font, znak) {
  const g = font.gid[znak.codePointAt(0)];
  return g === undefined ? (font.gid[63] || 0) : g;
}

function pdfSzerokosc(tekst, font, rozmiar) {
  let suma = 0;
  for (const z of String(tekst)) suma += font.szer[pdfGlif(font, z)] || 500;
  return suma * rozmiar / 1000;
}

/* Tekst w PDF-ie zapisujemy numerami glifów po dwa bajty (kodowanie
   Identity-H). To jedyny sposób, w jaki czcionka z osadzonym wycinkiem
   potrafi pokazać znak spoza podstawowego alfabetu. */
function pdfHex(tekst, font) {
  let out = '';
  for (const z of String(tekst)) out += pdfGlif(font, z).toString(16).padStart(4, '0');
  return out;
}

/* Łamanie wiersza na podanej szerokości — po słowach, a gdy pojedyncze
   słowo nie mieści się w kolumnie, to po znakach. */
function pdfZawin(tekst, font, rozmiar, szer) {
  const slowa = String(tekst).split(/\s+/).filter(Boolean);
  const wiersze = [];
  let biez = '';
  const dopchnij = s => {
    let kawalek = '';
    for (const z of s) {
      if (pdfSzerokosc(kawalek + z, font, rozmiar) > szer && kawalek) { wiersze.push(kawalek); kawalek = z; }
      else kawalek += z;
    }
    return kawalek;
  };
  for (const s of slowa) {
    const proba = biez ? biez + ' ' + s : s;
    if (pdfSzerokosc(proba, font, rozmiar) <= szer) { biez = proba; continue; }
    if (biez) wiersze.push(biez);
    biez = pdfSzerokosc(s, font, rozmiar) > szer ? dopchnij(s) : s;
  }
  if (biez) wiersze.push(biez);
  return wiersze.length ? wiersze : [''];
}

/* --- Kartka do rysowania --------------------------------------------- */

/* Zbiera polecenia rysowania i sama pilnuje, kiedy skończyła się strona.
   Współrzędne liczymy po ludzku — od góry w dół — a na format PDF-a,
   który liczy od dołu, przeliczamy dopiero przy zapisie. */
/* Kartka domyślnie jest pionowym A4 — takie są oferty i faktury.
   Schemat gałęzi bywa szerszy niż wyższy, więc może poprosić o inny
   rozmiar strony i wtedy cała arytmetyka odbicia osi Y idzie za nim. */
function pdfKartka(rozmiar) {
  const R = rozmiar || PDF_STRONA;
  const strony = [];
  let biez = null;
  const k = {
    y: 0,
    rozmiar: R,
    get strony() { return strony; },
    nowa() { biez = []; strony.push(biez); k.y = PDF_MARG; return k; },
    miejsce(ile) {
      if (!biez) k.nowa();
      if (k.y + ile > R.h - PDF_DOL) k.nowa();
      return k;
    },
    /* tryb: 'zwykla' albo 'pogrubiona'; kolor jako [r,g,b] w zakresie 0–1 */
    tekst(x, y, tresc, rozmiar, gruba, kolor) {
      if (!biez) k.nowa();
      const c = kolor || [0, 0, 0];
      biez.push(`${c[0]} ${c[1]} ${c[2]} rg BT /${gruba ? 'F2' : 'F1'} ${rozmiar} Tf `
        + `1 0 0 1 ${x.toFixed(2)} ${(R.h - y).toFixed(2)} Tm `
        + `<${pdfHex(tresc, gruba ? FONT_POGRUBIONA : FONT_ZWYKLA)}> Tj ET`);
      return k;
    },
    /* Tekst dosunięty do prawej krawędzi — kwoty w tabeli muszą stać
       w jednej linii, inaczej nie da się ich porównać wzrokiem. */
    doPrawej(prawa, y, tresc, rozmiar, gruba, kolor) {
      const f = gruba ? FONT_POGRUBIONA : FONT_ZWYKLA;
      return k.tekst(prawa - pdfSzerokosc(tresc, f, rozmiar), y, tresc, rozmiar, gruba, kolor);
    },
    linia(x1, y1, x2, y2, grubosc, kolor) {
      if (!biez) k.nowa();
      const c = kolor || [0.8, 0.8, 0.8];
      biez.push(`${c[0]} ${c[1]} ${c[2]} RG ${(grubosc || 0.6)} w `
        + `${x1.toFixed(2)} ${(R.h - y1).toFixed(2)} m `
        + `${x2.toFixed(2)} ${(R.h - y2).toFixed(2)} l S`);
      return k;
    },
    /* Obraz JPEG (bajty + wymiary w pikselach) wstawiany w prostokąt
       x,y,w,h na kartce. Same bajty trafiają raz do pliku jako XObject. */
    obraz(x, y, w, h, img) {
      if (!biez) k.nowa();
      if (!strony.obrazy) strony.obrazy = [];
      strony.obrazy.push(img);
      const nr = strony.obrazy.length;
      biez.push(`q ${w.toFixed(2)} 0 0 ${h.toFixed(2)} ${x.toFixed(2)} ${(R.h - y - h).toFixed(2)} cm /Im${nr} Do Q`);
      return k;
    },
    prostokat(x, y, w, h, kolor) {
      if (!biez) k.nowa();
      const c = kolor || [0.95, 0.95, 0.95];
      biez.push(`${c[0]} ${c[1]} ${c[2]} rg ${x.toFixed(2)} ${(R.h - y - h).toFixed(2)} `
        + `${w.toFixed(2)} ${h.toFixed(2)} re f`);
      return k;
    },
  };
  return k;
}

/* --- Zapis pliku ----------------------------------------------------- */

function pdfStrumienCzcionki(font) {
  return pdfZB64(font.b64);
}

/* Tablica, dzięki której zaznaczony w czytniku tekst wkleja się jako
   litery, a nie jako numery glifów. Bez niej PDF wygląda dobrze,
   ale skopiowanie z niego czegokolwiek daje bełkot. */
function pdfMapaZnakow(font) {
  const pary = [];
  for (const kod in font.gid) {
    pary.push(`<${Number(font.gid[kod]).toString(16).padStart(4, '0')}> `
      + `<${Number(kod).toString(16).padStart(4, '0')}>`);
  }
  const porcje = [];
  for (let i = 0; i < pary.length; i += 100) {
    const cz = pary.slice(i, i + 100);
    porcje.push(`${cz.length} beginbfchar\n${cz.join('\n')}\nendbfchar`);
  }
  return '/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n'
    + '/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n'
    + '/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n'
    + '1 begincodespacerange\n<0000> <FFFF>\nendcodespacerange\n'
    + porcje.join('\n') + '\nendcmap\nCMapName currentdict /CMap defineresource pop\nend\nend';
}

function pdfTabliceSzerokosci(font) {
  const gidy = Object.keys(font.szer).map(Number).sort((a, b) => a - b);
  const czesci = [];
  let i = 0;
  while (i < gidy.length) {
    let j = i;
    while (j + 1 < gidy.length && gidy[j + 1] === gidy[j] + 1) j++;
    czesci.push(`${gidy[i]} [${gidy.slice(i, j + 1).map(g => font.szer[g]).join(' ')}]`);
    i = j + 1;
  }
  return '[' + czesci.join(' ') + ']';
}

function pdfZloz(strony, tytul, rozmiar) {
  const R = rozmiar || PDF_STRONA;
  const obiekty = [];                       /* każdy element: string albo Uint8Array */
  const dodaj = tresc => { obiekty.push(tresc); return obiekty.length; };

  /* Numery rezerwujemy z góry, bo obiekty wskazują na siebie nawzajem. */
  const nrKatalog = 1, nrStrony = 2;
  obiekty.push(null, null);

  const czcionka = (font, nrF) => {
    const dane = pdfStrumienCzcionki(font);
    const nrPlik = dodaj([
      `<< /Length ${dane.length} /Length1 ${dane.length} >>\nstream\n`, dane, '\nendstream',
    ]);
    const mapa = pdfMapaZnakow(font);
    const nrMapa = dodaj(`<< /Length ${mapa.length} >>\nstream\n${mapa}\nendstream`);
    const o = font.opis;
    const nrOpis = dodaj(`<< /Type /FontDescriptor /FontName /${font.nazwa} /Flags 32 `
      + `/FontBBox [${o.bbox.join(' ')}] /ItalicAngle 0 /Ascent ${o.ascent} /Descent ${o.descent} `
      + `/CapHeight ${o.capHeight} /StemV 80 /FontFile2 ${nrPlik} 0 R >>`);
    const nrCid = dodaj(`<< /Type /Font /Subtype /CIDFontType2 /BaseFont /${font.nazwa} `
      + `/CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> `
      + `/FontDescriptor ${nrOpis} 0 R /DW 1000 /W ${pdfTabliceSzerokosci(font)} /CIDToGIDMap /Identity >>`);
    obiekty[nrF - 1] = `<< /Type /Font /Subtype /Type0 /BaseFont /${font.nazwa} `
      + `/Encoding /Identity-H /DescendantFonts [${nrCid} 0 R] /ToUnicode ${nrMapa} 0 R >>`;
  };

  const nrZwykla = dodaj(null);
  const nrPogrubiona = dodaj(null);
  czcionka(FONT_ZWYKLA, nrZwykla);
  czcionka(FONT_POGRUBIONA, nrPogrubiona);

  const obr = (strony.obrazy || []).map((im, i) => `/Im${i + 1} ` + dodaj([
    `<< /Type /XObject /Subtype /Image /Width ${im.w} /Height ${im.h} /ColorSpace /DeviceRGB `
    + `/BitsPerComponent 8 /Filter /DCTDecode /Length ${im.bajty.length} >>\nstream\n`, im.bajty, '\nendstream',
  ]) + ' 0 R').join(' ');
  const zasoby = `<< /Font << /F1 ${nrZwykla} 0 R /F2 ${nrPogrubiona} 0 R >>`
    + (obr ? ` /XObject << ${obr} >>` : '') + ' >>';
  const nryStron = [];
  strony.forEach(ops => {
    const tresc = ops.join('\n');
    const nrTresc = dodaj(`<< /Length ${tresc.length} >>\nstream\n${tresc}\nendstream`);
    nryStron.push(dodaj(`<< /Type /Page /Parent ${nrStrony} 0 R `
      + `/MediaBox [0 0 ${R.w} ${R.h}] /Resources ${zasoby} /Contents ${nrTresc} 0 R >>`));
  });

  obiekty[nrStrony - 1] = `<< /Type /Pages /Count ${nryStron.length} `
    + `/Kids [${nryStron.map(n => n + ' 0 R').join(' ')}] >>`;
  const nrInfo = dodaj(`<< /Title (${String(tytul || 'Dokument').replace(/[()\\]/g, '')}) `
    + `/Producer (Asystent Instalatora) >>`);
  obiekty[nrKatalog - 1] = `<< /Type /Catalog /Pages ${nrStrony} 0 R >>`;

  /* Składanie bajtów. Tekst traktujemy jako po jednym bajcie na znak —
     w pliku PDF poza strumieniem czcionki nie ma znaków spoza ASCII. */
  const kawalki = [];
  let dlugosc = 0;
  const pisz = x => {
    if (typeof x === 'string') {
      const b = new Uint8Array(x.length);
      for (let i = 0; i < x.length; i++) b[i] = x.charCodeAt(i) & 0xff;
      kawalki.push(b); dlugosc += b.length;
    } else { kawalki.push(x); dlugosc += x.length; }
  };

  pisz('%PDF-1.4\n%\xe2\xe3\xcf\xd3\n');
  const pozycje = [];
  obiekty.forEach((tresc, i) => {
    pozycje[i] = dlugosc;
    pisz(`${i + 1} 0 obj\n`);
    (Array.isArray(tresc) ? tresc : [tresc]).forEach(pisz);
    pisz('\nendobj\n');
  });

  const startXref = dlugosc;
  let xref = `xref\n0 ${obiekty.length + 1}\n0000000000 65535 f \n`;
  pozycje.forEach(p => { xref += String(p).padStart(10, '0') + ' 00000 n \n'; });
  xref += `trailer\n<< /Size ${obiekty.length + 1} /Root ${nrKatalog} 0 R /Info ${nrInfo} 0 R >>\n`
    + `startxref\n${startXref}\n%%EOF\n`;
  pisz(xref);

  const plik = new Uint8Array(dlugosc);
  let p = 0;
  kawalki.forEach(b => { plik.set(b, p); p += b.length; });
  return plik;
}

/* ============================================================
   OFERTA I FAKTURA NA KARTCE
   ------------------------------------------------------------
   Układ jest ten sam dla obu dokumentów — różnią się nagłówkiem,
   blokiem płatności i podpisem pod tabelą. Trzymanie ich razem
   sprawia, że poprawka w tabeli działa od razu w obu.
   ============================================================ */

const PDF_AKCENT = [0.91, 0.42, 0.13];
const PDF_SZARY = [0.42, 0.42, 0.42];

function pdfNaglowekStrony(k, st, tytul, prawe) {
  const L = PDF_MARG, P = PDF_STRONA.w - PDF_MARG;
  k.prostokat(0, 0, PDF_STRONA.w, 4, PDF_AKCENT);
  k.y = PDF_MARG + 8;

  k.tekst(L, k.y, st.company || 'Wykonawca', 15, true);
  k.doPrawej(P, k.y, tytul, 15, true, PDF_AKCENT);
  k.y += 16;

  const lewe = [];
  if (st.address) lewe.push(st.address);
  if (st.nip) lewe.push('NIP ' + st.nip);
  if (st.phone) lewe.push('tel. ' + st.phone);
  if (st.email) lewe.push(st.email);

  const ile = Math.max(lewe.length, prawe.length);
  for (let i = 0; i < ile; i++) {
    if (lewe[i]) k.tekst(L, k.y, lewe[i], 8.5, false, PDF_SZARY);
    if (prawe[i]) k.doPrawej(P, k.y, prawe[i], 8.5, false, PDF_SZARY);
    k.y += 11;
  }
  k.y += 6;
  k.linia(L, k.y, P, k.y, 0.8, [0.85, 0.85, 0.85]);
  k.y += 20;
}

function pdfNabywca(k, o, faktura) {
  const L = PDF_MARG;
  k.tekst(L, k.y, faktura ? 'Nabywca' : 'Oferta dla', 8, false, PDF_SZARY);
  k.y += 14;
  k.tekst(L, k.y, o.client.name || '—', 11, true);
  k.y += 13;
  [o.client.address, o.client.nip ? 'NIP ' + o.client.nip : '', o.client.phone]
    .filter(Boolean).forEach(w => { k.tekst(L, k.y, w, 9); k.y += 11; });
  k.y += 12;
}

/* Tabela pozycji. Kolumny są stałe, a nazwa pozycji zawija się w swojej
   kolumnie — długie opisy robót nie wypychają kwot poza kartkę. */
function pdfTabela(k, D, zwolniony) {
  const L = PDF_MARG, P = PDF_STRONA.w - PDF_MARG;
  /* Trzy kolumny liczbowe równane do prawej krawędzi, każda w swoim
     pasie. Pasy muszą być szersze niż najdłuższa kwota, jaka może się
     w nich znaleźć — inaczej „1 719,48 zł" wchodzi na cenę obok
     i wydruk staje się nieczytelny akurat w miejscu, na które klient
     patrzy najpierw. */
  const kol = { lp: L, nazwa: L + 22, ilosc: P - 170, cena: P - 82, wart: P };
  const szerNazwy = kol.ilosc - 62 - kol.nazwa;

  const glowka = () => {
    k.prostokat(L - 4, k.y - 10, P - L + 8, 18, [0.96, 0.96, 0.96]);
    k.tekst(kol.lp, k.y, 'Lp', 8, true, PDF_SZARY);
    k.tekst(kol.nazwa, k.y, 'Nazwa', 8, true, PDF_SZARY);
    k.doPrawej(kol.ilosc, k.y, 'Ilość', 8, true, PDF_SZARY);
    k.doPrawej(kol.cena, k.y, 'Cena', 8, true, PDF_SZARY);
    k.doPrawej(kol.wart, k.y, 'Wartość', 8, true, PDF_SZARY);
    k.y += 20;
  };
  glowka();

  let lp = 0;
  const sekcja = (tytul, pozycje) => {
    if (!pozycje.length) return;
    k.miejsce(30);
    if (k.y === PDF_MARG) glowka();
    k.tekst(kol.lp, k.y, tytul, 8.5, true, PDF_AKCENT);
    k.y += 14;
    pozycje.forEach(l => {
      const wiersze = pdfZawin(l.name, FONT_ZWYKLA, 9.5, szerNazwy);
      const wys = wiersze.length * 12 + 6;
      if (k.y + wys > PDF_STRONA.h - PDF_DOL) { k.nowa(); glowka(); }
      const gora = k.y;
      k.tekst(kol.lp, gora, String(++lp), 9.5, false, PDF_SZARY);
      wiersze.forEach((w, i) => k.tekst(kol.nazwa, gora + i * 12, w, 9.5));
      k.doPrawej(kol.ilosc, gora, fmt(l.qty, 2) + ' ' + l.jm, 9.5);
      k.doPrawej(kol.cena, gora, zl(l.unit), 9.5);
      k.doPrawej(kol.wart, gora, zl(l.val), 9.5, true);
      k.y = gora + wys;
      k.linia(L, k.y - 5, P, k.y - 5, 0.4, [0.9, 0.9, 0.9]);
    });
  };
  sekcja('Materiały', D.mats);
  sekcja('Robocizna', D.robs);

  k.miejsce(70);
  k.y += 6;
  const podsumowanie = [['Razem netto', zl(D.docNet)]];
  if (!zwolniony) podsumowanie.push(['VAT', zl(D.docVat)]);
  podsumowanie.forEach(([a, b]) => {
    k.doPrawej(kol.cena, k.y, a, 9.5, false, PDF_SZARY);
    k.doPrawej(kol.wart, k.y, b, 9.5);
    k.y += 14;
  });
  k.y += 4;
  return { kol, suma: zwolniony ? D.docNet : D.docGross };
}

function pdfSuma(k, etykieta, kwota) {
  const L = PDF_MARG, P = PDF_STRONA.w - PDF_MARG;
  k.prostokat(P - 250, k.y - 12, 250, 26, [0.97, 0.94, 0.90]);
  k.tekst(P - 240, k.y, etykieta, 10, true);
  k.doPrawej(P - 10, k.y, zl(kwota), 12, true, PDF_AKCENT);
  k.y += 28;
  return L;
}

/* Cały dokument jako bajty gotowe do zapisu albo wysyłki. */
function pdfDokument(o, faktura) {
  const st = (typeof state !== 'undefined' && state.settings) || DEFAULT_SETTINGS;
  const D = docLines(o);
  const zwolniony = st.vatStatus === 'zwolniony';
  const f = o.invoice || {};
  const k = pdfKartka().nowa();
  const L = PDF_MARG, P = PDF_STRONA.w - PDF_MARG;

  const prawe = faktura
    ? ['Data wystawienia: ' + plDate(f.issue),
       'Termin płatności: ' + plDate(terminPlatnosci(f)),
       'Sposób zapłaty: ' + (f.method || 'przelew')]
    : ['Data: ' + plDate(o.date)].concat(st.validDays ? ['Ważna ' + st.validDays + ' dni'] : []);

  pdfNaglowekStrony(k, st, faktura ? 'FAKTURA ' + f.number : 'OFERTA ' + o.number, prawe);
  pdfNabywca(k, o, faktura);
  pdfTabela(k, D, zwolniony);
  pdfSuma(k, faktura ? 'Do zapłaty' : 'Razem brutto', zwolniony ? D.docNet : D.docGross);

  if (zwolniony) {
    k.tekst(L, k.y, 'Sprzedawca zwolniony z VAT.', 8.5, false, PDF_SZARY);
    k.y += 14;
  }
  if (faktura && st.bank && f.method === 'przelew') {
    k.miejsce(30);
    k.tekst(L, k.y, 'Numer konta do wpłaty', 8, false, PDF_SZARY);
    k.y += 12;
    k.tekst(L, k.y, st.bank, 10, true);
    k.y += 18;
  }
  if (faktura && f.paid && f.paidAt) {
    k.tekst(L, k.y, 'Zapłacono ' + plDate(f.paidAt) + '.', 9.5, true);
    k.y += 16;
  }

  const uwagi = faktura ? f.footer : o.notes;
  if (uwagi) {
    k.miejsce(40);
    k.y += 6;
    pdfZawin(uwagi, FONT_ZWYKLA, 9, P - L).forEach(w => {
      k.miejsce(14);
      k.tekst(L, k.y, w, 9, false, PDF_SZARY);
      k.y += 12;
    });
  }

  k.miejsce(60);
  k.y += 24;
  k.linia(P - 200, k.y, P, k.y, 0.6, [0.75, 0.75, 0.75]);
  k.y += 12;
  k.doPrawej(P, k.y, faktura ? 'Podpis wystawcy' : 'Podpis wykonawcy', 8, false, PDF_SZARY);

  /* Numer strony dopisujemy na końcu, gdy już wiadomo, ile ich jest. */
  const strony = k.strony;
  strony.forEach((ops, i) => {
    const stopka = (st.company || '') + (strony.length > 1 ? '   ·   strona ' + (i + 1) + ' z ' + strony.length : '');
    const szer = pdfSzerokosc(stopka, FONT_ZWYKLA, 7.5);
    ops.push(`${PDF_SZARY[0]} ${PDF_SZARY[1]} ${PDF_SZARY[2]} rg BT /F1 7.5 Tf `
      + `1 0 0 1 ${((PDF_STRONA.w - szer) / 2).toFixed(2)} ${(PDF_DOL - 26).toFixed(2)} Tm `
      + `<${pdfHex(stopka, FONT_ZWYKLA)}> Tj ET`);
  });

  return pdfZloz(strony, faktura ? 'Faktura ' + f.number : 'Oferta ' + o.number);
}

/* Nazwa pliku bez znaków, których nie lubią menedżery plików i poczta. */
function pdfNazwa(o, faktura) {
  const rdzen = faktura && o.invoice ? 'Faktura_' + o.invoice.number : 'Oferta_' + o.number;
  return rdzen.replace(/[^\w-]+/g, '_') + '.pdf';
}


