/* ===== notatnik.js ===== */
/* ============================================================
   BIURO → NOTATNIK (BRUDNOPIS)
   ------------------------------------------------------------
   Szybkie notatki z budowy, niczego nie trzeba nigdzie przypinać:
   wchodzisz, wpisujesz, czego dotyczy, piszesz, robisz zdjęcia
   i odhaczasz listę „do kupienia / do zrobienia”. Na zdjęciu można
   narysować strzałkę, kreskę albo dopisać tekst — gdzie idzie rura,
   gdzie wiercić.

   Tekst notatek leży w pamięci aplikacji (ai_notatki_v1) i wchodzi do
   kopii zapasowej. Zdjęcia są za duże na tę pamięć, więc trzymamy je
   w bazie przeglądarki (IndexedDB), zmniejszone do 1600 px; do kopii
   zapasowej nie wchodzą.
   ============================================================ */
const NOT_KEY = 'ai_notatki_v1';
function loadNotatki() {
  try { const l = JSON.parse(localStorage.getItem(NOT_KEY) || '[]'); return Array.isArray(l) ? l : []; }
  catch (e) { return []; }
}
const persistNot = () => { try { localStorage.setItem(NOT_KEY, JSON.stringify(state.notatki)); } catch (e) { toast('Pamięć telefonu jest pełna — notatka mogła się nie zapisać.'); } };
state.notatki = loadNotatki();
/* Starsze notatki miały ilość wpisaną w tekst („… × 5 szt”) — przenosimy ją
   do licznika obok, żeby + i − działały. */
state.notatki.forEach(n => (n.lista || []).forEach(x => {
  const m = String(x.t || '').match(/^(.*?)\s*×\s*([\d.,]+)\s*(\S+)?$/);
  if (m && !x.ileZTekstu) { x.t = m[1]; x.qty = parseFloat(m[2].replace(',', '.')) || x.qty || 1; if (m[3] && !x.kat) x.jedn = m[3]; x.ileZTekstu = true; }
}));
state.notId = null;            // notatka otwarta do edycji
state.notRys = null;           // zdjęcie otwarte do rysowania: { notId, zdj }
state.notUsun = false;         // okno potwierdzenia usunięcia notatki
const currentNot = () => state.notatki.find(n => n.id === state.notId);
const notTeraz = () => new Date().toISOString();
const notData = iso => { const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleDateString('pl-PL', { day: 'numeric', month: 'short' }) + ', ' + d.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' }); };

/* ---------- zdjęcia: IndexedDB z zapasem w pamięci ---------- */
const NOT_MINI = {};           // id → miniatura (data URL), żeby lista nie mrugała
const NOT_PAM = {};            // gdy IndexedDB niedostępne — tylko na czas tej sesji
let notDbP = null;
function notDB() {
  if (!notDbP) notDbP = new Promise((ok, zle) => {
    try {
      const r = indexedDB.open('asystent_zdjecia', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('zdj');
      r.onsuccess = () => ok(r.result); r.onerror = () => zle(r.error);
    } catch (e) { zle(e); }
  });
  return notDbP;
}
function zdjZapisz(id, obj) {
  NOT_PAM[id] = obj;
  return notDB().then(db => new Promise(ok => { const tx = db.transaction('zdj', 'readwrite'); tx.objectStore('zdj').put(obj, id); tx.oncomplete = () => ok(true); tx.onerror = () => ok(false); })).catch(() => false);
}
function zdjCzytaj(id) {
  if (NOT_PAM[id]) return Promise.resolve(NOT_PAM[id]);
  return notDB().then(db => new Promise(ok => { const r = db.transaction('zdj').objectStore('zdj').get(id); r.onsuccess = () => ok(r.result || null); r.onerror = () => ok(null); })).catch(() => null);
}
function zdjUsun(id) {
  delete NOT_PAM[id]; delete NOT_MINI[id];
  return notDB().then(db => { db.transaction('zdj', 'readwrite').objectStore('zdj').delete(id); }).catch(() => {});
}
/* Miniatury dociągamy po narysowaniu ekranu — bez przerysowania. */
function notDociagnij() {
  document.querySelectorAll('img[data-zdjmini]').forEach(img => {
    const id = img.dataset.zdjmini;
    if (NOT_MINI[id]) { if (img.getAttribute('src') !== NOT_MINI[id]) img.src = NOT_MINI[id]; return; }
    zdjCzytaj(id).then(o => { if (o && o.mini) { NOT_MINI[id] = o.mini; img.src = o.mini; } });
  });
}
/* Plik z aparatu albo galerii → JPEG 1600 px + miniatura 360 px. */
function notObraz(src, max, jakosc) {
  return new Promise((ok, zle) => {
    const img = new Image();
    img.onload = () => {
      const s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
      const c = document.createElement('canvas');
      c.width = Math.round(img.naturalWidth * s); c.height = Math.round(img.naturalHeight * s);
      const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
      x.drawImage(img, 0, 0, c.width, c.height);
      ok(c.toDataURL('image/jpeg', jakosc));
    };
    img.onerror = zle; img.src = src;
  });
}
function notPlikDoDataUrl(f) {
  return new Promise((ok, zle) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = zle; r.readAsDataURL(f); });
}
async function notDodajZdjecia(pliki) {
  const n = currentNot(); if (!n) return;
  let ile = 0;
  for (const f of pliki) {
    try {
      const surowy = await notPlikDoDataUrl(f);
      const pelne = await notObraz(surowy, 1600, 0.82);
      const mini = await notObraz(pelne, 360, 0.7);
      const id = 'z' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      await zdjZapisz(id, { pelne, mini });
      NOT_MINI[id] = mini;
      n.zdj.push(id); ile++;
    } catch (e) { /* plik, którego nie da się odczytać — pomijamy */ }
  }
  n.zm = notTeraz(); persistNot(); renderKeepScroll();
  toast(ile ? (ile === 1 ? 'Dodano zdjęcie. Dotknij go, żeby coś na nim narysować.' : 'Dodano ' + ile + ' zdjęcia.') : 'Nie udało się odczytać zdjęcia.');
}

/* ---------- Biuro: wejście do notatnika ---------- */
function notatnikPrzyciskHtml() {
  const n = state.notatki.length;
  return `<button class="btn2" style="width:100%;margin-top:8px" data-notatnik>${svg('pen')}Notatnik${n ? ' <span class="tagmini">' + n + '</span>' : ''}</button>`;
}

/* ---------- ekran: lista notatek ---------- */
function renderNotatnik() {
  const l = state.notatki.slice().sort((a, b) => String(b.zm).localeCompare(String(a.zm)));
  setTimeout(notDociagnij, 0);
  return `<header class="hdr hdr--cat" style="--c:#6D5BD0"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" data-notwroc aria-label="Wróć">${svg('back')}</button>
      <div><h1>Notatnik</h1><p>${l.length ? l.length + ' ' + odmiana(l.length, 'notatka', 'notatki', 'notatek') : 'szybkie notatki z budowy'}</p></div></div></header>
    <div class="body">
      <button class="jump" style="--c:#6D5BD0" data-notnowa>${svg('plus')}Nowa notatka</button>
      <div class="sechead">${svg('pen')}Ostatnie notatki<span>${l.length}</span></div>
      ${l.length ? `<div class="olist">${l.map(n => {
        const z = n.zdj.length, lz = n.lista.length, lo = n.lista.filter(x => x.ok).length;
        const opis = String(n.tekst || '').replace(/\s+/g, ' ').trim();
        return `<div class="orow"><button class="ocard not-karta" data-nototworz="${n.id}">
          ${z ? `<img class="not-min" data-zdjmini="${n.zdj[0]}" alt="">` : `<span class="ocard-n not-ik">${svg('pen')}</span>`}
          <span class="ocard-t"><strong>${esc(n.tytul || 'Bez tytułu')}</strong>
            <span>${n.przyp ? '<b class="not-przyp' + (new Date(n.przyp) < new Date() ? ' po' : '') + '">🔔 ' + esc(notData(n.przyp)) + '</b><br>' : ''}${esc(notData(n.zm))}${z ? ' · ' + z + ' zdj.' : ''}${lz ? ' · lista ' + lo + '/' + lz : ''}${opis ? '<br>' + esc(opis.slice(0, 70)) + (opis.length > 70 ? '…' : '') : ''}</span></span>
        </button></div>`; }).join('')}</div>`
      : '<p class="empty">Nie ma jeszcze notatek. Dotknij „Nowa notatka”, wpisz, czego dotyczy — np. „Kowalski, pomiar kotłowni” — i dorzuć zdjęcia.</p>'}
    </div>`;
}

/* ---------- ekran: jedna notatka ---------- */
function renderNotatka() {
  const n = currentNot();
  if (!n) { state.offerScreen = 'notatnik'; return renderNotatnik(); }
  setTimeout(notDociagnij, 0);
  const lo = n.lista.filter(x => x.ok).length;
  return `<header class="hdr hdr--cat" style="--c:#6D5BD0"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" data-notdolisty aria-label="Wróć">${svg('back')}</button>
      <div style="flex:1;min-width:0"><h1>${esc(n.tytul || 'Nowa notatka')}</h1><p>${n.przyp ? '🔔 ' + esc(notData(n.przyp)) : 'zmieniona ' + esc(notData(n.zm)) + ' · zapisuje się sama'}</p></div>
      <button class="back not-dzw${n.przyp ? ' on' : ''}" data-notdzw aria-label="Ustaw przypomnienie">${svg('dzwonek')}</button></div></header>
    <div class="body">
      <div class="card"><div class="fields">
        <div class="field"><label for="nt-t">Czego dotyczy</label>
          <input id="nt-t" type="text" autocapitalize="sentences" data-notpole="tytul" value="${esc(n.tytul || '')}" placeholder="np. Kowalski — pomiar kotłowni"></div>
        <div class="mini grow"><label for="nt-x">Notatka</label>
          <textarea id="nt-x" class="not-tekst" rows="6" autocapitalize="sentences" data-notpole="tekst" placeholder="Wymiary, ustalenia, co trzeba sprawdzić…">${esc(n.tekst || '')}</textarea></div>
      </div></div>

      <div class="card"><div class="card-head">${svg('box')}Zdjęcia${n.zdj.length ? ' <span class="tagmini">' + n.zdj.length + '</span>' : ''}</div>
        ${n.zdj.length ? `<div class="not-zdj">${n.zdj.map(id => `<button class="not-zdj-b" data-notzdj="${id}" aria-label="Otwórz zdjęcie"><img data-zdjmini="${id}" alt=""></button>`).join('')}</div>
          <p class="hint" style="margin:8px 2px 0">Dotknij zdjęcia, żeby je powiększyć i narysować na nim strzałkę, linię albo napis.</p>` : '<p class="hint" style="margin:0 2px">Brak zdjęć.</p>'}
        <div class="proj-btny" style="margin:10px 0 0">
          <label class="btn2 not-plik">${svg('plus')}Zrób zdjęcie<input type="file" accept="image/*" capture="environment" data-notfoto hidden></label>
          <label class="btn2 not-plik">${svg('plus')}Z galerii<input type="file" accept="image/*" multiple data-notfoto hidden></label>
        </div>
      </div>

      <div class="card"><div class="card-head">${svg('check')}Do kupienia / do zrobienia${n.lista.length ? ' <span class="tagmini">' + lo + '/' + n.lista.length + '</span>' : ''}</div>
        <div class="not-lista">${n.lista.map((x, i) => `<div class="not-pkt${x.ok ? ' ok' : ''}">
            <input type="checkbox" data-notok="${i}"${x.ok ? ' checked' : ''} aria-label="Zrobione">
            <textarea class="not-pkt-t" rows="1" data-notpkt="${i}" aria-label="Punkt listy" enterkeyhint="done">${esc(x.t)}</textarea>
            <span class="not-szt" data-notszt="${i}">${String(x.qty || 1).replace('.', ',')} ${esc((x.kat && x.kat.unit) || x.jedn || 'szt')}</span>
            <div class="not-ile"><button data-notile="${i}" data-d="-1" aria-label="Mniej">−</button>
              <span><b>${String(x.qty || 1).replace('.', ',')}</b>${esc((x.kat && x.kat.unit) || x.jedn || 'szt')}</span>
              <button data-notile="${i}" data-d="1" aria-label="Więcej">+</button></div>
            <button class="item-x" data-notpktx="${i}" aria-label="Usuń punkt">${svg('x')}</button>
          </div>`).join('')}</div>
        <div class="not-nowy">
          <input type="text" data-notnowypkt placeholder="Wpisz i Enter — albo + z katalogu" autocapitalize="sentences" enterkeyhint="done">
          <button class="btn2" data-notkat aria-label="Dodaj z katalogu">${svg('plus')}</button>
        </div>
        <div class="proj-btny" style="margin:10px 0 0">
          <button class="btn2" data-notdooferty${n.lista.some(x => !x.ok) ? '' : ' disabled'}>${svg('doc')}Dodaj do oferty</button>
          <button class="btn2" data-notzoferty>${svg('arrow')}Wczytaj z oferty</button>
        </div>
      </div>

      <button class="btn2 proj-usun" style="width:100%" data-notusun>${svg('trash')}Usuń notatkę</button>
    </div>`;
}

/* ---------- rysowanie po zdjęciu ---------- */
const NR = { narz: 'pen', kol: '#FF3B30', ruchy: [], cofniete: [], img: null, cv: null, akt: null, txtPkt: null };
const NR_KOLORY = ['#FF3B30', '#FFCC00', '#34C759', '#0A84FF', '#FFFFFF', '#111111'];
function notRysHtml() {
  return `<div class="not-rys">
    <div class="not-rys-g">
      <button class="not-rb" data-nrzamknij aria-label="Zamknij">${svg('x')}</button>
      <div class="not-rys-n">
        <button class="not-rb${NR.narz === 'pen' ? ' on' : ''}" data-nrnarz="pen" aria-label="Pióro">${svg('pen')}</button>
        <button class="not-rb${NR.narz === 'arr' ? ' on' : ''}" data-nrnarz="arr" aria-label="Strzałka">${svg('arrow')}</button>
        <button class="not-rb not-rb-t${NR.narz === 'txt' ? ' on' : ''}" data-nrnarz="txt" aria-label="Tekst">Aa</button>
        <button class="not-rb" data-nrcofnij aria-label="Cofnij">↶</button>
      </div>
      <button class="not-rb not-zap" data-nrzapisz>Zapisz</button>
    </div>
    <div class="not-rys-k">${NR_KOLORY.map(k => `<button class="not-kol${NR.kol === k ? ' on' : ''}" style="background:${k}" data-nrkol="${k}" aria-label="Kolor"></button>`).join('')}
      <button class="not-rb not-del" data-nrusunzdj>${svg('trash')}${state.notRys && state.notRys.usun ? 'Na pewno?' : ''}</button></div>
    <div class="not-rys-p"><canvas></canvas></div>
    <div class="not-rys-txt"${NR.txtPkt ? '' : ' hidden'}><input type="text" data-nrtxt placeholder="Wpisz napis i dotknij OK" enterkeyhint="done"><button class="btn2" data-nrtxtok>OK</button></div>
    <p class="not-rys-h">${NR.narz === 'pen' ? 'Rysuj palcem po zdjęciu.' : NR.narz === 'arr' ? 'Przeciągnij od początku do grotu strzałki.' : 'Dotknij miejsca na zdjęciu, potem wpisz napis.'}</p>
  </div>`;
}
function nrRysuj() {
  const c = NR.cv; if (!c || !NR.img) return;
  const x = c.getContext('2d');
  x.drawImage(NR.img, 0, 0, c.width, c.height);
  const w = Math.max(3, c.width / 160);
  const ruchy = NR.akt ? NR.ruchy.concat([NR.akt]) : NR.ruchy;
  ruchy.forEach(r => {
    x.strokeStyle = r.kol; x.fillStyle = r.kol; x.lineWidth = w; x.lineCap = 'round'; x.lineJoin = 'round';
    if (r.typ === 'pen') {
      x.beginPath(); r.pts.forEach((p, i) => i ? x.lineTo(p[0], p[1]) : x.moveTo(p[0], p[1])); x.stroke();
    } else if (r.typ === 'arr') {
      const [a, b] = [r.a, r.b]; const kat = Math.atan2(b[1] - a[1], b[0] - a[0]), g = w * 5;
      x.beginPath(); x.moveTo(a[0], a[1]); x.lineTo(b[0], b[1]); x.stroke();
      x.beginPath(); x.moveTo(b[0], b[1]);
      x.lineTo(b[0] - g * Math.cos(kat - 0.45), b[1] - g * Math.sin(kat - 0.45));
      x.lineTo(b[0] - g * Math.cos(kat + 0.45), b[1] - g * Math.sin(kat + 0.45)); x.closePath(); x.fill();
    } else if (r.typ === 'txt') {
      const fs = Math.round(c.width / 20);
      x.font = `700 ${fs}px Barlow, Arial, sans-serif`; x.textBaseline = 'middle';
      x.lineWidth = Math.max(3, fs / 7); x.strokeStyle = r.kol === '#111111' ? '#fff' : 'rgba(0,0,0,.75)';
      x.strokeText(r.t, r.p[0], r.p[1]); x.fillText(r.t, r.p[0], r.p[1]);
    }
  });
}
function nrOtworz(notId, zdj) {
  state.notRys = { notId, zdj, usun: false };
  NR.ruchy = []; NR.akt = null; NR.txtPkt = null; NR.img = null;
  renderOverlay();
  zdjCzytaj(zdj).then(o => {
    if (!o) { toast('Nie znalazłem tego zdjęcia w telefonie.'); return; }
    const img = new Image();
    img.onload = () => {
      NR.img = img;
      const c = document.querySelector('.not-rys canvas'); if (!c) return;
      c.width = img.naturalWidth; c.height = img.naturalHeight; NR.cv = c; nrRysuj();
    };
    img.src = o.pelne;
  });
}
function nrPunkt(e) {
  const c = NR.cv, r = c.getBoundingClientRect();
  return [(e.clientX - r.left) * c.width / r.width, (e.clientY - r.top) * c.height / r.height];
}
function nrOdswiezPasek() {
  // przerysowanie samych przycisków, bez ruszania płótna
  const g = document.querySelector('.not-rys'); if (!g) return;
  g.querySelectorAll('[data-nrnarz]').forEach(b => b.classList.toggle('on', b.dataset.nrnarz === NR.narz));
  g.querySelectorAll('[data-nrkol]').forEach(b => b.classList.toggle('on', b.dataset.nrkol === NR.kol));
  const h = g.querySelector('.not-rys-h');
  if (h) h.textContent = NR.narz === 'pen' ? 'Rysuj palcem po zdjęciu.' : NR.narz === 'arr' ? 'Przeciągnij od początku do grotu strzałki.' : 'Dotknij miejsca na zdjęciu, potem wpisz napis.';
  const t = g.querySelector('.not-rys-txt'); if (t) t.hidden = !NR.txtPkt;
}
document.addEventListener('pointerdown', e => {
  if (!state.notRys || !NR.cv || e.target !== NR.cv) return;
  e.preventDefault();
  const p = nrPunkt(e);
  if (NR.narz === 'txt') { NR.txtPkt = p; nrOdswiezPasek(); const i = document.querySelector('[data-nrtxt]'); if (i) { i.value = ''; i.focus(); } return; }
  NR.akt = NR.narz === 'pen' ? { typ: 'pen', kol: NR.kol, pts: [p] } : { typ: 'arr', kol: NR.kol, a: p, b: p };
  try { NR.cv.setPointerCapture(e.pointerId); } catch (x) { /* trudno */ }
  nrRysuj();
});
document.addEventListener('pointermove', e => {
  if (!NR.akt || !NR.cv) return;
  const p = nrPunkt(e);
  if (NR.akt.typ === 'pen') NR.akt.pts.push(p); else NR.akt.b = p;
  nrRysuj();
});
document.addEventListener('pointerup', () => {
  if (!NR.akt) return;
  const r = NR.akt; NR.akt = null;
  if (r.typ === 'pen' ? r.pts.length > 1 : Math.hypot(r.b[0] - r.a[0], r.b[1] - r.a[1]) > 8) NR.ruchy.push(r);
  nrRysuj();
});

/* ---------- zdarzenia ---------- */
function notOtworz(id) { state.notId = id; state.offerScreen = 'notatka'; render(true); }
document.addEventListener('click', e => {
  const t = e.target, ds = s => t.closest(s);
  let x;
  if (ds('[data-notatnik]')) { state.tab = 'offers'; state.offerScreen = 'notatnik'; render(true); return; }
  if (ds('[data-notwroc]')) { state.offerScreen = 'list'; render(true); return; }
  if (ds('[data-notdolisty]')) {
    const n = currentNot();
    // pusta notatka nie zostaje na liście
    if (n && !n.tytul && !n.tekst && !n.zdj.length && !n.lista.length) { state.notatki = state.notatki.filter(k => k !== n); persistNot(); }
    state.offerScreen = 'notatnik'; state.notId = null; render(true); return;
  }
  if (ds('[data-notnowa]')) {
    const n = { id: 'n' + Date.now(), tytul: '', tekst: '', zdj: [], lista: [], utw: notTeraz(), zm: notTeraz() };
    state.notatki.unshift(n); persistNot(); notOtworz(n.id);
    const p = document.getElementById('nt-t'); if (p) p.focus();
    return;
  }
  if ((x = ds('[data-nototworz]'))) { notOtworz(x.dataset.nototworz); return; }

  // lista do zrobienia
  const n = currentNot();
  if (n && ds('[data-notkat]')) {
    // wpisany tekst nie przepada — najpierw trafia na listę
    const i = document.querySelector('[data-notnowypkt]'); if (i && i.value.trim()) notDodajPkt(n);
    state.notPick = n.id;
    state.picker = true; state.pickGrp = null; state.pickDn = null; state.pickWar = null; state.pickQ = ''; state.pickSel = null;
    renderOverlay(); return;
  }
  if (n && (x = ds('[data-notile]'))) {
    const p = n.lista[+x.dataset.notile]; if (!p) return;
    const nowa = Math.round(((Number(p.qty) || 1) + Number(x.dataset.d)) * 100) / 100;
    if (nowa < 1) { toast('Najmniej 1 — żeby usunąć punkt, użyj krzyżyka.'); return; }
    p.qty = nowa; n.zm = notTeraz(); persistNot();
    const b = x.parentElement.querySelector('b'); if (b) b.textContent = String(nowa).replace('.', ',');
    const sz = x.closest('.not-pkt').querySelector('.not-szt'); if (sz) sz.textContent = String(nowa).replace('.', ',') + ' ' + sz.textContent.split(' ').slice(1).join(' ');
    return;
  }
  if (n && (x = ds('[data-notpktx]'))) { n.lista.splice(+x.dataset.notpktx, 1); n.zm = notTeraz(); persistNot(); renderKeepScroll(); return; }
  if (n && ds('[data-notdooferty]')) {
    const lista = n.lista.filter(k => !k.ok && k.t.trim()).map(k => k.kat
      ? Object.assign({}, k.kat, { qty: k.qty || 1 })
      : { name: k.t.trim(), unit: k.jedn || 'szt', cat: 'mat', price: 0, qty: k.qty || 1 });
    if (!lista.length) return;
    const p = { name: lista.length + ' ' + odmiana(lista.length, 'pozycja', 'pozycje', 'pozycji') + ' z notatki', lista };
    // zawsze pytamy, do której oferty — albo nowa
    state.wybOferty = p; renderOverlay(); return;
  }
  if (n && ds('[data-notzoferty]')) {
    if (!state.offers.length) { toast('Nie ma jeszcze żadnej oferty.'); return; }
    state.notZOf = true; renderOverlay(); return;
  }
  if (state.notZOf && (x = ds('[data-notzof]'))) {
    const o = state.offers.find(k => k.id === x.dataset.notzof); state.notZOf = false; renderOverlay();
    if (!o || !n) return;
    (o.items || []).forEach(it => {
      const q = Number(it.qty) || 1;
      n.lista.push({ t: it.name, ok: false, qty: q,
        kat: { name: it.name, unit: it.unit, cat: it.cat, price: it.price, tag: it.tag || null, katId: it.katId } });
    });
    n.zm = notTeraz(); persistNot(); renderKeepScroll();
    toast('Wczytano ' + (o.items || []).length + ' poz. z oferty ' + o.number + '.'); return;
  }
  if (state.notZOf && ds('[data-notzofzam]') && (!ds('[data-stop]') || ds('.sheet-h [data-notzofzam]'))) { state.notZOf = false; renderOverlay(); return; }
  if (n && ds('[data-notusun]')) { state.notUsun = true; renderOverlay(); return; }
  if (state.notUsun && ds('[data-notusuntak]')) {
    const m = currentNot(); state.notUsun = false;
    if (m) { notPrzypAnuluj(m); m.zdj.forEach(zdjUsun); state.notatki = state.notatki.filter(k => k !== m); persistNot(); }
    state.offerScreen = 'notatnik'; state.notId = null; renderOverlay(); render(true); toast('Usunięto notatkę.'); return;
  }
  if (state.notUsun && ds('[data-notusunnie]') && (!ds('[data-stop]') || ds('.not-nie') || ds('.sheet-h [data-notusunnie]'))) { state.notUsun = false; renderOverlay(); return; }
  if (n && (x = ds('[data-notzdj]'))) { nrOtworz(n.id, x.dataset.notzdj); return; }

  // rysowanie
  if (!state.notRys) return;
  if (ds('[data-nrzamknij]')) { state.notRys = null; NR.cv = null; renderOverlay(); return; }
  if ((x = ds('[data-nrnarz]'))) { NR.narz = x.dataset.nrnarz; NR.txtPkt = null; nrOdswiezPasek(); return; }
  if ((x = ds('[data-nrkol]'))) { NR.kol = x.dataset.nrkol; nrOdswiezPasek(); return; }
  if (ds('[data-nrcofnij]')) { NR.ruchy.pop(); nrRysuj(); return; }
  if (ds('[data-nrtxtok]')) { nrDodajTekst(); return; }
  if (ds('[data-nrusunzdj]')) {
    if (!state.notRys.usun) { state.notRys.usun = true; const b = ds('[data-nrusunzdj]'); b.innerHTML = svg('trash') + 'Na pewno?'; return; }
    const m = state.notatki.find(k => k.id === state.notRys.notId), id = state.notRys.zdj;
    if (m) { m.zdj = m.zdj.filter(z => z !== id); m.zm = notTeraz(); persistNot(); }
    zdjUsun(id); state.notRys = null; NR.cv = null; renderOverlay(); renderKeepScroll(); toast('Usunięto zdjęcie.'); return;
  }
  if (ds('[data-nrzapisz]')) {
    const id = state.notRys.zdj, notId = state.notRys.notId;
    if (!NR.cv || !NR.ruchy.length) { state.notRys = null; NR.cv = null; renderOverlay(); return; }
    const pelne = NR.cv.toDataURL('image/jpeg', 0.85);
    notObraz(pelne, 360, 0.7).then(mini => zdjZapisz(id, { pelne, mini }).then(() => {
      NOT_MINI[id] = mini;
      const m = state.notatki.find(k => k.id === notId); if (m) { m.zm = notTeraz(); persistNot(); }
      state.notRys = null; NR.cv = null; renderOverlay(); renderKeepScroll(); toast('Zapisano rysunek na zdjęciu.');
    }));
  }
});
function notDodajPkt(n) {
  const i = document.querySelector('[data-notnowypkt]'); if (!i) return;
  const t = i.value.trim(); if (!t) { i.focus(); return; }
  n.lista.push({ t, ok: false }); n.zm = notTeraz(); persistNot(); renderKeepScroll();
  const j = document.querySelector('[data-notnowypkt]'); if (j) j.focus();
}
function nrDodajTekst() {
  const i = document.querySelector('[data-nrtxt]'); const t = i ? i.value.trim() : '';
  if (t && NR.txtPkt) { NR.ruchy.push({ typ: 'txt', kol: NR.kol, p: NR.txtPkt, t }); nrRysuj(); }
  NR.txtPkt = null; nrOdswiezPasek();
}
document.addEventListener('keydown', e => {
  if (e.key !== 'Enter') return;
  if (e.target.dataset && e.target.dataset.notnowypkt !== undefined) { e.preventDefault(); const n = currentNot(); if (n) notDodajPkt(n); }
  if (e.target.dataset && e.target.dataset.nrtxt !== undefined) { e.preventDefault(); nrDodajTekst(); }
});
document.addEventListener('input', e => {
  const t = e.target, n = currentNot(); if (!n || !t.dataset) return;
  if (t.dataset.notpole) {
    n[t.dataset.notpole] = t.value; n.zm = notTeraz(); persistNot();
    if (t.dataset.notpole === 'tytul') { const h = document.querySelector('.hdr h1'); if (h) h.textContent = t.value || 'Nowa notatka'; }
  } else if (t.dataset.notpkt !== undefined) { n.lista[+t.dataset.notpkt].t = t.value; n.zm = notTeraz(); persistNot(); }
});
document.addEventListener('change', e => {
  const t = e.target, n = currentNot(); if (!n || !t.dataset) return;
  if (t.dataset.notok !== undefined) {
    n.lista[+t.dataset.notok].ok = t.checked; n.zm = notTeraz(); persistNot();
    renderKeepScroll();
  }
  if (t.dataset.notfoto !== undefined && t.files && t.files.length) { notDodajZdjecia([...t.files]); t.value = ''; }
});

/* ---------- wpięcie w Biuro i nakładkę ---------- */
const _renderOffersTabNot = renderOffersTab;
renderOffersTab = function () {
  if (state.offerScreen === 'notatnik') return renderNotatnik();
  if (state.offerScreen === 'notatka') return renderNotatka();
  return _renderOffersTabNot();
};
const _renderOverlayNot = renderOverlay;
renderOverlay = function () {
  const el = document.getElementById('overlay');
  if (el && state.notRys) { el.innerHTML = notRysHtml(); return; }
  if (el && state.notZOf) {
    const l = state.offers.slice().reverse();
    el.innerHTML = `<div class="sheet" data-notzofzam role="dialog" aria-label="Wczytaj z oferty">
      <div class="sheet-in" data-stop>
        <div class="sheet-h">${svg('doc')}<strong>Wczytaj z oferty</strong>
          <button class="item-x" data-notzofzam aria-label="Zamknij">${svg('x')}</button></div>
        <div class="sheet-body">
          <p class="hint" style="margin:0 0 10px">Pozycje wybranej oferty trafią na listę „do kupienia / do zrobienia”.</p>
          ${l.map(o => { const t = offerTotals(o); return `<button class="ocard" data-notzof="${o.id}" style="margin-bottom:8px;width:100%">
            <span class="ocard-n">${esc(String(o.number).split('/')[0])}</span>
            <span class="ocard-t"><strong>${esc(o.client && o.client.name || 'Oferta bez nazwy')}</strong>
              <span>${plDate(o.date)} · ${t.count} poz.${o.invoice ? ' · faktura' : ''}</span></span>
            <span class="ocard-v"><b>${zl(t.gross)}</b><span>brutto</span></span></button>`; }).join('')}
        </div></div></div>`;
    return;
  }
  if (el && state.notUsun) {
    el.innerHTML = `<div class="sheet" data-notusunnie role="dialog" aria-label="Usunąć notatkę?">
      <div class="sheet-in" data-stop>
        <div class="sheet-h">${svg('trash')}<strong>Usunąć notatkę?</strong>
          <button class="item-x" data-notusunnie aria-label="Zamknij">${svg('x')}</button></div>
        <div class="sheet-body">
          <p class="hint" style="margin:0 0 14px">Zniknie tekst, lista i wszystkie zdjęcia z tej notatki.</p>
          <button class="jump" style="--c:#C62828" data-notusuntak>${svg('trash')}Usuń notatkę</button>
          <button class="btn2 not-nie" style="width:100%;margin-top:8px" data-notusunnie>Anuluj</button>
        </div></div></div>`;
    return;
  }
  return _renderOverlayNot();
};

/* ============================================================
   PRZYPOMNIENIE (DZWONECZEK)
   ------------------------------------------------------------
   W aplikacji na telefonie przypomnienie idzie przez wtyczkę
   LocalNotifications — przychodzi jak zwykłe powiadomienie, także gdy
   aplikacja jest zamknięta, a dotknięcie otwiera tę notatkę. Bez
   wtyczki (przeglądarka, podgląd) przypomnienie pokazuje się paskiem,
   kiedy aplikacja jest otwarta.
   ============================================================ */
ICO.dzwonek = '<path d="M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10.3 20a2 2 0 0 0 3.4 0"/>';
state.notDzw = false;          // arkusz ustawiania przypomnienia
const notPad = x => String(x).padStart(2, '0');
const notLokalnie = d => d.getFullYear() + '-' + notPad(d.getMonth() + 1) + '-' + notPad(d.getDate());
function notDzwHtml(n) {
  const d = n.przyp ? new Date(n.przyp) : new Date(Date.now() + 3600e3);
  const szybkie = [['Za godzinę', 'h1'], ['Dziś 16:00', 'd16'], ['Jutro 7:00', 'j7'], ['Jutro 16:00', 'j16'], ['Za tydzień 7:00', 't7']];
  return `<div class="sheet" data-notdzwzam role="dialog" aria-label="Przypomnienie">
    <div class="sheet-in" data-stop>
      <div class="sheet-h">${svg('dzwonek')}<strong>Przypomnienie</strong>
        <button class="item-x" data-notdzwzam aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        <p class="hint" style="margin:0 0 10px">${esc(n.tytul || 'Notatka bez tytułu')}</p>
        <div class="not-szybkie">${szybkie.map(s => `<button class="btn2" data-notszyb="${s[1]}">${s[0]}</button>`).join('')}</div>
        <div class="not-dt">
          <div class="field"><label for="nd-d">Dzień</label><input id="nd-d" type="date" value="${notLokalnie(d)}"></div>
          <div class="field"><label for="nd-g">Godzina</label><input id="nd-g" type="time" value="${notPad(d.getHours())}:${notPad(d.getMinutes())}"></div>
        </div>
        <button class="jump" style="--c:#6D5BD0;margin-top:12px" data-notdzwok>${svg('dzwonek')}Ustaw przypomnienie</button>
        ${n.przyp ? `<button class="btn2" style="width:100%;margin-top:8px;color:#C62828" data-notdzwusun>${svg('trash')}Usuń przypomnienie</button>` : ''}
        ${!naTelefonie() || !wtyczka('LocalNotifications') ? '<p class="hint" style="margin:10px 2px 0">W tej wersji przypomnienie pokaże się, gdy aplikacja będzie otwarta.</p>' : ''}
      </div></div></div>`;
}
function notPrzypNr(n) { if (!n.przypNr) n.przypNr = Math.floor(Math.random() * 2e9) + 1; return n.przypNr; }
function notPrzypAnuluj(n) {
  const ln = wtyczka('LocalNotifications');
  if (ln && n.przypNr) { try { ln.cancel({ notifications: [{ id: n.przypNr }] }); } catch (e) { /* trudno */ } }
}
async function notPrzypUstaw(n, kiedy) {
  notPrzypAnuluj(n);
  n.przyp = kiedy.toISOString(); n.przypPokaz = false; n.zm = notTeraz(); persistNot();
  const ln = wtyczka('LocalNotifications');
  if (!ln) return 'app';
  try {
    const u = await ln.requestPermissions();
    if (u && u.display && u.display !== 'granted') return 'odmowa';
    const tresc = (String(n.tekst || '').split('\n')[0] || n.lista.filter(x => !x.ok).map(x => x.t).join(', ') || 'Notatka z Asystenta Instalatora').slice(0, 120);
    await ln.schedule({ notifications: [{ id: notPrzypNr(n), title: '🔔 ' + (n.tytul || 'Notatka'), body: tresc,
      schedule: { at: kiedy, allowWhileIdle: true }, extra: { notId: n.id } }] });
    persistNot();
    return 'tel';
  } catch (e) { return 'app'; }
}
/* Dotknięcie powiadomienia otwiera notatkę. */
(function () {
  const ln = wtyczka('LocalNotifications');
  if (!ln || !ln.addListener) return;
  try {
    ln.addListener('localNotificationActionPerformed', a => {
      const id = a && a.notification && a.notification.extra && a.notification.extra.notId;
      const n = id && state.notatki.find(k => k.id === id); if (!n) return;
      n.przypPokaz = true; persistNot();
      state.tab = 'offers'; state.notId = id; state.offerScreen = 'notatka'; render(true);
    });
  } catch (e) { /* trudno */ }
})();
/* Przypomnienie w aplikacji — gdy nie ma powiadomień systemowych albo
   aplikacja i tak jest otwarta w chwili przypomnienia. */
state.notPrzypGo = null;
function notSprawdzPrzyp() {
  const teraz = new Date();
  const n = state.notatki.find(k => k.przyp && !k.przypPokaz && new Date(k.przyp) <= teraz);
  if (!n) return;
  n.przypPokaz = true; persistNot();
  state.notPrzypGo = n.id;
  toast('🔔 ' + (n.tytul || 'Przypomnienie z notatnika'), 'Pokaż');
}
setInterval(notSprawdzPrzyp, 30000);
setTimeout(notSprawdzPrzyp, 2500);
document.addEventListener('click', e => {
  if (state.notPrzypGo && e.target.closest('[data-toastgo]')) {
    const id = state.notPrzypGo; state.notPrzypGo = null; hideToast();
    state.tab = 'offers'; state.notId = id; state.offerScreen = 'notatka'; render(true);
    e.stopPropagation();
  }
}, true);
function notKiedySzybko(k) {
  const d = new Date();
  if (k === 'h1') return new Date(Date.now() + 3600e3);
  if (k === 'd16') { d.setHours(16, 0, 0, 0); if (d < new Date()) d.setDate(d.getDate() + 1); return d; }
  if (k === 'j7') { d.setDate(d.getDate() + 1); d.setHours(7, 0, 0, 0); return d; }
  if (k === 'j16') { d.setDate(d.getDate() + 1); d.setHours(16, 0, 0, 0); return d; }
  d.setDate(d.getDate() + 7); d.setHours(7, 0, 0, 0); return d;
}
async function notDzwZapisz(kiedy) {
  const n = currentNot(); if (!n) return;
  if (!(kiedy > new Date())) { toast('Wybierz czas w przyszłości.'); return; }
  state.notDzw = false; renderOverlay();
  const w = await notPrzypUstaw(n, kiedy);
  renderKeepScroll();
  toast(w === 'odmowa' ? 'Telefon nie pozwolił na powiadomienia — przypomnienie pokaże się w aplikacji.'
    : 'Przypomnę ' + notData(n.przyp) + (w === 'tel' ? '.' : ' (gdy aplikacja będzie otwarta).'));
}
document.addEventListener('click', e => {
  const t = e.target, ds = s => t.closest(s);
  if (ds('[data-notdzw]')) { if (currentNot()) { state.notDzw = true; renderOverlay(); } return; }
  if (!state.notDzw) return;
  let x;
  if ((x = ds('[data-notszyb]'))) { notDzwZapisz(notKiedySzybko(x.dataset.notszyb)); return; }
  if (ds('[data-notdzwok]')) {
    const d = document.getElementById('nd-d'), g = document.getElementById('nd-g');
    if (!d || !d.value || !g || !g.value) { toast('Wybierz dzień i godzinę.'); return; }
    const [r, m, dz] = d.value.split('-').map(Number), [h, mi] = g.value.split(':').map(Number);
    notDzwZapisz(new Date(r, m - 1, dz, h, mi, 0, 0)); return;
  }
  if (ds('[data-notdzwusun]')) {
    const n = currentNot(); if (n) { notPrzypAnuluj(n); delete n.przyp; delete n.przypPokaz; persistNot(); }
    state.notDzw = false; renderOverlay(); renderKeepScroll(); toast('Usunięto przypomnienie.'); return;
  }
  if (ds('[data-notdzwzam]') && (!ds('[data-stop]') || ds('.sheet-h [data-notdzwzam]'))) { state.notDzw = false; renderOverlay(); }
});
const _renderOverlayDzw = renderOverlay;
renderOverlay = function () {
  const el = document.getElementById('overlay'), n = currentNot();
  if (el && state.notDzw && n) { el.innerHTML = notDzwHtml(n); return; }
  return _renderOverlayDzw();
};

/* ---------- plusik przy liście: katalog produktów ----------
   Wybrana pozycja trafia na listę „do kupienia” z nazwą z katalogu;
   przy „Nieodhaczone do oferty” idzie z ceną i jednostką z cennika.
   „Pozycja własna” z katalogu wraca do pola tekstowego. */
state.notPick = null;
function notZKatalogu(c, qty) {
  const n = state.notatki.find(k => k.id === state.notPick); if (!n || !c) return;
  const it = itemFromCatalog(c, qty || 1);
  n.lista.push({ t: c.name, ok: false, qty: qty || 1,
    kat: { name: it.name, unit: it.unit, cat: it.cat, price: it.price, tag: it.tag, katId: it.katId } });
  n.zm = notTeraz();
}
document.addEventListener('click', e => {
  if (!state.notPick || !state.picker) return;
  const t = e.target;
  const koniec = (fokus) => {
    persistNot();
    state.picker = false; state.pickSel = null; state.pickQ = ''; state.notPick = null;
    e.stopPropagation(); e.preventDefault();
    renderOverlay(); renderKeepScroll();
    if (fokus) { const i = document.querySelector('[data-notnowypkt]'); if (i) i.focus(); }
  };
  const pick = t.closest('[data-pick]');
  if (pick && !state.pickSel) {
    if (typeof dlugiZaszlo !== 'undefined' && dlugiZaszlo) return;
    notZKatalogu(catalogById(pick.dataset.pick), 1); koniec(); toast('Dodano do listy.'); return;
  }
  if (t.closest('[data-seladd]')) {
    const sel = state.pickSel || {}, ids = Object.keys(sel);
    ids.forEach(id => notZKatalogu(catalogById(id), sel[id])); koniec();
    if (ids.length) toast('Dodano do listy: ' + ids.length + ' poz.'); return;
  }
  if (t.closest('[data-newin], [data-custom]')) { koniec(true); toast('Wpisz punkt w pole i naciśnij Enter.'); return; }
  const close = t.closest('[data-closepicker]');
  if (close && (close.classList.contains('sheet') ? t === close : true)) koniec();
}, true);

/* + i − pokazują się dopiero po dotknięciu pozycji; dotknięcie gdzie
   indziej chowa je i wiersz wraca do zwykłej wysokości. */
document.addEventListener('click', e => {
  const t = e.target, w = t.closest('.not-pkt');
  document.querySelectorAll('.not-pkt.akt').forEach(r => { if (r !== w) r.classList.remove('akt'); });
  if (!w || t.closest('input[type=checkbox], .item-x, [data-notile]')) return;
  w.classList.add('akt');
}, true);

/* Dłuższa nazwa punktu zawija się na kolejne linijki — pole rośnie
   razem z tekstem. */
function notDopasujPola() {
  document.querySelectorAll('.not-pkt-t').forEach(t => { t.style.height = 'auto'; t.style.height = t.scrollHeight + 'px'; });
}
document.addEventListener('input', e => { if (e.target.classList && e.target.classList.contains('not-pkt-t')) { e.target.style.height = 'auto'; e.target.style.height = e.target.scrollHeight + 'px'; } });
document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.classList && e.target.classList.contains('not-pkt-t')) { e.preventDefault(); e.target.blur(); }
});
new MutationObserver(() => { if (document.querySelector('.not-pkt-t')) notDopasujPola(); })
  .observe(document.body, { childList: true, subtree: true });

