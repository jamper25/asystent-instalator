/* ===== projekty_zest.js ===== */
/* ============================================================
   ZESTAWIENIE CZĘŚCI PROJEKTU — EDYCJA
   ------------------------------------------------------------
   Zestawienie liczy się samo z danych części, ale instalator ma
   ostatnie słowo: poprawia nazwę, ilość i cenę, wyrzuca to, czego nie
   potrzebuje, i dokłada coś z katalogu.

   Poprawki leżą obok wyliczenia (p.zest[część]):
   zm  — { klucz: { name, qty, price, usun } } dla pozycji wyliczonych,
   dod — pozycje dołożone ręcznie albo z katalogu,
   wyb — { klucz: true/false } zaznaczenia do oferty.
   Zmiana danych (np. trzeci grzejnik) dalej dopisuje się do
   zestawienia, a ręczne poprawki zostają.
   ============================================================ */
state.pickCel = null;          // { p, c } — katalog dokłada do zestawienia części

function projZestStan(p, c) {
  if (!p.zest) p.zest = {};
  if (!p.zest[c]) p.zest[c] = { zm: {}, dod: [], wyb: {} };
  const z = p.zest[c];
  z.zm = z.zm || {}; z.dod = z.dod || []; z.wyb = z.wyb || {};
  return z;
}
function projZestBaza(p, c) {
  if (!p.czesci[c]) return [];
  const w = projCzWynik(p, c);
  try {
    return c === 'kot' ? projZestawienie(w.v) : projZestawienieKalk(c, w.mode.key, w.v, w.res);
  } catch (e) { return []; }
}
function projZestPelne(p, c) {
  const z = projZestStan(p, c);
  const uzyte = {};
  const L = [];
  projZestBaza(p, c).forEach(it => {
    let k = 'g:' + it.name;
    while (uzyte[k]) k += '+';
    uzyte[k] = true;
    const m = z.zm[k] || {};
    if (m.usun) return;
    L.push(Object.assign({}, it, {
      klucz: k, cz: c,
      name: m.name != null ? m.name : it.name,
      qty: m.qty != null ? m.qty : it.qty,
      price: m.price != null ? m.price : (it.price || 0),
      cenaWlasna: m.price != null,
    }));
  });
  z.dod.forEach(it => L.push(Object.assign({}, it, { klucz: 'd:' + it.id, cz: c, dod: true })));
  return L;
}
function projZaznaczona(p, it) {
  const w = projZestStan(p, it.cz).wyb[it.klucz];
  return w === undefined ? !it.wyl : w;
}
/* Wszystko zaznaczone ze wszystkich części — do oferty. */
function projZaznaczoneWszystkie(p) {
  return projCzesciWszystkie(p).reduce((a, c) => a.concat(projZestPelne(p, c).filter(it => projZaznaczona(p, it))), []);
}
const projLiczba = s => { const n = parseFloat(String(s).replace(/\s/g, '').replace(',', '.')); return isFinite(n) ? n : 0; };
const projLiczbaTxt = n => String(Math.round(n * 100) / 100).replace('.', ',');
const projSuma = L => L.reduce((a, it) => a + (Number(it.price) || 0) * (Number(it.qty) || 0), 0);

/* Rozwijane zestawienie jednej części. */
function projZestHtml(p, c) {
  const zest = projZestPelne(p, c);
  const z = projZestStan(p, c);
  const usuniete = Object.keys(z.zm).filter(k => z.zm[k].usun).length;
  const zazn = zest.filter(it => projZaznaczona(p, it));
  const zrodloCeny = it => it.cenaWlasna ? 'cena zmieniona' : it.zCennika || it.katId ? 'z cennika' : (it.price ? '' : 'cena do wpisania');
  const id = k => esc(c + '|' + k);
  return `<details class="proj-det" data-projdet="${c}"${state.projOtwarte[c] ? ' open' : ''}>
      <summary>${svg('list')}<span>Zestawienie elementów</span><em data-sumacz="${c}">${zazn.length}/${zest.length} poz. · ${zl(projSuma(zazn))}</em>${svg('chevDown')}</summary>
      <p class="hint" style="margin:8px 2px">Zaznacz, co ma trafić do oferty. Nazwę, ilość i cenę poprawisz wprost na liście, krzyżykiem usuniesz to, czego nie potrzeba.</p>
      <div class="proj-zest">${zest.map(it => `<div class="proj-poz${projZaznaczona(p, it) ? '' : ' proj-poz--off'}">
          <input type="checkbox" data-projzaz="${id(it.klucz)}"${projZaznaczona(p, it) ? ' checked' : ''} aria-label="Do oferty">
          <div class="proj-poz-t">
            <textarea class="proj-in proj-in--n" rows="${Math.min(3, Math.ceil(String(it.name).length / 24) || 1)}" data-pzpole="name" data-pzk="${id(it.klucz)}" aria-label="Nazwa">${esc(it.name)}</textarea>
            <div class="proj-poz-r">
              <input class="proj-in proj-in--q" type="text" inputmode="decimal" value="${projLiczbaTxt(Number(it.qty) || 0)}" data-pzpole="qty" data-pzk="${id(it.klucz)}" aria-label="Ilość">
              <span>${esc(it.unit)} ×</span>
              <input class="proj-in proj-in--c" type="text" inputmode="decimal" value="${projLiczbaTxt(Number(it.price) || 0)}" data-pzpole="price" data-pzk="${id(it.klucz)}" aria-label="Cena netto">
              <span>zł</span>
            </div>
            <small>${it.cat === 'rob' ? 'robocizna' : 'materiał'}${zrodloCeny(it) ? ' · ' + zrodloCeny(it) : ''}${it.dod ? ' · dodane' : ''}</small>
          </div>
          <button class="proj-x" data-pzusun="${id(it.klucz)}" aria-label="Usuń pozycję" title="Usuń">${svg('x')}</button>
        </div>`).join('') || '<p class="empty">Pusto — dodaj pozycje z katalogu.</p>'}</div>
      <div class="proj-btny" style="margin:10px 0 0">
        <button class="btn2" data-pzkatalog="${c}">${svg('plus')}Dodaj z katalogu</button>
        ${usuniete ? `<button class="btn2" data-pzprzywroc="${c}">${svg('restore')}Przywróć usunięte (${usuniete})</button>` : ''}
      </div>
    </details>`;
}

function projDodajPozycje(p, c, it) {
  const z = projZestStan(p, c);
  const id = 'x' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
  z.dod.push(Object.assign({ name: 'Pozycja własna', unit: 'szt', cat: 'mat', price: 0, tag: null, qty: 1 }, it, { id }));
  p.zm = projDzis();
}
const projRozbij = s => { const i = s.indexOf('|'); return { c: s.slice(0, i), k: s.slice(i + 1) }; };

/* Sumy liczą się na bieżąco, bez przerysowania — inaczej przejście
   z ilości do ceny gubiłoby kursor. */
function projZestSumy() {
  const p = currentProjekt(); if (!p) return;
  document.querySelectorAll('[data-sumacz]').forEach(el => {
    const c = el.dataset.sumacz;
    const zest = projZestPelne(p, c), zazn = zest.filter(it => projZaznaczona(p, it));
    el.textContent = zazn.length + '/' + zest.length + ' poz. · ' + zl(projSuma(zazn));
  });
  const og = document.querySelector('[data-sumaall]');
  if (og) { const L = projZaznaczoneWszystkie(p); og.textContent = 'Zaznaczone we wszystkich częściach: ' + L.length + ' poz. · razem netto ' + zl(projSuma(L)); }
}

document.addEventListener('input', e => {
  const t = e.target;
  if (!t.dataset || !t.dataset.pzpole) return;
  const p = currentProjekt(); if (!p) return;
  const { c, k } = projRozbij(t.dataset.pzk), z = projZestStan(p, c), pole = t.dataset.pzpole;
  const w = pole === 'name' ? t.value : projLiczba(t.value);
  if (k.startsWith('d:')) { const it = z.dod.find(x => 'd:' + x.id === k); if (it) it[pole] = w; }
  else z.zm[k] = Object.assign({}, z.zm[k], { [pole]: w });
  p.zm = projDzis(); persistProj();
  projZestSumy();
});
document.addEventListener('change', e => {
  const t = e.target;
  if (!t.dataset || t.dataset.projzaz === undefined) return;
  const p = currentProjekt(); if (!p) return;
  const { c, k } = projRozbij(t.dataset.projzaz);
  projZestStan(p, c).wyb[k] = t.checked; persistProj();
  const w = t.closest('.proj-poz'); if (w) w.classList.toggle('proj-poz--off', !t.checked);
  projZestSumy();
});

document.addEventListener('click', e => {
  const t = e.target;
  // rozwinięcie zestawienia zapamiętujemy, żeby przetrwało przerysowanie
  const sum = t.closest('.proj-det > summary');
  if (sum) { const d = sum.parentElement; state.projOtwarte[d.dataset.projdet] = !d.open; return; }

  // katalog otwarty z oferty — nie z projektu
  if (t.closest('[data-additem]')) { state.pickCel = null; return; }

  // katalog otwarty z projektu: dokładamy do zestawienia części zamiast do oferty
  if (state.pickCel && state.picker) {
    const p = state.projekty.find(x => x.id === state.pickCel.p), c = state.pickCel.c;
    const zamknij = msg => {
      persistProj();
      state.picker = false; state.pickSel = null; state.pickQ = ''; state.pickCel = null;
      state.projOtwarte[c] = true;
      renderKeepScroll(); if (msg) toast(msg);
      e.stopPropagation(); e.preventDefault();
    };
    const pick = t.closest('[data-pick]');
    if (p && pick && !state.pickSel) {
      if (typeof dlugiZaszlo !== 'undefined' && dlugiZaszlo) return;   // długie przytrzymanie — obsłuży katalog
      const k = catalogById(pick.dataset.pick);
      if (k) projDodajPozycje(p, c, itemFromCatalog(k, 1));
      zamknij(k ? 'Dodano do zestawienia: ' + k.name + '.' : '');
      return;
    }
    if (p && t.closest('[data-seladd]')) {
      const ids = Object.keys(state.pickSel || {});
      ids.forEach(id => { const k = catalogById(id); if (k) projDodajPozycje(p, c, itemFromCatalog(k, state.pickSel[id])); });
      zamknij(ids.length ? 'Dodano do zestawienia: ' + ids.length + ' poz.' : '');
      return;
    }
    if (p && t.closest('[data-newin], [data-custom]')) {
      projDodajPozycje(p, c, {});
      zamknij('Wpisz nazwę, ilość i cenę nowej pozycji.');
      const pola = document.querySelectorAll(`[data-projdet="${c}"] [data-pzpole="name"]`);
      const ost = pola[pola.length - 1];
      if (ost) { ost.focus(); ost.select(); ost.scrollIntoView({ block: 'center' }); }
      return;
    }
  }

  const kat = t.closest('[data-pzkatalog]');
  if (kat) {
    const p = currentProjekt(); if (!p) return;
    state.pickCel = { p: p.id, c: kat.dataset.pzkatalog };
    state.picker = true; state.pickGrp = null; state.pickDn = null;
    state.pickWar = null; state.pickQ = ''; state.pickSel = null;
    renderOverlay(); return;
  }
  const u = t.closest('[data-pzusun]');
  if (u) {
    const p = currentProjekt(); if (!p) return;
    const { c, k } = projRozbij(u.dataset.pzusun), z = projZestStan(p, c);
    if (k.startsWith('d:')) z.dod = z.dod.filter(x => 'd:' + x.id !== k);
    else z.zm[k] = Object.assign({}, z.zm[k], { usun: true });
    p.zm = projDzis(); persistProj(); renderKeepScroll();
    toast('Usunięto z zestawienia.' + (k.startsWith('g:') ? ' Wróci przyciskiem „Przywróć usunięte”.' : ''));
    return;
  }
  const prz = t.closest('[data-pzprzywroc]');
  if (prz) {
    const p = currentProjekt(); if (!p) return;
    const z = projZestStan(p, prz.dataset.pzprzywroc);
    Object.keys(z.zm).forEach(k => { delete z.zm[k].usun; });
    persistProj(); renderKeepScroll(); return;
  }
}, true);

