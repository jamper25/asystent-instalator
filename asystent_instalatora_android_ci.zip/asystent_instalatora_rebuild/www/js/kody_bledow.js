/* ===== kody_bledow.js ===== */
/* ============================================================
   KODY BŁĘDÓW — ekran w zakładce Asystent
   Dane: kody_dane.js (KODY_BLEDOW). Działa bez internetu.
   Stan: state.kody = { rodzaj: 'kociol' | 'pompa', marka: 'wszystkie' | id, q: '' } — gdy null,
   zakładka Asystent pokazuje swój zwykły ekran.
   ============================================================ */

/* Normalizacja kodu: wielkie litery, bez kropek, spacji i myślników.
   Druga postać bez zer wiodących w ciągach cyfr, żeby F22 znalazło F.022,
   a E1 znalazło E01. */
function kodNorm(s) { return String(s || '').toUpperCase().replace(/[^0-9A-ZĄĆĘŁŃÓŚŹŻ]/g, ''); }
function kodBezZer(s) { return s.replace(/(^|[^0-9])0+(?=[0-9])/g, '$1'); }

/* Zapytanie może łączyć model i kod: „Inidens”, „Thelia F28”, „F.75”.
   Słowa z co najmniej trzema literami pod rząd, które pasują do nazwy
   serii albo modelu, zawężają serie; reszta to kod (albo słowo z opisu). */
const KOD_LITERY = /[a-ząćęłńóśźż]{3}/;
function kodSeriaHay(m, s) { return (m.marka + ' ' + s.n + ' ' + s.o + ' ' + (s.m || '')).toLowerCase(); }

const KOD_RODZAJE = { kociol: 'kocioł', pompa: 'pompa ciepła' };
/* Marki z seriami przyciętymi do wybranej zakładki. `m` zostaje oryginalnym
   obiektem marki (indeksy serii muszą pasować do KODY_BLEDOW), więc zwracamy
   parę { m, serie } zamiast kopii marki. */
function kodySerieOk(rodzaj, typ, s) {
  if (rodzaj !== 'kociol') return true;
  return typ === 'niekond' ? !s.kond : !!s.kond;
}
function kodyMarki(rodzaj, markaId, typ) {
  const out = [];
  KODY_BLEDOW.forEach(m => {
    if (m.rodzaj !== KOD_RODZAJE[rodzaj]) return;
    if (markaId && markaId !== 'wszystkie' && m.id !== markaId) return;
    const serie = m.serie.filter(s => kodySerieOk(rodzaj, typ, s));
    if (serie.length) out.push({ m, serie, id: m.id, marka: m.marka });
  });
  return out;
}

function kodyWyniki(rodzaj, markaId, q, typ) {
  const marki = kodyMarki(rodzaj, markaId, typ);
  const slowa = String(q || '').trim().toLowerCase().split(/\s+/).filter(Boolean);
  const modelowe = [], tekstowe = [], kodowe = [];
  slowa.forEach(w => {
    const pasuje = w.length >= 3 && /[a-ząćęłńóśźż]/.test(w)
      && marki.some(g => g.serie.some(s => kodSeriaHay(g.m, s).includes(w)));
    if (pasuje) modelowe.push(w);
    else if (KOD_LITERY.test(w)) tekstowe.push(w);
    else kodowe.push(w);
  });
  /* Liczba przy nazwie modelu („Vitocal 150”, „Vitodens 100”) to część
     modelu, nie kod — o ile taka seria istnieje. */
  if (modelowe.length) {
    const pasujace = marki.flatMap(g => g.serie.map(s => kodSeriaHay(g.m, s))).filter(h => modelowe.every(w => h.includes(w)));
    for (let i = kodowe.length - 1; i >= 0; i--) {
      const re = new RegExp('(^|[^0-9])' + kodowe[i].replace(/[^0-9a-z]/g, '') + '([^0-9]|$)');
      const krotkie = /^[a-ząćęłńóśźż]{1,2}$/.test(kodowe[i]);
      if ((/^[0-9]{2,4}$/.test(kodowe[i]) || krotkie) && pasujace.some(h => re.test(h))) modelowe.push(kodowe.splice(i, 1)[0]);
    }
  }
  const qn = kodNorm(kodowe.join('')), qz = kodBezZer(qn);
  const lista = [];
  marki.forEach(g => g.serie.forEach(s => {
    const m = g.m;
    if (modelowe.length) { const h = kodSeriaHay(m, s); if (!modelowe.every(w => h.includes(w))) return; }
    s.kody.forEach(k => {
      if (tekstowe.length) { const t = (k.n + ' ' + k.o).toLowerCase(); if (!tekstowe.every(w => t.includes(w))) return; }
      let ocena = 1;
      if (qn) {
        const kn = kodNorm(k.k), kz = kodBezZer(kn);
        const czesci = String(k.k).split(/[\s\/()]+/).map(kodNorm).filter(Boolean);
        if (kn === qn || kz === qz || czesci.some(c => c === qn || kodBezZer(c) === qz)) ocena = 3;
        else if (kn.startsWith(qn) || kz.startsWith(qz)) ocena = 2;
        else ocena = 0;
      }
      if (ocena) lista.push({ m, s, k, ocena });
    });
  }));
  lista.sort((a, b) => b.ocena - a.ocena);
  return { lista, grupuj: !qn && !tekstowe.length, pusty: !slowa.length };
}

function kodHtml(r) {
  const k = r.k;
  const lista = (t, arr, tag) => arr && arr.length
    ? `<h4>${t}</h4><${tag}>${arr.map(x => `<li>${esc(x)}</li>`).join('')}</${tag}>` : '';
  return `<details class="kod-item">
      <summary><span class="kod-k">${esc(k.k)}</span>
        <span class="kod-t"><b>${esc(k.n)}</b><span>${esc(r.m.marka)} · ${esc(r.s.n)}</span></span>
        <span class="kb-mark">${svg('chevDown')}</span></summary>
      <div class="kod-a">
        ${k.g ? `<p class="kod-gaz">${svg('alert')}Wymaga uprawnień gazowych</p>` : ''}
        ${k.f ? `<p class="kod-gaz">${svg('alert')}Praca przy czynniku — uprawnienia F-gaz</p>` : ''}
        <p>${esc(k.o)}</p>
        ${lista('Możliwe przyczyny', k.p, 'ul')}
        ${lista('Co sprawdzić', k.s, 'ol')}
        ${k.w ? `<p class="kod-uw">Opis z wtórnego źródła — potwierdź w instrukcji modelu.</p>` : ''}
        ${k.z ? `<p class="kod-zr">Źródło: ${esc(k.z)}</p>` : ''}
      </div>
    </details>`;
}

/* Seria (model) jako rozwijana karta; kody wstawiamy dopiero przy
   rozwinięciu, żeby lista ponad tysiąca kodów nie spowalniała ekranu. */
function kodSeriaHtml(m, s, otwarta) {
  const ile = s.kody.length;
  return `<details class="kod-seria" data-kodseria="${m.id}|${m.serie.indexOf(s)}"${otwarta ? ' open' : ''}>
      <summary><span class="kod-s-t"><b>${esc(s.n)}</b>
        ${s.m ? `<span>${esc(s.m)}</span>` : ''}</span>
        <span class="kod-s-ile">${ile} ${odmiana(ile, 'kod', 'kody', 'kodów')}</span>
        <span class="kb-mark">${svg('chevDown')}</span></summary>
      <div class="kod-s-body">${otwarta ? kodySeriiHtml(m, s) : ''}</div>
    </details>`;
}
function kodySeriiHtml(m, s) {
  return '<div class="kb">' + s.kody.map(k => kodHtml({ m, s, k })).join('') + '</div>';
}

function kodyListaHtml() {
  const st = state.kody;
  const q = String(st.q || '').trim();
  const marki = kodyMarki(st.rodzaj, st.marka, st.typ);
  // bez wpisanego tekstu: marki → modele (zwinięte) → kody
  if (!q) {
    if (!marki.length) return `<p class="empty">Tu jeszcze nic nie ma.</p>`;
    return marki.map(g => (st.marka === 'wszystkie'
        ? `<div class="cat-head" style="--c:var(--flame)"><span class="cat-dot"></span>${esc(g.marka)}</div>` : '')
      + `<div class="kod-serie">${g.serie.map(s => kodSeriaHtml(g.m, s, false)).join('')}</div>`).join('');
  }
  const { lista: wyn, grupuj } = kodyWyniki(st.rodzaj, st.marka, q, st.typ);
  if (!wyn.length) {
    const gdzie = [];
    if (st.rodzaj === 'kociol') {
      const innyTyp = st.typ === 'niekond' ? 'kond' : 'niekond';
      const ile = kodyWyniki('kociol', 'wszystkie', q, innyTyp).lista.length;
      if (ile) gdzie.push({ a: 'data-kodtyp="' + innyTyp + '"', t: innyTyp === 'niekond' ? 'kotły niekondensacyjne' : 'kotły kondensacyjne', ile });
    }
    const inny = st.rodzaj === 'kociol' ? 'pompa' : 'kociol';
    const ileInny = kodyWyniki(inny, 'wszystkie', q, 'kond').lista.length
      + (inny === 'kociol' ? kodyWyniki('kociol', 'wszystkie', q, 'niekond').lista.length : 0);
    if (ileInny) gdzie.push({ a: 'data-kodrodzaj="' + inny + '"', t: inny === 'pompa' ? 'pompy ciepła' : 'kotły gazowe', ile: ileInny });
    return `<p class="empty">Nie znalazłem „${esc(q)}”${st.marka !== 'wszystkie' ? ' w tej marce' : ''}.<br>`
      + (gdzie.length ? gdzie.map(g => `<button type="button" class="kb-link" ${g.a}>Znaleziono w: ${g.t} (${g.ile})${svg('arrow')}</button>`).join('')
                      : `Wpisz sam kod (np. „F28”, „E01”) albo model i kod (np. „Inidens H.02.04”).`) + '</p>';
  }
  // wpisany tylko model: pokaż pasujące modele do rozwinięcia
  if (grupuj) {
    const serie = [];
    wyn.forEach(r => { if (!serie.some(x => x.s === r.s)) serie.push(r); });
    return `<div class="kod-serie">${serie.map(r => kodSeriaHtml(r.m, r.s, serie.length === 1)).join('')}</div>`;
  }
  const LIMIT = 80;
  return `<p class="kod-ile">Znaleziono: ${wyn.length}</p><div class="kb">`
    + wyn.slice(0, LIMIT).map(kodHtml).join('') + '</div>'
    + (wyn.length > LIMIT ? `<p class="kod-ile">Pokazuję ${LIMIT} pierwszych — wpisz dokładniej.</p>` : '');
}

function kodyChipyHtml() {
  const st = state.kody;
  const marki = [{ id: 'wszystkie', marka: 'Wszystkie' }].concat(kodyMarki(st.rodzaj, null, st.typ));
  return marki.map(m => `<button type="button" class="kod-chip${st.marka === m.id ? ' on' : ''}" data-kodmarka="${m.id}">${esc(m.marka)}</button>`).join('');
}

function renderKody() {
  const st = state.kody;
  const segBtn = (r, t) => `<button type="button" data-kodrodzaj="${r}" aria-pressed="${st.rodzaj === r}">${t}</button>`;
  return `<header class="hdr"><span class="blob a"></span><span class="blob b"></span>
      <div class="hdr-row"><button class="back" data-kodyback aria-label="Wróć">${svg('back')}</button>
      <div><h1>Kody błędów</h1><p>Kotły gazowe i pompy ciepła — bez internetu</p></div></div></header>
    <div class="body">
      <div class="seg kod-seg">${segBtn('kociol', 'Kotły gazowe')}${segBtn('pompa', 'Pompy ciepła')}</div>
      ${st.rodzaj === 'kociol' ? `<div class="seg seg--sm kod-seg2">
        <button type="button" data-kodtyp="kond" aria-pressed="${st.typ !== 'niekond'}">Kondensacyjne</button>
        <button type="button" data-kodtyp="niekond" aria-pressed="${st.typ === 'niekond'}">Niekondensacyjne</button></div>` : ''}
      <div class="search">${svg('search')}
        <input id="kodq" type="search" placeholder="${st.rodzaj === 'pompa' ? 'Kod lub model, np. U4, H62' : 'Kod lub model, np. F28, Inidens'}"
          value="${esc(st.q)}" aria-label="Szukaj kodu błędu" autocomplete="off"></div>
      <div class="kod-chipy">${kodyChipyHtml()}</div>
      <div id="kodWyn">${kodyListaHtml()}</div>
      <div class="tip">${svg('alert')}<div>Opisy przygotowane na podstawie instrukcji producentów. Ten sam kod
        może znaczyć co innego w innej serii — porównaj z instrukcją konkretnego modelu.
        Prace przy układzie gazowym i obiegu chłodniczym tylko z uprawnieniami.</div></div>
    </div>`;
}

function kodyKartaHtml() {
  return `<button class="ocard" data-kodyopen>
      <span class="ocard-n" style="background:color-mix(in srgb,var(--cat-heat) 14%,transparent);color:var(--cat-heat)">${svg('wrench')}</span>
      <span class="ocard-t"><strong>Kody błędów</strong>
        <span>Kotły i pompy ciepła — ${KODY_ILE} ${odmiana(KODY_ILE, 'kod', 'kody', 'kodów')}</span></span>
      <span class="tile-chev">${svg('chev')}</span>
    </button>`;
}

/* ---------- Zdarzenia ---------- */
function kodyOdswiez() {
  const w = document.getElementById('kodWyn'); if (w) w.innerHTML = kodyListaHtml();
}
document.addEventListener('click', e => {
  if (e.target.closest('[data-kodyopen]')) { state.kody = { rodzaj: 'kociol', typ: 'kond', marka: 'wszystkie', q: '' }; render(true); return; }
  if (e.target.closest('[data-kodyback]')) { state.kody = null; render(true); return; }
  if (!state.kody) return;
  const tb = e.target.closest('[data-kodtyp]');
  if (tb && state.kody.rodzaj === 'kociol') {
    if (tb.dataset.kodtyp !== (state.kody.typ || 'kond')) {
      state.kody.typ = tb.dataset.kodtyp; state.kody.marka = 'wszystkie';
      const vp2 = document.getElementById('viewport'), y2 = vp2 ? vp2.scrollTop : 0;
      render(false); if (vp2) vp2.scrollTop = Math.min(y2, 160);
    }
    return;
  }
  const rb = e.target.closest('[data-kodrodzaj]');
  if (rb) {
    if (rb.dataset.kodrodzaj !== state.kody.rodzaj) {
      state.kody.rodzaj = rb.dataset.kodrodzaj; state.kody.marka = 'wszystkie';
      const vp = document.getElementById('viewport'), y = vp ? vp.scrollTop : 0;
      render(false); if (vp) vp.scrollTop = Math.min(y, 120);
    }
    return;
  }
  const ch = e.target.closest('[data-kodmarka]');
  if (ch) {
    state.kody.marka = ch.dataset.kodmarka;
    document.querySelectorAll('.kod-chip').forEach(b => b.classList.toggle('on', b === ch));
    kodyOdswiez();
  }
});
// rozwinięcie modelu: dopiero teraz wstawiamy jego kody
document.addEventListener('toggle', e => {
  const d = e.target;
  if (!d.classList || !d.classList.contains('kod-seria') || !d.open) return;
  const body = d.querySelector('.kod-s-body');
  if (!body || body.childElementCount) return;
  const [id, i] = d.dataset.kodseria.split('|');
  const m = KODY_BLEDOW.find(x => x.id === id), s = m && m.serie[+i];
  if (s) body.innerHTML = kodySeriiHtml(m, s);
}, true);
document.addEventListener('input', e => {
  if (e.target.id !== 'kodq' || !state.kody) return;
  state.kody.q = e.target.value;
  kodyOdswiez();
});

