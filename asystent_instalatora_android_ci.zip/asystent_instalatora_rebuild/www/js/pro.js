/* ===== pro.js ===== */
/* ============================================================
   ABONAMENT — podgląd zamiast kłódki
   ------------------------------------------------------------
   Kalkulator płatny otwiera się normalnie i pokazuje gotowe
   obliczenie: wynik, rysunek i opisy „skąd to się wzięło”.
   Zablokowane jest samo wpisywanie — dotknięcie pola otwiera
   arkusz z ceną. Kłódka na liście odstrasza, zanim człowiek
   zobaczy, za co miałby zapłacić; policzony przykład broni się sam.

   Kto wpisał już swoje dane w darmowej wersji, widzi dalej swoje,
   a nie przykład — to jego praca i nie znika przez aktualizację.
   ============================================================ */

const PRO_KALK = ['co_dia', 'rozdz_dia', 'woda_dia', 'gas', 'kotlownia'];
const PRO_KEY = 'ai_pro_v1';
const PRO_CENA = '29 zł';
const PRO_CENA_ROK = '249 zł';

state.pro = (function () {
  try { const r = localStorage.getItem(PRO_KEY); if (r) return JSON.parse(r) || {}; }
  catch (e) { /* prywatne okno — startujemy bez abonamentu */ }
  return {};
})();
function proZapisz() { try { localStorage.setItem(PRO_KEY, JSON.stringify(state.pro)); } catch (e) { /* bez zapisu też działa */ } }

/* Stan abonamentu: zapamiętany wynik ostatniego sprawdzenia w Google Play
   (patrz niżej, GOOGLE PLAY BILLING). Reszta aplikacji pyta tylko tutaj. */
function proMa() { return !!state.pro.aktywny; }
function proPlatny(id) { return PRO_KALK.indexOf(id) !== -1; }
function proPodglad(id) { return proPlatny(id) && !proMa(); }

/* ---------- przykładowe wpisy ----------
   Tyle, żeby wynik wyglądał jak z prawdziwej budowy: nazwy pomieszczeń,
   sensowne moce, wpisana długość rury. Reszta pól zostaje domyślna. */
const PRO_PRZYKLADY = {
  'co_dia::troj': {
    rad: [1150, 820, 480, 900, 760],
    radNazwy: ['Salon', 'Kuchnia', 'Łazienka', 'Sypialnia', 'Pokój dziecka'],
    radGrz: [], radGrz2: [], radDziel: [], reg: 1, dlZr: 22,
  },
  'co_dia::rozdz': {
    rad: [900, 1100, 650, 700],
    radNazwy: ['Sypialnia', 'Gabinet', 'Łazienka', 'Pokój'],
    reg: 1, dlZr: 14,
  },
  'rozdz_dia::_': {
    rozdz: [
      { nazwa: 'Parter', w: 6200, wyj: 7, dl: 9, dp: 16, metrow: 640, dlPetli: 108, rury: ['PE-RT 16×2'] },
      { nazwa: 'Piętro', w: 4600, wyj: 5, dl: 14, dp: 18, metrow: 380, dlPetli: 92, rury: ['PE-RT 16×2'] },
    ],
    mie: 'mieszacz', mieGdzie: 'osob',
  },
  /* Kotłownia pokazuje pełny schemat: źródło, zasobnik, sprzęgło i trzy
     obiegi z kalkulatorów — z rozdzielaczem, mieszaczem i średnicami DN
     na rurach. Obiegi są dokładnie takie, jakie wychodzą z „Ogrzewania
     grzejnikowego” i „podłogowego”, więc rysunek niczego nie udaje.
     Znacznik _zProjektu mówi kreatorowi, że obiegi są z zewnątrz —
     bez niego kreator z menu czyści je i rysuje samą kotłownię. */
  'kotlownia::_': {
    zr: 'k1', uklad: 'zam', wym: 'nie', cwu: 'zas', zasL: 200, prio: 'tak', cyrk: 'tak',
    grp: 'kot', sep: 'sprz', _zProjektu: true,
    ob: [
      { r: 'grz', kw: 4.1, n: 'Parter', dl: 22, hP: 3.21, qP: 0.236, hPz: 'co', rozd: null,
        rk: { s: 'obieg', mat: 'copper', p: '15x1', in: 13, q: 0.2356, vAct: 0.493, v: 0.6 } },
      { r: 'grz', kw: 3.4, n: 'Piętro', dl: 14, hP: 2.48, qP: 0.192, hPz: 'co',
        rozd: { wyj: 4, korpus: '1"', ile: 1 },
        rk: { s: 'obieg', mat: 'copper', p: '15x1', in: 13, q: 0.192, vAct: 0.402, v: 0.6 } },
      { r: 'podl', m: 1, kw: 6.2, n: 'Salon i hol', dl: 9, dp: 16, wyj: 7, hP: 3.25, qP: 1.066,
        rozd: { wyj: 7, korpus: '1"', ile: 1 },
        rk: { s: 'zrodlo', mat: 'copper', p: '18x1', in: 16, q: 0.3554, vAct: 0.491, v: 0.6 } },
    ],
  },
};
/* Przykład liczymy raz i trzymamy — inaczej każde przerysowanie ekranu
   dawałoby nowy obiekt i rozwinięte opisy zwijałyby się same. */
const PRO_CACHE = {};
function proPrzyklad(calc, mode) {
  const key = vkey(calc.id, mode.key);
  if (PRO_CACHE[key]) return PRO_CACHE[key];
  const v = {};
  fieldList(mode).forEach(f => {
    v[f.k] = (f.def && typeof f.def === 'object') ? JSON.parse(JSON.stringify(f.def)) : f.def;
    if (f.dynamic === 'pipeDia') v[f.k] = '';
  });
  const p = PRO_PRZYKLADY[key];
  if (p) Object.assign(v, JSON.parse(JSON.stringify(p)));
  PRO_CACHE[key] = v;
  return v;
}

/* Jedno miejsce, przez które przechodzą wszystkie odczyty wartości
   kalkulatora. W podglądzie oddajemy przykład (albo to, co człowiek
   wpisał wcześniej), więc wynik, rysunek i PDF widzą to samo. */
const getValuesOrig = getValues;
getValues = function (calc, mode) {
  if (proPodglad(calc.id)) return proPrzyklad(calc, mode);
  return getValuesOrig(calc, mode);
};
/* Czy ten kalkulator ma już wpisy właściciela telefonu. Nie pokazujemy
   ich w podglądzie — zwykle to urwany w pół wpis z dawnego klikania,
   a ten ekran ma pokazać, do czego aplikacja służy. Dane leżą
   nietknięte i wracają w sekundzie, w której abonament się włączy;
   pasek na górze o tym mówi, żeby nikt nie pomyślał, że przepadły. */
function proMaSwoje(calcId) {
  const c = CALCS.find(x => x.id === calcId);
  if (!c) return false;
  return !!state.values[vkey(calcId, activeMode(c).key)];
}

/* ---------- co wolno dotknąć w podglądzie ----------
   Wszystko, co służy oglądaniu: wyjście, dolne zakładki, rozwijanie
   opisu wyniku, pełny ekran rysunku i sam przycisk zakupu. Reszta
   otwiera arkusz z ceną. */
/* Oglądanie ma działać w całości: wyjście, zakładki, rozwijanie opisów,
   pełny ekran rysunku, przełączanie wariantu i ostrzeżenia — łącznie
   z oknem o uprawnieniach gazowych, które samo się otwiera i trzeba je
   czymś zamknąć. Drzwi do płatnego i tak łapie drugi słuchacz niżej. */
const PRO_WOLNO = '#back, .back, .nav, [data-pro], [data-wynikotw], [data-mode], .tip, summary,'
  + ' [data-ktfull], [data-ktclose], [data-ktzoom], [data-ktanuluj], [data-projktfull],'
  + ' [data-closeschemat], [data-schemat], [data-schematy], [data-czrys], [data-potwzamknij], [data-gasok], [data-projwroc],'
  + ' [data-projdet], .pro-arkusz, [data-proz],'
  /* stare dokumenty: otworzyć, podejrzeć, zapisać PDF/XML i wysłać wolno */
  + ' #backedit, #backdoc, #backoffers, [data-showdoc], [data-pdf], [data-mailoffer], [data-mailinv],'
  + ' [data-ksefxml], [data-xmlsave], [data-xmlcopy], [data-closexml], a[download]';
function proEkranPodgladu() {
  if (state.screen === 'calc' && state.tab === 'calc' && proPodglad(state.calc)) return true;
  /* Biuro bez abonamentu działa jak czytelnia: projekt, oferta i faktura
     otwierają się i dają się obejrzeć w całości, ale nic w nich nie da
     się zmienić. Dzięki temu stare dokumenty zostają dostępne, a nowych
     bez abonamentu nie przybywa. Notatnik jest darmowy i zostaje żywy. */
  if (!proMa() && state.tab === 'offers'
      && ['projekt', 'edit', 'doc', 'invoice', 'klienci'].indexOf(state.offerScreen) !== -1) return true;
  return false;
}
function proBlokuj(e) {
  if (!proEkranPodgladu()) return false;
  if (!e.target || !e.target.closest) return false;
  if (e.target.closest(PRO_WOLNO)) return false;
  return true;
}
/* Faza przechwytywania: zdarzenie zatrzymujemy, zanim dojdzie do
   zwykłych słuchaczy aplikacji — inaczej pole zdążyłoby się zapisać. */
['click', 'input', 'change', 'keydown'].forEach(typ => {
  document.addEventListener(typ, e => {
    if (!proBlokuj(e)) return;
    e.preventDefault(); e.stopImmediatePropagation();
    if (typ === 'click') { state.proArkusz = true; renderOverlay(); }
  }, true);
});

/* ---------- pasek na górze ekranu ---------- */
function proPasek(calcId) {
  if (!proPodglad(calcId)) return '';
  return '<div class="tip pro-pasek">' + svg('spark')
    + '<div><strong>Przykładowe obliczenie.</strong> Wynik, rysunek i opisy są pełne — rozwiń je strzałką. '
    + 'Żeby policzyć swoje, potrzebna jest pełna wersja.'
    + (proMaSwoje(calcId) ? '<br>Twoje wcześniejsze wpisy czekają w telefonie i wrócą po jej włączeniu.' : '')
    + '</div><button class="pro-btn" data-pro>Zobacz</button></div>';
}

/* ---------- arkusz z ceną ---------- */
const PRO_DAJE = [
  ['layers', 'Ogrzewanie grzejnikowe i podłogowe', 'średnice odcinek po odcinku, rysunek, zestawienie'],
  ['fire', 'Schemat kotłowni', 'źródło, bufor, sprzęgło, rozdzielacz, naczynia i pompy — dobrane same'],
  ['doc', 'Projekty, oferty i faktury', 'teczka budowy, zestawienia materiałów, PDF dla klienta'],
  ['drop', 'Średnice wody i gazu', 'przybory, piony, spadki ciśnienia'],
  /* Abonament odblokowuje całą aplikację, a nie wybrane kalkulatory —
     więc wszystko, co dojdzie później, abonent dostaje w tej samej cenie.
     To warto powiedzieć wprost: inaczej człowiek kupuje stan na dziś. */
  ['spark', 'Wszystko, co dojdzie później', 'aplikacja rośnie o rzeczy zgłaszane przez instalatorów — w cenie abonamentu'],
];
function proArkuszHtml() {
  const plan = state.proPlan || 'mies';
  const c = proCeny();
  const kafel = (k, cena, co, dop) => '<button class="pro-plan' + (plan === k ? ' on' : '') + '" data-proplan="' + k + '">'
    + '<b>' + esc(cena) + '</b><span>' + esc(co) + '</span>' + (dop ? '<em>' + esc(dop) + '</em>' : '') + '</button>';
  // dopóki Sklep nie odpowie, zakładamy próbę — o tym, komu się należy, i tak decyduje Google
  const proba = c.proba[plan] !== false;
  return '<div class="sheet pro-arkusz" data-proz role="dialog" aria-label="Pełna wersja">'
    + '<div class="sheet-in" data-stop>'
    + '<div class="sheet-h">' + svg('spark') + '<strong>Pełna wersja</strong>'
    + '<button class="item-x" data-proz aria-label="Zamknij">' + svg('x') + '</button></div>'
    + '<div class="sheet-body">'
    + '<p class="hint" style="margin:0 0 12px">Liczysz dalej tam, gdzie skończyłeś — bez internetu, na budowie.</p>'
    + '<div class="pro-lista">' + PRO_DAJE.map(d =>
      '<div class="pro-poz">' + svg(d[0]) + '<div><strong>' + esc(d[1]) + '</strong><span>' + esc(d[2]) + '</span></div></div>').join('')
    + '</div>'
    + '<div class="pro-plany">' + kafel('mies', c.mies, 'miesięcznie', '') + kafel('rok', c.rok, 'rocznie', 'taniej o dwa miesiące') + '</div>'
    + '<button class="jump" style="--c:#C2410C;margin-top:12px;width:100%" data-prokup>' + svg('spark')
    + (proba ? 'Wypróbuj 14 dni za darmo' : 'Kup pełną wersję') + '</button>'
    + '<p class="hint" style="margin:10px 2px 0">Płacisz za pełną wersję, nie za pojedyncze kalkulatory — '
    + 'kolejne funkcje dochodzą bez dopłaty. '
    + (proba ? 'Przez pierwsze 14 dni nic nie płacisz. ' : '')
    + 'Abonament anulujesz w Google Play, a to, co już policzyłeś, zostaje w telefonie.</p>'
    + '<button class="pro-link" data-proprzywroc>Kupiłeś już na innym telefonie? Przywróć zakup</button>'
    + '</div></div></div>';
}

/* ============================================================
   GOOGLE PLAY BILLING
   ------------------------------------------------------------
   Jedna subskrypcja „pelna_wersja” z dwoma planami bazowymi:
   „miesieczny” i „roczny”, każdy z ofertą 14 dni za darmo.
   Bez własnego serwera: o tym, czy abonament trwa, mówi Sklep
   Play na telefonie — pokazuje tylko subskrypcje aktywne.

   Aplikacja działa na budowach bez zasięgu, więc wynik ostatniego
   sprawdzenia pamiętamy. Jeśli Sklep nie odpowiada, abonament
   zostaje włączony jeszcze przez PRO_OFFLINE_DNI od ostatniego
   potwierdzenia — nikt nie traci dostępu w piwnicy.

   Obsługę Sklepu daje wtyczka capacitor-plugin-cdv-purchase
   (część natywna w projekcie Androida, część JS wklejona przed
   kodem aplikacji jako zrodla/vendor/cdv-purchase-store.js).
   ============================================================ */
const PRO_SUB = 'pelna_wersja';
const PRO_PLANY = { mies: 'miesieczny', rok: 'roczny' };
const PRO_OFFLINE_DNI = 30;
let PRO_SKLEP = null;          // CdvPurchase.store, gdy Sklep odpowiedział

function proSklepJest() {
  return naTelefonie() && typeof CdvPurchase !== 'undefined' && !!wtyczka('PurchasePlugin');
}
function proProdukt() {
  return PRO_SKLEP ? PRO_SKLEP.get(PRO_SUB, CdvPurchase.Platform.GOOGLE_PLAY) : null;
}
/* Oferta dla planu: najpierw ta z darmowym okresem. Google pokazuje ją
   tylko temu, komu się należy — kto już raz miał próbę, dostaje sam plan. */
function proOferta(plan) {
  const p = proProdukt();
  if (!p) return null;
  const baza = PRO_SUB + '@' + PRO_PLANY[plan];
  const lista = (p.offers || []).filter(o => o.id === baza || o.id.indexOf(baza + '@') === 0);
  const zProba = lista.find(o => (o.pricingPhases || []).some(f => f.priceMicros === 0));
  return zProba || lista.find(o => o.id === baza) || lista[0] || null;
}
/* Ceny z Google Play, w walucie telefonu. Zanim Sklep odpowie — nasze. */
function proCeny() {
  const wynik = { mies: PRO_CENA, rok: PRO_CENA_ROK, proba: {} };
  ['mies', 'rok'].forEach(k => {
    const o = proOferta(k);
    if (!o) return;
    const fazy = o.pricingPhases || [];
    const platna = fazy.filter(f => f.priceMicros > 0).slice(-1)[0];
    if (platna && platna.price) wynik[k] = platna.price;
    wynik.proba[k] = fazy.some(f => f.priceMicros === 0);
  });
  return wynik;
}

/* Stan abonamentu z tego, co mówi Sklep. „pewne” = Sklep odpowiedział,
   więc brak subskrypcji znaczy naprawdę brak, a nie brak zasięgu. */
function proUstalStan(pewne) {
  const bylo = proMa();
  if (PRO_SKLEP && PRO_SKLEP.owned(PRO_SUB)) {
    state.pro.aktywny = true; state.pro.sprawdzono = Date.now(); state.pro.zrodlo = 'sklep';
  } else if (pewne) {
    state.pro.aktywny = false; state.pro.zrodlo = 'sklep';
  } else if (state.pro.aktywny && state.pro.zrodlo === 'sklep'
             && Date.now() - (state.pro.sprawdzono || 0) > PRO_OFFLINE_DNI * 864e5) {
    state.pro.aktywny = false;    // za długo bez potwierdzenia ze Sklepu
  }
  proZapisz();
  if (bylo !== proMa()) {
    proUstawPrzyklad();
    if (proMa()) { state.proArkusz = false; if (state.proKupuje) toast('Dziękuję! Pełna wersja jest aktywna.'); }
    state.proKupuje = false;
    render(false); renderOverlay();
  }
}

function proStartSklep() {
  /* Zanim Sklep odpowie (albo gdy nie odpowie wcale — brak zasięgu, Sklep
     wyłączony), sprawdzamy, czy ostatnie potwierdzenie nie jest za stare. */
  proUstalStan(false);
  if (!proSklepJest()) return;
  window.CdvPurchaseCapacitor = { installed: true };
  const st = CdvPurchase.store;
  st.verbosity = CdvPurchase.LogLevel.WARNING;
  st.register([{ id: PRO_SUB, type: CdvPurchase.ProductType.PAID_SUBSCRIPTION, platform: CdvPurchase.Platform.GOOGLE_PLAY }]);
  st.when()
    /* Bez własnego serwera potwierdzamy zakup od razu. Niepotwierdzony
       zakup Google zwraca klientowi po trzech dniach. */
    .approved(t => { t.finish(); })
    .finished(() => { proUstalStan(true); })
    .receiptUpdated(() => { if (PRO_SKLEP) proUstalStan(true); })
    .productUpdated(() => { if (state.proArkusz) renderOverlay(); });
  // błędy zakupu obsługuje proKup — tu tylko nie pozwalamy im zginąć po cichu w konsoli
  st.error(err => { if (err) console.warn('Sklep Play:', err.code, err.message); });
  st.initialize([CdvPurchase.Platform.GOOGLE_PLAY]).then(bledy => {
    PRO_SKLEP = st;
    proUstalStan(!bledy || !bledy.length);
    if (state.proArkusz) renderOverlay();
  }).catch(() => { proUstalStan(false); });
}
setTimeout(proStartSklep, 400);

/* Kody z Google Play Billing (BillingResponseCode) przychodzą z wtyczki
   jako tekst. Anulowanie okna zakupu to nie błąd — nic nie mówimy. */
function proKomunikatBledu(err) {
  const kod = Number(err && err.code), tekst = String((err && err.message) || '');
  if (kod === 1 || tekst === 'USER_CANCELED' || (err && err.code === CdvPurchase.ErrorCode.PAYMENT_CANCELLED)) return '';
  if (kod === 7) return 'juz';                       // ITEM_ALREADY_OWNED — wystarczy przywrócić
  if (kod === 2 || kod === -3 || kod === -1 || kod === 12) return 'Brak połączenia ze Sklepem Google Play. Sprawdź internet i spróbuj jeszcze raz.';
  if (kod === 3) return 'Na tym telefonie nie da się płacić w Google Play. Sprawdź, czy jesteś zalogowany do Sklepu.';
  if (kod === 4) return 'Abonament jest chwilowo niedostępny w Sklepie. Spróbuj później.';
  return 'Zakup się nie udał. Spróbuj jeszcze raz za chwilę.';
}
function proKup() {
  if (!proSklepJest()) { toast('Zakup działa w aplikacji zainstalowanej z Google Play.'); return; }
  const o = proOferta(state.proPlan || 'mies');
  if (!o) { toast('Sklep Google Play jeszcze nie odpowiedział. Sprawdź internet i spróbuj za chwilę.'); return; }
  state.proKupuje = true;
  o.order().then(err => {
    if (!err) return;           // dalej prowadzi Sklep, wynik przyjdzie przez approved/finished
    state.proKupuje = false;
    const m = proKomunikatBledu(err);
    if (m === 'juz') proPrzywroc();
    else if (m) toast(m);
  });
}
function proPrzywroc() {
  if (!proSklepJest() || !PRO_SKLEP) { toast('Przywracanie działa w aplikacji zainstalowanej z Google Play.'); return; }
  toast('Sprawdzam zakupy w Google Play…');
  PRO_SKLEP.restorePurchases().then(() => {
    proUstalStan(true);
    toast(proMa() ? 'Pełna wersja przywrócona.' : 'Na tym koncie Google nie ma aktywnego abonamentu.');
  });
}
function proZarzadzaj() {
  if (PRO_SKLEP) PRO_SKLEP.manageSubscriptions(CdvPurchase.Platform.GOOGLE_PLAY);
}

document.addEventListener('click', e => {
  if (!e.target.closest) return;
  const pl = e.target.closest('[data-proplan]');
  if (pl) { state.proPlan = pl.dataset.proplan; renderOverlay(); return; }
  if (e.target.closest('[data-proprzywroc]')) { proPrzywroc(); return; }
  if (e.target.closest('[data-prozarzadzaj]')) { proZarzadzaj(); return; }
});

document.addEventListener('click', e => {
  if (!e.target.closest) return;
  if (e.target.closest('[data-pro]')) { state.proArkusz = true; renderOverlay(); return; }
  if (e.target.closest('[data-prokup]')) { proKup(); return; }
  if (state.proArkusz && e.target.closest('[data-proz]')
      && (!e.target.closest('[data-stop]') || e.target.closest('.sheet-h [data-proz]'))) {
    state.proArkusz = false; renderOverlay(); return;
  }
});

/* Arkusz wchodzi na wierzch nad wszystkim, co już jest na ekranie. */
const _renderOverlayPro = renderOverlay;
renderOverlay = function () {
  const el = document.getElementById('overlay');
  if (el && state.proArkusz) { el.innerHTML = proArkuszHtml(); return; }
  return _renderOverlayPro();
};

/* Klasa na <body> włącza blokadę dotyku na polach. Ustawiamy ją przy
   każdym przerysowaniu, bo ekran zmienia się też bez przeładowania. */
const _renderPro = render;
render = function (a) {
  const r = _renderPro(a);
  try { document.body.classList.toggle('pro-podglad', proEkranPodgladu()); } catch (e) { /* nieistotne */ }
  return r;
};

/* ---------- abonament w Ustawieniach ----------
   Na telefonie: stan z Google Play, zarządzanie i zakup.
   W przeglądarce (podgląd na komputerze) — przełącznik do oglądania
   obu wariantów, bo tam Sklepu nie ma. */
const _renderSettingsPro = renderSettingsMain;
renderSettingsMain = function () {
  const h = _renderSettingsPro();
  let wiersz;
  if (!naTelefonie()) {
    wiersz = '<button class="mrow" data-protest>'
      + '<span class="mrow-i">' + svg('spark') + '</span>'
      + '<span class="mrow-t"><strong>Abonament (podgląd): ' + (proMa() ? 'włączony' : 'wyłączony') + '</strong>'
      + '<span>Tylko w przeglądarce — dotknij, żeby zobaczyć drugi wariant</span></span>'
      + svg('chev') + '</button>';
  } else if (proMa()) {
    wiersz = '<button class="mrow" data-prozarzadzaj>'
      + '<span class="mrow-i">' + svg('spark') + '</span>'
      + '<span class="mrow-t"><strong>Pełna wersja — aktywna</strong>'
      + '<span>Zmiana planu albo anulowanie w Google Play</span></span>'
      + svg('chev') + '</button>';
  } else {
    wiersz = '<button class="mrow" data-pro>'
      + '<span class="mrow-i">' + svg('spark') + '</span>'
      + '<span class="mrow-t"><strong>Pełna wersja</strong>'
      + '<span>Schemat kotłowni, średnice, projekty, oferty — 14 dni za darmo</span></span>'
      + svg('chev') + '</button>';
  }
  return h.replace('</div>\n\n      ', wiersz + '</div>\n\n      ');
};
document.addEventListener('click', e => {
  if (!e.target.closest || !e.target.closest('[data-protest]') || naTelefonie()) return;
  state.pro.aktywny = !proMa(); state.pro.zrodlo = 'test'; proZapisz(); proUstawPrzyklad(); render(false);
  toast(proMa() ? 'Abonament włączony — wszystko odblokowane.' : 'Abonament wyłączony — płatne kalkulatory w podglądzie.');
});

/* ---------- drzwi z darmowej części do płatnej ----------
   Z „Doboru grzejnika” można dopisać wynik prosto do średnic c.o., a z
   notatnika wrzucić listę zakupów do oferty. Obie drogi omijają zakup,
   więc też prowadzą do arkusza z ceną. Przycisków nie chowamy — człowiek
   ma zobaczyć, że ta droga istnieje, zanim zdecyduje, czy warto. */
const PRO_DRZWI = '[data-doSrednic], [data-doRozdz], [data-rozdzdo], [data-gosrednice],'
  + ' [data-addoffer], [data-notdooferty], [data-projdooferty], [data-projprzenies], [data-projdo],'
  + ' [data-projnowy], [data-newoffer], [data-klienci], [data-opencat], [data-setgo="catalog"]';
function proDoPlatnego(t) {
  if (!t || !t.closest) return false;
  if (t.closest(PRO_DRZWI)) return true;
  const j = t.closest('[data-jumpidx]');
  if (j) { const cel = (state.pendingJumps || [])[+j.dataset.jumpidx]; if (cel && proPlatny(cel.calc)) return true; }
  const k = t.closest('[data-kbcalc]');
  if (k && proPlatny(k.dataset.kbcalc)) return true;
  return false;
}
document.addEventListener('click', e => {
  if (proMa() || !proDoPlatnego(e.target)) return;
  e.preventDefault(); e.stopImmediatePropagation();
  state.proArkusz = true; renderOverlay();
}, true);

/* ============================================================
   PRZYKŁADOWY PROJEKT W BIURZE
   ------------------------------------------------------------
   Teczka jednej budowy, złożona z tych samych przykładów, co
   kalkulatory — żeby było widać, że to jedna droga, a nie trzy
   osobne ekrany. Kotłownia: kocioł na pellet w układzie otwartym
   z buforem, bo tak wygląda połowa budów, na które jeździ
   instalator, a układ otwarty rysuje się inaczej niż zamknięty.

   Projekt żyje w pamięci i nie trafia do zapisu — nie zaśmieca
   listy po wykupieniu abonamentu.
   ============================================================ */
let PRO_PROJEKT = null;
function proProjekt() {
  if (PRO_PROJEKT) return PRO_PROJEKT;
  const p = {
    id: 'przyklad', nazwa: 'Dom Nowaków — przykład', adres: 'ul. Lipowa 12, Kraków',
    notatki: 'Kotłownia w piwnicy, rozdzielacze w szafkach na korytarzu. Pellet, bo nie ma gazu w drodze.',
    klient: { name: 'Anna i Piotr Nowak', address: 'ul. Lipowa 12, Kraków', phone: '', email: '' },
    utw: projDzis(), zm: projDzis(), czesci: {}, zest: {}, ofertaId: null, przyklad: true,
  };
  const dodaj = (c, calcId, modeKey) => {
    const calc = CALCS.find(x => x.id === calcId);
    const mode = calc.modes ? (calc.modes.find(m => m.key === modeKey) || calc.modes[0]) : activeMode(calc);
    p.czesci[c] = { mode: mode.key, v: projKopia(proPrzyklad(calc, mode)) };
    p.zest[c] = { zm: {}, dod: [], wyb: {} };
  };
  dodaj('grz', 'co_dia', 'troj');
  dodaj('podl', 'rozdz_dia', '_');
  const kot = ktDomyslne();
  Object.assign(kot, { zr: 'pel', uklad: 'otw', cwu: 'zas', zasL: 200, prio: 'tak',
                       cyrk: 'tak', grp: 'kot', sep: 'buf', bufy: 1, ob: [] });
  p.czesci.kot = { mode: '_', v: kot };
  p.zest.kot = { zm: {}, dod: [], wyb: {} };
  // obiegi wchodzą do kotłowni tą samą drogą co w prawdziwym projekcie
  try { projSyncKot(p, 'grz'); projSyncKot(p, 'podl'); } catch (e) { /* schemat pokaże się bez obiegów */ }
  PRO_PROJEKT = p;
  return p;
}
/* Przykład wchodzi do listy projektów jak zwykła teczka — dzięki temu
   otwiera się, liczy i rysuje tą samą drogą co prawdziwy projekt, bez
   osobnego kodu na „prawie projekt”. Do zapisu nie trafia nigdy. */
const saveProjektyOrig = saveProjekty;
saveProjekty = function (l) { return saveProjektyOrig((l || []).filter(x => !x.przyklad)); };
function proUstawPrzyklad() {
  const i = state.projekty.findIndex(x => x.przyklad);
  if (!proMa()) { if (i < 0) state.projekty.unshift(proProjekt()); }
  else if (i >= 0) {
    state.projekty.splice(i, 1);
    if (state.projektId === 'przyklad') { state.projektId = null; state.offerScreen = 'list'; }
  }
}
proUstawPrzyklad();

