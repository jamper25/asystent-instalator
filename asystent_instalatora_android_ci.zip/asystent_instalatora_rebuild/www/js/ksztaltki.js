/* ===== ksztaltki.js ===== */
/* ============================================================
   BAZA RUR, KSZTAŁTEK I ARMATURY
   ------------------------------------------------------------
   Osiem systemów, w każdym rury w kilku średnicach i kilkanaście
   rodzajów kształtek — razem grubo ponad pół tysiąca pozycji.
   Wpisanie ich po kolei dałoby plik, którego nikt nigdy nie poprawi,
   i aplikację cięższą o kilkaset kilobajtów.

   Dlatego trzymamy tu tylko przepis: listę systemów, ich średnice
   i rodzaje kształtek. Pozycje powstają z tego przepisu przy starcie
   aplikacji. Dopisanie nowej średnicy to jedna liczba, a nie
   dwadzieścia nowych wierszy.

   Cen tu nie ma i być nie może. Każdy instalator kupuje u swojego
   hurtownika, na swoim rabacie — cena wpisana przeze mnie byłaby
   zmyślona, a zmyślona cena w wycenie jest gorsza niż jej brak.
   Użytkownik wpisuje swoje stawki, a aplikacja zapamiętuje wyłącznie
   je (patrz ceny w offers.js), nie całą bazę.

   Zakres średnic: instalacje domowe — domy jednorodzinne i mieszkania.
   PP do 63 mm, stal i miedź do 54 mm, wielowarstwowa do 32 mm,
   gwintowane do 2", kanalizacja do 110 mm.

   Źródła zakresów: KAN-therm (Steel ∅12–108, PP ∅16–110, ultraPRESS
   ∅16–63, Copper ∅12–108) oraz asortyment hurtowni (Onninen, Metal
   Tech). Z tych zakresów bierzemy część domową.
   ============================================================ */

/* Gwinty, które w hurtowni realnie idą w parze z daną średnicą rury.
   Bez tej tablicy powstałyby bzdury w rodzaju kolana Ø16 z gwintem 2". */
const GWINT_DO = {
  '12': ['1/2"'], '15': ['1/2"'], '16': ['1/2"'], '18': ['1/2"', '3/4"'],
  '20': ['1/2"', '3/4"'], '22': ['3/4"', '1"'], '25': ['3/4"', '1"'],
  '28': ['1"', '5/4"'], '32': ['1"', '5/4"'], '35': ['5/4"'],
  '40': ['5/4"', '6/4"'], '42': ['6/4"'], '50': ['6/4"', '2"'],
  '54': ['2"'], '63': ['2"'],
};

/* Krótki, stały skrót gwintu do identyfikatora pozycji. Identyfikatory
   muszą przeżyć aktualizację aplikacji — to po nich odnajdują się ceny
   wpisane przez użytkownika. */
const GWINT_ID = { '3/8"': '38', '1/2"': '12', '3/4"': '34', '1"': '1',
                   '5/4"': '54', '6/4"': '64', '2"': '2' };

/* Znaczniki („tag") to jedyne, po czym kontrola kompletności oferty
   poznaje, że coś jest rurą albo kształtką — i dzięki temu potrafi
   powiedzieć „są rury, a nie ma izolacji". Bez nich baza byłaby dla tej
   kontroli niewidzialna i milczałaby przy każdej wycenie.

   Kanalizacja znaczników nie dostaje celowo: to rury, ale nieogrzewane.
   Uwaga „są rury, a nie ma izolacji" przy wymianie pionu kanalizacyjnego
   byłaby bzdurą, a kontrola, która mówi bzdury, przestaje być czytana.

   Rodzaje kształtek. Pole „jak" mówi, w ilu wariantach pozycja powstaje:
   prosta   — jedna na średnicę
   gwint    — jedna na każdą parę średnica + pasujący gwint
   redukcja — jedna na parę sąsiednich średnic
   trojnikR — trójnik z mniejszym odgałęzieniem
   rura     — jak prosta, ale w metrach
   warianty — jedna na każdą parę rozmiar + wariant (np. długość), ale na
              liście wyboru zwinięte w jeden wiersz                      */
const K = (k, n, jak) => ({ k, n, jak: jak || 'prosta' });

const SYSTEMY = [
  {
    id: 'pp', nazwa: 'PP-R zgrzewany', krotko: 'PP-R', znaczniki: true,
    opis: 'polipropylen, łączony przez zgrzewanie',
    srednice: ['16', '20', '25', '32', '40', '50', '63'],
    przedrostek: 'Ø',
    ksztaltki: [
      K('rura', 'Rura PN20', 'rura'),
      K('rurastabi', 'Rura stabilizowana PN20', 'rura'),
      K('mufa', 'Mufa'),
      K('kol90', 'Kolano 90°'),
      K('kol45', 'Kolano 45°'),
      K('luk', 'Łuk'),
      K('mijanka', 'Mijanka'),
      K('troj', 'Trójnik równoprzelotowy'),
      K('czworn', 'Czwórnik'),
      K('zaslepka', 'Zaślepka'),
      K('red', 'Mufa redukcyjna', 'redukcja'),
      K('trojred', 'Trójnik redukcyjny', 'trojnikR'),
      K('mufaGW', 'Mufa z gwintem wewnętrznym', 'gwint'),
      K('mufaGZ', 'Mufa z gwintem zewnętrznym', 'gwint'),
      K('kolGW', 'Kolano z gwintem wewnętrznym', 'gwint'),
      K('kolGZ', 'Kolano z gwintem zewnętrznym', 'gwint'),
      K('kolnas', 'Kolano naścienne z uchem', 'gwint'),
      K('trojGW', 'Trójnik z gwintem wewnętrznym', 'gwint'),
      K('srub', 'Złączka śrubunkowa (rozłączna)'),
      K('zawor', 'Zawór kulowy PP'),
    ],
  },
  {
    id: 'stal', nazwa: 'Stal węglowa zaciskana', krotko: 'stal press', znaczniki: true,
    opis: 'stal ocynkowana, zaprasowywana',
    srednice: ['12', '15', '18', '22', '28', '35', '42', '54'],
    przedrostek: 'Ø',
    ksztaltki: [
      K('rura', 'Rura ocynkowana', 'rura'),
      K('mufa', 'Mufa'),
      K('kol90', 'Kolano 90°'),
      K('kol45', 'Kolano 45°'),
      K('troj', 'Trójnik równoprzelotowy'),
      K('obejscie', 'Obejście'),
      K('zaslepka', 'Zaślepka'),
      K('red', 'Redukcja', 'redukcja'),
      K('trojred', 'Trójnik redukcyjny', 'trojnikR'),
      K('mufaGW', 'Mufa z gwintem wewnętrznym', 'gwint'),
      K('mufaGZ', 'Mufa z gwintem zewnętrznym', 'gwint'),
      K('kolGW', 'Kolano z gwintem wewnętrznym', 'gwint'),
      K('kolGZ', 'Kolano z gwintem zewnętrznym', 'gwint'),
      K('trojGW', 'Trójnik z gwintem wewnętrznym', 'gwint'),
      K('zawor', 'Zawór kulowy systemowy'),
    ],
  },
  {
    id: 'miedz', nazwa: 'Miedź zaciskana', krotko: 'miedź press', znaczniki: true,
    opis: 'miedź, zaprasowywana',
    srednice: ['12', '15', '18', '22', '28', '35', '42', '54'],
    przedrostek: 'Ø',
    ksztaltki: [
      K('rura', 'Rura', 'rura'),
      K('mufa', 'Mufa'),
      K('kol90d', 'Łuk 90° dwukielichowy'),
      K('kol90j', 'Łuk 90° jednokielichowy'),
      K('kol45', 'Łuk 45°'),
      K('troj', 'Trójnik równoprzelotowy'),
      K('zaslepka', 'Zaślepka'),
      K('red', 'Redukcja', 'redukcja'),
      K('trojred', 'Trójnik redukcyjny', 'trojnikR'),
      K('mufaGW', 'Mufa przejściowa GW', 'gwint'),
      K('mufaGZ', 'Mufa przejściowa GZ', 'gwint'),
      K('nypGZ', 'Złączka przejściowa GZ', 'gwint'),
      K('kolGW', 'Kolano przejściowe GW', 'gwint'),
      K('kolGZ', 'Kolano przejściowe GZ', 'gwint'),
    ],
  },
  {
    id: 'peal', nazwa: 'PE-X/Al zaprasowywana', krotko: 'PE-X/Al press', znaczniki: true,
    opis: 'rura wielowarstwowa, złączki zaprasowywane',
    srednice: ['16', '20', '25', '32'],
    przedrostek: 'Ø',
    ksztaltki: [
      K('rura', 'Rura', 'rura'),
      K('ruraotul', 'Rura w otulinie', 'rura'),
      K('zlprosta', 'Złączka prosta'),
      K('kol90', 'Kolano 90°'),
      K('troj', 'Trójnik równoprzelotowy'),
      K('zaslepka', 'Zaślepka'),
      K('red', 'Złączka redukcyjna', 'redukcja'),
      K('trojred', 'Trójnik redukcyjny', 'trojnikR'),
      K('zlGW', 'Złączka z gwintem wewnętrznym', 'gwint'),
      K('zlGZ', 'Złączka z gwintem zewnętrznym', 'gwint'),
      K('kolGW', 'Kolano z gwintem wewnętrznym', 'gwint'),
      K('kolGZ', 'Kolano z gwintem zewnętrznym', 'gwint'),
      K('kolnas', 'Kolano naścienne z uchem', 'gwint'),
    ],
  },
  {
    id: 'pealsk', nazwa: 'PE-X/Al skręcana', krotko: 'PE-X/Al skręcana', znaczniki: true,
    opis: 'rura wielowarstwowa, złączki śrubunkowe',
    srednice: ['16', '20', '25', '32'],
    przedrostek: 'Ø',
    ksztaltki: [
      K('zlprosta', 'Złączka prosta skręcana'),
      K('kol90', 'Kolano 90° skręcane'),
      K('troj', 'Trójnik skręcany'),
      K('red', 'Złączka redukcyjna skręcana', 'redukcja'),
      K('eurokonus', 'Złączka do rozdzielacza (eurokonus)'),
      K('zlGW', 'Złączka skręcana z gwintem wewnętrznym', 'gwint'),
      K('zlGZ', 'Złączka skręcana z gwintem zewnętrznym', 'gwint'),
      K('kolGW', 'Kolano skręcane z gwintem wewnętrznym', 'gwint'),
      K('kolGZ', 'Kolano skręcane z gwintem zewnętrznym', 'gwint'),
    ],
  },
  {
    id: 'ocynk', nazwa: 'Ocynk gwintowany', krotko: 'ocynk', znaczniki: true,
    opis: 'żeliwo ciągliwe ocynkowane, łączone na gwint',
    srednice: ['1/2"', '3/4"', '1"', '5/4"', '6/4"', '2"'],
    przedrostek: '',
    ksztaltki: [
      K('rura', 'Rura gwintowana', 'rura'),
      K('kolNN', 'Kolano nakrętne (GW/GW)'),
      K('kolNW', 'Kolano nakrętno-wkrętne (GW/GZ)'),
      K('mufa', 'Mufa nakrętna'),
      K('nypel', 'Nypel wkrętny'),
      K('troj', 'Trójnik nakrętny'),
      K('korek', 'Korek z obrzeżem'),
      K('zaslepka', 'Zaślepka nakrętna'),
      K('srubP', 'Śrubunek płaski'),
      K('srubS', 'Śrubunek stożkowy'),
      K('red', 'Mufa redukcyjna', 'redukcja'),
      K('nypred', 'Nypel redukcyjny', 'redukcja'),
      K('trojred', 'Trójnik redukcyjny', 'trojnikR'),
    ],
  },
  {
    /* Stal czarna do spawania — kotłownie, stare instalacje c.o., większe
       średnice. Rura ze szwem i bez szwu to dwa różne wyroby (i dwie ceny),
       więc są osobnymi pozycjami. Po calu dopisujemy średnicę zewnętrzną,
       bo tak jest na fakturze z hurtowni: 3/4" = Ø26,9. Grubości ścianki
       nie wpisujemy — bywa różna u różnych dostawców. */
    id: 'spaw', nazwa: 'Stal czarna spawana', krotko: '', znaczniki: true,
    opis: 'rury ze szwem i bez szwu, kształtki do spawania',
    srednice: ['3/8"', '1/2"', '3/4"', '1"', '5/4"', '6/4"', '2"'],
    przedrostek: '',
    wymiar: { '3/8"': '(Ø17,2)', '1/2"': '(Ø21,3)', '3/4"': '(Ø26,9)', '1"': '(Ø33,7)',
              '5/4"': '(Ø42,4)', '6/4"': '(Ø48,3)', '2"': '(Ø60,3)' },
    ksztaltki: [
      K('ruraSzew', 'Rura stalowa czarna ze szwem', 'rura'),
      K('ruraBez', 'Rura stalowa czarna bez szwu', 'rura'),
      K('kol90', 'Kolano hamburskie 90°'),
      K('kol45', 'Kolano hamburskie 45°'),
      K('troj', 'Trójnik spawany równoprzelotowy'),
      K('trojred', 'Trójnik spawany redukcyjny', 'trojnikR'),
      K('red', 'Redukcja spawana koncentryczna', 'redukcja'),
      K('dennica', 'Dennica (zaślepka) do spawania'),
      Object.assign(K('mufa', 'Mufa do wspawania (GW)'), { bezWymiaru: true }),
      Object.assign(K('polmufa', 'Półmufa do wspawania (GW)'), { bezWymiaru: true }),
      Object.assign(K('nypel', 'Nypel do wspawania (GZ)'), { bezWymiaru: true }),
    ],
  },
  {
    id: 'mosiadz', nazwa: 'Mosiądz gwintowany', krotko: 'mosiądz', znaczniki: true,
    opis: 'kształtki mosiężne, łączone na gwint',
    srednice: ['1/2"', '3/4"', '1"', '5/4"', '6/4"', '2"'],
    przedrostek: '',
    ksztaltki: [
      K('kolNN', 'Kolano (GW/GW)'),
      K('kolNW', 'Kolano (GW/GZ)'),
      K('mufa', 'Mufa'),
      K('nypel', 'Nypel'),
      K('troj', 'Trójnik'),
      K('korek', 'Korek'),
      K('srubProsty', 'Śrubunek prosty'),
      K('srubKat', 'Śrubunek kątowy'),
      K('srubPrzel', 'Śrubunek przelotowy'),
      /* Przedłużki różnią się ceną co długość, więc w katalogu muszą być
         osobnymi pozycjami. Na liście wyboru zwijają się w jedną — długość
         wybiera się dopiero po dotknięciu, żeby dwadzieścia wariantów nie
         przykryło reszty działu. */
      Object.assign(K('przedl', 'Przedłużka', 'warianty'), {
        warianty: ['5 mm', '10 mm', '15 mm', '20 mm', '25 mm',
                   '30 mm', '35 mm', '40 mm', '45 mm', '50 mm'],
        tylkoDla: ['1/2"', '3/4"'],
      }),
      K('red', 'Redukcja', 'redukcja'),
      K('trojred', 'Trójnik redukcyjny', 'trojnikR'),
    ],
  },
  {
    /* Otuliny opisuje się średnicą WEWNĘTRZNĄ — tą, która wchodzi na rurę.
       Kolor i grubość ścianki wybiera się dopiero po dotknięciu, bo sześć
       kombinacji na każdą średnicę przykryłoby cały dział.

       Grubości: 6 i 9 mm. To są ścianki, które faktycznie są w sprzedaży —
       7 i 8 mm nie istnieją jako wyrób, więc ich nie wpisuję. */
    id: 'izol', nazwa: 'Izolacja', krotko: '', tagStaly: 'izolacja',
    opis: 'otuliny na rury, kolory i grubości',
    srednice: ['18', '22', '28', '35', '42', '54'],
    przedrostek: 'Ø',
    ksztaltki: [
      Object.assign(K('otulina', 'Otulina na rurę', 'warianty'), {
        warianty: ['czerwona 6 mm', 'czerwona 9 mm', 'niebieska 6 mm',
                   'niebieska 9 mm', 'szara 6 mm', 'szara 9 mm'],
        jedn: 'mb',
      }),
    ],
  },
  {
    id: 'kanal', nazwa: 'Kanalizacja PVC/PP', krotko: 'kanalizacja',
    opis: 'wewnętrzna, kielichowa na uszczelkę',
    srednice: ['32', '40', '50', '75', '110'],
    przedrostek: 'Ø',
    ksztaltki: [
      /* Rury kanalizacyjne kupuje się na sztuki, w gotowych długościach,
         a nie na metry z rolki — dlatego długość jest wariantem, a
         jednostką jest sztuka. */
      Object.assign(K('rura', 'Rura', 'warianty'), {
        warianty: ['0,25 m', '0,5 m', '1 m', '2 m', '3 m'],
        jedn: 'szt',
      }),
      K('kol15', 'Kolano 15°'),
      K('kol30', 'Kolano 30°'),
      K('kol45', 'Kolano 45°'),
      K('kol67', 'Kolano 67°'),
      K('kol87', 'Kolano 87°'),
      K('troj45', 'Trójnik 45°'),
      K('troj87', 'Trójnik 87°'),
      K('mufa', 'Mufa nasuwna'),
      K('czyscik', 'Czyszczak (rewizja)'),
      K('zaslepka', 'Zaślepka'),
      /* Trapery są dopiero od DN50 — w Ø32 i Ø40 nie istnieją. */
      Object.assign(K('traperBez', 'Traper bez uszczelki'), { tylkoDla: ['50', '75', '110'] }),
      Object.assign(K('traperGuma', 'Guma trapera'), { tylkoDla: ['50', '75', '110'] }),
      Object.assign(K('traperZest', 'Traper zestaw'), { tylkoDla: ['50', '75', '110'] }),
      K('red', 'Redukcja', 'redukcja'),
      /* Trójniki redukcyjne w kanalizacji mają kąt odgałęzienia i zaczynają
         się od DN50 — poniżej nie ma czego redukować. Kąt jest tu osobnym
         rodzajem, a nie wariantem do wyboru po dotknięciu, bo to trzy
         różne kształtki, a nie trzy odmiany tej samej. */
      Object.assign(K('trojred45', 'Trójnik redukcyjny 45°', 'trojnikR'),
        { tylkoDla: ['50', '75', '110'] }),
      Object.assign(K('trojred67', 'Trójnik redukcyjny 67°', 'trojnikR'),
        { tylkoDla: ['50', '75', '110'] }),
      Object.assign(K('trojred87', 'Trójnik redukcyjny 87°', 'trojnikR'),
        { tylkoDla: ['50', '75', '110'] }),
    ],
  },
];

/* Armatura nie układa się w „średnica × rodzaj" jak kształtki: zawór
   umywalkowy jest zawsze 1/2"×3/8", a filtr skośny idzie przez cały
   szereg. Dlatego ma własną, krótszą listę z podanym zakresem. */
const ARMATURA = [
  { k: 'kulwoda', n: 'Zawór kulowy do wody GW/GW', dn: ['1/2"', '3/4"', '1"', '5/4"', '6/4"', '2"'] },
  { k: 'kulwodaNW', n: 'Zawór kulowy do wody GW/GZ', dn: ['1/2"', '3/4"', '1"', '5/4"', '6/4"', '2"'] },
  { k: 'kulmot', n: 'Zawór kulowy z motylkiem', dn: ['1/2"', '3/4"', '1"'] },
  { k: 'kulgaz', n: 'Zawór kulowy do gazu', dn: ['1/2"', '3/4"', '1"', '5/4"', '6/4"', '2"'] },
  { k: 'kulspust', n: 'Zawór kulowy ze spustem', dn: ['1/2"', '3/4"', '1"'] },
  { k: 'zwrotny', n: 'Zawór zwrotny', dn: ['1/2"', '3/4"', '1"', '5/4"', '6/4"', '2"'] },
  { k: 'zwrotnyAM', n: 'Zawór zwrotny antyskażeniowy', dn: ['1/2"', '3/4"', '1"'] },
  { k: 'filtr', n: 'Filtr skośny', tag: 'filtr', dn: ['1/2"', '3/4"', '1"', '5/4"', '6/4"', '2"'] },
  { k: 'filtrzaw', n: 'Filtr skośny z zaworem kulowym', tag: 'filtr', dn: ['1/2"', '3/4"', '1"'] },
  { k: 'filtrplu', n: 'Filtr płukany wstecznie', dn: ['3/4"', '1"'] },
  /* Te trzy mają rozmiar wpisany w nazwę, bo występują tylko w jednym
     wariancie. Stawiamy je pod 1/2" — pod tym gwintem szuka się ich
     w hurtowni — ale nie doklejamy rozmiaru drugi raz na końcu nazwy. */
  { k: 'umyw', n: 'Zaworek kątowy umywalkowy 1/2" × 3/8"', dn: ['1/2"'], sufiks: false },
  { k: 'umywfil', n: 'Zaworek kątowy z filtrem 1/2" × 3/8"', dn: ['1/2"'], sufiks: false },
  { k: 'pralka', n: 'Zawór do pralki 1/2" × 3/4"', dn: ['1/2"'], sufiks: false },
  { k: 'grzejP', n: 'Zawór grzejnikowy prosty', dn: ['1/2"', '3/4"'] },
  { k: 'grzejK', n: 'Zawór grzejnikowy kątowy', dn: ['1/2"', '3/4"'] },
  { k: 'redcis', n: 'Reduktor ciśnienia', dn: ['1/2"', '3/4"', '1"'] },
  { k: 'bezp', n: 'Zawór bezpieczeństwa', tag: 'zawor_bezp', dn: ['1/2"', '3/4"'] },
  { k: 'odpow', n: 'Odpowietrznik automatyczny', dn: ['1/2"', '3/4"'] },
];

/* --- Rozwijanie przepisu w listę pozycji --------------------------- */

const idGwintu = g => GWINT_ID[g] || String(g).replace(/[^0-9]/g, '');
const idRozmiaru = d => String(d).replace(/[^0-9a-zA-Z]/g, '') || 'x';

/* Redukcje robimy tylko między sąsiednimi rozmiarami i o jeden dalej.
   Redukcja 63 → 16 istnieje w katalogach, ale nikt jej nie kupuje;
   wrzucona tu zrobiłaby z listy ścianę nieczytelnego tekstu. */
function paryRedukcji(srednice) {
  const pary = [];
  for (let i = 1; i < srednice.length; i++) {
    for (let j = Math.max(0, i - 2); j < i; j++) pary.push([srednice[i], srednice[j]]);
  }
  return pary;
}

/* Nazwę składamy z kawałków i pomijamy puste. Otuliny nie mają skrótu
   materiału — „Otulina na rurę  Ø22" z dziurą w środku wyglądałoby jak
   błąd, bo nim jest. */
const zloz = (...czesci) => czesci.filter(Boolean).join(' ');

function rozwinSystem(s) {
  const poz = [];
  /* „dn" to rozmiar, pod którym pozycja ma stanąć w menu. Przy redukcji
     i trójniku redukcyjnym bierzemy większy wymiar — tak samo szuka się
     ich w hurtowni: pod średnicą rury głównej. */
  const dodaj = (id, nazwa, dn, jedn) => poz.push({
    id: s.id + '-' + id, name: nazwa, unit: jedn || 'szt', cat: 'mat',
    price: 0, grp: s.nazwa, sys: s.id, dn: s.przedrostek + dn,
    tag: s.tagStaly || (s.znaczniki ? (jedn === 'mb' ? 'rura' : 'ksztaltka') : null),
  });
  const etykieta = d => s.przedrostek + d;

  s.ksztaltki.forEach(f => {
    /* Warianty tej samej kształtki — na przykład przedłużki w dziesięciu
       długościach. W katalogu muszą być osobnymi pozycjami, bo każda ma
       inną cenę; pole „wg" spina je z powrotem w jeden wiersz na liście
       wyboru, żeby nie przykryły całego działu. */
    if (f.jak === 'warianty') {
      s.srednice.forEach(d => {
        if (f.tylkoDla && f.tylkoDla.indexOf(d) < 0) return;
        const grupa = s.id + '-' + f.k + '-' + idRozmiaru(d);
        f.warianty.forEach(w => {
          dodaj(f.k + '-' + idRozmiaru(d) + '-' + idRozmiaru(w),
            zloz(f.n, s.krotko, etykieta(d), w), d, f.jedn);
          const ost = poz[poz.length - 1];
          ost.wg = grupa;
          ost.wgNazwa = zloz(f.n, s.krotko, etykieta(d));
        });
      });
      return;
    }
    /* Znak średnicy stawiamy tylko przy pierwszym wymiarze: „Ø25/20"
       czyta się jak w hurtowni, „Ø25/Ø20" wygląda na pomyłkę. */
    if (f.jak === 'redukcja') {
      paryRedukcji(s.srednice).filter(([a]) => !f.tylkoDla || f.tylkoDla.indexOf(a) >= 0)
        .forEach(([a, b]) => dodaj(
        f.k + '-' + idRozmiaru(a) + '-' + idRozmiaru(b),
        zloz(f.n, s.krotko, etykieta(a) + '/' + b), a));
      return;
    }
    if (f.jak === 'trojnikR') {
      paryRedukcji(s.srednice).filter(([a]) => !f.tylkoDla || f.tylkoDla.indexOf(a) >= 0)
        .forEach(([a, b]) => dodaj(
        f.k + '-' + idRozmiaru(a) + '-' + idRozmiaru(b),
        zloz(f.n, s.krotko, etykieta(a) + '/' + b + '/' + a), a));
      return;
    }
    if (f.jak === 'gwint') {
      s.srednice.forEach(d => (GWINT_DO[d] || []).forEach(g => dodaj(
        f.k + '-' + idRozmiaru(d) + '-' + idGwintu(g),
        zloz(f.n, s.krotko, etykieta(d) + ' × ' + g), d)));
      return;
    }
    /* Część kształtek istnieje tylko w niektórych średnicach — traper
       zaczyna się od DN50 i wypisywanie go przy Ø32 byłoby zmyślaniem. */
    s.srednice.forEach(d => {
      if (f.tylkoDla && f.tylkoDla.indexOf(d) < 0) return;
      dodaj(f.k + '-' + idRozmiaru(d),
        zloz(f.n, s.krotko, etykieta(d), s.wymiar && !f.bezWymiaru ? s.wymiar[d] : ''), d,
        f.jedn || (f.jak === 'rura' ? 'mb' : 'szt'));
    });
  });
  return poz;
}

function rozwinArmature() {
  const poz = [];
  ARMATURA.forEach(a => a.dn.forEach(d => poz.push({
    id: 'arm-' + a.k + (d ? '-' + idRozmiaru(d) : ''),
    name: a.n + (d && a.sufiks !== false ? ' ' + d : ''), unit: 'szt', cat: 'mat',
    price: 0, tag: a.tag || null, grp: 'Armatura', sys: 'arm', dn: d || '',
  })));
  return poz;
}

/* Cała baza, policzona raz przy starcie. */
function bazaKsztaltek() {
  const poz = [];
  SYSTEMY.forEach(s => poz.push(...rozwinSystem(s)));
  poz.push(...rozwinArmature());
  return poz;
}

/* Systemy do menu wyboru — razem z armaturą, która menu też potrzebuje. */
function bazaSystemy() {
  return SYSTEMY.map(s => ({ id: s.id, nazwa: s.nazwa, opis: s.opis,
      rozmiary: s.srednice.map(d => s.przedrostek + d) }))
    .concat([{ id: 'arm', nazwa: 'Armatura', opis: 'zawory, filtry, odpowietrzniki', rozmiary: [] }]);
}


