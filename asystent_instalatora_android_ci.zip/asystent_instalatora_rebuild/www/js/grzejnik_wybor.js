/* ===== grzejnik_wybor.js ===== */
/* ============================================================
   KONKRETNY GRZEJNIK PRZY POZYCJI W ŚREDNICACH C.O.
   ------------------------------------------------------------
   Moc pomieszczenia jest liczbą, którą instalator policzył i której nie
   ruszamy. Pod nią aplikacja podpowiada konkretny grzejnik z tabeli —
   z typem i wymiarem, bo to on idzie na zamówienie i na rysunek.

   Czasem trzeba dać inny pod to samo zapotrzebowanie: pod oknem jest tylko
   1,2 m ściany, parapet wisi nisko, inwestor chce trzydziestkę trójkę.
   Wtedy „Zmień" otwiera listę innych grzejników, które też tę moc pokryją,
   a wybór zapisuje się przy pozycji. Moc pomieszczenia zostaje ta sama —
   i średnice rur liczą się dalej z niej, nie z mocy grzejnika: większy
   grzejnik nie zmienia tego, ile ciepła pokój naprawdę potrzebuje.

   Wybór zapisany ręcznie nie podmienia się po cichu. Gdy instalator
   później podniesie moc i grzejnik przestanie wystarczać, pozycja robi się
   czerwona z napisem „za mały o … W" i czeka, aż wybierze inny.

   W łazience podpowiadamy drabinkę — płaską albo wypukłą — a płytowy
   wolno wybrać ręcznie. W innych pomieszczeniach są same płytowe.

   Pomieszczenie może mieć dwa grzejniki: dwa okna albo za mało ściany na
   jeden duży. Moc pomieszczenia zostaje jedna, dzieli się na dwa grzejniki
   (domyślnie po połowie), a do obliczenia średnic, na rysunek i do
   zestawienia idą dwa osobne grzejniki, każdy ze swoim podejściem.

   Zapis leży w tablicach pod tym samym indeksem co moc i nazwa:
   radGrz — wybór (pierwszego) grzejnika, pusty znaczy „weź podpowiedź";
   radDziel — podział: { u: udział pierwszego grzejnika } albo pusty;
   radGrz2 — wybór drugiego grzejnika przy podziale.
   Stare zapisy i grzejniki dopisane z innych kalkulatorów działają bez zmian.
   ============================================================ */

/* Temperatury pracy z parametrów kalkulatora. Przy „Własnym Δt" nie znamy
   temperatury zasilania, a bez niej nie da się wziąć mocy z katalogu —
   wtedy grzejnika nie podpowiadamy w ogóle, zamiast zgadywać. */
function grzRezim(v) {
  const reg = Number(v.reg);
  if (reg === -1) return null;
  const r = REGIMES_CO[reg] || REGIMES_CO[1];
  const tz = r[2], tp = r[2] - r[1];
  return { tz, tp, ti: 20, etykieta: tz + '/' + tp + '/20' };
}

function grzOpis(g) { return g.drab ? drabinkaOpis(g) : 'Typ ' + g.type + ' · ' + g.height + ' × ' + g.length; }
function grzKrotko(g) { return g.drab ? drabinkaKrotko(g) : g.type + ' · ' + g.height + '×' + g.length; }

function czyLazienka(nm) { return /^łazienka/i.test(String(nm || '').trim()); }

/* ---------- podział mocy pomieszczenia na dwa grzejniki ---------- */

function grzDziel(v, k, i) {
  const d = (v[k + 'Dziel'] || [])[i];
  return d && d.u > 0 && d.u < 1 ? d : null;
}
/* Moc pierwszego grzejnika; drugi dostaje resztę, więc suma zawsze równa
   się mocy pomieszczenia. */
function podzialMoc(req, u) { return Math.round(Number(req) * u); }
function grzMocCzesci(v, k, i, req, j) {
  const d = grzDziel(v, k, i);
  if (!d) return req;
  const m1 = podzialMoc(req, d.u);
  return j ? req - m1 : m1;
}

/* Do obliczenia średnic każdy grzejnik musi być osobną pozycją — ma swoje
   podejście i swój odcinek. Rozwijamy więc podzielone pomieszczenia na dwie
   pozycje: „Pokój 1 · 1/2" i „Pokój 1 · 2/2". Na ekranie lista zostaje
   taka, jaką wpisał instalator. */
function rozwinPodzial(v) {
  const dz = v.radDziel || [];
  if (!dz.some(x => x && x.u > 0 && x.u < 1)) return v;
  const o = Object.assign({}, v, { rad: [], radNazwy: [], radGrz: [], radGalaz: [], radDziel: [], radGrz2: [] });
  (v.rad || []).forEach((moc, i) => {
    const nm = String((v.radNazwy || [])[i] || '').trim();
    const g1 = (v.radGrz || [])[i] || null;
    const gal = (v.radGalaz || [])[i];
    const d = grzDziel(v, 'rad', i);
    if (d && Number(moc) > 0) {
      const m1 = podzialMoc(moc, d.u);
      o.rad.push(m1, Number(moc) - m1);
      o.radNazwy.push(nm ? nm + ' · 1/2' : '', nm ? nm + ' · 2/2' : '');
      o.radGrz.push(g1, (v.radGrz2 || [])[i] || null);
      o.radGalaz.push(gal, gal);
    } else {
      o.rad.push(moc); o.radNazwy.push(nm); o.radGrz.push(g1); o.radGalaz.push(gal);
    }
  });
  return o;
}

/* Stan jednego grzejnika (j — który z dwóch przy podziale). Jedno miejsce,
   z którego czytają lista, arkusz wyboru, rysunek i PDF — żeby nigdzie nie
   wyszło co innego. */
function grzStan(v, k, i, req, nm, j) {
  const rez = grzRezim(v);
  if (!rez) return { brakRezimu: true, req };
  if (!(req > 0)) return { req, rez, brakMocy: true };
  const laz = czyLazienka(nm);
  const wyb = (v[k + (j ? 'Grz2' : 'Grz')] || [])[i];
  if (wyb && wyb.d) {
    const w = drabinkaMoc(wyb.d, wyb.h, wyb.w, rez.tz, rez.tp, rez.ti);
    const g = { drab: true, ksztalt: wyb.d, height: Number(wyb.h), width: Number(wyb.w), watts: w };
    return { req, rez, reczny: true, g, ok: w >= req, lazienka: laz };
  }
  if (wyb && wyb.l) {
    const w = mocGrzejnika(wyb.t, wyb.h, wyb.l, rez.tz, rez.tp, rez.ti);
    const g = { type: String(wyb.t), height: Number(wyb.h), length: Number(wyb.l), watts: w };
    return { req, rez, reczny: true, g, ok: w >= req, lazienka: laz };
  }
  if (laz) {
    const p = drabinkaProponowana(req, rez.tz, rez.tp, rez.ti);
    return p ? { req, rez, g: p, ok: true, lazienka: true } : { req, rez, brak: true, lazienka: true };
  }
  const p = grzejnikProponowany(req, rez.tz, rez.tp, rez.ti);
  return p ? { req, rez, g: p, ok: true } : { req, rez, brak: true };
}

/* Szkic grzejnika w skali. Płytowy: szerokość z długości, wysokość
   z wysokości, grubsza ramka dla trzydziestki trójki. Drabinka: stojąca,
   ze szczeblami. Na pierwszy rzut oka widać, co jest czym. */
function grzMini(g, cls) {
  if (g.drab) {
    const w = Math.round(12 + (g.width - 380) / 270 * 10);
    const h = Math.round(16 + (g.height - 420) / 1530 * 20);
    return '<i class="grz-mini grz-mini--lazienka' + (cls || '') + '" style="width:' + w + 'px;height:' + h + 'px"></i>';
  }
  const w = Math.round(14 + (g.length / 3000) * 40);
  const h = Math.round(10 + (g.height / 900) * 20);
  const gr = g.type === '33' ? 3 : g.type === '11' ? 1.5 : 2;
  return '<i class="grz-mini' + (cls || '') + '" style="width:' + w + 'px;height:' + h + 'px;border-width:' + gr + 'px"></i>';
}

function grzChipHtml(k, i, req, v, nm, j, dopisek) {
  const s = grzStan(v, k, i, req, nm, j);
  if (s.brakRezimu || s.brakMocy) return '';
  let cls = 'grz', body, mini = '';
  const em = dopisek ? ' <em>' + dopisek + '</em>' : '';
  if (s.brak && s.lazienka) {
    cls += ' grz--warn';
    mini = '<i class="grz-mini grz-mini--lazienka"></i>';
    body = '<b>Żadna drabinka z tabeli nie wystarcza' + em + '</b><span>' + fmt(req, 0)
      + ' W przy ' + s.rez.etykieta + ' — podziel na dwa grzejniki albo wybierz płytowy</span>';
  } else if (s.brak) {
    cls += ' grz--warn';
    body = '<b>Żaden płytowy z tabeli nie wystarcza' + em + '</b><span>' + fmt(req, 0)
      + ' W przy ' + s.rez.etykieta + ' — podziel moc na dwa grzejniki</span>';
  } else {
    const g = s.g;
    if (!s.ok) cls += ' grz--warn';
    mini = grzMini(g);
    const ogon = s.ok
      ? 'zapas ' + fmt(Math.max(0, (g.watts / req - 1) * 100), 0) + '%'
      : 'za mały o ' + fmt(req - g.watts, 0) + ' W';
    /* Karta drabinki jest liczona dla 20 °C, a w łazience jest 24 —
       dopisujemy, ile ta drabinka odda tam naprawdę. */
    const w24 = g.drab && s.lazienka ? ' · w 24 °C ok. ' + fmt(drabinkaW24(g, s.rez.tz, s.rez.tp), 0) + ' W' : '';
    body = '<b>' + esc(grzOpis(g)) + (s.reczny ? ' <em>wybrany ręcznie</em>' : '') + em + '</b>'
      + '<span>' + fmt(g.watts, 0) + ' W przy ' + s.rez.etykieta + ' · ' + ogon + w24 + '</span>';
  }
  return '<button type="button" class="' + cls + '" data-grz="' + k + '" data-i="' + i + '" data-j="' + (j ? 1 : 0) + '">'
    + mini + '<span class="grz-t">' + body + '</span><span class="grz-zm">Zmień ›</span></button>';
}

/* Paski pod mocą pomieszczenia: jeden grzejnik albo dwa z sumą. */
function grzChipyHtml(k, i, req, v, nm) {
  const d = grzDziel(v, k, i);
  let html;
  if (!d) html = grzChipHtml(k, i, req, v, nm, 0, '');
  else {
    const a = grzChipHtml(k, i, grzMocCzesci(v, k, i, req, 0), v, nm, 0, '1 z 2');
    const b = grzChipHtml(k, i, grzMocCzesci(v, k, i, req, 1), v, nm, 1, '2 z 2');
    if (!a && !b) return '';
    const s1 = grzStan(v, k, i, grzMocCzesci(v, k, i, req, 0), nm, 0);
    const s2 = grzStan(v, k, i, grzMocCzesci(v, k, i, req, 1), nm, 1);
    const suma = (s1.g ? s1.g.watts : 0) + (s2.g ? s2.g.watts : 0);
    const ok = s1.g && s2.g && suma >= req && s1.ok && s2.ok;
    const sumaHtml = (s1.g || s2.g) ? '<div class="grz-sum' + (ok ? '' : ' grz-sum--warn') + '"><b>Razem '
      + fmt(suma, 0) + ' W</b> — dwa grzejniki na ' + fmt(req, 0) + ' W'
      + (ok ? ', zapas ' + fmt((suma / req - 1) * 100, 0) + '%' : ', za mało') + '</div>' : '';
    html = a + b + sumaHtml;
  }
  return html ? '<div class="grz-box" data-grzbox="' + k + '" data-i="' + i + '">' + html + '</div>' : '';
}

/* Arkusz „inny grzejnik na tę samą moc". Moc pomieszczenia stoi na górze
   i nie da się jej tu zmienić — zmienia się tylko grzejnik. Lista to po
   jednym grzejniku na każdą parę wysokość × typ: najkrótszy, który
   wystarcza. Dotknięcie pozycji od razu ją wybiera — w rękawicach każde
   dodatkowe „Zatwierdź" to dodatkowe pudło. */
function grzSheetHtml(w) {
  const { v } = curr();
  const lista = v[w.k] || [];
  const reqPom = Number(lista[w.i]) || 0;
  const surowa = (v[w.k + 'Nazwy'] || [])[w.i];
  const nazwa = nazwyGrzejnikow(v[w.k + 'Nazwy'], lista.length)[w.i];
  const dziel = grzDziel(v, w.k, w.i);
  const j = dziel ? (w.j ? 1 : 0) : 0;
  const req = grzMocCzesci(v, w.k, w.i, reqPom, j);
  const s = grzStan(v, w.k, w.i, req, surowa, j);
  if (!s.rez || !(reqPom > 0)) return '';
  const rez = s.rez;
  const laz = czyLazienka(surowa);
  const tenSam = (a, b) => a && b && !!a.drab === !!b.drab && Number(a.height) === Number(b.height)
    && (a.drab ? a.ksztalt === b.ksztalt && Number(a.width) === Number(b.width)
               : String(a.type) === String(b.type) && Number(a.length) === Number(b.length));

  /* W łazience filtr to kształt drabinki albo płytowe; gdzie indziej —
     wysokość płytowego, jak dotąd. */
  const filtr = laz ? (w.f || (s.g && !s.g.drab && s.reczny ? 'plyt' : (s.g && s.g.drab ? s.g.ksztalt : 'plaska'))) : 'plyt';
  let alt, prop;
  if (filtr === 'plyt') {
    prop = laz ? null : grzejnikProponowany(req, rez.tz, rez.tp, rez.ti);
    alt = grzejnikiAlternatywy(req, rez.tz, rez.tp, rez.ti, { height: w.h || null });
  } else {
    prop = drabinkaProponowana(req, rez.tz, rez.tp, rez.ti);
    alt = drabinkiNaMoc(req, rez.tz, rez.tp, rez.ti, { ksztalt: filtr });
  }
  /* Na górze to, co już wybrane, i to, co aplikacja proponuje — reszta
     od najsłabszego. Inaczej propozycja ginie w środku listy. */
  const waga = g => (s.reczny && tenSam(g, s.g)) ? 0 : tenSam(g, prop) ? 1 : 2;
  alt.sort((a, b) => waga(a) - waga(b) || a.watts - b.watts);

  const fBtn = (val, txt, on) => '<button type="button" class="grz-f' + (on ? ' on' : '') + '" ' + val + '>' + txt + '</button>';
  const filtry = laz
    ? fBtn('data-grzf="plaska"', 'Drabinki płaskie', filtr === 'plaska')
      + fBtn('data-grzf="wypukla"', 'Drabinki wypukłe', filtr === 'wypukla')
      + fBtn('data-grzf="plyt"', 'Płytowe', filtr === 'plyt')
      + (filtr === 'plyt' ? '</div><div class="grz-fl">' + [0].concat(RADSON_HEIGHTS).map(h =>
          fBtn('data-grzwys="' + h + '"', h ? 'wys. ' + h : 'Wszystkie', (w.h || 0) === h)).join('') : '')
    : [0].concat(RADSON_HEIGHTS).map(h => fBtn('data-grzwys="' + h + '"', h ? 'wys. ' + h : 'Wszystkie', (w.h || 0) === h)).join('');

  const pozycje = alt.length ? alt.map(g => {
    const wybrany = s.reczny && tenSam(g, s.g);
    const podp = tenSam(g, prop) ? 'proponowany przez aplikację' : '';
    const dane = g.drab
      ? ' data-d="' + g.ksztalt + '" data-h="' + g.height + '" data-w="' + g.width + '"'
      : ' data-t="' + esc(g.type) + '" data-h="' + g.height + '" data-l="' + g.length + '"';
    return '<button type="button" class="grz-opt' + (wybrany ? ' sel' : '') + '" data-grzbierz' + dane + '>'
      + '<i class="grz-rb"></i>' + grzMini(g)
      + '<span class="grz-n"><b>' + esc(grzOpis(g)) + '</b>' + (podp ? '<span>' + podp + '</span>' : '') + '</span>'
      + '<span class="grz-w"><b>' + fmt(g.watts, 0) + ' W</b><span>+' + fmt(g.margin, 0) + '%</span></span></button>';
  }).join('') : '<p class="hint">Przy tych ustawieniach nic z tabeli nie pokrywa ' + fmt(req, 0) + ' W.'
    + (dziel ? '' : ' Podziel moc na dwa grzejniki.') + '</p>';

  /* Podział: przełącznik na górze, pod nim dwie karty — dotknięcie karty
     wybiera, którego grzejnika dotyczy lista; moc pierwszego da się wpisać,
     drugi dostaje resztę. */
  const m1 = grzMocCzesci(v, w.k, w.i, reqPom, 0), m2 = reqPom - m1;
  const opisCzesci = jj => {
    const st = grzStan(v, w.k, w.i, jj ? m2 : m1, surowa, jj);
    return st.g ? esc(grzKrotko(st.g)) : 'brak w tabeli';
  };
  const podzial = '<div class="seg grz-seg" role="group" aria-label="Liczba grzejników">'
    + '<button type="button" data-grzdziel="0" aria-pressed="' + !dziel + '">Jeden grzejnik</button>'
    + '<button type="button" data-grzdziel="1" aria-pressed="' + !!dziel + '">Dwa grzejniki</button></div>'
    + (dziel ? '<div class="grz-czesci">'
      + [0, 1].map(jj => '<button type="button" class="grz-cz' + (jj === j ? ' on' : '') + '" data-grzj="' + jj + '">'
        + '<span>Grzejnik ' + (jj + 1) + (jj === j ? ' · wybierasz' : '') + '</span>'
        + '<b>' + fmt(jj ? m2 : m1, 0) + ' <small>W</small></b><em>' + opisCzesci(jj) + '</em></button>').join('')
      + '</div>'
      + '<div class="grz-m1"><label for="grzM1">Moc grzejnika 1</label>'
      + '<input id="grzM1" type="number" inputmode="numeric" min="1" step="10" value="' + m1 + '" data-grzm1>'
      + '<span>W — drugi dostaje resztę</span></div>' : '');

  return '<div class="sheet" data-grzzamknij role="dialog" aria-label="Wybór grzejnika">'
    + '<div class="sheet-in" data-stop>'
    + '<div class="sheet-h">' + svg('layers') + '<strong>' + esc(nazwa) + (dziel ? ' — grzejnik ' + (j + 1) + ' z 2' : ' — grzejnik') + '</strong>'
    + '<button class="item-x" data-grzzamknij aria-label="Zamknij">' + svg('x') + '</button></div>'
    + '<div class="sheet-body">'
    + '<div class="grz-need">' + (dziel
      ? 'Pomieszczenie potrzebuje <b>' + fmt(reqPom, 0) + ' W</b> przy ' + rez.etykieta + ' °C — dzielisz to na dwa grzejniki.'
      : 'Zapotrzebowanie: <b>' + fmt(reqPom, 0) + ' W</b> przy ' + rez.etykieta + ' °C.')
    + '<br>Ta liczba zostaje — zmieniasz tylko grzejnik. Średnice rur liczą się dalej z niej.</div>'
    + podzial
    + '<div class="grz-fl">' + filtry + '</div>'
    + pozycje
    + (s.reczny ? '<button type="button" class="btn2" style="width:100%;margin-top:12px" data-grzauto>'
        + svg('restore') + 'Wróć do proponowanego'
        + (laz ? '' : (grzejnikProponowany(req, rez.tz, rez.tp, rez.ti) ? ' (' + esc(grzKrotko(grzejnikProponowany(req, rez.tz, rez.tp, rez.ti))) + ')' : ''))
        + '</button>' : '')
    + '<p class="hint" style="margin-top:10px">' + (filtr === 'plyt'
      ? 'Moce z tabeli Radson. Grzejnik innej marki o tym samym typie i wymiarze ma moc zbliżoną, ale nie identyczną — przy zapasie poniżej kilku procent sprawdź jego katalog.'
      : 'Moce drabinek z kart katalogowych, dla pomieszczenia 20 °C. W łazience przy 24 °C ta sama drabinka odda o kilkanaście procent mniej.')
    + '</p></div></div></div>';
}

/* Po zmianie mocy paski pod nią muszą pokazać nowy zapas albo ostrzeżenie
   — ale nie przerysowujemy formularza, bo pole mocy straciłoby kursor
   w pół wpisywania. Podmieniamy same paski. */
function grzOdswiez() {
  const boksy = document.querySelectorAll('[data-grzbox]');
  if (!boksy.length) return;
  const { v } = curr();
  boksy.forEach(el => {
    const k = el.dataset.grzbox, i = +el.dataset.i;
    const html = grzChipyHtml(k, i, Number((v[k] || [])[i]) || 0, v, (v[k + 'Nazwy'] || [])[i]);
    if (html) el.outerHTML = html; else el.remove();
  });
}

/* Przerysowanie z zachowaniem miejsca na ekranie — po wyborze grzejnika
   przy piątej pozycji lista nie ma skakać na samą górę. */
function grzRenderTuSamo() {
  const vp = document.getElementById('viewport');
  const y = vp ? vp.scrollTop : 0;
  render(false);
  if (vp) vp.scrollTop = y;
}

function grzTablica(v, klucz) {
  if (!Array.isArray(v[klucz])) v[klucz] = [];
  return v[klucz];
}

document.addEventListener('click', e => {
  const pasek = e.target.closest('[data-grz]');
  if (pasek) {
    state.grzWybor = { k: pasek.dataset.grz, i: +pasek.dataset.i, j: +(pasek.dataset.j || 0), h: 0, f: null };
    renderOverlay(); return;
  }
  if (!state.grzWybor) return;
  const W = state.grzWybor;

  const wys = e.target.closest('[data-grzwys]');
  if (wys) { W.h = Number(wys.dataset.grzwys) || 0; renderOverlay(); return; }
  const fil = e.target.closest('[data-grzf]');
  if (fil) { W.f = fil.dataset.grzf; W.h = 0; renderOverlay(); return; }
  const cz = e.target.closest('[data-grzj]');
  if (cz) { W.j = +cz.dataset.grzj; W.f = null; W.h = 0; renderOverlay(); return; }

  const dz = e.target.closest('[data-grzdziel]');
  if (dz) {
    const { v } = curr();
    const on = dz.dataset.grzdziel === '1';
    grzTablica(v, W.k + 'Dziel')[W.i] = on ? { u: 0.5 } : null;
    if (!on) grzTablica(v, W.k + 'Grz2')[W.i] = null;
    W.j = 0; W.f = null; W.h = 0;
    saveCalcValues(); grzRenderTuSamo(); return;
  }

  const opt = e.target.closest('[data-grzbierz]');
  if (opt) {
    const { v } = curr();
    const wyb = opt.dataset.d
      ? { d: opt.dataset.d, h: Number(opt.dataset.h), w: Number(opt.dataset.w) }
      : { t: opt.dataset.t, h: Number(opt.dataset.h), l: Number(opt.dataset.l) };
    grzTablica(v, W.k + (W.j ? 'Grz2' : 'Grz'))[W.i] = wyb;
    /* Przy dwóch grzejnikach po wyborze pierwszego od razu przechodzimy
       do drugiego — instalator i tak wybiera oba. */
    if (grzDziel(v, W.k, W.i) && !W.j) { W.j = 1; W.f = null; W.h = 0; saveCalcValues(); grzRenderTuSamo(); return; }
    state.grzWybor = null; saveCalcValues(); grzRenderTuSamo(); return;
  }
  if (e.target.closest('[data-grzauto]')) {
    const { v } = curr();
    const t = v[W.k + (W.j ? 'Grz2' : 'Grz')];
    if (Array.isArray(t)) t[W.i] = null;
    if (!grzDziel(v, W.k, W.i)) state.grzWybor = null;
    saveCalcValues(); grzRenderTuSamo(); return;
  }
  /* Zamknięcie: krzyżyk albo dotknięcie w przyciemnione tło. Niczego nie
     zmienia — wybór zapisuje się tylko dotknięciem konkretnego grzejnika. */
  if (e.target.closest('[data-grzzamknij]')
      && (!e.target.closest('[data-stop]') || e.target.closest('.sheet-h [data-grzzamknij]'))) {
    state.grzWybor = null; renderOverlay(); return;
  }
});

/* Moc pierwszego grzejnika przy podziale — zapisujemy jako udział, żeby
   po zmianie mocy pomieszczenia proporcja została ta sama. */
document.addEventListener('change', e => {
  const pole = e.target.closest && e.target.closest('[data-grzm1]');
  if (!pole || !state.grzWybor) return;
  const W = state.grzWybor;
  const { v } = curr();
  const req = Number((v[W.k] || [])[W.i]) || 0;
  const m1 = Number(pole.value);
  if (!(req > 0) || !(m1 > 0)) { setTimeout(renderOverlay, 0); return; }
  const u = Math.min(0.9, Math.max(0.1, m1 / req));
  grzTablica(v, W.k + 'Dziel')[W.i] = { u };
  saveCalcValues();
  /* „change" przychodzi przy opuszczaniu pola — przerysowanie od razu
     zabrałoby przeglądarce pole, które właśnie traci kursor. */
  setTimeout(() => { if (state.grzWybor) grzRenderTuSamo(); }, 0);
});

/* Grzejniki do rysunku i PDF — w kolejności pozycji z listy mocy, pomijając
   puste wiersze, tak jak robi to obliczenie średnic. Dostaje listę już
   rozwiniętą (podzielone pomieszczenia jako dwie pozycje). */
function grzDoRysunku(v, idx) {
  return idx.map(i => {
    const s = grzStan(v, 'rad', i, Number((v.rad || [])[i]) || 0, (v.radNazwy || [])[i], 0);
    if (!s.g) return s.lazienka ? { opis: 'łazienkowy', lazienka: true } : null;
    if (s.g.drab) return { opis: grzKrotko(s.g), drab: true, ksztalt: s.g.ksztalt,
      height: s.g.height, length: s.g.width, watts: s.g.watts, ok: s.ok, reczny: !!s.reczny };
    return { opis: grzKrotko(s.g), type: s.g.type, height: s.g.height, length: s.g.length,
      watts: s.g.watts, ok: s.ok, reczny: !!s.reczny };
  });
}

if (typeof module !== 'undefined') module.exports = { grzRezim, grzStan, grzOpis, grzKrotko, czyLazienka,
  grzDoRysunku, rozwinPodzial, podzialMoc, grzDziel, grzMocCzesci, grzChipyHtml };

