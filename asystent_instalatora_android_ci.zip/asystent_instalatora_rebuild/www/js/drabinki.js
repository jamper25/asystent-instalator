/* ===== drabinki.js ===== */
/* ============================================================
   GRZEJNIKI DRABINKOWE (ŁAZIENKOWE)
   ------------------------------------------------------------
   Dane wprost z kart katalogowych serii inwestycyjnej: wysokość,
   szerokość i moc przy dwóch parametrach podanych przez producenta,
   oba dla pomieszczenia 20 °C. W aplikacji pokazujemy tylko kształt —
   płaski albo wypukły — bez nazw modeli i kodów; nazwy zostają w danych,
   żeby było wiadomo, skąd liczby.
   [wysokość mm, szerokość mm, W przy 55/45/20, W przy 75/65/20, kod]
   ============================================================ */

const DRABINKI = {
  plaska: {
    model: 'FIDO', nazwa: 'płaski',
    wiersze: [
      [689, 400, 125, 230, 'TRGGLFI0604SX'],
      [689, 500, 158, 292, 'TRGGLFI0605SX'],
      [689, 600, 186, 342, 'TRGGLFI0606SX'],
      [911, 400, 169, 312, 'TRGGLFI0904SX'],
      [911, 500, 214, 396, 'TRGGLFI0905SX'],
      [911, 600, 252, 466, 'TRGGLFI0906SX'],
      [1133, 400, 213, 395, 'TRGGLFI1104SX'],
      [1133, 500, 270, 500, 'TRGGLFI1105SX'],
      [1133, 600, 319, 590, 'TRGGLFI1106SX'],
      [1429, 400, 272, 504, 'TRGGLFI1404SX'],
      [1429, 500, 345, 640, 'TRGGLFI1405SX'],
      [1429, 600, 407, 755, 'TRGGLFI1406SX'],
      [1725, 400, 331, 615, 'TRGGLFI1704SX'],
      [1725, 500, 420, 780, 'TRGGLFI1705SX'],
      [1725, 600, 495, 920, 'TRGGLFI1706SX'],
      [1947, 400, 374, 697, 'TRGGLFI1904SX'],
      [1947, 500, 475, 885, 'TRGGLFI1905SX'],
      [1947, 600, 561, 1044, 'TRGGLFI1906SX'],
    ],
  },
  wypukla: {
    model: 'MONA', nazwa: 'wypukły',
    wiersze: [
      [620, 380, 156, 295, 'TRGGLMN062038'],
      [900, 380, 217, 409, 'TRGGLMN090038'],
      [1100, 380, 260, 489, 'TRGGLMN110038'],
      [620, 440, 178, 336, 'TRGGLMN062044'],
      [900, 440, 248, 466, 'TRGGLMN090044'],
      [1100, 440, 302, 568, 'TRGGLMN110044'],
      [420, 560, 156, 294, 'TRGGLMN042056'],
      [620, 560, 221, 415, 'TRGGLMN062056'],
      [900, 560, 309, 578, 'TRGGLMN090056'],
      [1100, 560, 370, 690, 'TRGGLMN110056'],
      [1340, 560, 441, 822, 'TRGGLMN134056'],
      [1500, 560, 488, 908, 'TRGGLMN150056'],
      [1700, 560, 546, 1015, 'TRGGLMN170056'],
      [900, 650, 353, 659, 'TRGGLMN090065'],
      [1100, 650, 410, 755, 'TRGGLMN110065'],
      [1340, 650, 504, 938, 'TRGGLMN134065'],
    ],
  },
};

const DRABINKI_PARAMETRY = ['55/45/20', '75/65/20'];
const DRAB_KSZTALTY = ['plaska', 'wypukla'];
const DRAB_SZEROKOSCI = [...new Set(DRAB_KSZTALTY.flatMap(k => DRABINKI[k].wiersze.map(r => r[1])))].sort((a, b) => a - b);
const DRAB_WYSOKOSCI = [...new Set(DRAB_KSZTALTY.flatMap(k => DRABINKI[k].wiersze.map(r => r[0])))].sort((a, b) => a - b);

/* Moc drabinki przy dowolnych parametrach pracy.
   Przy 55/45/20 i 75/65/20 bierzemy liczbę wprost z karty. Przy innych
   przeliczamy jak norma grzejnikowa PN-EN 442 — stosunkiem średnich
   logarytmicznych różnic temperatur podniesionym do wykładnika
   charakterystyki. Wykładnik wyliczamy z dwóch punktów z karty, osobno
   dla każdego rozmiaru: drabinki oddają ciepło inaczej niż płytowe
   (wychodzi im ok. 1,2, a nie 1,3), a karta podaje to wprost, wystarczy
   policzyć. Gdyby wyszło coś niefizycznego, bierzemy 1,3 jak dla płytowych. */
function drabinkaMocWiersza(r, tz, tp, ti) {
  const p55 = r[2], p75 = r[3];
  const t = ti === undefined ? 20 : ti;
  const klucz = tz + '/' + tp + '/' + t;
  if (klucz === '55/45/20') return p55;
  if (klucz === '75/65/20') return p75;
  const d75 = dtLog(75, 65, 20), d55 = dtLog(55, 45, 20), x = dtLog(tz, tp, t);
  if (!(x > 0)) return 0;
  let n = Math.log(p75 / p55) / Math.log(d75 / d55);
  if (!(n > 1 && n < 1.6)) n = 1.3;
  return Math.round(p75 * Math.pow(x / d75, n));
}
function drabinkaWiersz(k, h, w) {
  const d = DRABINKI[k];
  return d ? d.wiersze.find(r => r[0] === Number(h) && r[1] === Number(w)) || null : null;
}
function drabinkaMoc(k, h, w, tz, tp, ti) {
  const r = drabinkaWiersz(k, h, w);
  return r ? drabinkaMocWiersza(r, tz, tp, ti) : 0;
}

/* Wszystkie drabinki, które pokrywają moc, od najsłabszej.
   opt: { ksztalt, maxSzer, maxWys } — każde może być puste. */
function drabinkiNaMoc(req, tz, tp, ti, opt) {
  const o = opt || {};
  const out = [];
  DRAB_KSZTALTY.forEach(k => {
    if (o.ksztalt && o.ksztalt !== k) return;
    DRABINKI[k].wiersze.forEach(r => {
      if (o.maxSzer && r[1] > Number(o.maxSzer)) return;
      if (o.maxWys && r[0] > Number(o.maxWys)) return;
      const w = drabinkaMocWiersza(r, tz, tp, ti);
      if (w >= req) out.push({ drab: true, ksztalt: k, height: r[0], width: r[1], watts: w, margin: (w / req - 1) * 100 });
    });
  });
  out.sort((a, b) => a.watts - b.watts || a.height - b.height);
  return out;
}

/* Podpowiedź do łazienki: najpierw najmniejsza płaska, która wystarcza —
   płaska jest tańsza i częściej wisi — a dopiero potem wypukła. */
function drabinkaProponowana(req, tz, tp, ti) {
  if (!(req > 0)) return null;
  return drabinkiNaMoc(req, tz, tp, ti, { ksztalt: 'plaska' })[0]
      || drabinkiNaMoc(req, tz, tp, ti, { ksztalt: 'wypukla' })[0] || null;
}

function drabinkaNazwa(k) { return (DRABINKI[k] || {}).nazwa || ''; }
/* „Drabinkowy płaski 1133 × 500" — wysokość × szerokość, tak jak przy
   płytowych wysokość × długość. */
function drabinkaOpis(g) { return 'Drabinkowy ' + drabinkaNazwa(g.ksztalt) + ' ' + g.height + ' × ' + g.width; }
function drabinkaKrotko(g) { return 'drabinkowy ' + drabinkaNazwa(g.ksztalt) + ' ' + g.height + '×' + g.width; }

/* Ile drabinka odda w łazience przy 24 °C — karta jest liczona dla 20 °C,
   więc w ciepłej łazience ten sam grzejnik grzeje słabiej. */
function drabinkaW24(g, tz, tp) { return drabinkaMoc(g.ksztalt, g.height, g.width, tz, tp, 24); }


