/* ===== conowego.js ===== */
/* ============================================================
   CO NOWEGO PO AKTUALIZACJI
   ------------------------------------------------------------
   Sklep pokazuje opis zmian tylko temu, kto sam wejdzie na kartę
   aplikacji — a aktualizacje instalują się same, w tle. Instalator
   dostaje więc nowe funkcje, o których nie ma skąd wiedzieć.
   Dlatego po pierwszym uruchomieniu nowej wersji aplikacja sama
   mówi, co się zmieniło, i więcej już o to nie zaczepia.

   Zasady:
   — okno pokazuje się raz na wersję, po jej pierwszym otwarciu;
   — świeża instalacja go nie dostaje, bo dla nowego wszystko jest
     nowe, a okno na dzień dobry tylko przeszkadza;
   — numer ostatnio pokazanej wersji zapisujemy od razu przy
     wyświetleniu, żeby zamknięcie apki w trakcie czytania nie
     wywołało okna drugi raz.
   ============================================================ */

const NOWOSCI_KEY = 'ai_wersja_v1';

/* Zmiany w kolejności od najnowszej. Opisujemy to, co instalator
   zobaczy w swojej robocie, a nie to, co zmieniło się w kodzie.
   Polityki prywatności tu nie wymieniamy — ma własny ekran
   w Ustawieniach i własną datę obowiązywania. */
const NOWOSCI = [
  { wersja: '1.6.0', tytul: 'Pełna wersja — 14 dni za darmo', punkty: [
    'Średnice c.o., podłogówki, wody i gazu, schemat kotłowni i Biuro wchodzą do pełnej wersji: 29 zł miesięcznie albo 249 zł za rok, pierwsze 14 dni za darmo. Kolejne funkcje dochodzą w cenie abonamentu.',
    'Za darmo zostaje na stałe: przekrój rurociągu, strata ciepła, zapotrzebowanie, dobór grzejnika, rozstaw i pętle podłogówki, pompa, naczynie, Kvs, pojemność, zawór bezpieczeństwa, notatnik i kody błędów.',
    'Nic nie znika: bez abonamentu płatne kalkulatory pokazują pełne przykładowe obliczenie, a stare oferty i faktury dalej otworzysz, zapiszesz w PDF i wyślesz.',
    'W Biurze przykładowy projekt — kocioł na pellet w układzie otwartym, bufor i trzy obiegi, z całym schematem i średnicami.',
    'Pytanie o stratę ciepła przy doborze grzejnika możesz wyłączyć, a przyciski rysunków stoją w jednym rzędzie z „Do projektu”.',
    'Usunięcie oferty albo faktury pyta najpierw o potwierdzenie, z nazwą dokumentu — pasek „Cofnij” zostaje jak dotąd.',
    'Gdy suwak w kalkulatorze odbiega od wartości domyślnej, nad wynikiem staje pasek z informacją i przyciskiem „Przywróć” — przypadkowe przesunięcie nie przejdzie niezauważone.',
  ] },
  { wersja: '1.5.0', tytul: 'Kotłownia, projekty i notatnik', punkty: [
    'Schemat kotłowni: wybierasz źródło, układ, c.w.u. i bufor albo sprzęgło, a „Stwórz projekt” zakłada teczkę budowy w Biurze.',
    'Obiegi z kalkulatorów grzejników i podłogówki przenosisz do projektu — kotłownia sama dobiera moc, bufor, sprzęgło, rozdzielacz, naczynia, Kvs i pompy, a na schemacie opisuje średnice DN.',
    'Pompa obiegowa liczy się sama w kalkulatorach grzejników i podłogówki — z długości rur i pętli. Ręcznie dobierzesz ją w „Doborze pompy”.',
    'Zestawienia materiałów do każdego obiegu i do kotłowni, z cenami z katalogu — zaznaczone pozycje idą do oferty.',
    'Notatnik ze zdjęciami, rysowaniem po zdjęciu, listą zakupów i przypomnieniem. Kody błędów kotłów i pomp ciepła w zakładce Asystent.',
  ] },
  { wersja: '1.4.0', tytul: 'Łazienki i podwójne grzejniki', punkty: [
    'Grzejniki drabinkowe do łazienek — płaskie i wypukłe, dobierane z tabeli mocy.',
    'Jedno pomieszczenie, dwa grzejniki: dzielisz moc na dwa okna, a rysunek i zestawienie liczą oba.',
    'W zakładce Asystent zapowiedź modułu AI na budowę — możesz podpowiedzieć, co ma umieć.',
  ] },
  { wersja: '1.3.0', tytul: 'Grzejnik przy każdym pomieszczeniu', punkty: [
    'Przy każdym pomieszczeniu w średnicach c.o. dobierany jest konkretny grzejnik, z przyciskiem „Zmień”.',
    'Rysunek pokazuje rurę przy kotle, opisane nitki i zestawienie grzejników.',
  ] },
];

/* Porównanie numerów wersji: 1.10.0 jest nowsze od 1.9.0, choć
   tekstowo wypada odwrotnie. */
function porownajWersje(a, b) {
  const x = String(a || '0').split('.').map(n => parseInt(n, 10) || 0);
  const y = String(b || '0').split('.').map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    const d = (x[i] || 0) - (y[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

/* Czy to pierwsze uruchomienie po instalacji. Rozpoznajemy po tym,
   że w pamięci telefonu nie ma jeszcze żadnych danych aplikacji —
   ani ustawień firmy, ani ofert, ani choćby jednego kalkulatora. */
const NOWOSCI_SLADY = ['ai_ustawienia_v1', 'ai_kalkulatory_v1', 'ai_oferty_v1',
  'ai_klienci_v1', 'ai_ceny_v1', 'ai_katalog_v1'];
function swiezaInstalacja() {
  try {
    return !NOWOSCI_SLADY.some(k => localStorage.getItem(k) !== null);
  } catch (e) { return true; }   /* pamięć zablokowana — lepiej nie zaczepiać */
}

function zapiszPokazanaWersje() {
  try { localStorage.setItem(NOWOSCI_KEY, APP_WERSJA); } catch (e) { /* trudno */ }
}

/* Uruchamiane raz, przy starcie aplikacji. */
function sprawdzNowosci() {
  let zapisana = null;
  try { zapisana = localStorage.getItem(NOWOSCI_KEY); } catch (e) { return; }
  if (zapisana === APP_WERSJA) return;

  if (zapisana === null && swiezaInstalacja()) { zapiszPokazanaWersje(); return; }

  /* Kto aktualizuje z wersji sprzed tego okna, nie ma zapisanego numeru —
     pokazujemy mu wtedy samą bieżącą wersję, a nie całą historię. */
  const lista = zapisana === null
    ? NOWOSCI.filter(n => n.wersja === APP_WERSJA)
    : NOWOSCI.filter(n => porownajWersje(n.wersja, zapisana) > 0
                       && porownajWersje(n.wersja, APP_WERSJA) <= 0);

  zapiszPokazanaWersje();
  if (!lista.length) return;
  state.coNowego = lista;
  renderOverlay();
}

function coNowegoHtml(lista) {
  const wersje = lista.map(n => `
    <div class="now-w">
      <div class="now-h">${svg('spark')}<b>${esc(n.tytul)}</b><span>wersja ${esc(n.wersja)}</span></div>
      <ul class="now-l">${n.punkty.map(p => `<li>${esc(p)}</li>`).join('')}</ul>
    </div>`).join('');

  return `<div class="sheet" data-nowosciok>
    <div class="sheet-in" role="dialog" aria-label="Co nowego w aplikacji">
      <div class="sheet-h">${svg('spark')}<strong>Co nowego</strong>
        <button class="item-x" data-nowosciok aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        ${wersje}
        <button class="jump" style="--c:var(--flame);width:100%;margin-top:4px" data-nowosciok>
          ${svg('check')}Jasne, wracam do roboty</button>
        <p class="hint">Twoje dane zostały na miejscu — aktualizacja niczego nie kasuje.</p>
      </div>
    </div></div>`;
}

document.addEventListener('click', e => {
  if (!state.coNowego) return;
  if (e.target.closest('[data-nowosciok]')) {
    state.coNowego = null;
    renderOverlay();
  }
});

