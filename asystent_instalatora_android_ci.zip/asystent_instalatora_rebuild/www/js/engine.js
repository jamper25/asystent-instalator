/* ===== engine.js ===== */
/* ============================================================
   SILNIK OBLICZENIOWY — czyste funkcje, testowalne osobno.
   ============================================================ */

/* --- Współczynnik przenikania ciepła ściany U [W/(m²·K)] ---
   U = 1 / (Rsi + d1/λ1 + d2/λ2 + Rse)     (PN-EN ISO 6946)   */
function wallU(lambdaWall, dWallM, lambdaIns, dInsM) {
  let R = RSI_WALL + RSE_WALL;
  if (lambdaWall > 0 && dWallM > 0) R += dWallM / lambdaWall;
  if (lambdaIns > 0 && dInsM > 0) R += dInsM / lambdaIns;
  return 1 / R;
}

/* --- Powierzchnia ścian zewnętrznych pomieszczenia --- */
function externalWallArea(lenM, widM, hM, nWalls) {
  const per = { 0: 0, 1: lenM, 2: lenM + widM, 3: 2 * lenM + widM, 4: 2 * (lenM + widM) };
  return (per[nWalls] || 0) * hM;
}

/* --- Strata ciepła pomieszczenia (PN-EN 12831, ujęcie uproszczone) ---
   Qt = Σ(A · U · fx) · (ti − te)      przenikanie
   Qv = 0,34 · n · V · (ti − te)       wentylacja                     */
function roomHeatLoss(p) {
  const dT = p.tIn - p.tOut;
  const V = p.len * p.wid * p.h;

  const aWindows = p.winCount * p.winW * p.winH;
  const aWallRaw = externalWallArea(p.len, p.wid, p.h, p.nWalls);
  const aWall = Math.max(0, aWallRaw - aWindows);
  const aFloor = p.len * p.wid;
  const aCeil = p.len * p.wid;

  const qWall = aWall * p.uWall * dT;
  const qWin = aWindows * p.uWin * dT;
  const qFloor = aFloor * p.uFloor * p.fxFloor * dT;
  const qCeil = aCeil * p.uCeil * p.fxCeil * dT;
  const qTrans = qWall + qWin + qFloor + qCeil;
  const qVent = AIR_FACTOR * p.n * V * dT;

  return {
    dT, V, aWall, aWindows, aFloor,
    qWall, qWin, qFloor, qCeil,
    qTrans, qVent,
    total: qTrans + qVent,
    perM2: (qTrans + qVent) / aFloor,
  };
}

/* --- Wydajność pompy: q = Q / (1,163 · Δt)  [m³/h] ---
   wzór wprost z poradnika instalatora (s. 32)                        */
function pumpFlow(kW, dT) {
  if (dT <= 0) return 0;
  return kW / (1.163 * dT);
}

/* --- Rura od źródła: c.o. plus zasobnik c.w.u. ---
   Kocioł w domu jednorodzinnym grzeje zwykle jedno i drugie, a rura,
   która z niego wychodzi, musi to unieść. Przy priorytecie c.w.u. — a tak
   działa większość kotłów — grzanie wody wyłącza na ten czas ogrzewanie,
   więc rura niesie większą z dwóch wartości, nie ich sumę. Przy pracy
   równoległej trzeba dodać.

   Zwraca moc w watach oraz informację, co zdecydowało — bo to jest
   rzecz, którą instalator powinien zobaczyć, a nie tylko wynik. */

/* Prędkość wody w rurze o znanej średnicy wewnętrznej [mm] przy przepływie
   [m³/h]. Osobno, bo wchodzi w trzy różne obliczenia. */
/* Odwrotność predkosciWRurze: jaki przepływ [l/h] daje zadaną prędkość
   w rurze o świetle d [mm]. Potrzebne tam, gdzie granicą jest prędkość,
   a odpowiedzią ma być liczba do ustawienia na rotametrze. */
function przeplywZPredkosci(vMs, dWewnMm) {
  const r = (Number(dWewnMm) || 0) / 2000;
  if (!(r > 0)) return 0;
  return vMs * Math.PI * r * r * 1000 * 3600;
}

function predkoscWRurze(qM3h, dWewnMm) {
  if (!(qM3h > 0) || !(dWewnMm > 0)) return 0;
  return (qM3h / 3600) / (Math.PI * Math.pow(dWewnMm / 1000, 2) / 4);
}

/* --- Doprowadzenia do rozdzielaczy ---
   ------------------------------------------------------------
   Cała trudność tego obliczenia siedzi w jednym miejscu: po której stronie
   zaworu mieszającego liczymy rurę.

   Podłogówka pracuje na małym Δt — zwykle 5 do 7 kelwinów. Przy tej samej
   mocy przepływ wychodzi więc trzy razy większy niż w instalacji grzejnikowej
   na 15 K, a rura odpowiednio grubsza. Ale jeżeli grupa mieszająca stoi przy
   rozdzielaczu — a przy kotle gazowym stoi tam prawie zawsze — to rura od
   kotła jest po stronie pierwotnej i płynie nią woda o parametrach kotła,
   z jego Δt. Wtedy jest cieńsza, i to znacznie.

   Dlatego liczymy dwa przepływy dla każdego rozdzielacza: jeden przez belkę
   (decyduje o rozmiarze korpusu i o pętlach) i drugi przez doprowadzenie
   (decyduje o średnicy rury od źródła).

   Odcinek wspólny to suma przepływów w doprowadzeniach, a nie suma mocy
   podzielona przez jedno Δt — rozdzielacze mogą pracować na różnych
   parametrach i dodawanie mocy dałoby wtedy wynik z sufitu. */
/* --- Pompa obiegu podłogowego ---
   ------------------------------------------------------------
   Dwie rzeczy, o które łatwo się potknąć.

   Pierwsza: oporów pętli NIE sumuje się. Pętle wiszą na belce równolegle,
   więc pompa pokonuje najgorszą z nich, a nie wszystkie po kolei. Dodawanie
   dałoby pompę kilka razy za dużą.

   Druga: granica obiegu. Gdy przy rozdzielaczu stoi grupa mieszająca, pompa
   siedzi po stronie wtórnej i krąży w kółku rozdzielacz → pętle → zawór →
   pompa. Rura od kotła do mieszacza należy do pompy kotła, nie do tej —
   więc jej tu nie doliczamy. Bez mieszacza jest odwrotnie: to jeden obieg
   od źródła do pętli i rura wchodzi w całości, w obie strony.

   Belki rozdzielacza i zawór z przepływomierzem liczymy z Kv producenta:
   Δp = (G / Kv)² kPa, gdzie G to przepływ w l/h. */
function pompaPodlogowki(p, o) {
  const qLh = p.qBelka * 1000;                 /* l/h przez cały rozdzielacz */
  const qPetlaLh = p.qPetla * 1000;            /* l/h przez jedną pętlę */

  const belka = KV_BELKA.find(x => p.wyj <= x[0]) || KV_BELKA[KV_BELKA.length - 1];
  const dpBelki = Math.pow(qLh / belka[1], 2) + Math.pow(qLh / belka[2], 2);
  const dpPrzeplywomierz = Math.pow(qPetlaLh / KV_PRZEPLYWOMIERZ, 2);

  /* Opory najgorszej pętli. Najlepiej z kalkulatora podłogówki (guzik
     „Dopisz”) albo wpisane ręcznie. Gdy ich nie ma, liczymy je z długości:
     najdłuższa pętla z dopisanych pomieszczeń, a bez niej — z łącznej
     długości rury na rozdzielaczu (najdłuższa ≈ 1,2 × średnia pętla).
     Bez żadnej długości przyjmujemy typową najdłuższą pętlę 80 m. */
  let dpPetli = Math.max(0, Number(p.dpPetli) || 0), dpPetliZr = 'wpisane', dlPetliUzyta = 0;
  if (!(dpPetli > 0)) {
    const sr = p.metrow > 0 && p.wyj > 0 ? p.metrow / p.wyj : 0;
    if (p.dlPetli > 0) { dlPetliUzyta = p.dlPetli; dpPetliZr = 'najdluzsza'; }
    else if (sr > 0) { dlPetliUzyta = Math.min(120, sr * 1.2); dpPetliZr = 'srednia'; }
    else { dlPetliUzyta = 80; dpPetliZr = 'typowa'; }
    const m = String((p.rury || [])[0] || '').replace(',', '.').match(/(\d+(?:\.\d+)?)\s*[x×]\s*(\d+(?:\.\d+)?)/);
    const wew = m ? (+m[1] - 2 * +m[2]) : pipeInner(NITKA_ROZDZ);
    const fp = pipeFriction(p.qPetla, wew, dlPetliUzyta, 'multi', WATER_UFH);
    dpPetli = (fp ? fp.dp : 0) / 1000 * 1.1;   // +10% na łuki
  }

  /* Rura od źródła: tylko gdy nie ma mieszacza, i wtedy tam i z powrotem. */
  let dpRury = 0, rurometrow = 0;
  if (!o.mieszacz && p.dl > 0 && p.rura && p.rura.pick) {
    rurometrow = p.dl * 2;
    /* Woda podłogówki jest chłodniejsza i gęstsza niż kotłowa — przy
       trzydziestu kilku stopniach lepkość jest wyraźnie większa, więc
       opory liczymy jej własnymi parametrami, nie parametrami c.o. */
    const f = pipeFriction(p.qDoj, p.rura.inner, rurometrow, o.mat, WATER_UFH);
    dpRury = (f ? f.dp : 0) / 1000;            /* Pa → kPa */
  }

  /* Zawór mieszający jest w obiegu wtórnym, więc jego spadek pompa pokonuje. */
  const dpZaworu = (o.mieszacz && o.zaworDp) ? o.zaworDp : 0;

  const suma = dpPetli + dpPrzeplywomierz + dpBelki + dpRury + dpZaworu;
  const zZapasem = suma * (1 + (Number(o.zapas) || 0) / 100);

  return {
    q: p.qBelka,
    dpPetli, dpPetliZr, dlPetliUzyta, dpPrzeplywomierz, dpBelki, dpRury, dpZaworu, rurometrow,
    suma, zZapasem,
    H: zZapasem * 1000 / (WATER_UFH.rho * WATER_UFH.g),   /* kPa → m słupa wody */
    brakPetli: !(dpPetli > 0), szacPetli: dpPetliZr === 'typowa',
  };
}

/* Pompa obiegu grzejnikowego — z tego, co wiadomo w kalkulatorze:
   rura od źródła do najdalszego grzejnika tam i z powrotem (opory liniowe
   + 30% na kształtki), grzejnik z zaworem termostatycznym i śrubunkiem
   (ok. 10 kPa, typowe nastawy projektowe), armatura w kotłowni (zawory,
   filtr, zwrotny — ok. 3 kPa), przy układzie rozdzielaczowym jeszcze
   rozdzielacz (ok. 2 kPa). Do tego 10% zapasu. */
function pompaGrzejnikowa(q, rura, mat, dl, rozdz) {
  if (!(q > 0) || !(dl > 0) || !rura) return null;
  const f = pipeFriction(q, rura.inner || pipeInner(rura.pick), 2 * dl, mat, WATER);
  const dpRury = (f ? f.dp : 0) / 1000 * 1.3;
  const dpGrz = 10, dpArm = 3, dpRozdz = rozdz ? 2 : 0;
  const suma = dpRury + dpGrz + dpArm + dpRozdz;
  const zZapasem = suma * 1.1;
  return { q, dl, dpRury, dpGrz, dpArm, dpRozdz, suma, zZapasem, H: zZapasem * 1000 / (WATER.rho * WATER.g) };
}

const dtCoBezp = o => (o && o.dtCo > 0 ? o.dtCo : 15);

function dojsciaRozdzielaczy(lista, o) {
  const pozycje = (lista || []).map((r, i) => {
    const w = Math.max(0, Number(r.w) || 0);
    const wyj = Math.max(0, Math.round(Number(r.wyj) || 0));

    /* Belką płynie woda już zmieszana, więc liczymy ją na Δt podłogówki.
       Doprowadzenie od źródła zależy od tego, gdzie stoi zawór: za grupą
       mieszającą to strona kotła i jego Δt, bez niej — Δt obiegu. */
    const dtBelka = o.dtPod;
    /* Jeden mieszacz w kotłowni: do rozdzielaczy płynie już woda zmieszana,
       więc ich doprowadzenia liczą się na Δt podłogówki, tak jak bez mieszacza. */
    const przyRozdz = o.mieszacz && !o.wspolnyMieszacz;
    const dtDoj = przyRozdz ? o.dtCo : o.dtPod;

    /* Przez belkę płynie suma przepływów pętli, a te wynikają z mocy —
       tak samo jak po stronie pojedynczego obiegu. Nie podnosimy tego
       do żadnego minimum: nastawy rotametrów są projektowe, więc i suma
       musi być projektowa, inaczej korpus i zawór liczyłyby się z wody,
       której nikt nie przepuści. */
    const qMinPetla = przeplywZPredkosci(V_MIN_PETLA_POD, pipeInner(NITKA_ROZDZ)) / 1000;
    const qBelka = pumpFlow(w / 1000, dtBelka);
    const qBelkaZMocy = qBelka;
    const belkaPodniesiona = false;

    const qDoj = przyRozdz ? pumpFlow(w / 1000, dtCoBezp(o)) : qBelka;
    const rura = selectPipe(qDoj, o.mat, o.v);

    const korpus = ROZDZ_KORPUSY.find(k => predkoscWRurze(qBelka, k[1]) <= V_MAX_KORPUS)
      || ROZDZ_KORPUSY[ROZDZ_KORPUSY.length - 1];
    const vKorpus = predkoscWRurze(qBelka, korpus[1]);

    const qPetla = wyj > 0 ? qBelka / wyj : 0;
    const vPetla = predkoscWRurze(qPetla, pipeInner(NITKA_ROZDZ));

    return {
      nr: i + 1, nazwa: r.nazwa || ('Rozdzielacz ' + (i + 1)), w, wyj,
      dl: Math.max(0, Number(r.dl) || 0), dpPetli: Math.max(0, Number(r.dp) || 0),
      metrow: Math.max(0, Number(r.metrow) || 0), rury: r.rury || [], dlPetli: Math.max(0, Number(r.dlPetli) || 0),
      wklady: r.wklady || null,
      dtBelka, dtDoj, qBelka, qDoj,
      rura, przezMieszacz: przyRozdz,
      korpus: korpus[0], vKorpus, korpusZaMaly: vKorpus > V_MAX_KORPUS,
      qPetla, vPetla, petlaZaSzybko: wyj > 0 && vPetla > V_MAX_PETLA_POD,
      qBelkaZMocy, belkaPodniesiona, qMinPetla,
      petlaZaWolno: wyj > 0 && qBelka / wyj < qMinPetla,
    };
  });

  const qWspolny = pozycje.reduce((a, p) => a + p.qDoj, 0);
  const sumaW = pozycje.reduce((a, p) => a + p.w, 0);

  /* Metry rury pętli w całym budynku — to się zamawia, więc sumujemy
     wszystko i zbieramy rozmiary, jakie padły. */
  const sumaMetrow = pozycje.reduce((a, p) => a + p.metrow, 0);
  const rury = [];
  pozycje.forEach(p => (p.rury || []).forEach(x => { if (rury.indexOf(x) < 0) rury.push(x); }));

  /* Ładowanie zasobnika idzie wprost od kotła, obok grupy mieszającej —
     więc dolicza się do odcinka wspólnego, ale nigdy do belki ani do zaworu. */
  const qZasobnik = (o.zasobnikW > 0 && o.zasobnikDalej && !o.wspolnyMieszacz) ? pumpFlow(o.zasobnikW / 1000, o.dtCo) : 0;
  const wspolny = selectPipe(qWspolny + qZasobnik, o.mat, o.v);

  /* Zawór mieszający dobieramy tą samą drogą, co kalkulator zaworu — jedna
     tabela Kvs i jedno pasmo spadku na całą aplikację, żeby ten sam obieg
     policzony w dwóch miejscach nie dawał dwóch różnych zaworów. Przez zawór
     przechodzi cały obieg podłogowy po stronie wtórnej, bo pompa stoi za nim. */
  const qObiegu = pozycje.reduce((a, p) => a + p.qBelka, 0);
  /* Wspólny mieszacz przepuszcza cały obieg podłogowy. Mieszacz przy każdym
     rozdzielaczu — tylko wodę swojego rozdzielacza, więc każdy ma własny Kvs. */
  const zawor = o.mieszacz && o.wspolnyMieszacz ? selectMixingValve(qObiegu, DP_VALVE_MAX) : null;
  if (zawor) zawor.q = qObiegu;
  if (o.mieszacz && !o.wspolnyMieszacz) pozycje.forEach(p => {
    p.zawor = selectMixingValve(p.qBelka, DP_VALVE_MAX);
    if (p.zawor) p.zawor.q = p.qBelka;
  });

  /* Pompy liczymy na końcu, bo potrzebują spadku na zaworze mieszającym. */
  pozycje.forEach(p => {
    if (zawor) {
      /* Jedna pompa w kotłowni za wspólnym mieszaczem: pokonuje też rurę
         do rozdzielacza w obie strony — liczymy jak bez mieszacza i dokładamy zawór. */
      p.pompa = pompaPodlogowki(p, { mieszacz: false, mat: o.mat, zapas: o.zapas });
      const dz = zawor.dp * 100;
      p.pompa.dpZaworu = dz; p.pompa.suma += dz;
      p.pompa.zZapasem = p.pompa.suma * (1 + (Number(o.zapas) || 0) / 100);
      p.pompa.H = p.pompa.zZapasem * 1000 / (WATER_UFH.rho * WATER_UFH.g);
    } else {
      p.pompa = pompaPodlogowki(p, {
        mieszacz: o.mieszacz, mat: o.mat, zapas: o.zapas,
        zaworDp: p.zawor ? p.zawor.dp * 100 : 0,
      });
    }
  });
  const pompaWsp = zawor ? { q: qObiegu, H: Math.max(...pozycje.map(p => p.pompa.H)) } : null;

  return { pozycje, qWspolny, qZasobnik, sumaW, wspolny, zawor, pompaWsp, sumaMetrow, rury };
}

/* --- Opory liniowe przewodu (Darcy–Weisbach + Swamee–Jain) ---
   zwraca prędkość, liczbę Reynoldsa, opór jednostkowy [Pa/m]
   i spadek ciśnienia na całej długości [Pa]                          */
const ROUGHNESS = { copper: 0.0015, press: 0.0015, multi: 0.007, pp20: 0.007, pp16: 0.007, steel: 0.045 };

function pipeFriction(flowM3h, innerMm, lengthM, material, water) {
  const w = water || WATER;
  const d = innerMm / 1000;
  const A = Math.PI * d * d / 4;
  const Q = flowM3h / 3600;
  const v = Q / A;
  if (!(v > 0)) return { v: 0, Re: 0, lambda: 0, R: 0, dp: 0 };

  const Re = v * d / w.nu;
  const k = (ROUGHNESS[material] || 0.0015) / 1000;
  let lambda;
  if (Re < 2300) lambda = 64 / Re;
  else lambda = 0.25 / Math.pow(Math.log10(k / (3.7 * d) + 5.74 / Math.pow(Re, 0.9)), 2);

  const R = lambda * (1 / d) * (w.rho * v * v / 2);   // Pa/m
  return { v, Re, lambda, R, dp: R * lengthM };
}

/* --- Dobór średnicy z zadanej prędkości --- */
function selectPipe(flowM3h, material, vTarget, minZewnMm) {
  const list = pipeList(material);
  const Q = flowM3h / 3600;
  if (!(Q > 0) || !(vTarget > 0)) return null;
  const needMm = Math.sqrt((4 * Q) / (Math.PI * vTarget)) * 1000;

  /* Dwa warunki, każdy mierzony czym innym. Prędkość mówi, ile musi być
     ŚWIATŁA; króciec kotła — jaka ma być ŚREDNICA ZEWNĘTRZNA, bo to ją
     obejmuje złączka. Mieszanie tych miar dawało bzdurę: stal zaciskowa
     22×1,5 odpadała przy 3/4", bo w świetle ma 19 mm, i instalacja
     wychodziła o rozmiar grubsza niż identyczna z miedzi. */
  const minZewn = Math.max(0, Number(minZewnMm) || 0);
  const zSamejPredkosci = list.find(p => pipeInner(p) >= needMm);
  const pick = list.find(p => pipeInner(p) >= needMm && p[1] >= minZewn - 0.01)
    || list[list.length - 1];
  const inner = pipeInner(pick);
  const vAct = Q / (Math.PI * Math.pow(inner / 1000, 2) / 4);
  return { needMm, pick, inner, vAct, tooSmall: inner < needMm,
           zPrzylacza: !!(minZewn > 0 && zSamejPredkosci && zSamejPredkosci[1] < pick[1]) };
}

/* --- Naczynie wzbiorcze przeponowe ---
   Ve = V · n                        przyrost objętości wody przy nagrzaniu
   Vv = max(0,5% · V ; 3 l)          zapas wodny
   Vn = (Ve + Vv) · (pw + 1) / (pw − p0)

   Zapas wodny to woda, która ma zostać w naczyniu nawet po wystygnięciu
   instalacji. Bez niego przy stygnięciu membrana dochodzi do końca i układ
   zasysa powietrze, a naczynie wychodzi za małe. Producenci liczą go
   podobnie: tablica doboru ze znanej mocy, którą dostaliśmy, dorzuca dla
   naczyń poniżej 12 l ryczałt 6–9 l zależny od wysokości instalacji.

   Zwracamy też Vn bez zapasu, żeby było widać, ile ta poprawka zmienia. */
const VV_UDZIAL = 0.005;   /* 0,5% pojemności instalacji */
const VV_MIN = 3;          /* nie mniej niż 3 litry      */

function expansionVessel(volumeL, n, p0, pw, opt) {
  if (!(pw > p0)) return null;
  const o = opt || {};
  const ve = volumeL * n;
  const vv = o.reserve === false ? 0 : Math.max(volumeL * VV_UDZIAL, VV_MIN);
  const wsp = (pw + 1) / (pw - p0);
  const vn = (ve + vv) * wsp;
  const vnBez = ve * wsp;
  return { ve, vv, vn, vnBez, rec: standardVessel(vn), recBez: standardVessel(vnBez) };
}
const VESSELS = [8, 12, 18, 25, 35, 50, 60, 80, 100, 140, 200, 250, 300, 400, 500, 600, 800, 1000];
const standardVessel = vn => VESSELS.find(s => s >= vn) || VESSELS[VESSELS.length - 1];

/* --- Ciśnienie statyczne i napełnienia z wysokości instalacji ---
   10 m słupa wody ≈ 1 bar. Wysokość NIE wchodzi do wysokości
   podnoszenia pompy (obieg zamknięty jest zrównoważony) —
   służy do ciśnienia napełnienia i nastawy naczynia.                  */
function staticPressure(heightM) {
  const stat = heightM / 10;
  return { stat, fill: stat + 0.3, vesselPre: stat + 0.2 };
}

/* --- Dobór grzejnika z tabeli Radson --- */
function radiatorMatches(requiredW, regime, opt) {
  const o = opt || {};

  /* Ograniczenia przychodzą z pól wyboru w interfejsie, a te oddają wartość
     raz jako liczbę, raz jako tekst — „11" z listy typów robiło się liczbą 11
     i nie zgadzało się z tekstem „11" w tabeli, przez co dobór z ograniczeniem
     typu nie znajdował niczego. Dlatego porównujemy po sprowadzeniu do
     wspólnej postaci: wymiary liczbowo, typ tekstowo. */
  const wantH = o.height ? Number(o.height) : null;
  const wantT = (o.type === null || o.type === undefined || o.type === '') ? null : String(o.type);
  const maxL = o.maxLength ? Number(o.maxLength) : null;


  const out = [];
  for (const L of Object.keys(RADSON).map(Number).sort((a, b) => a - b)) {
    if (maxL && L > maxL) continue;
    const row = RADSON[L][regime];
    RADSON_HEIGHTS.forEach((h, hi) => {
      if (wantH && Number(h) !== wantH) return;
      RADSON_TYPES.forEach((t, ti) => {
        if (wantT && String(t) !== wantT) return;
        const w = row[hi * 4 + ti];
        if (w >= requiredW) out.push({ length: L, height: h, type: t, watts: w, margin: (w / requiredW - 1) * 100 });
      });
    });
  }
  out.sort((a, b) => a.watts - b.watts);
  return out;
}

/* --- Grzejnik przy dowolnych parametrach pracy ---
   Tabela Radson ma trzy zestawy: 75/65/20, 70/55/20 i 55/45/20. Kalkulator
   średnic pozwala też na 60/45, 45/35 i 35/28 — dla nich przeliczamy moc
   z 75/65/20 tak, jak robi to norma grzejnikowa PN-EN 442: stosunek
   średnich logarytmicznych różnic temperatur podniesiony do wykładnika
   charakterystyki. Dla płytowych n leży między 1,25 a 1,35; bierzemy 1,3.
   Przeliczenie jest dokładne na tyle, na ile katalog — kilka procent. */
const RAD_N = 1.3;
function dtLog(tz, tp, ti) {
  if (!(tz - ti > 0) || !(tp - ti > 0)) return 0;
  if (Math.abs(tz - tp) < 1e-6) return tz - ti;
  return (tz - tp) / Math.log((tz - ti) / (tp - ti));
}
function radsonPrzelicznik(tz, tp, ti) {
  const klucz = tz + '/' + tp + '/' + ti;
  if (RADSON_REGIMES.indexOf(klucz) >= 0) return { regime: klucz, f: 1 };
  const x = dtLog(tz, tp, ti), ref = dtLog(75, 65, 20);
  if (!(x > 0)) return null;
  return { regime: '75/65/20', f: Math.pow(x / ref, RAD_N) };
}
function mocGrzejnika(typ, h, L, tz, tp, ti) {
  const p = radsonPrzelicznik(tz, tp, ti === undefined ? 20 : ti);
  if (!p || !RADSON[L]) return 0;
  const hi = RADSON_HEIGHTS.indexOf(Number(h)), ki = RADSON_TYPES.indexOf(String(typ));
  if (hi < 0 || ki < 0) return 0;
  return Math.round(RADSON[L][p.regime][hi * 4 + ki] * p.f);
}
/* Wszystkie grzejniki z tabeli, które pokrywają moc, od najsłabszego. */
function grzejnikiNaMoc(req, tz, tp, ti, opt) {
  const o = opt || {};
  const out = [];
  RADSON_LENGTHS.forEach(L => {
    if (o.maxLength && L > o.maxLength) return;
    RADSON_HEIGHTS.forEach(h => {
      if (o.height && h !== Number(o.height)) return;
      RADSON_TYPES.forEach(t => {
        if (o.type && t !== String(o.type)) return;
        const w = mocGrzejnika(t, h, L, tz, tp, ti);
        if (w >= req) out.push({ type: t, height: h, length: L, watts: w, margin: (w / req - 1) * 100 });
      });
    });
  });
  out.sort((a, b) => a.watts - b.watts);
  return out;
}
/* Grzejnik, który aplikacja podpowiada sama. Najczęściej montowany jest
   typ 22 o wysokości 600 mm — pod typowy parapet — więc szukamy najpierw
   jego, potem trzydziestki trójki tej samej wysokości, a dopiero na końcu
   czegokolwiek z tabeli. Bez tej kolejności podpowiedzią bywałby niski
   jedenastka na trzy metry, bo przy danej mocy akurat wychodzi najsłabszy. */
function grzejnikProponowany(req, tz, tp, ti) {
  if (!(req > 0)) return null;
  const all = grzejnikiNaMoc(req, tz, tp, ti, {});
  return all.find(x => x.type === '22' && x.height === 600)
    || all.find(x => x.type === '33' && x.height === 600)
    || all[0] || null;
}
/* Po jednym grzejniku na każdą parę wysokość × typ — najkrótszy, który
   wystarcza. To jest lista do wyboru „inny grzejnik na tę samą moc":
   instalator szuka zwykle innego kształtu, a nie tego samego o 20 cm dłuższego. */
function grzejnikiAlternatywy(req, tz, tp, ti, opt) {
  const o = opt || {};
  const out = [];
  RADSON_HEIGHTS.forEach(h => {
    if (o.height && h !== Number(o.height)) return;
    RADSON_TYPES.forEach(t => {
      const m = grzejnikiNaMoc(req, tz, tp, ti, { height: h, type: t, maxLength: o.maxLength })
        .sort((a, b) => a.length - b.length)[0];
      if (m) out.push(m);
    });
  });
  out.sort((a, b) => a.watts - b.watts);
  return out;
}

/* --- Przepływ obliczeniowy wody (PN-92/B-01706, budynki mieszkalne) ---
   q = 0,682 · (Σqn)^0,45 − 0,14   dla Σqn ≤ 20 l/s
   z zabezpieczeniem: nie mniej niż największy pojedynczy wypływ        */
function waterDesignFlow(sumQn, maxSingle) {
  if (!(sumQn > 0)) return 0;
  const q = 0.682 * Math.pow(sumQn, 0.45) - 0.14;
  return Math.max(q, maxSingle || 0, 0);
}

/* ============================================================
   OGRZEWANIE PODŁOGOWE
   ------------------------------------------------------------
   Ujęcie uproszczone PN-EN 1264. Ciepło idzie z wody przez ściankę rury,
   jastrych i wykładzinę do powierzchni, a stamtąd do pomieszczenia.
   Każda z tych warstw to opór; sumujemy je i dzielimy przez nie różnicę
   temperatur, dostając strumień ciepła w W/m².

   Wpływ rozstawu rur ujmujemy jako dodatkowy opór: im rzadziej ułożone
   rury, tym dłuższa droga ciepła w jastrychu na boki, czyli większy opór.
   ============================================================ */

/* Temperatura powierzchni podłogi przy zadanym strumieniu ciepła */
function ufhSurfaceTemp(q, tIn) {
  if (!(q > 0)) return tIn;
  return tIn + Math.pow(q / UFH_C, 1 / UFH_N);
}
/* Odwrotnie: jaki strumień daje zadana temperatura powierzchni */
function ufhFluxFromSurface(tSurface, tIn) {
  const d = tSurface - tIn;
  return d > 0 ? UFH_C * Math.pow(d, UFH_N) : 0;
}

/* Opory warstw [m²·K/W].
   Rozpraszanie ciepła na boki liczymy inaczej w zależności od systemu:
   • mokry — rura zatopiona w wylewce, więc rozpływ idzie wylewką i zależy
     od jej przewodności oraz od rozstawu rur,
   • suchy — rura leży w metalowym rozpraszaczu, który rozprowadza ciepło
     niemal bez oporu; zostaje opór styku, praktycznie niezależny od rozstawu.
   Wrzucenie płyty OSB do wzoru dla systemu mokrego dałoby wynik kilkukrotnie
   zaniżony, bo OSB nie pełni roli rozpraszacza. */
function ufhResistance(spacingM, pipeOuterM, screedAboveM, lambdaScreed, rCovering, dry) {
  const rAlpha = 1 / ALPHA_FLOOR;
  const rScreed = screedAboveM / lambdaScreed;
  const rSpacing = dry
    ? UFH_DRY_R
    : Math.max(0, (spacingM / (2 * Math.PI * lambdaScreed)) * Math.log(spacingM / (Math.PI * pipeOuterM)));
  return { rAlpha, rScreed, rCovering, rSpacing, dry: !!dry,
           total: rAlpha + rScreed + rCovering + rSpacing };
}

/* Pełne obliczenie pętli podłogowej */
function ufhDesign(p) {
  const qReq = p.area > 0 ? p.loss / p.area : 0;
  const tWaterMean = p.tSupply - p.dt / 2;
  const R = ufhResistance(p.spacing / 100, p.pipeOuter / 1000, p.screed / 1000, p.lambdaScreed, p.rCov, p.dry);

  const qAch = Math.max(0, (tWaterMean - p.tIn) / R.total);
  const tSurface = ufhSurfaceTemp(qAch, p.tIn);

  /* Jaka temperatura zasilania wystarczy, żeby pokryć straty — pozwala
     zejść z parametrami i podnieść sprawność kotła albo pompy ciepła. */
  const tSupplyNeeded = p.tIn + qReq * R.total + p.dt / 2;

  /* Długość rury.

     Rura w podłodze to powierzchnia podzielona przez rozstaw. Do tego
     dochodzi doprowadzenie od rozdzielacza — i tu jest rzecz, którą łatwo
     przeoczyć: doprowadzenie ma KAŻDA pętla z osobna, a nie pomieszczenie
     jako całość. Trzy pętle w salonie to trzy przejścia od szafki i trzy
     powroty, bo każda zaczyna się i kończy na belce.

     Ma to dwie konsekwencje. Metrów do zamówienia jest więcej, niż wynika
     z samego rozstawu, a dopuszczalna długość pętli nie jest dla grzania
     dostępna w całości: najpierw trzeba dojechać do pomieszczenia. Przy
     rozdzielaczu oddalonym o 20 m z setki metrów zostaje na grzanie tylko
     sześćdziesiąt — i to ta liczba decyduje o podziale na pętle. */
  const grzejna = p.spacing > 0 ? p.area / (p.spacing / 100) : 0;
  const dojscie = 2 * Math.max(0, p.lead || 0);
  const naGrzanie = p.maxLoop - dojscie;
  const zaDaleko = !(naGrzanie > 0);

  const loops = zaDaleko
    ? Math.max(1, Math.ceil(grzejna / p.maxLoop))
    : Math.max(1, Math.ceil(grzejna / naGrzanie));
  const loopLength = grzejna / loops + dojscie;
  const pipeLength = grzejna + loops * dojscie;

  /* Przepływ: Q = 0,86 · P / Δt  [l/h] */
  const flowTotal = p.dt > 0 ? 0.86 * p.loss / p.dt : 0;
  const flowLoop = flowTotal / loops;

  const inner = p.pipeOuter - 2 * p.pipeWall;

  /* Nastawą jest przepływ obliczeniowy i nic innego — ta liczba wynika
     z mocy pomieszczenia i z zadanego Δt, i to ona idzie na rotametr.

     Osobno sprawdzamy, czy nie wypada bardzo wolno. Polskie wytyczne
     projektowania podłogówki przyjmują jako założenie wstępne minimalną
     prędkość 0,15 m/s w wężownicy, co dla rury 16×2 daje około 1,0 l/min.
     Poradniki dla instalatorów podają jednak wprost, że mała pętla może
     mieć prawidłowy przepływ poniżej 1 l/min — i mają rację, bo przy
     jednym kilowacie na pomieszczenie bilans jest bilansem.

     Dlatego nie podnosimy nastawy po cichu, tylko ją sygnalizujemy:
     liczba zostaje projektowa, a instalator dostaje uwagę, żeby sprawdzić
     odpowietrzenie i zakres przepływomierza. Decyzja należy do niego —
     to on widzi, jaka wkładka siedzi na belce. */
  const flowMinPetla = przeplywZPredkosci(V_MIN_PETLA_POD, inner);
  const flowNastawa = flowLoop;
  const ponizejMin = flowLoop > 0 && flowLoop < flowMinPetla;

  const f = pipeFriction(flowNastawa / 1000, inner, loopLength, 'multi', WATER_UFH);

  return {
    qReq, qAch, tSurface, tSupplyNeeded, tWaterMean, R,
    pipeLength, loops, loopLength, grzejna, dojscie, zaDaleko,
    flowTotal, flowLoop,
    /* Przepływ, który naprawdę popłynie przez rozdzielacz z tego
       pomieszczenia — z podniesionymi nastawami, nie z samej mocy. */
    flowTotalNastawa: flowNastawa * loops,
    flowMinPetla, flowNastawa, ponizejMin,
    velocity: f.v, dpLoop: f.dp, inner,
    covers: qAch >= qReq,
    surfaceOk: tSurface <= p.tMaxSurface + 0.05,
  };
}

/* ============================================================
   ZAWÓR MIESZAJĄCY — DOBÓR Kvs
   ------------------------------------------------------------
   Kvs to przepustowość zaworu: przepływ w m³/h przy spadku ciśnienia
   1 bar na zaworze, przy w pełni otwartym przelocie.

       Kvs = G / √Δp        [G w m³/h, Δp w bar]
       Δp  = (G / Kvs)²

   Dobór polega na znalezieniu takiego Kvs, żeby przy przepływie
   obliczeniowym obiegu spadek ciśnienia na zaworze mieścił się
   w przedziale ok. 2–10 kPa:

   • za duży zawór (Δp bliskie zeru) — cały skok siłownika mieści się
     w kilku stopniach obrotu, regulacja robi się skokowa i temperatura
     obiegu buja się wokół zadanej,
   • za mały zawór — zawór zjada wysokość podnoszenia pompy i hałasuje.

   Przez zawór mieszający przepływa woda obiegu (strona wtórna) —
   to jej przepływ wchodzi do wzoru, nie przepływ kotła.
   ============================================================ */

/* Typoszereg zaworów obrotowych wg katalogu ESBE VRG131/VRG132.
   Ta sama przepustowość Kvs bywa dostępna w dwóch wielkościach korpusu —
   np. Kvs 4,0 jako DN 15 i jako DN 20. Hydraulicznie to ten sam zawór,
   różni się tylko przyłącze, więc trzymamy obie pozycje. */
const KVS_TABLE = [
  { kvs: 0.4,  sizes: [{ dn: 'DN 15', thread: 'Rp ½"', bore: 16 }] },
  { kvs: 0.63, sizes: [{ dn: 'DN 15', thread: 'Rp ½"', bore: 16 }] },
  { kvs: 1.0,  sizes: [{ dn: 'DN 15', thread: 'Rp ½"', bore: 16 }] },
  { kvs: 1.6,  sizes: [{ dn: 'DN 15', thread: 'Rp ½"', bore: 16 }] },
  { kvs: 2.5,  sizes: [{ dn: 'DN 15', thread: 'Rp ½"', bore: 16 },
                       { dn: 'DN 20', thread: 'Rp ¾"', bore: 20 }] },
  { kvs: 4.0,  sizes: [{ dn: 'DN 15', thread: 'Rp ½"', bore: 16 },
                       { dn: 'DN 20', thread: 'Rp ¾"', bore: 20 }] },
  { kvs: 6.3,  sizes: [{ dn: 'DN 20', thread: 'Rp ¾"', bore: 20 },
                       { dn: 'DN 25', thread: 'Rp 1"', bore: 26 }] },
  { kvs: 10,   sizes: [{ dn: 'DN 25', thread: 'Rp 1"', bore: 26 }] },
  { kvs: 16,   sizes: [{ dn: 'DN 32', thread: 'Rp 1¼"', bore: 32 }] },
  { kvs: 25,   sizes: [{ dn: 'DN 40', thread: 'Rp 1½"', bore: 39 }] },
  { kvs: 40,   sizes: [{ dn: 'DN 50', thread: 'Rp 2"', bore: 51 }] },
];

/* Zalecany spadek ciśnienia na zaworze [bar] — zakres 3–15 kPa podawany
   zgodnie przez ESBE (karta VRG130, „zacienione pole") i AFRISO. */
const DP_VALVE_MIN = 0.03;
const DP_VALVE_MAX = 0.15;

/* Prędkość w przyłączu — to jest nasze własne kryterium pomocnicze,
   katalogi go nie stosują. Służy tylko do podpowiedzi, którą wielkość
   korpusu wybrać przy tej samej wartości Kvs; nie zmienia doboru Kvs. */
const V_VALVE_SOFT = 1.5;

const kvsRequired = (flowM3h, dpBar) => (dpBar > 0 ? flowM3h / Math.sqrt(dpBar) : 0);
const valveDp = (flowM3h, kvs) => (kvs > 0 ? Math.pow(flowM3h / kvs, 2) : 0);
const valveVelocity = (flowM3h, boreMm) =>
  (boreMm > 0 ? (flowM3h / 3600) / (Math.PI * Math.pow(boreMm / 1000, 2) / 4) : 0);

/* Przepływ obiegu z mocy: G = 0,86 · P / Δt  [m³/h przy P w kW] */
const circuitFlow = (kW, dt) => (dt > 0 ? 0.86 * kW / dt : 0);

/* Stosunek mieszania: ile wody musi dać źródło, żeby po zmieszaniu
   z wodą powrotną obiegu uzyskać zadaną temperaturę zasilania.
       G_pierwotny = G_obiegu · (t_zas − t_pow) / (t_źródła − t_pow)      */
function mixingRatio(flowM3h, tSupply, tReturn, tPrimary) {
  const dSec = tSupply - tReturn;
  const dPri = tPrimary - tReturn;
  if (!(dSec > 0) || !(dPri > 0) || tPrimary <= tSupply) return null;
  const share = dSec / dPri;
  return { share, primary: flowM3h * share, recirc: flowM3h * (1 - share) };
}

/* Dobór zaworu mieszającego.

   Metoda odwzorowuje nomogram katalogowy: bierzemy NAJMNIEJSZY zawór,
   przy którym spadek ciśnienia nie przekracza górnej granicy zalecanego
   pola. Najmniejszy, a nie pierwszy lepszy mieszczący się w polu —
   przewymiarowany zawór to najczęstszy błąd doboru: cały skok siłownika
   mieści się wtedy w kilku stopniach obrotu i temperatura obiegu oscyluje.

   Sprawdzenie: przykład z karty ESBE — 25 kW przy Δt 15 °C daje Kvs 4,0.   */
function selectMixingValve(flowM3h, dpMaxBar) {
  if (!(flowM3h > 0) || !(dpMaxBar > 0)) return null;
  const req = kvsRequired(flowM3h, dpMaxBar);

  const idx = KVS_TABLE.findIndex(x => x.kvs >= req);
  const pickIdx = idx >= 0 ? idx : KVS_TABLE.length - 1;
  const entry = KVS_TABLE[pickIdx];
  const dp = valveDp(flowM3h, entry.kvs);

  /* Wielkości korpusu dostępne dla tej przepustowości, z prędkością w każdej.
     Podpowiadamy najmniejszy korpus, w którym woda nie płynie zbyt szybko. */
  const sizes = entry.sizes.map(z => ({ ...z, v: valveVelocity(flowM3h, z.bore) }));
  const pickSize = sizes.find(z => z.v <= V_VALVE_SOFT) || sizes[sizes.length - 1];

  /* Sąsiad o jeden stopień większy — do porównania, gdyby ktoś wolał
     spokojniejszy spadek ciśnienia kosztem dokładności regulacji. */
  const nextEntry = KVS_TABLE[pickIdx + 1];
  const alt = nextEntry
    ? { kvs: nextEntry.kvs, dp: valveDp(flowM3h, nextEntry.kvs), dn: nextEntry.sizes[0].dn }
    : null;

  return {
    required: req, kvs: entry.kvs, dp, sizes, pick: pickSize, alt,
    velocity: pickSize.v,
    belowBand: dp < DP_VALVE_MIN,
    aboveBand: dp > DP_VALVE_MAX,
    fast: pickSize.v > V_VALVE_SOFT,
    overRange: idx < 0,
  };
}


/* ============================================================
   NACZYNIE PRZEPONOWE Z ZNANEJ MOCY (procedura z tablic Reflex)
   ------------------------------------------------------------
   Kolejność działań wzięta wprost z przykładu w materiale źródłowym:
     1. odczyt pojemności dla każdego rodzaju instalacji osobno,
     2. zsumowanie,
     3. mnożnik dla płynu niezamarzającego,
     4. jeżeli wynik < 12 l — dodanie zapasu zależnego od wysokości,
     5. mnożnik dla zaworu bezpieczeństwa 2,5 bar,
     6. odczyt najbliższego większego naczynia z typoszeregu.

   Kolejność ma znaczenie: zapas dla małych naczyń dodawany jest PRZED
   mnożnikiem zaworu, dokładnie tak jak w przykładzie (9,9 + 7 = 16,9;
   16,9 × 1,3 = 22,0 → naczynie 25 l).
   ============================================================ */

/* Odczyt z tablicy z interpolacją liniową między wierszami mocy */
function reflexLookup(kind, height, kW) {
  const col = (REFLEX_VN[kind] || {})[height];
  if (!col || !(kW > 0)) return 0;
  const rows = REFLEX_KW;
  if (kW <= rows[0]) return col[0] * (kW / rows[0]);
  if (kW >= rows[rows.length - 1]) return col[col.length - 1] * (kW / rows[rows.length - 1]);
  for (let i = 1; i < rows.length; i++) {
    if (kW <= rows[i]) {
      const t = (kW - rows[i - 1]) / (rows[i] - rows[i - 1]);
      return col[i - 1] + t * (col[i] - col[i - 1]);
    }
  }
  return 0;
}

const reflexVessel = vn => REFLEX_SERIES.find(s => s >= vn) || REFLEX_SERIES[REFLEX_SERIES.length - 1];

function expansionFromPower(p) {
  const H = REFLEX_HEIGHTS.find(h => h.h === p.height) || REFLEX_HEIGHTS[1];
  const parts = [];

  const vUfh = reflexLookup('podlogowe', H.h, p.kwUfh || 0);
  const vRad = reflexLookup('plytowe', H.h, p.kwRad || 0);
  if (p.kwUfh > 0) parts.push({ label: 'Ogrzewanie podłogowe', kW: p.kwUfh, v: vUfh });
  if (p.kwRad > 0) parts.push({ label: 'Grzejniki płytowe', kW: p.kwRad, v: vRad });
  if (!parts.length) return null;

  const vSum = vUfh + vRad;
  const vFluid = vSum * (p.fluid || 1);
  const small = vFluid < REFLEX_SMALL;
  const vExtra = small ? vFluid + H.extra : vFluid;

  /* Mnożnik zaworu 2,5 bar istnieje tylko dla 4 i 7 m — przy 10 m tablica
     go nie podaje, więc nie zgadujemy i mówimy o tym wprost. */
  const svApplied = p.sv25 && H.sv25 ? H.sv25 : 1;
  const vFinal = vExtra * svApplied;

  return {
    H, parts, vSum, vFluid, small, vExtra, svApplied, vFinal,
    rec: reflexVessel(vFinal),
    svMissing: !!p.sv25 && !H.sv25,
  };
}

/* ============================================================
   INSTALACJA GAZOWA — dobór średnic odcinek po odcinku
   ------------------------------------------------------------
   Gaz dobiera się inaczej niż wodę. Przy wodzie średnica wynika wprost
   z prędkości: bierzemy rurę, w której woda płynie z zadaną prędkością,
   i tyle. Przy gazie prędkość jest tylko sprawdzeniem — decyduje SUMA
   spadków ciśnienia na całej drodze od gazomierza do urządzenia. Dlatego
   nie da się dobrać odcinka w oderwaniu od reszty: ta sama rura będzie
   dobra przy 4 metrach i za cienka przy 25.

   Stąd bierze się kolejność działań:
     1. przeliczenie mocy urządzeń na przepływ gazu: V = Q / Wd,
     2. wstępna średnica każdego odcinka — najmniejsza, w której prędkość
        mieści się w granicy 6 m/s,
     3. policzenie strat na całej drodze do każdego urządzenia,
     4. jeżeli gdziekolwiek przekroczyliśmy dopuszczalny spadek, powiększamy
        o jeden stopień ten odcinek, który zjada najwięcej — i liczymy od nowa.

   Krok czwarty powtarza się, bo długości zastępcze kształtek zależą od
   średnicy. Powiększenie rury zmniejsza opór na długości, ale jednocześnie
   wydłuża zastępczą długość kolanka, więc wyniku nie da się przewidzieć
   jednym przejściem — trzeba przeliczyć.

   Wzór na straty: uproszczony wzór Renouarda dla niskiego ciśnienia

       Δp [mbar] = 23200 · d · L · V^1,82 / D^4,82
       d — gęstość względna gazu [-]     L — długość odcinka [m]
       V — przepływ [m³/h]               D — średnica wewnętrzna [mm]

   Sprawdzenie: DN15 (Ø wewn. 16,1 mm) przy 1,59 m³/h daje 4,93 Pa/m.
   Tablica przepustowości w materiale źródłowym podaje dla tego samego
   przypadku 4,95 Pa/m, a niezależne przeliczenie wzorem Darcy'ego–Weisbacha
   (λ ze Swamee–Jaina, chropowatość stali 0,045 mm, lepkość gazu 15·10⁻⁶ m²/s)
   daje 5,16 Pa/m. Trzy drogi, ten sam rząd wielkości — metoda się trzyma.
   ============================================================ */

/* Przepływ gazu z mocy urządzenia: V = Q / Wd  [m³/h] */
const gasFlow = (kW, wd) => (wd > 0 ? kW / wd : 0);

/* Prędkość gazu w rurze [m/s] */
const gasVelocity = (flowM3h, innerMm) =>
  (innerMm > 0 ? (flowM3h / 3600) / (Math.PI * Math.pow(innerMm / 1000, 2) / 4) : 0);

/* Spadek ciśnienia na odcinku [Pa] — wzór Renouarda, niskie ciśnienie */
function renouard(flowM3h, innerMm, lengthM, d) {
  if (!(flowM3h > 0) || !(innerMm > 0) || !(lengthM > 0)) return 0;
  const mbar = 23200 * d * lengthM * Math.pow(flowM3h, 1.82) / Math.pow(innerMm, 4.82);
  return mbar * 100;   /* mbar → Pa */
}

const GAS_STEEL = () => pipeList('steel');

function gasDesign(p) {
  const pts = (p.points || []).filter(x => x && x.kw > 0);
  if (!pts.length) return null;
  const rury = GAS_STEEL();
  const wd = p.wd || GAS_WD, d = p.d || GAS_D;
  const limit = p.limit || 200;
  const dokl = !!p.dokladnie;
  const dlPod = p.drop === undefined ? GAS_DROP_DEF : Math.max(0, p.drop);

  /* Przepływ na odcinku i: suma urządzeń, które są za nim.
     Pierwszy odcinek — od gazomierza — niesie gaz do wszystkich.
     Jednoczesności nie stosujemy: przy dwóch–trzech urządzeniach w domu
     jednorodzinnym zysk jest żaden, a ryzyko niedowymiarowania realne.
     Tablice jednoczesności zaczynają mieć sens przy budynkach wielorodzinnych
     i tam trzeba ich użyć świadomie, a nie w tle kalkulatora. */
  const flows = pts.map((_, i) => {
    const kW = pts.slice(i).reduce((a, x) => a + x.kw, 0);
    return { kW, V: gasFlow(kW, wd) };
  });

  /* Przepływ przez samo urządzenie — do podejścia, czyli krótkiego odcinka
     od gałęzi głównej do kotła czy kuchenki. To właśnie tę średnicę instalator
     kupuje „pod urządzenie" i liczy się ją dla mocy tego jednego urządzenia,
     a nie dla całej gałęzi. */
  const own = pts.map(x => gasFlow(x.kw, wd));

  /* Najmniejsza rura, w której prędkość mieści się w granicy */
  const zPredkosci = V => {
    const k = rury.findIndex(r => gasVelocity(V, pipeInner(r)) <= GAS_V_MAX);
    return k < 0 ? rury.length - 1 : k;
  };
  const idx = flows.map(f => zPredkosci(f.V));
  const pidx = own.map(zPredkosci);

  /* Średnica gałęzi głównej nie może rosnąć wzdłuż przepływu. Każdy kolejny
     odcinek niesie mniej gazu niż poprzedni, więc rura węższa przy gazomierzu
     niż dalej to instalacja, której nikt by tak nie wykonał — a taki wynik
     potrafi wyjść z samej arytmetyki, jeśli odcinek dalszy jest dłuższy
     i to jego powiększenie najtaniej ratuje bilans ciśnienia. Dlatego po
     każdym powiększeniu podciągamy wszystko, co jest przed nim.
     Podejście też nie może być szersze od gałęzi, która je zasila. */
  const wyrownaj = (gi, pi) => {
    for (let i = pts.length - 2; i >= 0; i--) gi[i] = Math.max(gi[i], gi[i + 1]);
    for (let i = 0; i < pts.length; i++) pi[i] = Math.min(pi[i], gi[i]);
  };
  wyrownaj(idx, pidx);

  const koszt = (V, ri, len, kolanek, ktoryTrojnik) => {
    const inner = pipeInner(rury[ri]);
    const lz = GAS_LZ[ri] || GAS_LZ[0];
    const lRown = dokl ? kolanek * lz.kolano + lz[ktoryTrojnik] + (ktoryTrojnik === 'trojnikO' ? lz.kurek : 0) : 0;
    const lin = renouard(V, inner, len, d);
    const mie = dokl ? renouard(V, inner, lRown, d) : lin * GAS_FIT_PCT;
    return { inner, lRown, lin, mie };
  };

  const policz = (idx, pidx) => {
    const secs = [], pod = [];
    let cum = 0, max = 0, maxAt = 0;
    for (let i = 0; i < pts.length; i++) {
      /* Gałąź główna: gaz mija tu trójnik przelotem, a kolanka wpisuje
         instalator — to jedyna rzecz, którą da się policzyć z rysunku. */
      const k = koszt(flows[i].V, idx[i], Math.max(0, pts[i].len || 0), pts[i].kol || 0, 'trojnikP');
      const wys = -(pts[i].wys || 0) * GAS_H_GAIN;
      const dp = k.lin + k.mie + wys;
      cum += dp;
      secs.push({
        i, nr: i + 1, rura: rury[idx[i]], inner: k.inner, len: Math.max(0, pts[i].len || 0),
        lRown: k.lRown, lin: k.lin, mie: k.mie, wys, dp, cum,
        ile: pts.length - i, kW: flows[i].kW, V: flows[i].V,
        v: gasVelocity(flows[i].V, k.inner),
      });

      /* Podejście: trójnik odgałęzieniem, jedno kolano i kurek odcinający.
         Pionu tu nie liczymy — podejście jest krótkie, a pomijając zysk
         z jego wzniesienia zostajemy po bezpieczniejszej stronie. */
      const kp = koszt(own[i], pidx[i], dlPod, 1, 'trojnikO');
      const dpPod = kp.lin + kp.mie;
      pod.push({
        i, nr: i + 1, rura: rury[pidx[i]], inner: kp.inner, len: dlPod,
        lRown: kp.lRown, lin: kp.lin, mie: kp.mie, dp: dpPod,
        kW: pts[i].kw, V: own[i], v: gasVelocity(own[i], kp.inner),
      });

      /* Droga do urządzenia to gałąź główna do tego punktu PLUS jego podejście.
         Najgorsze urządzenie nie musi być tym ostatnim: kuchenka bliżej
         gazomierza, ale na cieńszym podejściu, potrafi wypaść gorzej. */
      const doUrzadzenia = cum + dpPod;
      if (doUrzadzenia > max) { max = doUrzadzenia; maxAt = i; }
    }
    return { secs, pod, max, maxAt };
  };

  let r = policz(idx, pidx);
  let kroki = 0;

  /* Kiedy spadek przekracza limit, trzeba coś powiększyć — ale nie wystarczy
     powiększyć tego, co zjada najwięcej ciśnienia. Powiększenie odcinka
     dalszego podciąga za sobą wszystko, co jest przed nim (bo gałąź nie może
     zwężać się wstecz), więc potrafi wyjść drożej niż powiększenie odcinka
     przy gazomierzu, który nie ciągnie za sobą niczego.

     Dlatego sprawdzamy każdą możliwość po kolei i wybieramy tę, która mieści
     instalację w limicie najmniejszym kosztem materiału. Kandydatów jest
     najwyżej tyle, ile odcinków plus jedno podejście, a przeliczenie gałęzi
     jest tanie — więc stać nas na sprawdzenie zamiast zgadywania. */
  const koszrur = (gi, pi) => gi.reduce((a, k) => a + k, 0) + pi.reduce((a, k) => a + k, 0);

  while (r.max > limit && kroki < 40) {
    const warianty = [];
    for (let i = 0; i <= r.maxAt; i++) {
      if (idx[i] >= rury.length - 1) continue;
      const gi = idx.slice(), pi = pidx.slice();
      gi[i]++; wyrownaj(gi, pi);
      warianty.push({ gi, pi, wynik: policz(gi, pi) });
    }
    if (pidx[r.maxAt] < idx[r.maxAt]) {
      const gi = idx.slice(), pi = pidx.slice();
      pi[r.maxAt]++; wyrownaj(gi, pi);
      warianty.push({ gi, pi, wynik: policz(gi, pi) });
    }
    if (!warianty.length) break;

    const mieszczace = warianty.filter(w => w.wynik.max <= limit);
    /* Przy równym koszcie materiału wybieramy wariant z większym zapasem
       ciśnienia — bo trasa na budowie zawsze wychodzi dłuższa niż na papierze. */
    const lepszy = (a, b) => {
      const ka = koszrur(a.gi, a.pi), kb = koszrur(b.gi, b.pi);
      if (ka !== kb) return kb < ka ? b : a;
      return b.wynik.max < a.wynik.max ? b : a;
    };
    const wybor = mieszczace.length
      ? mieszczace.reduce(lepszy)
      : warianty.reduce((a, b) => (b.wynik.max < a.wynik.max ? b : a));

    /* Jeżeli żaden wariant nie poprawia wyniku, dalsze kręcenie się nic nie da —
       instalacja jest po prostu za długa i trzeba to powiedzieć wprost. */
    if (!mieszczace.length && wybor.wynik.max >= r.max - 0.01) break;

    for (let i = 0; i < idx.length; i++) { idx[i] = wybor.gi[i]; pidx[i] = wybor.pi[i]; }
    r = wybor.wynik;
    kroki++;
  }

  /* Przycinanie. Powiększanie idzie krok po kroku i nigdy się nie cofa, więc
     potrafi zostawić rurę grubszą, niż trzeba — najczęściej na końcu gałęzi,
     gdzie płynie już mało gazu. Na koniec próbujemy więc zejść z każdym
     elementem o stopień, zaczynając od najdalszego, i zostawiamy zwężenie,
     jeżeli instalacja nadal mieści się w limicie i w granicy prędkości.
     Efekt: gałąź schodzi ze średnicą tam, gdzie naprawdę może. */
  if (r.max <= limit) {
    let zmieniono = true;
    let obrotow = 0;
    while (zmieniono && obrotow++ < 20) {
      zmieniono = false;
      for (let i = pts.length - 1; i >= 0; i--) {
        for (const co of ['pod', 'galaz']) {
          const gi = idx.slice(), pi = pidx.slice();
          if (co === 'pod') { if (pi[i] <= 0) continue; pi[i]--; }
          else {
            if (gi[i] <= 0) continue;
            /* Gałąź nie może zwęzić się poniżej tego, co jest za nią,
               ani poniżej granicy prędkości. */
            if (i < pts.length - 1 && gi[i] - 1 < gi[i + 1]) continue;
            if (gi[i] - 1 < zPredkosci(flows[i].V)) continue;
            gi[i]--;
          }
          if (co === 'pod' && pi[i] < zPredkosci(own[i])) continue;
          wyrownaj(gi, pi);
          const pr = policz(gi, pi);
          if (pr.max <= limit) {
            for (let j = 0; j < idx.length; j++) { idx[j] = gi[j]; pidx[j] = pi[j]; }
            r = pr; zmieniono = true;
          }
        }
      }
    }
  }

  const secs = r.secs;
  const suma = (arr, k) => arr.reduce((a, s) => a + s[k], 0);
  const meter = GAS_METERS.find(m => m[1] >= flows[0].V) || GAS_METERS[GAS_METERS.length - 1];

  return {
    secs, pod: r.pod, max: r.max, maxAt: r.maxAt, limit, kroki, dlPod,
    kWtotal: flows[0].kW, Vtotal: flows[0].V,
    lin: suma(secs, 'lin') + suma(r.pod, 'lin'),
    mie: suma(secs, 'mie') + suma(r.pod, 'mie'),
    wys: suma(secs, 'wys'),
    dlugosc: suma(secs, 'len'),
    lRown: suma(secs, 'lRown') + suma(r.pod, 'lRown'),
    meter,
    ok: r.max <= limit,
    szybkie: secs.filter(s => s.v > GAS_V_MAX).concat(r.pod.filter(s => s.v > GAS_V_MAX)),
    zmiany: secs.filter((s, i) => i > 0 && s.rura[0] !== secs[i - 1].rura[0]),
  };
}


