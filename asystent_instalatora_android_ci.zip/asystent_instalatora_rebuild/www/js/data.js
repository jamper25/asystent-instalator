/* ===== data.js ===== */
/* ============================================================
   BAZA DANYCH APLIKACJI
   Dane pochodzą z materiałów przesłanych przez użytkownika
   (poradnik instalatora) oraz z norm i powszechnie publikowanych
   tablic budowlanych. Każda pozycja ma podane źródło.
   ============================================================ */

/* --- Strefy klimatyczne Polski (PN-EN 12831, załącznik krajowy) --- */
const ZONES = [
  ['I',   -16, 'zachodnia i centralna Polska (m.in. Poznań, Wrocław, Szczecin)'],
  ['II',  -18, 'centralna Polska (m.in. Warszawa, Łódź, Kraków, Gdańsk)'],
  ['III', -20, 'wschodnia i południowa Polska (m.in. Lublin, Rzeszów, Katowice)'],
  ['IV',  -22, 'północno-wschodnia Polska (m.in. Białystok, Suwałki)'],
  ['V',   -24, 'rejon Suwałk i tereny górskie'],
];

/* --- Temperatury obliczeniowe pomieszczeń (PN-EN 12831 / WT) --- */
const ROOM_TEMPS = [
  ['Pokój / salon / sypialnia', 20],
  ['Kuchnia', 20],
  ['Łazienka', 24],
  ['Przedpokój / korytarz', 16],
  ['Klatka schodowa', 12],
  ['Garaż ogrzewany / pom. gospodarcze', 12],
];

/* --- Przewodność cieplna λ [W/(m·K)] — materiały ścienne --- */
const WALL_MATERIALS = [
  ['Cegła pełna ceramiczna', 0.77],
  ['Cegła dziurawka / kratówka', 0.56],
  ['Pustak ceramiczny (poryzowany)', 0.36],
  ['Silikat (bloczek wapienno-piaskowy)', 0.90],
  ['Beton komórkowy 600', 0.19],
  ['Beton komórkowy 500', 0.16],
  ['Beton komórkowy 400', 0.13],
  ['Keramzytobeton', 0.45],
  ['Pustak żużlobetonowy', 0.60],
  ['Beton / żelbet', 1.70],
  ['Drewno (bale)', 0.16],
];

/* --- Przewodność cieplna λ [W/(m·K)] — izolacje --- */
const INSULATIONS = [
  ['Brak ocieplenia', 0],
  ['Styropian EPS biały', 0.040],
  ['Styropian EPS grafitowy', 0.031],
  ['Wełna mineralna', 0.037],
  ['Płyta PIR / PUR', 0.023],
];

/* Opory przejmowania ciepła dla ściany (PN-EN ISO 6946) */
const RSI_WALL = 0.13, RSE_WALL = 0.04;

/* --- Współczynniki U okien i drzwi [W/(m²·K)] — wartości typowe --- */
const WINDOW_TYPES = [
  ['Pojedyncza szyba', 5.0],
  ['Stare okno skrzynkowe / dwie szyby', 2.6],
  ['Dwuszybowe (lata 90. / 2000.)', 1.7],
  ['Dwuszybowe standard', 1.3],
  ['Dwuszybowe nowoczesne (ciepła ramka)', 1.1],
  ['Trójszybowe', 0.8],
  ['Trójszybowe pasywne', 0.6],
];

/* --- Podłogi: U [W/(m²·K)] + współczynnik temperaturowy fx ---
   fx wg uproszczenia PN-EN 12831 (grunt i pom. nieogrzewane) */
const FLOOR_TYPES = [
  ['Nad pomieszczeniem ogrzewanym', 0, 0],
  ['Na gruncie, nieocieplona', 1.00, 0.5],
  ['Na gruncie, ocieplona 5 cm', 0.45, 0.5],
  ['Na gruncie, ocieplona 10 cm', 0.30, 0.5],
  ['Na gruncie, ocieplona 15 cm i więcej', 0.22, 0.5],
  ['Nad piwnicą nieogrzewaną', 0.80, 0.5],
  ['Nad przejazdem / na zewnątrz', 0.45, 1.0],
];

/* --- Stropy / dachy: U + fx --- */
const CEILING_TYPES = [
  ['Pod pomieszczeniem ogrzewanym', 0, 0],
  ['Strop pod poddaszem nieogrzewanym, nieocieplony', 1.20, 0.8],
  ['Strop pod poddaszem, ocieplony 10 cm', 0.35, 0.8],
  ['Strop pod poddaszem, ocieplony 20 cm', 0.18, 0.8],
  ['Dach skośny ocieplony 15 cm', 0.23, 1.0],
  ['Dach skośny ocieplony 20 cm', 0.18, 1.0],
  ['Dach skośny ocieplony 25 cm i więcej', 0.15, 1.0],
  ['Stropodach nieocieplony', 1.10, 1.0],
];

/* --- Wentylacja: efektywna krotność wymian n [1/h] --- */
const VENTILATION = [
  ['Grawitacyjna, stare nieszczelne okna', 1.2],
  ['Grawitacyjna, okna szczelne z nawiewnikami', 0.7],
  ['Grawitacyjna, okna szczelne bez nawiewników', 0.5],
  ['Mechaniczna wywiewna', 0.6],
  ['Mechaniczna z rekuperacją (odzysk 70%)', 0.18],
  ['Mechaniczna z rekuperacją (odzysk 85%)', 0.09],
];

/* Ciepło właściwe powietrza × gęstość ≈ 0,34 Wh/(m³·K) */
const AIR_FACTOR = 0.34;

/* ============================================================
   RURY — wymiary znormalizowane (nazwa, Ø zewn. mm, ścianka mm)
   ============================================================ */
const PIPE_MATERIALS = [
  ['copper', 'Miedź', [
    ['15x1',15,1],['18x1',18,1],['22x1',22,1],['28x1.5',28,1.5],
    ['35x1.5',35,1.5],['42x1.5',42,1.5],['54x2',54,2]]],
  ['steel', 'Stal (gwintowana, DN)', [
    ['DN15 (1/2")',21.3,2.6],['DN20 (3/4")',26.9,2.6],['DN25 (1")',33.7,3.2],
    ['DN32 (1¼")',42.4,3.2],['DN40 (1½")',48.3,3.2],['DN50 (2")',60.3,3.6]]],
  ['press', 'Stal zaciskowa press', [
    ['15x1.2',15,1.2],['18x1.2',18,1.2],['22x1.5',22,1.5],['28x1.5',28,1.5],
    ['35x1.5',35,1.5],['42x1.5',42,1.5],['54x1.5',54,1.5],['76.1x2',76.1,2]]],
  ['multi', 'Wielowarstwowa PE-X/Al', [
    ['16x2',16,2],['20x2',20,2],['26x3',26,3],['32x3',32,3],
    ['40x4',40,4],['50x4.5',50,4.5],['63x6',63,6]]],
  ['pp20', 'Polipropylen PP PN20 (c.o., c.w.u.)', [
    ['20x3.4',20,3.4],['25x4.2',25,4.2],['32x5.4',32,5.4],['40x6.7',40,6.7],
    ['50x8.3',50,8.3],['63x10.5',63,10.5],['75x12.5',75,12.5]]],
  ['pp16', 'Polipropylen PP PN16 (woda zimna)', [
    ['20x2.8',20,2.8],['25x3.5',25,3.5],['32x4.4',32,4.4],['40x5.5',40,5.5],
    ['50x6.9',50,6.9],['63x8.6',63,8.6]]],
];
const pipeList = key => (PIPE_MATERIALS.find(m => m[0] === key) || PIPE_MATERIALS[0])[2];
const pipeInner = p => p[1] - 2 * p[2];
/* pojemność rury [l/m] wyliczana z geometrii: π·d²/4 */
const pipeLitersPerM = p => Math.PI * Math.pow(pipeInner(p) / 1000, 2) / 4 * 1000;

/* ============================================================
   PRZYBORY SANITARNE — wypływy normatywne qn [l/s]
   wg PN-92/B-01706 (instalacje wodociągowe)
   ============================================================ */
const FIXTURES = [
  ['Umywalka', 0.07],
  ['Zlewozmywak', 0.07],
  ['Bidet', 0.07],
  ['Miska ustępowa (płuczka zbiornikowa)', 0.13],
  ['Natrysk / prysznic', 0.15],
  ['Wanna', 0.15],
  ['Zmywarka', 0.15],
  ['Pralka automatyczna', 0.25],
  ['Zawór czerpalny ze złączką do węża', 0.30],
];

/* ============================================================
   TABELE Z PORADNIKA INSTALATORA (materiały użytkownika)
   ============================================================ */

/* Orientacyjne jednostkowe zapotrzebowanie na ciepło [W/m²]
   — koło doborowe Afriso „Moc obiegu grzewczego” */
const TIERS = [
  ['Przed 1970 r.', 'budynek nieocieplony', 120],
  ['Lata 70–80', 'budynek nieocieplony', 100],
  ['Przed 1990 r.', '~5 cm styropianu', 80],
  ['Lata 90', '8–10 cm styropianu', 70],
  ['2000–2010', '~15 cm styropianu', 60],
  ['Po 2010 r.', 'min. 15 cm styropianu, okna dwuszybowe', 50],
  ['Po 2010 r. energooszcz.', 'bardzo dobra izolacja, okna trójszybowe', 40],
];

/* Pojemność wodna instalacji na 1 kW wg rodzaju odbiornika [l/kW] */
const EMITTERS = [
  ['Grzejniki konwektorowe', 6],
  ['Wentylacja (nagrzewnice)', 8],
  ['Grzejniki płytowe', 11],
  ['Grzejniki radiatorowe', 14],
  ['Rozbudowany system rur', 20],
  ['Ogrzewanie podłogowe', 23],
];

/* Multiplikator pojemności wg maks. temperatury zasilania (baza 90 °C) */
const TEMP_MULT = {
  50: 3.03, 55: 2.50, 60: 2.13, 65: 1.82, 70: 1.59, 75: 1.39, 80: 1.23,
  90: 1.00, 95: 0.90, 100: 0.82, 105: 0.75, 110: 0.69, 115: 0.64, 120: 0.59,
};

/* Zawory bezpieczeństwa c.o. (na przykładzie SYR 1915):
   [przyłącze, min. kanał wylotowy mm, moc max @2,5 bar kW, moc max @3,0 bar kW] */
const SV_CO = [
  ['½"', 12, 72, 64], ['¾"', 14, 101, 118], ['1"', 20, 228, 284],
  ['1¼"', 27, 348, 394], ['1½"', 35, 803, 910], ['2"', 42, 892, 1011],
];

/* Zawory bezpieczeństwa c.w.u. (na przykładzie SYR 2115):
   [przyłącze, min. kanał dolotowy mm, opis zakresu, górny limit pojemności l] */
const SV_CWU = [
  ['½"', 12, 'do 200 l', 200], ['¾"', 14, '200–1000 l', 1000],
  ['1"', 20, '1000–5000 l', 5000], ['1¼"', 27, 'pow. 5000 l', null],
];

/* Współczynnik rozszerzalności objętościowej wody (odniesienie ~10 °C)
   — standardowe wartości katalogowe producentów naczyń przeponowych */
const EXPANSION = {
  30: 0.0044, 40: 0.0078, 50: 0.0121, 60: 0.0171,
  70: 0.0228, 80: 0.0290, 90: 0.0359, 95: 0.0396, 100: 0.0435,
};

/* ============================================================
   OGRZEWANIE PODŁOGOWE
   ============================================================ */

/* Pomieszczenia: temperatura wewnętrzna + dopuszczalna temperatura
   powierzchni podłogi. Limity wg PN-EN 1264. */
const UFH_ROOMS = [
  ['Pokój / salon / sypialnia', 20, 29],
  ['Kuchnia', 20, 29],
  ['Łazienka', 24, 33],
  ['Przedpokój / korytarz', 20, 29],
  ['Strefa brzegowa (przy oknach)', 20, 35],
];

/* Opór cieplny warstwy wykończeniowej R [m²·K/W].
   PN-EN 1264 przyjmuje, że wykładzina nadaje się pod podłogówkę
   przy R nie większym niż 0,15. */
const FLOOR_COVERINGS = [
  ['Płytki ceramiczne / gres', 0.010],
  ['Kamień naturalny', 0.020],
  ['Wykładzina PVC / winyl', 0.030],
  ['Panele laminowane 8 mm', 0.060],
  ['Deska warstwowa 14 mm', 0.100],
  ['Parkiet drewniany 22 mm', 0.140],
  ['Wykładzina dywanowa', 0.150],
];

/* Wylewka lub płyta nad rurą: [nazwa, λ W/(m·K), system, typowa grubość mm]
   system 'mokry' — rura zatopiona w wylewce, ciepło rozchodzi się nią na boki
   system 'suchy' — rura w metalowym rozpraszaczu pod płytą; ciepło rozchodzi
                    się blachą, a płyta jest już tylko oporem nad rurą
   Wartości λ są typowe — konkretny produkt potrafi się różnić, sprawdź kartę
   techniczną, zwłaszcza przy wylewkach z dodatkami do ogrzewania podłogowego. */
const SCREED_TYPES = [
  ['Jastrych cementowy', 1.20, 'mokry', 45],
  ['Jastrych cementowy z dodatkiem do podłogówki', 1.40, 'mokry', 45],
  ['Jastrych anhydrytowy (siarczanowapniowy)', 1.60, 'mokry', 40],
  ['Beton', 1.70, 'mokry', 50],
  ['Masa samopoziomująca', 1.40, 'mokry', 35],
  ['Jastrych lekki (keramzyt, perlit)', 0.70, 'mokry', 50],
  ['Płyta gipsowo-włóknowa — system suchy', 0.32, 'suchy', 20],
  ['Suchy jastrych gipsowy — system suchy', 0.29, 'suchy', 25],
  ['Płyta OSB — system suchy', 0.13, 'suchy', 22],
  ['Deska / sklejka — system suchy', 0.15, 'suchy', 20],
];

/* Opór zastępczy systemu suchego: styk rura–rozpraszacz plus rozpływ ciepła
   w blasze. Blacha ma λ rzędu 200, więc rozstaw rur ma tu znikome znaczenie —
   decyduje o nim konstrukcja płyty, nie projektant. Wartość przyjęta
   szacunkowo; dla konkretnego systemu sprawdź tabele producenta. */
const UFH_DRY_R = 0.040;

const UFH_SPACINGS = [10, 15, 20, 25, 30];

/* Rury do podłogówki: [nazwa, Ø zewn. mm, ścianka mm, maks. długość pętli m].
   Maksymalna długość pętli wynika z dopuszczalnych oporów — powyżej niej
   pompa nie wyrobi i pętla grzeje nierówno. */
const UFH_PIPES = [
  ['16x2', 16, 2, 100],
  ['17x2', 17, 2, 120],
  ['20x2', 20, 2, 140],
];

/* Stałe wg PN-EN 1264:
   q = 8,92 · (θF,m − θi)^1,1   — strumień ciepła z powierzchni podłogi */
const UFH_C = 8.92, UFH_N = 1.1;
const ALPHA_FLOOR = 10.8;   // W/(m²·K), przejmowanie ciepła podłoga → pomieszczenie

/* --- Woda w podłogówce (ok. 35 °C) --- */
const WATER_UFH = { rho: 994, nu: 0.72e-6, g: 9.81 };

/* --- Woda: właściwości do obliczeń oporów (ok. 60 °C) --- */
const WATER = { rho: 983, nu: 0.474e-6, g: 9.81 };
/* --- Woda zimna (instalacja wodociągowa, ok. 10 °C) --- */
const WATER_COLD = { rho: 999, nu: 1.31e-6, g: 9.81 };


/* ============================================================
   DOBÓR NACZYNIA PRZEPONOWEGO Z ZNANEJ MOCY (tablice Reflex)
   ------------------------------------------------------------
   Tablica z materiałów zamawiającego: „Dobór naczyń przeponowych —
   instalacja grzewcza o znanej mocy [kW] (nieznanej pojemności)".
   Trzy warianty wysokości statycznej instalacji, każdy z własnym
   ciśnieniem wstępnym i własną dodatkową pojemnością dla małych naczyń.
   Przepisane wprost ze skanu; do aplikacji wzięte dwie kolumny —
   ogrzewanie podłogowe i grzejniki płytowe.
   ============================================================ */
const REFLEX_KW = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, 25, 30, 35, 40, 45, 50, 100];

const REFLEX_HEIGHTS = [
  { h: 4,  p0: 0.7, pStart: 1.0, pValve: 3.0, extra: 6, sv25: 1.19 },
  { h: 7,  p0: 1.0, pStart: 1.3, pValve: 3.0, extra: 7, sv25: 1.30 },
  { h: 10, p0: 1.3, pStart: 1.6, pValve: 3.0, extra: 9, sv25: null },
];

/* Pojemność naczynia Vn [l] w zależności od mocy — wiersze jak w REFLEX_KW */
const REFLEX_VN = {
  podlogowe: {
    4:  [0.4, 0.8, 1.2, 1.5, 2, 3, 3, 3, 4, 4, 6, 8, 15, 17, 20, 23, 26, 29, 57],
    7:  [0.4, 0.9, 1.3, 1.8, 2, 3, 3, 4, 4, 4, 7, 9, 17, 20, 24, 27, 30, 34, 67],
    10: [0.6, 1.1, 1.7, 2.2, 3, 3, 4, 4, 5, 6, 8, 17, 21, 25, 30, 34, 38, 42, 84],
  },
  plytowe: {
    4:  [0.7, 1.3, 2, 2.6, 4, 4, 5, 6, 6, 7, 10, 15, 19, 23, 26, 30, 34, 38, 75],
    7:  [0.8, 1.6, 2.3, 3.1, 4, 5, 5, 6, 7, 8, 12, 18, 22, 27, 31, 36, 40, 44, 89],
    10: [1, 1.9, 2.9, 3.9, 5, 6, 7, 8, 9, 10, 17, 22, 28, 33, 39, 44, 50, 56, 111],
  },
};

/* Współczynniki zwiększające dla płynu niezamarzającego (te same dla
   wszystkich wysokości) */
const REFLEX_FLUIDS = [
  ['Woda', 1.00],
  ['Płyn niezamarzający −15 °C', 1.30],
  ['Płyn niezamarzający −25 °C', 1.45],
  ['Płyn niezamarzający −35 °C', 1.55],
];

/* Typoszereg naczyń Reflex z tej samej tablicy */
const REFLEX_SERIES = [8, 12, 18, 25, 35, 50, 80, 100, 150, 200, 250, 300, 400, 500];

/* Próg, poniżej którego tablica każe dodać zapas pojemności */
const REFLEX_SMALL = 12;

/* Typowe parametry pracy instalacji grzewczej — zasilanie/powrót i wynikające
   z nich Δt. Instalator myśli „siedemdziesiąt na pięćdziesiąt pięć", a nie
   „delta piętnaście", więc lepiej, żeby wybierał parametry, a Δt liczyło się
   samo. Mniej miejsc na pomyłkę i mniej pisania na budowie. */
/* Poniżej tej prędkości przepływ przestaje wynosić pęcherzyki powietrza
   z gałęzi i grzejniki potrafią zapowietrzać się w kółko. Wartość z praktyki
   warsztatowej, nie z normy — oznaczona w karcie jako przyjęcie. */
const V_MIN_CO = 0.15;

/* Przyłącza kotłów: gwint na króćcach i najmniejsza rura, jaką się w ten
   gwint wpina. Odcinek wychodzący z kotła nie może być od niej cieńszy —
   nie da się go tam fizycznie wpiąć bez przewężenia. Stąd bierze się to,
   co widać w projektach: przy kotle rura jest „o rozmiar większa", niż
   wynikałoby z prędkości. Przykład z projektu instalacji przy Dwernickiego:
   2880 W przy Δt 10 K to 0,25 m³/h, czyli w rurze 22 woda płynie 0,24 m/s —
   żadne kryterium prędkości nie każe tam dać 22, a projektant dał, bo taki
   jest króciec kotła.

   Trzecia liczba to minimalna średnica ZEWNĘTRZNA, nie wewnętrzna. Na 3/4"
   idzie rura 22 niezależnie od materiału, choć miedź 22×1 ma w świetle
   20 mm, a stal zaciskowa 22×1,5 tylko 19 — złączka obejmuje rurę
   z zewnątrz. Gdyby liczyć po świetle, ta sama instalacja na stali
   wychodziłaby o rozmiar grubsza niż na miedzi. */
const PRZYLACZA_KOTLA = [
  ['brak', 'Nie ograniczaj', 0],
  ['g12', '1/2"  ·  rura 15', 15],
  ['g34', '3/4"  ·  rura 22', 22],
  ['g1', '1"  ·  rura 28', 28],
  ['g54', '5/4"  ·  rura 35', 35],
  ['g32', '6/4"  ·  rura 42', 42],
];

/* Nitka z rozdzielacza. W praktyce zawsze PE-X 16×2 — i do grzejnika,
   i do kranu — więc nie dobieramy jej średnicy, tylko sprawdzamy prędkość.
   Granica dla c.o. jest niższa niż dla wody: pętla grzewcza pracuje
   bez przerwy, a kran przez kilka minut dziennie. */
/* Nazwy pomieszczeń do podpisania grzejników na rysunku. Krótkie, bo mają
   się zmieścić nad skrzynką grzejnika — nie mylić z listą w stratach ciepła,
   która niesie ze sobą temperatury obliczeniowe i dlatego jest opisowa. */
/* Nazwy pomieszczeń do list z wynikami — grzejniki w średnicach i pokoje
   dopisywane do rozdzielaczy. Wybiera się je z listy, nie wpisuje: na
   budowie, w rękawicach, klikanie jest szybsze od pisania, a nazwy i tak
   powtarzają się w kółko. */
const POMIESZCZENIA = [
  'Salon', 'Pokój', 'Sypialnia', 'Kuchnia', 'Łazienka', 'WC', 'Przedpokój',
  'Korytarz', 'Gabinet', 'Jadalnia', 'Pralnia', 'Kotłownia', 'Garaż', 'Strych', 'Piwnica',
];

/* Nazwy rozdzielaczy. W domu jednorodzinnym rozdzielacze dzieli się
   kondygnacjami, a nie pomieszczeniami — stąd osobna, krótsza lista. */
const ROZDZIELACZE = [
  'Parter', 'Piętro', 'Poddasze', 'Garaż', 'Łazienki', 'Grzejniki', 'Kotłownia',
];

/* Korpusy rozdzielaczy — te dwa rozmiary pokrywają domy jednorodzinne.
   Średnica wewnętrzna belki, nie gwintu przyłączeniowego. */
const ROZDZ_KORPUSY = [['1"', 26.0], ['5/4"', 32.0]];

/* Prędkość w belce rozdzielacza. Powyżej robi się słyszalny szum, a belka
   przestaje równo rozdzielać między obiegi — woda „leci na wprost" do
   ostatnich wyjść zamiast rozkładać się po wszystkich. */
const V_MAX_KORPUS = 0.8;

/* Opory rozdzielacza i przepływomierza — wg karty katalogowej Caleffi (seria
   rozdzielaczy z przepływomierzami). Producent podaje nie spadek, tylko Kv
   przy jednym kilopaskalu: przepływ w l/h, przy którym na elemencie zostaje
   1 kPa. Spadek przy dowolnym innym przepływie liczy się wtedy wprost:
   Δp = (G / Kv)² kPa.

   Zaskoczeniem jest proporcja. Same belki rozdzielacza to przy typowym
   przepływie domowym ułamek kilopaskala — Caleffi w swoim przykładzie
   liczy 0,10 i 0,08 kPa przy 350 l/h i sam pisze, że można je pominąć.
   Naprawdę liczy się zawór z przepływomierzem na pojedynczym obiegu:
   przy 150 l/h to już prawie dwa kilopaskale, czyli więcej niż obie belki
   razem wzięte kilkanaście razy. */
const KV_PRZEPLYWOMIERZ = 110;          /* l/h przy 1 kPa, zawór otwarty */
const KV_BELKA = [                       /* [do ilu wyjść, Kv zasilanie, Kv powrót] */
  [7, 900, 690],
  [12, 1230, 1110],
];

/* Prędkość w pętli podłogowej 16×2. Typowo wychodzi 0,2–0,4 m/s; powyżej
   rosną opory i pompa musi dawać więcej, niż jest sens. */
const V_MAX_PETLA_POD = 0.6;

/* Dolna granica prędkości w pętli podłogowej. Nie bierze się z podziałki
   przyrządu, tylko z samej instalacji: poniżej mniej więcej 0,15 m/s woda
   przestaje porywać ze sobą pęcherzyki powietrza, więc pętli nie da się
   porządnie odpowietrzyć, a przepływomierz pracuje w zakresie, w którym
   nic sensownego nie pokazuje. Wartość przyjmowana w polskich wytycznych
   projektowania ogrzewania podłogowego jako założenie wstępne.

   Dla rury 16×2, czyli 12 mm w świetle, wychodzi z tego około 1,0 l/min —
   i to jest prawdziwe minimum nastawy rotametru, znacznie wyżej niż dolna
   kreska podziałki. Pomieszczenie o małym zapotrzebowaniu dostaje więc
   więcej wody, niż wynikałoby z samej mocy; nadmiar ścina termostat. */
const V_MIN_PETLA_POD = 0.15;

/* Typowe Δt obiegu podłogowego. Mniejsze niż przy grzejnikach, więc przy tej
   samej mocy przepływ wychodzi kilka razy większy — i dlatego rura do
   rozdzielacza podłogówki bywa grubsza, niż się instalatorowi wydaje. */
/* Podziałka rotametru (przepływomierza) na belce rozdzielacza. Typowe
   wkładki mają skalę 0,5–5 l/min; poniżej dolnej kreski pływak nic nie
   pokazuje, powyżej górnej wychodzi poza skalę i pętli po prostu nie da
   się wyregulować. To granice przyrządu, nie fizyki. */
const ROTAMETR_MIN = 0.5;
const ROTAMETR_MAX = 5.0;

/* Spotykane zakresy wkładek przepływomierzy: 0–3, 0–4 i 0–5 l/min.
   Najmniejsza z nich jest najczęstsza, więc nastawa powyżej trzech litrów
   na minutę to sygnał, żeby sprawdzić, co siedzi na belce — a nie błąd
   obliczeń. Przy takim przepływie warto też rozważyć podział pętli:
   kilowat na jeden obieg to już dużo. */
const ROTAMETR_SKALE = [3, 4, 5];
const ROTAMETR_SKALA_MALA = 3;

const DT_PODLOGOWKA = [
  ['5 K  ·  35/30 °C', 5],
  ['7 K  ·  35/28 °C', 7],
  ['10 K  ·  40/30 °C', 10],
];

/* Nitki grubsze od 16 — tyle wystarczy, żeby podpowiedzieć rozmiar
   pod pralkę albo zawór ogrodowy. */
const NITKI_GRUBSZE = [['20x2', 20, 2], ['26x3', 26, 3]];

const NITKA_ROZDZ = ['16x2', 16, 2];

/* Podpisy grzejników na rysunku. Bez nazwy zostaje „Grzejnik 3", a gdy ta
   sama nazwa powtarza się na liście — bo w domu bywają trzy pokoje —
   dostaje numer porządkowy, żeby monter wiedział, który jest który. */
function nazwyGrzejnikow(nazwy, ile) {
  const czyste = [];
  for (let i = 0; i < ile; i++) {
    const n = nazwy && nazwy[i] ? String(nazwy[i]).trim() : '';
    czyste.push(n);
  }
  const ileRazy = {};
  czyste.forEach(n => { if (n) ileRazy[n] = (ileRazy[n] || 0) + 1; });
  const licznik = {};
  return czyste.map((n, i) => {
    if (!n) return 'Grzejnik ' + (i + 1);
    if (ileRazy[n] === 1) return n;
    licznik[n] = (licznik[n] || 0) + 1;
    return n + ' ' + licznik[n];
  });
}

/* Najcieńsza nitka, w której dany wypływ nie przekracza granicy szumu.
   Zwraca null, gdy nawet najgrubsza z listy nie wystarcza. */
function nitkaDoWyplywu(qls, granica) {
  const lim = granica || 2;
  const lista = [NITKA_ROZDZ].concat(NITKI_GRUBSZE);
  return lista.find(p => {
    const di = (p[1] - 2 * p[2]) / 1000;
    return (qls / 1000) / (Math.PI * di * di / 4) <= lim;
  }) || null;
}
const V_MAX_NITKA = 1.0;

/* Polska odmiana po liczebniku: 1 wyjście, 2–4 wyjścia, 5 i więcej wyjść.
   Wyjątek na nastki, bo „22 wyjścia", ale „12 wyjść". */
function odmianaWyjsc(n) {
  const j = n % 10, d = n % 100;
  if (n === 1) return 'wyjście';
  if (j >= 2 && j <= 4 && !(d >= 12 && d <= 14)) return 'wyjścia';
  return 'wyjść';
}

/* Polska odmiana przez liczbę: jeden pokój, dwa pokoje, pięć pokoi.
   Trzy formy, bo inaczej aplikacja pisze „5 grzejniki" i wygląda
   na napisaną przez automat. */
function odmiana(n, jeden, dwa, piec) {
  const j = n % 10, d = n % 100;
  if (n === 1) return jeden;
  if (j >= 2 && j <= 4 && !(d >= 12 && d <= 14)) return dwa;
  return piec;
}

/* Etykiety trzymamy krótkie — w polu wyboru na telefonie dłuższe i tak się
   nie mieszczą i urywają w pół słowa. Opis, do czego który zestaw pasuje,
   jest w podpowiedzi pod kalkulatorem. */
/* [etykieta, Δt, temperatura zasilania] — zasilanie potrzebne do doboru
   mocy wężownicy zasobnika, bo to od niej ta moc zależy najbardziej. */
const REGIMES_CO = [
  ['75/65 °C', 10, 75],
  ['70/55 °C', 15, 70],
  ['60/45 °C', 15, 60],
  ['55/45 °C', 10, 55],
  ['45/35 °C', 10, 45],
  ['35/28 °C', 7, 35],
];

/* ============================================================
   INSTALACJA GAZOWA — dane do doboru średnic
   ------------------------------------------------------------
   Zakres: gaz ziemny wysokometanowy grupy E (dawny GZ-50), instalacja
   niskiego ciśnienia w budynku mieszkalnym, rury stalowe.
   Propan-butan celowo pominięty: ma inną wartość opałową, inną gęstość
   względną, inne ciśnienie zasilania, a człon wysokościowy działa
   w przeciwną stronę (LPG jest cięższy od powietrza, więc w pionie do góry
   ciśnienie SPADA zamiast rosnąć). To nie jest zmiana jednej liczby, tylko
   osobna procedura — dopiszemy ją po potwierdzeniu wartości.
   ============================================================ */

/* Wartość opałowa i gęstość względna gazu E */
const GAS_WD = 9.44;      /* kWh/m³ (≈ 34 MJ/m³) */
const GAS_D = 0.6;        /* gęstość względem powietrza [-] */
const GAS_RHO = 0.75;     /* kg/m³ — tylko do wyliczenia prędkości */

/* Maksymalna prędkość gazu w przewodach instalacji wewnętrznej.
   Wartość powszechnie przyjmowana w polskiej praktyce projektowej
   (K. Bąkowski, „Sieci i instalacje gazowe"). */
const GAS_V_MAX = 6;      /* m/s */

/* Zysk ciśnienia na metr wzniesienia. Gaz ziemny jest lżejszy od powietrza,
   więc płynąc do góry ZYSKUJE ciśnienie — kocioł na poddaszu dostaje bonus,
   a nie karę. Δp_h = g · ΔH · (ρ_powietrza − ρ_gazu) ≈ 9,81 · (1,293 − 0,75). */
const GAS_H_GAIN = 5.4;   /* Pa na metr w górę */

/* Dopuszczalny łączny spadek ciśnienia w instalacji niskiego ciśnienia.
   UWAGA: to wartość z praktyki projektowej, nie z rozporządzenia. Formalną
   granicą jest różnica między ciśnieniem za reduktorem a minimalnym
   ciśnieniem wymaganym przez urządzenie; 150–200 Pa to ta granica
   z zapasem. Oznaczone w karcie weryfikacyjnej jako przyjęcie. */
const GAS_DP_LIMITS = [150, 200];

/* Ryczałt na opory miejscowe, gdy instalator nie chce liczyć kształtek. */
const GAS_FIT_PCT = 0.25;

/* Typowe obciążenia nominalne urządzeń gazowych [kW].
   To wartości katalogowe „środka półki" — jeżeli znasz moc konkretnego
   urządzenia z tabliczki znamionowej, wpisz ją zamiast domyślnej.

   Trzecia pozycja to nazwa skrócona — w tabeli wyników odcinek podpisany jest
   „gazomierz → kuchenka", a pełne nazwy katalogowe nie zmieściłyby się w wierszu. */
const GAS_APPLIANCES = [
  ['Kocioł dwufunkcyjny kondensacyjny', 24, 'kocioł'],
  ['Kocioł jednofunkcyjny c.o.', 20, 'kocioł c.o.'],
  ['Kuchenka gazowa 4-palnikowa', 9, 'kuchenka'],
  ['Przepływowy podgrzewacz c.w.u.', 24, 'podgrzewacz'],
  ['Nagrzewnica gazowa', 20, 'nagrzewnica'],
  ['Promiennik gazowy', 15, 'promiennik'],
  ['Inne urządzenie', 10, 'urządzenie'],
];

/* Domyślna długość podejścia — krótkiego odcinka od gałęzi głównej
   do samego urządzenia. Każde urządzenie ma takie podejście i to właśnie
   jego średnica jest tą, którą instalator faktycznie kupuje pod kocioł
   czy pod kuchenkę. Liczy się je dla mocy TEGO urządzenia, a nie dla
   całej gałęzi. */
const GAS_DROP_DEF = 1.5;

/* Długości zastępcze oporów miejscowych [m] dla rur stalowych.
   Kolejność wierszy odpowiada typoszeregowi PIPE_MATERIALS['steel'],
   czyli DN15, DN20, DN25, DN32, DN40, DN50. Zależą od średnicy, więc
   dopóki nie znamy średnicy, nie znamy i oporów miejscowych — dlatego
   dobór trzeba przeliczyć jeszcze raz po zmianie średnicy. */
const GAS_LZ = [
  /* DN15 */ { kurek: 0.15, kolano: 0.50, trojnikP: 0.40, trojnikO: 0.40 },
  /* DN20 */ { kurek: 0.20, kolano: 1.30, trojnikP: 0.40, trojnikO: 0.90 },
  /* DN25 */ { kurek: 0.30, kolano: 1.30, trojnikP: 0.50, trojnikO: 1.10 },
  /* DN32 */ { kurek: 0.40, kolano: 1.50, trojnikP: 0.60, trojnikO: 1.40 },
  /* DN40 */ { kurek: 0.50, kolano: 1.50, trojnikP: 0.90, trojnikO: 1.90 },
  /* DN50 */ { kurek: 0.60, kolano: 1.70, trojnikP: 1.30, trojnikO: 2.70 },
];

/* Gazomierze miechowe: [oznaczenie, przepływ nominalny Qn, maksymalny Qmax]
   — oba w m³/h. Gazomierz dobiera się do przepływu NOMINALNEGO, nie do
   maksymalnego: Qmax to chwilowy szczyt, którego licznik nie rozsypie,
   a nie przepływ, na którym ma pracować. Przykład z materiału źródłowego
   dobiera przy 4,77 m³/h gazomierz G6, mimo że G4 ma Qmax aż 6 — właśnie
   dlatego, że Qn tego G4 wynosi 4. */
const GAS_METERS = [['G4', 4, 6], ['G6', 6, 10], ['G10', 10, 16], ['G16', 16, 25], ['G25', 25, 40]];

if (typeof module !== 'undefined') module.exports = {
  ZONES, ROOM_TEMPS, WALL_MATERIALS, INSULATIONS, RSI_WALL, RSE_WALL,
  WINDOW_TYPES, FLOOR_TYPES, CEILING_TYPES, VENTILATION, AIR_FACTOR,
  PIPE_MATERIALS, pipeList, pipeInner, pipeLitersPerM, FIXTURES, WATER, WATER_COLD,
  REFLEX_KW, REFLEX_HEIGHTS, REFLEX_VN, REFLEX_FLUIDS, REFLEX_SERIES, REFLEX_SMALL,
  REGIMES_CO, V_MIN_CO, WATER_UFH,
  GAS_WD, GAS_D, GAS_RHO, GAS_V_MAX, GAS_H_GAIN, GAS_DP_LIMITS, GAS_FIT_PCT,
  GAS_APPLIANCES, GAS_LZ, GAS_METERS, GAS_DROP_DEF,
};
