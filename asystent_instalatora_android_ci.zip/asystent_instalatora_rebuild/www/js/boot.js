/* ===== boot.js ===== */
/* Start aplikacji — uruchamiany po wczytaniu wszystkich modułów. */
render(false);

/* Okno „Co nowego" po aktualizacji. Dopiero po pierwszym rysowaniu,
   żeby instalator zobaczył je na tle swojej listy kalkulatorów. */
if (typeof sprawdzNowosci === 'function') sprawdzNowosci();

