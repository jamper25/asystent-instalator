/* ===== dopisz.js ===== */
/* ============================================================
   DOPISYWANIE GRZEJNIKA DO ŚREDNIC
   ------------------------------------------------------------
   Instalator liczy stratę ciepła pomieszczenia, z niej dobiera grzejnik —
   i dotąd musiał tę moc przepisać ręcznie do kalkulatora średnic. Teraz
   pod dobranym grzejnikiem jest guzik, który dopisuje go do listy razem
   z nazwą pomieszczenia. Nazwa jedzie dalej na rysunek poglądowy, więc
   monter dostaje „Grzejnik 2 — Kuchnia, 902 W", a nie sam numer.

   Świadomie nie ma tu żadnego dokumentu ani osobnego ekranu: lista
   grzejników mieszka w samym kalkulatorze średnic, tam gdzie i tak
   musiałaby być wpisana ręcznie.
   ============================================================ */

/* Wynik czekający na dopisanie, kiedy pytamy jeszcze o pomieszczenie. */
state.pytamPokoj = null;
state.pytamRozdz = null;
state.pytamRozdzPokoj = null;

/* Grzejnik dopisujemy do obu systemów naraz: trójnikowego i rozdzielaczowego.
   Lista grzejników z mocami jest ta sama niezależnie od tego, czy poprowadzisz
   je gałęzią, czy nitkami z rozdzielacza — różni się sposób rozprowadzenia,
   a nie to, co wisi na ścianie. Instalator ma wtedy przełączyć zakładkę
   i od razu porównać oba warianty, zamiast wpisywać wszystko drugi raz. */
const TRYBY_CO = ['troj', 'rozdz'];
const trybSrednic = () => state.mode['co_dia'] || 'troj';

function listaGrzejnikow(tryb) {
  const k = vkey('co_dia', tryb || trybSrednic());
  if (!state.values[k]) state.values[k] = {};
  const v = state.values[k];
  if (!Array.isArray(v.rad)) v.rad = [];
  if (!Array.isArray(v.radNazwy)) v.radNazwy = [];
  return v;
}

/* Arkusz wyboru pomieszczenia. Kalkulator grzejnika o pomieszczenie nie
   pyta, bo do samego doboru nie jest potrzebne — do rysunku jest, więc
   pytamy tutaj, raz. Na górze pomieszczenia już wpisane do listy. */
function wyborPokojuHtml(w) {
  const v = listaGrzejnikow();
  /* Na górze to, co już jest na liście — dotknięcie podmienia moc i grzejnik
     w tym wierszu. Niżej pełna lista pomieszczeń: dotknięcie dopisuje nowy
     wiersz, więc drugi pokój czy druga kuchnia to po prostu kolejny wpis,
     a numer („Pokój 2") aplikacja dopisze sama. */
  const wysw = nazwyGrzejnikow(v.radNazwy, v.rad.length);
  const juz = v.rad.map((m, i) => ({ i, m, n: v.radNazwy[i] })).filter(x => x.n && Number(x.m) > 0);
  return `<div class="sheet" data-closepokoj role="dialog" aria-label="Do którego pomieszczenia">
    <div class="sheet-in" data-stop>
      <div class="sheet-h">${svg('home')}<strong>Które pomieszczenie?</strong>
        <button class="item-x" data-closepokoj aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        <p class="hint" style="margin:0 0 10px">Dopisujesz: <b>${esc(w.tytul || '')}</b>
          · zapotrzebowanie ${fmt(w.moc, 0)} W</p>
        ${juz.length ? `<div class="subhead" style="margin-top:0">Podmień na liście</div>`
          + juz.map(x => `<button class="citem" data-pokojidx="${x.i}">
          <span class="citem-t"><strong>${esc(wysw[x.i])}</strong><span>teraz ${fmt(x.m, 0)} W</span></span></button>`).join('')
          + `<div class="subhead">Dopisz jako nowe</div>` : ''}
        ${POMIESZCZENIA.map(x => `<button class="citem" data-pokoj="${esc(x)}">
          <span class="citem-t"><strong>${esc(x)}</strong></span></button>`).join('')}
        <button class="btn2" style="width:100%;margin-top:6px" data-pokoj="">
          Bez nazwy</button>
      </div>
    </div></div>`;
}

/* Dopisanie grzejnika do obu systemów naraz.

   Punktem odniesienia jest lista z systemu, w którym instalator właśnie
   pracuje. Drugi system dostaje to samo, ale nie kasujemy mu tego, co sam
   tam wpisał: jeśli obie listy były zgodne (albo druga pusta), po prostu
   je zrównujemy, a jeśli druga była ręcznie zmieniona, tylko dopisujemy
   do niej grzejnik i zostawiamy resztę jak było.

   Ten sam pokój podmienia poprzednią moc zamiast dokładać drugi wiersz —
   przy poprawianiu doboru w kuchni instalator chce jednej kuchni, a nie
   trzech. */
function dopiszGrzejnik(w, pokoj, idx) {
  const moc = Math.round(w.moc);
  const teraz = trybSrednic();
  const bazaPrzed = JSON.stringify(listaGrzejnikow(teraz).radNazwy);
  const grz = w.grz || null;
  /* Dwa grzejniki w jednym pomieszczeniu: moc zostaje jedna, a obok niej
     podział i wybór drugiego grzejnika. */
  const dziel = w.dziel || null, grz2 = w.grz2 || null;

  /* idx — podmiana konkretnego wiersza; bez niego zawsze nowy wiersz. */
  const wstaw = (v, i) => {
    ['radGrz', 'radGrz2', 'radDziel'].forEach(t => { if (!Array.isArray(v[t])) v[t] = []; });
    const ustaw = j => { v.radGrz[j] = grz; v.radGrz2[j] = grz2; v.radDziel[j] = dziel; };
    if (i >= 0 && i < v.rad.length) { v.rad[i] = moc; ustaw(i); return true; }
    v.rad.push(moc); v.radNazwy.push(pokoj || '');
    ['radGrz', 'radGrz2', 'radDziel'].forEach(t => { while (v[t].length < v.rad.length - 1) v[t].push(null); });
    ustaw(v.rad.length - 1);
    return false;
  };

  const baza = listaGrzejnikow(teraz);
  const podmiana = wstaw(baza, idx == null ? -1 : idx);
  const nazwa = podmiana ? baza.radNazwy[idx] : pokoj;

  TRYBY_CO.filter(t => t !== teraz).forEach(t => {
    const k = vkey('co_dia', t);
    const nietkniety = !state.values[k] || !Array.isArray(state.values[k].rad);
    const v = listaGrzejnikow(t);
    if (nietkniety || JSON.stringify(v.radNazwy) === bazaPrzed) {
      v.rad = baza.rad.slice();
      v.radNazwy = baza.radNazwy.slice();
      v.radGrz = (baza.radGrz || []).slice();
      v.radGrz2 = (baza.radGrz2 || []).slice();
      v.radDziel = (baza.radDziel || []).slice();
    } else {
      wstaw(v, -1);
    }
  });

  saveCalcValues();
  state.pytamPokoj = null;
  state.dopisano = true;
  renderOverlay();
  const ile = baza.rad.length;
  toast(`${podmiana ? 'Zaktualizowano' : 'Dopisano'} ${nazwa || 'grzejnik'} — `
    + `w średnicach c.o. jest ${ile} ${odmiana(ile, 'grzejnik', 'grzejniki', 'grzejników')} `
    + 'w obu systemach.',
    'Policz średnice');
}

/* Przełączenie systemu w „Ogrzewaniu grzejnikowym".

   Grzejniki wiszą na ścianie te same niezależnie od tego, czy poprowadzisz
   je gałęzią trójnikową, czy nitkami z rozdzielacza — zmienia się tylko
   rozprowadzenie. Dlatego przy przełączeniu zakładki lista jedzie z nami:
   instalator dobiera raz, a potem porównuje oba warianty jednym kliknięciem,
   zamiast wpisywać wszystko drugi raz.

   Nie nadpisujemy tego, co w drugim systemie zostało wpisane ręcznie —
   kopiujemy tylko do listy pustej. Kto ma tam własne grzejniki, ten ich
   nie straci. */
function przeniesGrzejniki(zTrybu, naTryb) {
  if (zTrybu === naTryb) return 0;
  const zrodlo = listaGrzejnikow(zTrybu);
  if (!zrodlo.rad.length) return 0;
  const cel = listaGrzejnikow(naTryb);
  if (cel.rad.length) return 0;
  cel.rad = zrodlo.rad.slice();
  cel.radNazwy = zrodlo.radNazwy.slice();
  cel.radGrz = (zrodlo.radGrz || []).slice();
  cel.radGrz2 = (zrodlo.radGrz2 || []).slice();
  cel.radDziel = (zrodlo.radDziel || []).slice();
  saveCalcValues();
  return cel.rad.length;
}

/* Skok do kalkulatora średnic z gotową listą. */
function doSrednicCO() {
  state.mode['co_dia'] = trybSrednic();
  state.tab = 'calc';
  state.screen = 'calc';
  state.calc = 'co_dia';
  render(true);
}

document.addEventListener('click', e => {
  /* Guzik pod dobranym grzejnikiem. */
  if (e.target.closest('[data-doSrednic]')) {
    const w = state.pendingSrednice;
    if (!w || !(w.moc > 0)) return;
    state.pytamPokoj = Object.assign({}, w);
    renderOverlay();
    return;
  }

  /* Wybór pomieszczenia. Pusty atrybut znaczy „bez nazwy", więc sprawdzamy
     istnienie przycisku, a nie prawdziwość wartości. */
  const pokIdx = e.target.closest('[data-pokojidx]');
  if (pokIdx) {
    const w = state.pytamPokoj;
    state.pytamPokoj = null;
    if (!w) { renderOverlay(); return; }
    dopiszGrzejnik(w, '', Number(pokIdx.dataset.pokojidx));
    return;
  }
  const pok = e.target.closest('[data-pokoj]');
  if (pok) {
    const w = state.pytamPokoj;
    state.pytamPokoj = null;
    if (!w) { renderOverlay(); return; }
    dopiszGrzejnik(w, pok.dataset.pokoj || '');
    return;
  }
  if (e.target.closest('[data-closepokoj]')
      && (!e.target.closest('[data-stop]') || e.target.closest('.sheet-h [data-closepokoj]'))) {
    state.pytamPokoj = null; renderOverlay(); return;
  }

  if (e.target.closest('[data-gosrednice]')) { doSrednicCO(); return; }
});

/* ============================================================
   DOPISYWANIE PODŁOGÓWKI DO ROZDZIELACZA
   ------------------------------------------------------------
   Rozdzielacz obsługuje kilka pomieszczeń naraz, więc tutaj nie dokładamy
   wierszy, tylko sumujemy: moc pokoju dolicza się do mocy rozdzielacza,
   a jego pętle do liczby wyjść. Z tej sumy wychodzi potem średnica rury,
   którą trzeba do rozdzielacza dojechać.

   Żeby dało się poprawić jedno pomieszczenie bez liczenia wszystkiego od
   nowa, pamiętamy, ile które wniosło. Drugie dopisanie tego samego pokoju
   podmienia jego wkład zamiast doliczać go po raz drugi.
   ============================================================ */

const KLUCZ_ROZDZ = vkey('rozdz_dia', '_');

function listaRozdzielaczy() {
  if (!state.values[KLUCZ_ROZDZ]) state.values[KLUCZ_ROZDZ] = {};
  const v = state.values[KLUCZ_ROZDZ];
  if (!Array.isArray(v.rozdz)) v.rozdz = [];
  return v;
}

/* Przy pierwszym prawdziwym dopisaniu przykładowe rozdzielacze znikają —
   inaczej pokój o dwóch pętlach dokładałby się do wymyślonych sześciu. */
function listaBezPrzykladow() {
  const v = listaRozdzielaczy();
  v.rozdz = v.rozdz.filter(x => !x.przyklad);
  return v;
}

/* Arkusz wyboru rozdzielacza. Na górze te, które już są w kalkulatorze,
   pod nimi reszta typowych nazw. */
function wyborRozdzielaczaHtml(w) {
  const v = listaRozdzielaczy();
  const znane = v.rozdz.map(r => r.nazwa).filter(Boolean);
  const lista = znane.concat(ROZDZIELACZE.filter(x => znane.indexOf(x) < 0));
  return `<div class="sheet" data-closerozdz role="dialog" aria-label="Do którego rozdzielacza">
    <div class="sheet-in" data-stop>
      <div class="sheet-h">${svg('list')}<strong>Do którego rozdzielacza?</strong>
        <button class="item-x" data-closerozdz aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        <p class="hint" style="margin:0 0 10px">Dopisujesz: <b>${esc(w.tytul || '')}</b>
          · ${fmt(w.moc, 0)} W</p>
        ${lista.map(x => {
          const r = v.rozdz.find(y => y.nazwa === x);
          const pokoje = r ? Object.keys(r.wklady || {}) : [];
          return `<button class="citem" data-rozdzdo="${esc(x)}">
            <span class="citem-t"><strong>${esc(x)}</strong>${r
              ? `<span>już ${fmt((r.w || 0) / 1000, 1)} kW · ${r.wyj || 0} ${odmianaWyjsc(r.wyj || 0)}`
                + (pokoje.length ? '<br>' + esc(pokoje.join(', ')) : '') + '</span>'
              : '<span>nowy rozdzielacz</span>'}</span></button>`;
        }).join('')}
      </div>
    </div></div>`;
}

/* Dopisanie pomieszczenia do rozdzielacza. `wklady` trzyma, ile które
   pomieszczenie wniosło — dzięki temu poprawka nie dubluje mocy. */
function dopiszDoRozdzielacza(w, nazwa) {
  /* Przykładowe rozdzielacze znikają przy pierwszym prawdziwym dopisaniu —
     ale instalator musi się o tym dowiedzieć. Inaczej wygląda to tak, jakby
     aplikacja zgubiła mu „Piętro", które przed chwilą widział na ekranie. */
  const przedPrzyklady = listaRozdzielaczy().rozdz.filter(x => x.przyklad).map(x => x.nazwa);
  const v = listaBezPrzykladow();
  let r = v.rozdz.find(x => x.nazwa === nazwa);
  if (!r) { r = { nazwa, w: 0, wyj: 0, dl: 0, dp: 0, wklady: {} }; v.rozdz.push(r); }
  if (!r.wklady) r.wklady = {};

  /* Wpis rozpoznajemy po pomieszczeniu, a nie po tytule wyniku. Tytuł
     zawiera powierzchnię i liczbę pętli, więc dwa pokoje o tych samych
     wymiarach miały identyczny — i drugi podmieniał pierwszy zamiast się
     dodać. Pomieszczenie jest tym, co instalator ma w głowie, i jedyną
     rzeczą, która naprawdę odróżnia jeden wkład od drugiego. */
  const klucz = w.pomieszczenie || ('bez nazwy ' + (Object.keys(r.wklady).length + 1));
  const stary = r.wklady[klucz];
  const podmiana = !!stary;
  if (stary) {
    r.w = Math.max(0, (Number(r.w) || 0) - stary.moc);
    r.wyj = Math.max(0, (Number(r.wyj) || 0) - stary.petle);
  }
  r.w = Math.round((Number(r.w) || 0) + (Number(w.moc) || 0));
  r.wyj = Math.round((Number(r.wyj) || 0) + (Number(w.petle) || 0));
  r.wklady[klucz] = {
    moc: Number(w.moc) || 0, petle: Number(w.petle) || 0,
    dp: Number(w.dpPetli) || 0, dl: Number(w.dlPetli) || 0,
    m: Number(w.metrow) || 0, rura: w.rura || '',
  };

  /* Opory pętli to jedyna liczba, której nie wolno sumować: pętle wiszą na
     belce równolegle, więc pompa pokonuje najgorszą z nich. Po każdej zmianie
     przeliczamy maksimum z wszystkich dopisanych pomieszczeń od nowa —
     inaczej po skasowaniu najdłuższej pętli zostałaby jej wartość. */
  const wklady = Object.keys(r.wklady).map(k => r.wklady[k]);
  const najgorsza = wklady.reduce((a, x) => Math.max(a, x.dp || 0), 0);
  if (najgorsza > 0) r.dp = Math.round(najgorsza * 10) / 10;
  const najdluzsza = wklady.reduce((a, x) => Math.max(a, x.dl || 0), 0);
  if (najdluzsza > 0) r.dlPetli = Math.round(najdluzsza);

  /* Metry sumujemy — to jedyna liczba, która naprawdę się dodaje, bo rurę
     kupuje się na bieżące. Rozmiary zbieramy osobno: jeśli ktoś w łazience
     dał inną rurę niż w salonie, hurtownia musi o tym wiedzieć. */
  r.metrow = Math.round(wklady.reduce((a, x) => a + (x.m || 0), 0));
  const rury = [];
  wklady.forEach(x => { if (x.rura && rury.indexOf(x.rura) < 0) rury.push(x.rura); });
  r.rury = rury;

  saveCalcValues();
  state.pytamRozdz = null;
  state.dopisanoRozdz = true;
  renderOverlay();
  toast(`${podmiana ? 'Zaktualizowano ' + klucz + ' na rozdzielaczu' : 'Dopisano ' + klucz + ' do rozdzielacza'} ${nazwa} — `
    + `razem ${fmt(r.w / 1000, 1)} kW i ${r.wyj} ${odmianaWyjsc(r.wyj)}`
    + (r.metrow > 0 ? `, ${fmt(r.metrow, 0)} m rury` : '')
    + (r.dp > 0 ? `, najgorsza pętla ${fmt(r.dp, 1)} kPa.` : '.')
    + (przedPrzyklady.length
      ? ' Zniknęły przykładowe rozdzielacze: ' + przedPrzyklady.join(', ') + '.'
      : ''),
    'Dobierz średnicę');
}

function doRozdzielaczy() {
  state.tab = 'calc';
  state.screen = 'calc';
  state.calc = 'rozdz_dia';
  render(true);
}

/* Podłogówka idzie do rozdzielacza w dwóch krokach: najpierw pomieszczenie,
   potem rozdzielacz. Pomieszczenia nie da się pominąć, bo to ono decyduje,
   czy wynik dokłada się do rozdzielacza, czy podmienia wcześniejszy wpis. */
function dalejDoRozdzielacza(w) {
  if (!w) return;
  /* Pytamy raz. Pusta nazwa to świadomy wybór „bez nazwy", a nie brak
     odpowiedzi — bez tego rozróżnienia arkusz wracałby w kółko. */
  if (!w.pytano) {
    state.pytamRozdzPokoj = w; state.pytamRozdz = null; renderOverlay(); return;
  }
  state.pytamRozdzPokoj = null;
  state.pytamRozdz = w;
  renderOverlay();
}

/* Arkusz pomieszczeń dla podłogówki. Na górze te, które są już na
   rozdzielaczach — żeby poprawka trafiła tam, gdzie powinna. */
function wyborPokojuRozdzHtml(w) {
  const v = listaRozdzielaczy();
  const znane = [];
  v.rozdz.forEach(r => Object.keys(r.wklady || {}).forEach(k => {
    if (znane.indexOf(k) < 0) znane.push(k);
  }));
  const lista = znane.concat(POMIESZCZENIA.filter(x => znane.indexOf(x) < 0));
  return `<div class="sheet" data-closerozdzpokoj role="dialog" aria-label="Które pomieszczenie">
    <div class="sheet-in" data-stop>
      <div class="sheet-h">${svg('home')}<strong>Które pomieszczenie?</strong>
        <button class="item-x" data-closerozdzpokoj aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        <p class="hint" style="margin:0 0 10px">Dopisujesz: <b>${esc(w.tytul || '')}</b>
          · ${fmt(w.moc, 0)} W</p>
        ${lista.map(x => `<button class="citem" data-rozdzpokoj="${esc(x)}">
          <span class="citem-t"><strong>${esc(x)}</strong>${znane.indexOf(x) >= 0
            ? '<span>już na rozdzielaczu — poprawi wcześniejszy wpis</span>' : ''}</span></button>`).join('')}
        <button class="btn2" style="width:100%;margin-top:6px" data-rozdzpokoj="">
          Bez nazwy — dopisz osobno</button>
      </div>
    </div></div>`;
}

document.addEventListener('click', e => {
  if (e.target.closest('[data-doRozdz]')) {
    const w = state.pendingRozdz;
    if (!w || !(w.moc > 0)) return;
    dalejDoRozdzielacza(Object.assign({}, w));
    return;
  }

  const rpok = e.target.closest('[data-rozdzpokoj]');
  if (rpok) {
    const w = state.pytamRozdzPokoj;
    state.pytamRozdzPokoj = null;
    if (!w) { renderOverlay(); return; }
    w.pomieszczenie = rpok.dataset.rozdzpokoj || '';
    w.pytano = true;
    dalejDoRozdzielacza(w);
    return;
  }
  if (e.target.closest('[data-closerozdzpokoj]')
      && (!e.target.closest('[data-stop]') || e.target.closest('.sheet-h [data-closerozdzpokoj]'))) {
    state.pytamRozdzPokoj = null; renderOverlay();
    /* Zamknięcie arkusza to też odpowiedź — tyle że odmowna. Bez słowa
       wygląda jak zacięcie: instalator klika „Dopisz", trafia obok listy,
       arkusz znika i nic się nie dzieje. Potem szuka pętli w rozdzielaczu
       i jej tam nie ma. */
    toast('Nie dopisano — wybierz pomieszczenie z listy albo „Bez nazwy".');
    return;
  }
  const doR = e.target.closest('[data-rozdzdo]');
  if (doR) {
    const w = state.pytamRozdz;
    state.pytamRozdz = null;
    if (!w) { renderOverlay(); return; }
    dopiszDoRozdzielacza(w, doR.dataset.rozdzdo);
    return;
  }
  if (e.target.closest('[data-closerozdz]')
      && (!e.target.closest('[data-stop]') || e.target.closest('.sheet-h [data-closerozdz]'))) {
    state.pytamRozdz = null; renderOverlay();
    toast('Nie dopisano — trzeba wskazać rozdzielacz z listy.');
    return;
  }
});

/* ---------- najpierw zapotrzebowanie ----------
   Dobór grzejnika i ogrzewanie podłogowe otwarte z menu zaczynają się od
   pytania o zapotrzebowanie: najlepiej policzyć je w „Stracie ciepła
   pomieszczenia”, skąd wynik przechodzi tu jednym guzikiem. */
state.pytajStrate = null;
let STRATA_PRZEPUSC = false;
const STRATA_CEL = { radiator: 'Dobór grzejnika', ufh: 'Ogrzewanie podłogowe' };

/* Kto zna tę drogę na pamięć, zaznacza „nie pokazuj” i wchodzi prosto
   w kalkulator. Wybór pamięta telefon; wraca go włączyć w Ustawieniach,
   gdzie wiersz pojawia się dopiero po wyłączeniu pytania. */
const STRATA_KEY = 'ai_strata_pytaj_v1';
function strataPytac() {
  try { return localStorage.getItem(STRATA_KEY) !== 'nie'; } catch (e) { return true; }
}
function strataUstawPytanie(pytac) {
  try { localStorage.setItem(STRATA_KEY, pytac ? 'tak' : 'nie'); } catch (e) { /* bez zapisu pytamy dalej */ }
}
function strataPytanieHtml(id) {
  return `<div class="sheet" data-strataz role="dialog" aria-label="Zapotrzebowanie na ciepło">
    <div class="sheet-in" data-stop>
      <div class="sheet-h">${svg('wall')}<strong>Najpierw zapotrzebowanie</strong>
        <button class="item-x" data-strataz aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        <p class="hint" style="margin:0 0 12px">${id === 'radiator' ? 'Grzejnik' : 'Podłogówkę'} dobiera się do straty ciepła pomieszczenia. Policz ją najpierw — wynik przejdzie do „${esc(STRATA_CEL[id])}” jednym guzikiem pod wynikiem.</p>
        <label class="strata-nie"><input type="checkbox" data-stratanie${strataPytac() ? '' : ' checked'}>
          <span>Nie pokazuj następnym razem</span></label>
        <button class="jump" style="--c:#C2410C;margin-bottom:8px" data-strata="licz">${svg('wall')}Policz stratę ciepła pomieszczenia</button>
        <button class="btn2" style="width:100%" data-strata="dalej" data-stratacel="${id}">${svg('arrow')}Znam zapotrzebowanie — wpiszę sam</button>
      </div></div></div>`;
}
const _renderOverlayStrata = renderOverlay;
renderOverlay = function () {
  const el = document.getElementById('overlay');
  if (state.pytajStrate && el) { el.innerHTML = strataPytanieHtml(state.pytajStrate); return; }
  return _renderOverlayStrata();
};
document.addEventListener('click', e => {
  if (!e.target.closest) return;
  /* Fasolka działa od razu — bez niej trzeba by zgadywać, czy zdążyła
     zadziałać przed zamknięciem arkusza. */
  const chk = e.target.closest('[data-stratanie]');
  if (chk) { strataUstawPytanie(!chk.checked); return; }
  const b = e.target.closest('[data-strata]');
  if (b && state.pytajStrate) {
    const id = state.pytajStrate;
    state.pytajStrate = null; renderOverlay();
    if (b.dataset.strata === 'licz') {
      state.tab = 'calc'; state.calc = 'heat_loss'; state.screen = 'calc'; state.gasWarn = false;
      render(true);
      toast('Policz stratę ciepła pomieszczenia, a pod wynikiem kliknij „' + (id === 'radiator' ? 'Dobierz grzejnik' : 'Zaprojektuj ogrzewanie podłogowe') + '”.');
    } else {
      const t = document.querySelector('[data-calc="' + id + '"]');
      STRATA_PRZEPUSC = true;
      if (t) t.click(); else { state.tab = 'calc'; state.calc = id; state.screen = 'calc'; render(true); }
      STRATA_PRZEPUSC = false;
    }
    return;
  }
  if (state.pytajStrate && e.target.closest('[data-strataz]') && (!e.target.closest('[data-stop]') || e.target.closest('.sheet-h [data-strataz]'))) {
    state.pytajStrate = null; renderOverlay(); return;
  }
  // kafelek w menu kalkulatorów
  const tile = e.target.closest('[data-calc]');
  if (!tile || tile.hasAttribute('data-projdo') || STRATA_PRZEPUSC || !STRATA_CEL[tile.dataset.calc]) return;
  if (!strataPytac()) return;
  e.stopPropagation(); e.preventDefault();
  state.pytajStrate = tile.dataset.calc; renderOverlay();
}, true);

/* Droga powrotna: wiersz w Ustawieniach pokazuje się dopiero wtedy, gdy
   pytanie jest wyłączone — inaczej byłby to kolejny punkt do przewinięcia
   dla kogoś, kto nigdy go nie potrzebował. */
const _renderSettingsStrata = renderSettingsMain;
renderSettingsMain = function () {
  const h = _renderSettingsStrata();
  if (strataPytac()) return h;
  const wiersz = '<button class="mrow" data-stratawroc>'
    + '<span class="mrow-i">' + svg('wall') + '</span>'
    + '<span class="mrow-t"><strong>Pytanie o zapotrzebowanie — wyłączone</strong>'
    + '<span>Dobór grzejnika i podłogówka otwierają się od razu. Dotknij, żeby pytanie wróciło</span></span>'
    + svg('chev') + '</button>';
  return h.replace('</div>\n\n      ', wiersz + '</div>\n\n      ');
};
document.addEventListener('click', e => {
  if (!e.target.closest || !e.target.closest('[data-stratawroc]')) return;
  strataUstawPytanie(true); render(false);
  toast('Pytanie o zapotrzebowanie wróciło.');
});

