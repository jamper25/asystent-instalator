/* ===== natywne.js ===== */
/* ============================================================
   WARSTWA NATYWNA — most między aplikacją a telefonem
   ------------------------------------------------------------
   Ten sam kod działa w trzech miejscach: w przeglądarce na komputerze,
   w pliku HTML otwartym z dysku i w aplikacji zainstalowanej na telefonie.
   Różnią się tylko sposobem zapisu pliku i udostępniania, więc te dwie
   rzeczy przechodzą przez jedno miejsce — tutaj.

   Wtyczek nie importujemy pakietami, tylko sięgamy po nie przez
   window.Capacitor.Plugins. Dzięki temu cała aplikacja zostaje jednym
   plikiem HTML, bez narzędzi budujących, i nadal otwiera się z dysku.
   ============================================================ */

const CAP = () => (typeof window !== 'undefined' && window.Capacitor) || null;

/* Czy działamy jako zainstalowana aplikacja, a nie w przeglądarce. */
function naTelefonie() {
  const c = CAP();
  try { return !!(c && c.isNativePlatform && c.isNativePlatform()); } catch (e) { return false; }
}

/* Wtyczka albo null. Sprawdzamy obecność, bo projekt może być zbudowany
   bez którejś z nich, a aplikacja ma wtedy działać dalej, tylko gorzej. */
function wtyczka(nazwa) {
  const c = CAP();
  const p = c && c.Plugins && c.Plugins[nazwa];
  return p || null;
}

/* Zapis pliku w pamięci telefonu i od razu okno udostępniania.
   Katalog Documents jest widoczny w menedżerze plików, więc użytkownik
   znajdzie swoje oferty i faktury także po zamknięciu aplikacji. */
function zapiszNaTelefonie(nazwa, tresc, mime, gotowe) {
  const fs = wtyczka('Filesystem');
  const share = wtyczka('Share');
  if (!fs) { gotowe({ ok: false, powod: 'Brak dostępu do plików w tej wersji aplikacji.' }); return; }

  fs.writeFile({ path: nazwa, data: tresc, directory: 'DOCUMENTS', encoding: 'utf8', recursive: true })
    .then(() => fs.getUri({ path: nazwa, directory: 'DOCUMENTS' }))
    .then(r => {
      if (!share) { gotowe({ ok: true, gdzie: 'Dokumenty' }); return null; }
      /* Okno udostępniania pozwala wysłać plik od razu na WhatsAppa albo
         mailem — bez szukania go w menedżerze plików. Anulowanie
         udostępniania nie jest błędem: plik i tak został zapisany. */
      return share.share({ title: nazwa, url: r.uri, dialogTitle: 'Wyślij ' + nazwa })
        .then(() => gotowe({ ok: true, gdzie: 'Dokumenty' }))
        .catch(() => gotowe({ ok: true, gdzie: 'Dokumenty' }));
    })
    .catch(e => gotowe({ ok: false, powod: 'Nie udało się zapisać pliku: ' + (e && e.message ? e.message : 'błąd zapisu') }));
}

/* Zapis gotowego pliku PDF i wysłanie go dalej.
   ------------------------------------------------------------
   PDF to nie tekst, tylko bajty, więc wtyczka dostaje je w base64
   i bez podanego kodowania — wtedy zapisuje plik dosłownie, bajt
   w bajt, zamiast próbować go traktować jak napis.

   Udostępniamy przez `files`, a nie przez `url`: tylko lista plików
   każe Androidowi podpiąć dokument jako prawdziwy załącznik. Przy
   `url` poczta dostaje co najwyżej ścieżkę w treści wiadomości. */
function wyslijPdfZTelefonu(nazwa, daneB64, opis, gotowe) {
  const fs = wtyczka('Filesystem');
  const share = wtyczka('Share');
  if (!fs) { gotowe({ ok: false, powod: 'Brak dostępu do plików w tej wersji aplikacji.' }); return; }

  fs.writeFile({ path: nazwa, data: daneB64, directory: 'DOCUMENTS', recursive: true })
    .then(() => fs.getUri({ path: nazwa, directory: 'DOCUMENTS' }))
    .then(r => {
      if (!share) { gotowe({ ok: true, gdzie: 'Dokumenty' }); return null; }
      return share.share({
        title: (opis && opis.temat) || nazwa,
        text: (opis && opis.tresc) || '',
        files: [r.uri],
        dialogTitle: (opis && opis.okno) || ('Wyślij ' + nazwa),
      })
        /* Anulowanie okna udostępniania nie jest błędem — plik i tak leży
           w Dokumentach i użytkownik może wysłać go później. */
        .then(() => gotowe({ ok: true, wyslane: true, gdzie: 'Dokumenty' }))
        .catch(() => gotowe({ ok: true, gdzie: 'Dokumenty' }));
    })
    .catch(e => gotowe({ ok: false, powod: 'Nie udało się zapisać pliku: ' + (e && e.message ? e.message : 'błąd zapisu') }));
}


