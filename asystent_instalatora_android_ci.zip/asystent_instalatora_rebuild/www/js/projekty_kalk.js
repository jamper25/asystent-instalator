/* ===== projekty_kalk.js ===== */
/* ============================================================
   ZESTAWIENIE Z KALKULATORÓW: GRZEJNIKI I PODŁOGÓWKA
   ------------------------------------------------------------
   Z listy grzejników (z typem i wymiarem, jeśli dobrany) i z listy
   rozdzielaczy podłogówki (obwody, metry rury, mieszacze, pompy).
   ============================================================ */
/* --- zestawienie do oferty --- */
function projZestawienieKalk(c, mode, v, res) {
  const L = [];
  const dodaj = (name, qty, o) => { if (qty > 0) L.push(Object.assign({ name, qty, unit: 'szt', cat: 'mat', tag: null, wzor: null, wyl: false }, o || {})); };
  const grupuj = (m, n, o) => { if (!m[n]) m[n] = Object.assign({ qty: 0 }, o || {}); m[n].qty++; };

  if (projTyp(c) === 'grz') {
    const r = typeof rozwinPodzial === 'function' ? rozwinPodzial(v) : v;
    const m = {};
    let n = 0;
    (r.rad || []).forEach((moc, i) => {
      if (!(Number(moc) > 0)) return;
      n++;
      const nm = (r.radNazwy || [])[i] || '';
      const st = typeof grzStan === 'function' ? grzStan(r, 'rad', i, Number(moc), nm, 0) : {};
      const g = st && st.g;
      if (g && g.drab) grupuj(m, 'Grzejnik łazienkowy ' + drabinkaKrotko(g) + ' mm', { tag: 'grzejnik', wzor: /drabin|łazienk/i });
      else if (g) grupuj(m, 'Grzejnik płytowy typ ' + g.type + ' ' + g.height + '×' + g.length + ' mm',
        { tag: 'grzejnik', wzor: new RegExp('typ ' + g.type + '\\D+' + g.height + ' ?[x×] ?' + g.length + '\\b', 'i') });
      else grupuj(m, 'Grzejnik ' + fmt(Number(moc), 0) + ' W' + (nm ? ' — ' + nm : '') + ' (do doboru)', {});
    });
    Object.keys(m).forEach(k => dodaj(k, m[k].qty, { tag: m[k].tag || null, wzor: m[k].wzor || null }));
    dodaj('Zawór termostatyczny z głowicą', n, { unit: 'kpl', tag: 'zawor_term' });
    dodaj('Zawór powrotny odcinający', n, { tag: 'zawor_odc' });
    dodaj('Zestaw przyłączeniowy grzejnika', n, { unit: 'kpl', tag: 'zestaw_grz' });
    if (mode === 'rozdz') dodaj('Rozdzielacz c.o. ' + n + '-obwodowy z szafką', 1, { unit: 'kpl', tag: 'rozdzielacz' });
    dodaj('Montaż grzejnika z podłączeniem', n, { cat: 'rob', tag: 'montaz_grz', wyl: true });
  } else {
    const l = (v.rozdz || []).filter(r => Number(r.w) > 0);
    const rozd = {}, rury = {};
    l.forEach(r => {
      grupuj(rozd, 'Rozdzielacz podłogowy ' + (Number(r.wyj) || '?') + '-obwodowy z przepływomierzami i szafką');
      const mb = Number(r.metrow) || 0;
      if (mb > 0) {
        const nz = 'Rura do ogrzewania podłogowego' + ((r.rury || []).length === 1 ? ' ' + r.rury[0] : '');
        rury[nz] = (rury[nz] || 0) + mb;
      }
    });
    Object.keys(rozd).forEach(k => dodaj(k, rozd[k].qty, { unit: 'kpl', tag: 'rozdzielacz' }));
    Object.keys(rury).forEach(k => dodaj(k, Math.ceil(rury[k] * 1.05), { unit: 'mb', opis: 'z zapasem 5%' }));
    const zw = {}, pm = {};
    ((res && res.results) || []).forEach(x => {
      if (/^Zawór mieszający/.test(x.label)) { const n = x.value + ' ' + String(x.unit || '').replace(' ', ''); zw[n] = (zw[n] || 0) + 1; }
      if (/^Pompa obiegowa/.test(x.label)) pm[x.value] = (pm[x.value] || 0) + 1;
    });
    let ileZ = 0;
    Object.keys(zw).forEach(n => { dodaj('Zawór mieszający 3-drogowy ' + n + ' z siłownikiem', zw[n]); ileZ += zw[n]; });
    Object.keys(pm).forEach(c => dodaj('Pompa obiegowa elektroniczna ' + c, pm[c], { tag: 'pompa' }));
    dodaj('Termostat bezpieczeństwa (STB) podłogówki', ileZ);
    dodaj('Montaż rozdzielacza z szafką', l.length, { cat: 'rob', wyl: true });
    const mbAll = Object.keys(rury).reduce((a, k) => a + rury[k], 0);
    if (mbAll > 0) dodaj('Ułożenie pętli ogrzewania podłogowego', Math.ceil(mbAll), { cat: 'rob', unit: 'mb', wyl: true });
  }
  dodaj('Próba szczelności instalacji', 1, { cat: 'rob', unit: 'kpl', tag: 'proba', wyl: true });
  dodaj('Uruchomienie i regulacja instalacji', 1, { cat: 'rob', unit: 'kpl', tag: 'uruchomienie', wyl: true });
  return projCeny(L);
}

/* ============================================================
   ZESTAWIENIE MATERIAŁÓW PROSTO Z KALKULATORA → OFERTA
   ------------------------------------------------------------
   Pod wynikiem „Ogrzewania grzejnikowego” i „Ogrzewania podłogowego”
   jest guzik, który otwiera zestawienie proponowanych materiałów.
   Zaznaczasz, co bierzesz, poprawiasz ilości — i dopiero wtedy
   pozycje idą do oferty. Grzejniki: same grzejniki zaznaczone,
   armatura i robocizna do dobrania. Podłogówka: rury, grupy pompowe
   (mieszacz Kvs + pompa) i rozdzielacze na daną liczbę obwodów.
   ============================================================ */
const KZ_KALK = { co_dia: 'grz', rozdz_dia: 'podl' };
state.kalkZest = null;     // { calc, lista: [...], wyb: [...] }

/* Mieszacz i pompa tego samego rozdzielacza to jedna grupa pompowa. */
function kzGrupyPompowe(res) {
  const R = (res && res.results) || [];
  const sufiks = l => { const i = l.indexOf(' — '); return i < 0 ? '' : l.slice(i + 3); };
  const zaw = R.filter(x => /^Zawór mieszający/.test(x.label)), pom = R.filter(x => /^Pompa obiegowa/.test(x.label));
  const m = {};
  const dodaj = (n, gdzie) => { if (!m[n]) m[n] = { qty: 0, gdzie: [] }; m[n].qty++; if (gdzie) m[n].gdzie.push(gdzie); };
  if (zaw.length) {
    zaw.forEach(z => {
      const s = sufiks(z.label);
      const wsp = /wspólny/.test(s);
      const p = pom.find(x => sufiks(x.label) === s) || (wsp ? pom.find(x => /jedna/.test(x.label)) : null) || (pom.length === 1 ? pom[0] : null);
      dodaj('Grupa pompowa z zaworem mieszającym ' + z.value + ' ' + String(z.unit || '').replace(' ', '') + (p ? ' i pompą ' + p.value : ''), wsp ? 'w kotłowni' : s);
    });
  } else pom.forEach(p => dodaj('Grupa pompowa bez mieszacza z pompą ' + p.value, sufiks(p.label)));
  return Object.keys(m).map(n => ({ name: n, opis: m[n].gdzie.join(', '), qty: m[n].qty, unit: 'kpl', cat: 'mat', tag: null }));
}

function kalkZestawienie(calcId) {
  const calc = CALCS.find(c => c.id === calcId), mode = activeMode(calc), v = getValues(calc, mode);
  let res; try { res = mode.compute(JSON.parse(JSON.stringify(v))); } catch (e) { res = { error: true }; }
  if (res.error) return [];
  const L = projZestawienieKalk(KZ_KALK[calcId], mode.key, v, res);
  if (calcId === 'co_dia') return L.map(it => Object.assign(it, { wyl: !/^Grzejnik/.test(it.name) }));
  // podłogówka: zamiast osobnych zaworów i pomp — grupy pompowe
  const bez = L.filter(it => !/^Zawór mieszający|^Pompa obiegowa|^Termostat bezpieczeństwa/.test(it.name));
  const grupy = projCeny(kzGrupyPompowe(res).map(g => Object.assign({ wyl: false }, g)));
  const rury = bez.filter(it => /^Rura/.test(it.name)), rozdz = bez.filter(it => /^Rozdzielacz/.test(it.name));
  const reszta = bez.filter(it => !/^Rura|^Rozdzielacz/.test(it.name)).map(it => Object.assign(it, { wyl: true }));
  return rury.concat(grupy, rozdz, reszta);
}

function kalkZestBtn(calcId, res) {
  if (!KZ_KALK[calcId] || !res || res.error) return '';
  return `<button class="jump" style="--c:var(--flame)" data-kalkzest="${calcId}">${svg('list')}Zestawienie materiałów → do oferty</button>`;
}

function kalkZestHtml(z) {
  const zazn = z.lista.filter((it, i) => z.wyb[i]);
  const suma = zazn.reduce((a, it) => a + (Number(it.price) || 0) * (Number(it.qty) || 0), 0);
  const brakRur = z.calc === 'rozdz_dia' && !z.lista.some(it => /^Rura/.test(it.name));
  return `<div class="sheet" data-kzzamknij role="dialog" aria-label="Zestawienie materiałów">
    <div class="sheet-in" data-stop>
      <div class="sheet-h">${svg('list')}<strong>Zestawienie materiałów</strong>
        <button class="item-x" data-kzzamknij aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        <p class="hint" style="margin:0 0 10px">Zaznacz, co ma trafić do oferty, i popraw ilości. Ceny są z Twojego cennika, gdzie pasują — resztę wpisz tutaj albo później w ofercie.</p>
        ${brakRur ? '<div class="tip" style="margin-bottom:10px">' + svg('spark') + '<div>Brak metrów rury — dopisuj pomieszczenia z kalkulatora pętli podłogowej guzikiem „Dopisz do rozdzielaczy”, wtedy rura policzy się sama.</div></div>' : ''}
        <div class="proj-zest">${z.lista.map((it, i) => `<div class="proj-poz${z.wyb[i] ? '' : ' proj-poz--off'}">
          <input type="checkbox" data-kzz="${i}"${z.wyb[i] ? ' checked' : ''} aria-label="Do oferty">
          <div class="proj-poz-t">${z.edyt === i ? `
            <textarea class="proj-in proj-in--n" rows="${Math.min(3, Math.ceil(String(it.name).length / 24) || 1)}" data-kzn="${i}" aria-label="Nazwa">${esc(it.name)}</textarea>
            <div class="proj-poz-r">
              <select class="proj-in" data-kzu="${i}" aria-label="Jednostka">${UNITS.concat(UNITS.includes(it.unit) ? [] : [it.unit])
                .map(u => `<option value="${esc(u)}"${u === it.unit ? ' selected' : ''}>${esc(u)}</option>`).join('')}</select>
              <button class="pill-cat ${it.cat === 'rob' ? 'pill-rob' : 'pill-mat'}" data-kzcat="${i}">${svg('pen')}${it.cat === 'rob' ? 'robocizna' : 'materiał'}</button>
            </div>` : `<b>${esc(it.name)}</b>`}
            <div class="proj-poz-r">
              <input class="proj-in proj-in--q" type="text" inputmode="decimal" value="${projLiczbaTxt(Number(it.qty) || 0)}" data-kzq="${i}" aria-label="Ilość">
              <span>${esc(it.unit)}</span>
              <span>×</span>
              <input class="proj-in proj-in--c" type="text" inputmode="decimal" value="${Number(it.price) > 0 ? projLiczbaTxt(Number(it.price)) : ''}" placeholder="cena" data-kzc="${i}" aria-label="Cena netto">
              <span>zł</span>
            </div>
            <small>${it.opis ? esc(it.opis) + ' · ' : ''}${it.cat === 'rob' ? 'robocizna' : 'materiał'}${it.zCennika ? ' · z cennika' : ''}</small>
          </div>
          <button class="proj-x proj-gear${z.edyt === i ? ' on' : ''}" data-kzedyt="${i}" aria-label="${z.edyt === i ? 'Zakończ edycję' : 'Edytuj pozycję'}">${svg(z.edyt === i ? 'check' : 'gear')}</button>
          </div>`).join('')}</div>
        <div style="height:10px"></div>
        <button class="addbtn" data-kzkat style="--c:var(--flame)">${svg('plus')}Dodaj z katalogu</button>
        <p class="hint" style="margin:12px 2px 0" data-kzsuma>Zaznaczone: ${zazn.length} poz. · razem netto ${zl(suma)}</p>
        <button class="jump" style="--c:#2E7D5B;margin-top:10px" data-kzdodaj>${svg('plus')}Dodaj zaznaczone do oferty</button>
      </div>
    </div></div>`;
}

function kzSuma() {
  const z = state.kalkZest, el = document.querySelector('[data-kzsuma]');
  if (!z || !el) return;
  const zazn = z.lista.filter((it, i) => z.wyb[i]);
  el.textContent = 'Zaznaczone: ' + zazn.length + ' poz. · razem netto ' + zl(zazn.reduce((a, it) => a + (Number(it.price) || 0) * (Number(it.qty) || 0), 0));
}
document.addEventListener('input', e => {
  const t = e.target; if (!state.kalkZest || !t.dataset || t.dataset.kzq === undefined) return;
  state.kalkZest.lista[+t.dataset.kzq].qty = projLiczba(t.value); kzSuma();
});
document.addEventListener('input', e => {
  const t = e.target; if (!state.kalkZest || !t.dataset || t.dataset.kzn === undefined) return;
  state.kalkZest.lista[+t.dataset.kzn].name = t.value;
});
document.addEventListener('change', e => {
  const t = e.target; if (!state.kalkZest || !t.dataset || t.dataset.kzu === undefined) return;
  state.kalkZest.lista[+t.dataset.kzu].unit = t.value;
});
document.addEventListener('input', e => {
  const t = e.target; if (!state.kalkZest || !t.dataset || t.dataset.kzc === undefined) return;
  const it = state.kalkZest.lista[+t.dataset.kzc]; it.price = projLiczba(t.value); it.zCennika = false; kzSuma();
});
document.addEventListener('change', e => {
  const t = e.target; if (!state.kalkZest || !t.dataset || t.dataset.kzz === undefined) return;
  state.kalkZest.wyb[+t.dataset.kzz] = t.checked;
  const w = t.closest('.proj-poz'); if (w) w.classList.toggle('proj-poz--off', !t.checked);
  kzSuma();
});
document.addEventListener('click', e => {
  const t = e.target;
  const b = t.closest('[data-kalkzest]');
  if (b) {
    const lista = kalkZestawienie(b.dataset.kalkzest);
    if (!lista.length) { toast('Najpierw uzupełnij dane w kalkulatorze.'); return; }
    state.kalkZest = { calc: b.dataset.kalkzest, lista, wyb: lista.map(it => !it.wyl) };
    renderOverlay(); return;
  }
  if (!state.kalkZest) return;
  /* Koło zębate: edycja nazwy, jednostki i rodzaju pozycji w miejscu. */
  const ed = t.closest('[data-kzedyt]');
  if (ed) {
    const i = +ed.dataset.kzedyt, z = state.kalkZest;
    if (z.edyt === i) { const it = z.lista[i]; it.name = String(it.name || '').trim() || 'Pozycja własna'; z.edyt = null; }
    else z.edyt = i;
    const body = document.querySelector('#overlay .sheet-body'), y = body ? body.scrollTop : 0;
    renderOverlay();
    const b2 = document.querySelector('#overlay .sheet-body'); if (b2) b2.scrollTop = y; const si = document.querySelector('#overlay .sheet-in'); if (si) si.style.animation = 'none';
    if (z.edyt === i) { const n = document.querySelector(`[data-kzn="${i}"]`); if (n) n.focus(); }
    return;
  }
  const kc = t.closest('[data-kzcat]');
  if (kc) {
    const it = state.kalkZest.lista[+kc.dataset.kzcat]; it.cat = it.cat === 'rob' ? 'mat' : 'rob';
    const body = document.querySelector('#overlay .sheet-body'), y = body ? body.scrollTop : 0;
    renderOverlay(); const b2 = document.querySelector('#overlay .sheet-body'); if (b2) b2.scrollTop = y; const si = document.querySelector('#overlay .sheet-in'); if (si) si.style.animation = 'none';
    return;
  }
  if (t.closest('[data-kzdodaj]')) {
    const z = state.kalkZest;
    const lista = z.lista.filter((it, i) => z.wyb[i] && Number(it.qty) > 0);
    if (!lista.length) { toast('Zaznacz co najmniej jedną pozycję.'); return; }
    state.kalkZest = null;
    /* Cena wpisana tutaj trafia też do katalogu — jak przy poprawianiu ceny
       w ofercie: znana pozycja dostaje nową cenę, nowa ląduje w „Moje pozycje”. */
    let wKat = 0;
    lista.forEach(it => { if (Number(it.price) > 0) { const w = katalogZOferty(it, state.catalog); if (w.co !== 'nic') wKat++; } });
    if (wKat) persistCatalog();
    const p = { name: lista.length + ' ' + odmiana(lista.length, 'pozycja', 'pozycje', 'pozycji') + ' z zestawienia', lista };
    const wToku = state.offers.filter(o => !o.invoice);
    if (wToku.length > 1) { state.wybOferty = p; renderOverlay(); return; }
    dodajPozycjeDoOferty(wToku[0] || null, p);
    return;
  }
  if (t.closest('[data-kzzamknij]') && (!t.closest('[data-stop]') || t.closest('.sheet-h [data-kzzamknij]'))) {
    state.kalkZest = null; renderOverlay();
  }
});

/* --- dokładanie pozycji do zestawienia: z katalogu albo własnej ---
   Katalog otwiera się w tym samym miejscu co zestawienie, więc na czas
   wyboru chowamy zestawienie i przywracamy je po wyborze albo zamknięciu. */
state.kzSchowek = null;
function kzDodaj(it, otworz) {
  const z = state.kalkZest;
  z.lista.push(Object.assign({ name: '', unit: 'szt', cat: 'mat', price: 0, qty: 1, tag: null }, it));
  z.wyb.push(true);
  if (otworz) z.edyt = z.lista.length - 1;
}
function kzPrzewinNaDol(fokus) {
  const si = document.querySelector('#overlay .sheet-in'); if (si) si.style.animation = 'none';
  const body = document.querySelector('#overlay .sheet-body');
  const pozycje = document.querySelectorAll('#overlay .proj-poz');
  const ost = pozycje[pozycje.length - 1];
  if (body && ost) ost.scrollIntoView({ block: 'center' });
  if (fokus) { const n = document.querySelector(`[data-kzn="${state.kalkZest.lista.length - 1}"]`); if (n) n.focus(); }
}
document.addEventListener('click', e => {
  if (!state.kzSchowek || !state.picker) return;
  const t = e.target;
  const wroc = (fokus) => {
    state.picker = false; state.pickSel = null; state.pickQ = '';
    state.kalkZest = state.kzSchowek; state.kzSchowek = null;
    e.stopPropagation(); e.preventDefault();
    return fokus;
  };
  const pick = t.closest('[data-pick]');
  if (pick && !state.pickSel) {
    if (typeof dlugiZaszlo !== 'undefined' && dlugiZaszlo) return;
    const c = catalogById(pick.dataset.pick);
    wroc(); if (c) { const it = itemFromCatalog(c, 1); it.zCennika = Number(c.price) > 0; kzDodaj(it); }
    renderOverlay(); kzPrzewinNaDol(false); return;
  }
  if (t.closest('[data-seladd]')) {
    const sel = state.pickSel || {};
    wroc(); Object.keys(sel).forEach(id => { const c = catalogById(id); if (c) { const it = itemFromCatalog(c, sel[id]); it.zCennika = Number(c.price) > 0; kzDodaj(it); } });
    renderOverlay(); kzPrzewinNaDol(false); return;
  }
  if (t.closest('[data-newin], [data-custom]')) {
    wroc(); kzDodaj({}, true); renderOverlay(); kzPrzewinNaDol(true); return;
  }
  const close = t.closest('[data-closepicker]');
  if (close && (close.classList.contains('sheet') ? t === close : true)) { wroc(); renderOverlay(); kzPrzewinNaDol(false); }
}, true);
document.addEventListener('click', e => {
  const t = e.target;
  if (!state.kalkZest) return;
  if (t.closest('[data-kzkat]')) {
    state.kzSchowek = state.kalkZest; state.kalkZest = null;
    state.picker = true; state.pickGrp = null; state.pickDn = null; state.pickWar = null; state.pickQ = ''; state.pickSel = null;
    renderOverlay(); return;
  }
  if (t.closest('[data-kzwlasna]')) { kzDodaj({}, true); renderOverlay(); kzPrzewinNaDol(true); }
});

