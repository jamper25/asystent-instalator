/* ===== offers.js ===== */
/* ============================================================
   MODUŁ OFERT — model danych, baza cenowa, wyliczenia, kontrola braków
   ============================================================ */

/* --- Baza cenowa (startowa) ---
   Rur i kształtek tu nie ma: siedzą w ksztaltki.js, w dziewięciuset
   pozycjach rozpisanych na systemy i średnice. Trzymanie obok nich ośmiu
   ogólników w rodzaju „Kolano zaciskowe" oznaczałoby dwa miejsca na tę
   samą rzecz i pytanie, które z nich jest tym właściwym.

   Zostaje to, czego baza kształtek nie obejmuje: urządzenia, izolacja
   i robocizna.

   UWAGA: ceny są PRZYKŁADOWE, do podmiany na własne. Nie są notowaniem
   rynkowym — każdy instalator ma swoje stawki i rabaty u hurtownika.
   tag → używany przez kontrolę kompletności oferty.
   cat: 'mat' = materiał, 'rob' = robocizna                              */
const DEFAULT_CATALOG = [
  // --- Izolacja ---
  /* Otuliny są w bazie systemowej, rozpisane na średnice wewnętrzne,
     kolory i grubości. Tu zostaje tylko to, co się w tamten podział
     nie układa. */
  { id: 'i3', name: 'Peszel osłonowy', unit: 'mb', cat: 'mat', price: 3.00, tag: 'izolacja', grp: 'Izolacja' },

  // --- Grzejniki i armatura ---
  { id: 'g1', name: 'Grzejnik płytowy typ 22 600x1000', unit: 'szt', cat: 'mat', price: 420.00, tag: 'grzejnik', grp: 'Grzejniki i armatura' },
  { id: 'g2', name: 'Grzejnik płytowy typ 11 600x800', unit: 'szt', cat: 'mat', price: 290.00, tag: 'grzejnik', grp: 'Grzejniki i armatura' },
  { id: 'g3', name: 'Grzejnik łazienkowy drabinkowy', unit: 'szt', cat: 'mat', price: 340.00, tag: 'grzejnik', grp: 'Grzejniki i armatura' },
  { id: 'g4', name: 'Zawór termostatyczny z głowicą', unit: 'kpl', cat: 'mat', price: 95.00, tag: 'zawor_term', grp: 'Grzejniki i armatura' },
  { id: 'g5', name: 'Zawór powrotny odcinający', unit: 'szt', cat: 'mat', price: 45.00, tag: 'zawor_odc', grp: 'Grzejniki i armatura' },
  { id: 'g6', name: 'Zestaw przyłączeniowy grzejnika', unit: 'kpl', cat: 'mat', price: 60.00, tag: 'zestaw_grz', grp: 'Grzejniki i armatura' },

  // --- Źródło ciepła i osprzęt ---
  { id: 'k1', name: 'Kocioł gazowy kondensacyjny 24 kW', unit: 'szt', cat: 'mat', price: 6800.00, tag: 'kociol', grp: 'Źródło ciepła' },
  { id: 'k2', name: 'Pompa ciepła powietrze-woda 8 kW', unit: 'szt', cat: 'mat', price: 21000.00, tag: 'kociol', grp: 'Źródło ciepła' },
  { id: 'k3', name: 'Naczynie wzbiorcze przeponowe c.o. 12 l', unit: 'szt', cat: 'mat', price: 130.00, tag: 'naczynie', grp: 'Źródło ciepła' },
  { id: 'k4', name: 'Zawór bezpieczeństwa c.o. 2,5 bar', unit: 'szt', cat: 'mat', price: 55.00, tag: 'zawor_bezp', grp: 'Źródło ciepła' },
  { id: 'k5', name: 'Pompa obiegowa elektroniczna', unit: 'szt', cat: 'mat', price: 520.00, tag: 'pompa', grp: 'Źródło ciepła' },
  { id: 'k6', name: 'Filtr / odmulacz magnetyczny', unit: 'szt', cat: 'mat', price: 280.00, tag: 'filtr', grp: 'Źródło ciepła' },
  { id: 'k7', name: 'Rozdzielacz z szafką', unit: 'kpl', cat: 'mat', price: 900.00, tag: 'rozdzielacz', grp: 'Źródło ciepła' },

  // --- Ciepła woda ---
  { id: 'w1', name: 'Zasobnik c.w.u. 200 l', unit: 'szt', cat: 'mat', price: 2400.00, tag: 'zasobnik', grp: 'Ciepła woda' },
  { id: 'w2', name: 'Naczynie przeponowe c.w.u. 12 l (atest PZH)', unit: 'szt', cat: 'mat', price: 180.00, tag: 'naczynie_cwu', grp: 'Ciepła woda' },
  { id: 'w3', name: 'Zawór bezpieczeństwa c.w.u. 6 bar', unit: 'szt', cat: 'mat', price: 70.00, tag: 'zawor_bezp_cwu', grp: 'Ciepła woda' },
  { id: 'w4', name: 'Zawór mieszający termostatyczny c.w.u.', unit: 'szt', cat: 'mat', price: 210.00, tag: 'mieszacz', grp: 'Ciepła woda' },

  // --- Robocizna ---
  { id: 'p1', name: 'Montaż grzejnika z podłączeniem', unit: 'szt', cat: 'rob', price: 180.00, tag: 'montaz_grz', grp: 'Robocizna' },
  { id: 'p2', name: 'Montaż instalacji — rurociąg', unit: 'mb', cat: 'rob', price: 45.00, tag: 'montaz_rur', grp: 'Robocizna' },
  { id: 'p3', name: 'Montaż i podłączenie kotła', unit: 'kpl', cat: 'rob', price: 2200.00, tag: 'montaz_kociol', grp: 'Robocizna' },
  { id: 'p4', name: 'Montaż zasobnika c.w.u.', unit: 'szt', cat: 'rob', price: 600.00, tag: 'montaz_zasob', grp: 'Robocizna' },
  { id: 'p5', name: 'Próba szczelności instalacji', unit: 'kpl', cat: 'rob', price: 350.00, tag: 'proba', grp: 'Robocizna' },
  { id: 'p6', name: 'Uruchomienie i regulacja instalacji', unit: 'kpl', cat: 'rob', price: 450.00, tag: 'uruchomienie', grp: 'Robocizna' },
  { id: 'p7', name: 'Bruzdowanie ścian', unit: 'mb', cat: 'rob', price: 55.00, tag: 'bruzdy', grp: 'Robocizna' },
  { id: 'p8', name: 'Dojazd / transport', unit: 'kpl', cat: 'rob', price: 150.00, tag: 'transport', grp: 'Robocizna' },
];

/* Katalog roboczy: kopia domyślnego, którą użytkownik edytuje i która
   zapisuje się w telefonie. Odczytywany przy każdym użyciu, żeby zmiany
   w ustawieniach były od razu widoczne w ofertach. */
/* Zanim ekran ustawień zdąży zbudować katalog z cenami użytkownika,
   sięgamy po samą bazę — inaczej wszystko, co uruchamia się wcześniej
   (choćby przykładowa oferta), widziałoby katalog bez rur i kształtek
   i po cichu gubiło pozycje. */
const activeCatalog = () =>
  (typeof state !== 'undefined' && state.catalog) ? state.catalog : bazaPelna();

const catalogById = id => activeCatalog().find(c => c.id === id);
const catalogGroups = () => {
  const g = [];
  activeCatalog().forEach(c => {
    let e = g.find(x => x.name === c.grp);
    if (!e) g.push(e = { name: c.grp, items: [] });
    e.items.push(c);
  });
  return g;
};

/* ============================================================
   PRZEGLĄDANIE KATALOGU PO POZIOMACH
   ------------------------------------------------------------
   Przy trzydziestu pozycjach płaska lista była najszybsza. Przy
   dziewięciuset jest nie do użycia: szukanie kolana Ø25 oznaczałoby
   przewijanie kilkuset wierszy kciukiem na budowie.

   Dlatego katalog rozkłada się na trzy poziomy — system, rozmiar,
   kształtka — dokładnie tak, jak wygląda szukanie w hurtowni:
   najpierw dział, potem średnica, potem konkretna sztuka. Grupy bez
   rozmiarów (robocizna, własne pozycje) mają tylko dwa poziomy.

   Obok jest wyszukiwarka, bo kto wie, czego szuka, nie chce klikać
   przez poziomy.
   ============================================================ */

function katalogMenu() {
  const lista = [];
  const wg = {};
  activeCatalog().forEach(c => {
    let e = wg[c.grp];
    if (!e) { e = wg[c.grp] = { nazwa: c.grp, ile: 0, rozmiary: [], bezRozmiaru: 0 }; lista.push(e); }
    e.ile++;
    if (!c.dn) e.bezRozmiaru++;
    /* Rozmiary zbieramy w kolejności, w jakiej powstały pozycje — czyli
       rosnąco. Sortowanie tekstowe ustawiłoby Ø110 przed Ø32. */
    if (c.dn && e.rozmiary.indexOf(c.dn) < 0) e.rozmiary.push(c.dn);
  });
  return lista;
}

/* BEZ_ROZMIARU zbiera to, co do podziału na średnice nie pasuje — peszel
   w izolacji, a w przyszłości każdą pozycję, która po prostu nie ma
   średnicy. Bez tego takie rzeczy znikałyby z działu, bo żaden kafelek
   z rozmiarem by ich nie pokazał. */
const BEZ_ROZMIARU = '\u2014';

function katalogWGrupie(grupa, rozmiar) {
  return activeCatalog().filter(c => c.grp === grupa && (!rozmiar
    || (rozmiar === BEZ_ROZMIARU ? !c.dn : c.dn === rozmiar)));
}

/* Szukanie po słowach, nie po całej frazie: „kolano 25" ma znaleźć
   „Kolano 90° PP-R Ø25", choć nigdzie nie stoją obok siebie w tej
   kolejności. Znak średnicy i cudzysłów przy calach pomijamy, bo nikt
   ich nie wpisuje z klawiatury telefonu.

   Ogonki ścieramy po obu stronach. Na budowie nikt nie przełącza się na
   polskie znaki, żeby wpisać „trójnik" — a bez tego wpisany „trojnik"
   nie znalazłby ani jednej z kilkudziesięciu pozycji, które go mają
   w nazwie. */
const BEZ_OGONKOW = { ą: 'a', ć: 'c', ę: 'e', ł: 'l', ń: 'n', ó: 'o', ś: 's', ź: 'z', ż: 'z' };

function katalogSzukajFrazy(fraza, limit) {
  const czysc = t => String(t || '').toLowerCase()
    .replace(/[ąćęłńóśźż]/g, z => BEZ_OGONKOW[z])
    .replace(/[ø"°]/g, '').replace(/\s+/g, ' ').trim();
  const slowa = czysc(fraza).split(' ').filter(Boolean);
  if (!slowa.length) return [];
  /* Końcówkę dłuższego słowa obcinamy, bo w nazwach hurtowni ta sama
     rzecz raz jest „redukcją", a raz „redukcyjna". Wpisujący nie ma
     obowiązku zgadnąć, którą formę wybrał producent. */
  const rdzen = s => (s.length >= 5 ? s.slice(0, -2) : s);
  const pasuje = (n, s) => n.indexOf(s) >= 0 || n.indexOf(rdzen(s)) >= 0;

  const out = [];
  const lista = activeCatalog();
  for (let i = 0; i < lista.length && out.length < (limit || 60); i++) {
    const n = czysc(lista[i].name);
    if (slowa.every(s => pasuje(n, s))) out.push(lista[i]);
  }
  return out;
}

/* ============================================================
   USTAWIENIA FIRMY I DANE ZAPISANE W TELEFONIE
   ============================================================ */
const DEFAULT_SETTINGS = {
  company: '', nip: '', address: '', phone: '', email: '', logo: null,
  marginPct: 15, vatRate: 0.08, validDays: 30, numberPrefix: '',
  terms: 'Termin realizacji do uzgodnienia. Płatność: 30% zaliczki, reszta po odbiorze.',
  /* --- dane potrzebne dopiero na fakturze --- */
  bank: '',                 /* numer rachunku do przelewu            */
  vatStatus: 'czynny',      /* 'czynny' albo 'zwolniony'             */
  zwPodstawa: 'art. 113 ust. 1 ustawy o VAT',
  invPrefix: 'FV',
  payDays: 14,
  payMethod: 'przelew',
  invFooter: 'Dziękuję za zlecenie. W razie pytań proszę o kontakt.',
};

/* Sposoby płatności — nazwy jak na dokumencie */
const PAY_METHODS = ['przelew', 'gotówka', 'karta', 'blik'];
const SETTINGS_KEY = 'ai_ustawienia_v1';
const CATALOG_KEY = 'ai_katalog_v1';

function loadSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return Object.assign({}, DEFAULT_SETTINGS, JSON.parse(raw));
  } catch (e) { /* prywatne okno albo zablokowane dane — jedziemy na domyślnych */ }
  return Object.assign({}, DEFAULT_SETTINGS);
}
function saveSettings(s) {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch (e) { /* bez zapisu też działa */ }
}
/* ============================================================
   KATALOG: BAZA W KODZIE, CENY W TELEFONIE
   ------------------------------------------------------------
   Baza to prawie dziewięćset pozycji — rury, kształtki i armatura
   rozwijane z przepisu w ksztaltki.js. Gdyby zapisywać ją w telefonie
   w całości, przy każdym zapisaniu ceny lądowałoby tam sto trzydzieści
   kilobajtów tekstu, w większości zer. Co gorsza, przy aktualizacji
   aplikacji nowe pozycje nigdy by się nie pojawiły: wygrywałaby stara
   kopia z pamięci.

   Dlatego w telefonie trzymamy tylko to, czego aplikacja nie potrafi
   odtworzyć: ceny wpisane przez użytkownika i pozycje, które sam dodał.
   Reszta powstaje przy starcie. Dzięki temu kolejna wersja może dołożyć
   dwieście kształtek, a jego stawki zostaną nietknięte.
   ============================================================ */

const CENY_KEY = 'ai_ceny_v1';

/* Baza liczy się raz na uruchomienie. Bez tego każde naciśnięcie klawisza
   w cenie przeliczałoby od nowa osiemset kilkadziesiąt pozycji — na telefonie
   byłoby to czuć jako zacinanie się pola. */
let _bazaPelna = null;
function bazaPelna() {
  if (!_bazaPelna) {
    _bazaPelna = DEFAULT_CATALOG.concat(typeof bazaKsztaltek === 'function' ? bazaKsztaltek() : []);
  }
  return _bazaPelna;
}

function loadCeny() {
  try {
    const raw = localStorage.getItem(CENY_KEY);
    if (raw) {
      const m = JSON.parse(raw);
      if (m && typeof m === 'object') return m;
    }
  } catch (e) { /* jw. */ }
  return {};
}

/* Pozycje dopisane przez użytkownika — te z ofert i te z ekranu katalogu.
   Rozpoznajemy je po identyfikatorze zaczynającym się od „c".

   Tu też odbywa się przejście ze starego zapisu, w którym cały katalog
   leżał w telefonie jako jedna lista. Ze starej listy wyjmujemy ceny
   pozycji bazowych i pozycje własne, a resztę porzucamy — bez tego
   użytkownik, który ma już wpisane swoje stawki, straciłby je przy
   aktualizacji. */
function loadWlasne(baza, ceny) {
  let stare = null;
  try { stare = JSON.parse(localStorage.getItem(CATALOG_KEY) || 'null'); } catch (e) { /* jw. */ }
  if (!Array.isArray(stare)) return [];

  const wBazie = {};
  baza.forEach(c => { wBazie[c.id] = c; });
  const wlasne = [];
  stare.forEach(c => {
    if (!c || !c.id) return;
    const b = wBazie[c.id];
    if (!b) { wlasne.push(Object.assign({}, c)); return; }
    if (ceny[c.id] === undefined && Number(c.price) !== Number(b.price)) ceny[c.id] = Number(c.price);
  });
  return wlasne;
}

/* Katalog widziany przez resztę aplikacji: baza z nałożonymi cenami
   użytkownika plus jego własne pozycje. */
function loadCatalog() {
  const baza = bazaPelna().map(c => Object.assign({}, c));
  const ceny = loadCeny();
  const wlasne = loadWlasne(baza, ceny);
  baza.forEach(c => { if (ceny[c.id] !== undefined) c.price = ceny[c.id]; });
  const lista = baza.concat(wlasne);
  if (typeof katalogPorzadkuj === 'function' && katalogPorzadkuj(lista)) saveCatalog(lista);
  return lista;
}

/* Zapis rozbija listę z powrotem na dwie części. Cenę zapisujemy tylko
   wtedy, gdy różni się od tej z bazy — inaczej plik cen puchłby o setki
   zer, które i tak są w kodzie. */
function saveCatalog(list) {
  const domyslne = {};
  bazaPelna().forEach(c => { domyslne[c.id] = Number(c.price); });

  const ceny = {};
  const wlasne = [];
  (list || []).forEach(c => {
    if (!c || !c.id) return;
    if (domyslne[c.id] === undefined) { wlasne.push(c); return; }
    if (Number(c.price) !== domyslne[c.id]) ceny[c.id] = Number(c.price);
  });
  try {
    localStorage.setItem(CENY_KEY, JSON.stringify(ceny));
    localStorage.setItem(CATALOG_KEY, JSON.stringify(wlasne));
  } catch (e) { /* bez zapisu też działa */ }
}
/* Nowa pozycja w katalogu — bez tagu, więc kontrola kompletności jej nie rozpozna */
function blankCatalogItem() {
  return { id: 'c' + Date.now(), name: 'Nowa pozycja', unit: 'szt', cat: 'mat',
           price: 0, tag: null, grp: 'Moje pozycje' };
}

/* --- Stawki VAT ---
   8% dla robót w budownictwie objętym społecznym programem mieszkaniowym,
   23% w pozostałych przypadkach. Stawkę potwierdź z księgowością.        */
const VAT_RATES = [
  { value: 0.08, label: '8% — budownictwo mieszkaniowe' },
  { value: 0.23, label: '23% — pozostałe' },
];

/* --- Wyliczenia oferty ---
   Marża naliczana jest na materiałach (robocizna jest już wyceniona).   */
function offerTotals(offer) {
  let netMat = 0, netRob = 0;
  (offer.items || []).forEach(it => {
    const v = (Number(it.qty) || 0) * (Number(it.price) || 0);
    if (it.cat === 'rob') netRob += v; else netMat += v;
  });
  const margin = netMat * (Number(offer.marginPct) || 0) / 100;
  const net = netMat + margin + netRob;
  const vat = net * (Number(offer.vatRate) || 0);
  return { netMat, netRob, margin, net, vat, gross: net + vat, count: (offer.items || []).length };
}

/* --- Kontrola kompletności oferty ---
   Reguła: jeśli oferta zawiera "gdy", a nie zawiera żadnego z "brak",
   zgłaszamy podpowiedź. To wersja regułowa — asystent AI (etap 5)
   rozszerzy ją o analizę opisową.                                       */
const OFFER_RULES = [
  { when: ['rura'], missing: ['izolacja'],
    msg: 'Są rury, ale nie ma izolacji termicznej. Przewody c.o. i c.w.u. w bruzdach i nieogrzewanych pomieszczeniach trzeba zaizolować.' },
  { when: ['rura'], missing: ['ksztaltka'],
    msg: 'Są rury, ale nie ma kształtek (kolan, trójników, złączek). Łatwo o nich zapomnieć przy wycenie.' },
  { when: ['grzejnik'], missing: ['zawor_term'],
    msg: 'Są grzejniki, ale nie ma zaworów termostatycznych z głowicami.' },
  { when: ['grzejnik'], missing: ['zestaw_grz', 'zawor_odc'],
    msg: 'Są grzejniki, ale nie ma zestawów przyłączeniowych ani zaworów odcinających.' },
  { when: ['grzejnik'], missing: ['montaz_grz'],
    msg: 'Grzejniki są w materiałach, ale nie ma pozycji za ich montaż.' },
  { when: ['kociol'], missing: ['naczynie'],
    msg: 'Jest źródło ciepła, ale nie ma naczynia wzbiorczego c.o.' },
  { when: ['kociol'], missing: ['zawor_bezp'],
    msg: 'Jest źródło ciepła, ale nie ma zaworu bezpieczeństwa c.o.' },
  { when: ['kociol'], missing: ['montaz_kociol'],
    msg: 'Kocioł jest w materiałach, ale nie ma pozycji za montaż i podłączenie.' },
  { when: ['zasobnik'], missing: ['naczynie_cwu'],
    msg: 'Jest zasobnik c.w.u., ale nie ma naczynia przeponowego do wody pitnej (osobnego od naczynia c.o.).' },
  { when: ['zasobnik'], missing: ['zawor_bezp_cwu'],
    msg: 'Jest zasobnik c.w.u., ale nie ma zaworu bezpieczeństwa c.w.u.' },
  { when: ['rura', 'kociol', 'grzejnik'], missing: ['proba'],
    msg: 'Brak próby szczelności instalacji — to pozycja, której klienci nie kwestionują, a często wypada z wyceny.' },
  { when: ['kociol'], missing: ['uruchomienie'],
    msg: 'Brak uruchomienia i regulacji instalacji.' },
  { when: ['rura', 'grzejnik', 'kociol'], missing: ['transport'],
    msg: 'Brak pozycji za dojazd/transport.' },
  { when: ['kociol'], missing: ['filtr'],
    msg: 'Jest źródło ciepła, ale nie ma filtra ani odmulacza. Producenci kotłów i pomp ciepła często uzależniają od tego gwarancję.' },
  { when: ['kociol'], missing: ['pompa'],
    msg: 'Jest źródło ciepła, ale nie ma pompy obiegowej — sprawdź, czy kocioł ma ją wbudowaną.' },
  { when: ['zasobnik'], missing: ['montaz_zasob'],
    msg: 'Zasobnik c.w.u. jest w materiałach, ale nie ma pozycji za jego montaż.' },
  { when: ['rura'], missing: ['bruzdy', 'montaz_rur'],
    msg: 'Są rury, ale nie ma pozycji za ich montaż ani za bruzdowanie.' },
];

/* Reguły, które patrzą na coś więcej niż obecność tagów. */
function contextChecks(offer) {
  const out = [];
  const items = offer.items || [];
  const names = items.map(i => String(i.name || '')).join(' | ');
  const tags = new Set(items.map(i => i.tag).filter(Boolean));

  // Pompa ciepła pracuje na małym Δt, więc przy tej samej mocy potrzebuje
  // znacznie większego przepływu — a to znaczy większych średnic.
  if (/pomp[aeęy] ciep[łl]/i.test(names)) {
    out.push('W ofercie jest pompa ciepła. Pracuje na małej różnicy temperatur (zwykle 5 K zamiast 20 K), '
      + 'czyli przy tej samej mocy potrzebuje ok. czterokrotnie większego przepływu niż kocioł. '
      + 'Sprawdź średnice rur — dobrane jak pod grzejniki będą za małe.');
  }
  // Ogrzewanie podłogowe bez rozdzielacza
  if (/pod[łl]ogow/i.test(names) && !tags.has('rozdzielacz')) {
    out.push('Jest ogrzewanie podłogowe, ale nie ma rozdzielacza ze szafką.');
  }
  return out;
}

function offerChecks(offer) {
  // pozycje własne nie mają tagu z katalogu — rozpoznajemy je po nazwie
  const tags = new Set((offer.items || [])
    .map(i => i.tag || guessTag(i.name))
    .filter(Boolean));
  const out = [];
  const hasAnyMaterial = (offer.items || []).some(i => i.cat === 'mat');
  const hasAnyLabour = (offer.items || []).some(i => i.cat === 'rob');

  if (hasAnyMaterial && !hasAnyLabour) {
    out.push('Oferta zawiera same materiały — nie ma żadnej pozycji za robociznę.');
  }
  OFFER_RULES.forEach(r => {
    if (r.when.some(t => tags.has(t)) && !r.missing.some(t => tags.has(t))) out.push(r.msg);
  });
  contextChecks(offer).forEach(m => out.push(m));
  return out;
}

/* --- Przechowywanie (podgląd: pamięć przeglądarki; w aplikacji: baza lokalna) --- */
const STORE_KEY = 'ai_oferty_v1';
function loadOffers() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) { /* prywatne okno / zablokowane dane — działamy na przykładzie */ }
  return [sampleOffer()];
}
function saveOffers(list) {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(list)); }
  catch (e) { /* brak zapisu nie może psuć działania podglądu */ }
}

/* --- Baza klientów ---------------------------------------------------
   Instalator jeździ do tych samych ludzi po kilka razy: najpierw wycena
   kotłowni, za pół roku łazienka, za rok przegląd. Przepisywanie nazwiska,
   adresu i NIP-u za każdym razem to nie tylko strata czasu — to miejsce,
   w którym robi się literówka w adresie na fakturze. Dlatego dane klienta
   zapisuje się raz i potem wybiera z listy.

   Klient trzyma dokładnie te same pola co `offer.client`, więc wstawienie
   go do oferty to przepisanie pól, bez żadnego tłumaczenia formatów. */
const KLIENCI_KEY = 'ai_klienci_v1';

function loadKlienci() {
  try {
    const raw = localStorage.getItem(KLIENCI_KEY);
    const l = raw ? JSON.parse(raw) : null;
    if (Array.isArray(l)) return l.filter(Boolean);
  } catch (e) { /* prywatne okno albo zablokowana pamięć — zaczynamy pusto */ }
  return [];
}
function saveKlienci(list) {
  try { localStorage.setItem(KLIENCI_KEY, JSON.stringify(list || [])); }
  catch (e) { /* brak zapisu nie może psuć działania aplikacji */ }
}

const KLIENT_POLA = ['name', 'address', 'phone', 'email', 'nip', 'type'];

function blankKlient() {
  return { id: 'k' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
           name: '', address: '', phone: '', email: '', nip: '', type: 'osoba', notatka: '' };
}

/* Dane klienta wyjęte z oferty — tylko te pola, które klient ma u siebie. */
function klientZOferty(o) {
  const c = (o && o.client) || {};
  const k = blankKlient();
  KLIENT_POLA.forEach(p => { k[p] = c[p] == null ? k[p] : c[p]; });
  return k;
}

/* Wstawienie klienta do oferty. Przepisujemy WSZYSTKIE pola, także puste —
   bo wybór z bazy znaczy „to jest ten klient", a nie „dolej mi brakujące
   dane". Zostawianie starego e-maila dlatego, że nowy klient go nie ma,
   kończy się ofertą wysłaną pod nie ten adres. */
function klientDoOferty(o, k) {
  if (!o || !k) return;
  o.client = o.client || {};
  KLIENT_POLA.forEach(p => { o.client[p] = k[p] == null ? '' : k[p]; });
  if (!o.client.type) o.client.type = 'osoba';
}

const klientPusty = k => !k || !KLIENT_POLA.some(p => String(k[p] || '').trim() && p !== 'type');

/* Ten sam klient to ten sam, gdy zgadza się nazwa — a przy firmach NIP,
   bo dwie „Budownictwo sp. z o.o." to najczęściej jedna firma wpisana
   dwa razy, raz z literówką. */
function klientTenSam(a, b) {
  if (!a || !b) return false;
  const nip = x => String(x.nip || '').replace(/\D/g, '');
  if (nip(a) && nip(a) === nip(b)) return true;
  const n = x => String(x.name || '').trim().toLowerCase().replace(/\s+/g, ' ');
  return !!n(a) && n(a) === n(b);
}

function klientOpis(k) {
  const czesci = [k.address, k.phone].filter(x => String(x || '').trim());
  return czesci.join('  ·  ') || 'bez adresu i telefonu';
}

/* Sortujemy po nazwie, bo baza klientów służy do szukania, nie do historii. */
function klienciPosortowane(list) {
  return (list || []).slice().sort((a, b) =>
    String(a.name || '').localeCompare(String(b.name || ''), 'pl'));
}

function klienciSzukaj(list, fraza) {
  const f = String(fraza || '').trim().toLowerCase();
  if (!f) return klienciPosortowane(list);
  return klienciPosortowane(list).filter(k =>
    [k.name, k.address, k.phone, k.email, k.nip].some(x =>
      String(x || '').toLowerCase().includes(f)));
}

const todayISO = () => new Date().toISOString().slice(0, 10);
const nextNumber = (list, prefix) => {
  const y = new Date().getFullYear();
  const n = `${String((list || []).length + 1).padStart(3, '0')}/${y}`;
  return prefix ? `${prefix} ${n}` : n;
};

/* Jednostki do wyboru przy pozycji oferty */
const UNITS = ['szt', 'kpl', 'mb', 'm²', 'm³', 'kg', 'l', 'godz.', 'usł.', 'pkt'];

function itemFromCatalog(c, qty) {
  /* katId wiąże pozycję w ofercie z wpisem w katalogu. Bez tego zmiana
     ceny w ofercie musiałaby szukać wpisu po nazwie — a nazwę użytkownik
     często poprawia („Grzejnik typ 22" → „Grzejnik typ 22 w łazience")
     i trafiałaby wtedy albo w nic, albo w cudzą pozycję. */
  return { name: c.name, unit: c.unit, cat: c.cat, price: c.price, tag: c.tag,
           katId: c.id, qty: qty || 1 };
}

/* ============================================================
   KATALOG UCZY SIĘ Z OFERT
   ------------------------------------------------------------
   Cennik, który trzeba uzupełniać osobno, nigdy nie jest uzupełniony.
   Dlatego katalog zapisuje to, co i tak przechodzi przez ofertę: nową
   usługę wpisaną ręcznie dopisuje do siebie, a zmienioną cenę pozycji,
   którą już zna — podmienia.

   Dwie rzeczy, których celowo NIE robimy. Nie zapisujemy pozycji
   niedokończonej: świeżo dodany wiersz ma nazwę „Pozycja własna"
   i cenę zero, a katalog pełen zer byłby gorszy niż pusty. I nie
   zapisujemy przy każdym naciśnięciu klawisza, tylko wtedy, gdy
   użytkownik skończy pisać — inaczej po wpisaniu „Montaż zlewu"
   w katalogu wylądowałoby „M", „Mo", „Mon" i tak dalej. */

const katalogKlucz = s => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();

/* Czy to pozycja, którą użytkownik sam utworzył (a nie jedna z wpisanych
   fabrycznie). Tylko przy własnych wolno nam poprawiać nazwę i jednostkę —
   fabryczna nazwa jest punktem odniesienia dla kontroli kompletności. */
const katalogWlasna = c => !!c && (c.grp === 'Moje pozycje' || /^c\d/.test(String(c.id || '')));

function katalogZnajdz(katalog, it) {
  if (it.katId) {
    const po = katalog.find(c => c.id === it.katId);
    if (po) return po;
  }
  const k = katalogKlucz(it.name);
  return k ? (katalog.find(c => katalogKlucz(c.name) === k) || null) : null;
}

/* Pozycja nadaje się do katalogu, gdy ma sensowną nazwę. Ceny nie
   wymagamy: instalator często wie, co wchodzi do wyceny, zanim zadzwoni
   do hurtowni po cenę — a pozycja bez ceny i tak jest w katalogu warta
   więcej niż brak pozycji. Pusta cena jest zresztą widoczna na liście
   jako „brak ceny", więc nic się nie chowa.

   Zostaje próg nazwy: świeży wiersz nazywa się „Pozycja własna", a dwie
   litery to połowa słowa w trakcie pisania — ani jedno, ani drugie nie
   jest pozycją katalogową. */
function pozycjaDoKatalogu(it) {
  const n = katalogKlucz(it.name);
  return n.length >= 3 && n !== 'pozycja własna' && n !== 'nowa pozycja';
}

/* Dopisuje albo aktualizuje wpis. Zwraca, co się stało — ekran na tej
   podstawie decyduje, czy pokazać pasek z możliwością cofnięcia.
   Sama pozycja w ofercie dostaje katId, więc następna zmiana ceny trafi
   w ten sam wpis, nawet gdy nazwa się potem zmieni. */
function katalogZOferty(it, katalog) {
  if (!it || !pozycjaDoKatalogu(it)) return { co: 'nic' };
  const cena = Math.round(Number(it.price) * 100) / 100;
  const stara = katalogZnajdz(katalog, it);

  if (stara) {
    it.katId = stara.id;
    if (katalogWlasna(stara)) {
      stara.name = it.name;
      stara.unit = it.unit;
      stara.cat = it.cat;
    }
    if (Math.round(Number(stara.price) * 100) / 100 === cena) return { co: 'nic' };
    const poprzednia = stara.price;
    stara.price = cena;
    return { co: 'cena', poz: stara, poprzednia };
  }

  /* Dział bierzemy stamtąd, gdzie użytkownik nacisnął „dopisz do działu".
     Kolano PP-R, którego zabrakło w bazie, ma leżeć wśród kształtek PP-R
     przy swojej średnicy, a nie w osobnym worku na końcu katalogu. */
  const nowa = { id: 'c' + Date.now() + Math.floor(Math.random() * 100),
    name: it.name, unit: it.unit || 'szt', cat: it.cat || 'mat',
    price: cena, tag: it.tag || null, grp: it.katGrp || katalogDzial(it.name, it.cat) };
  if (it.katDn) nowa.dn = it.katDn;
  katalog.push(nowa);
  it.katId = nowa.id;
  return { co: 'nowa', poz: nowa };
}

/* ============================================================
   DZIAŁ KATALOGU DLA NOWEJ POZYCJI
   ------------------------------------------------------------
   Pozycja dopisana z oferty, z zestawienia albo ręcznie ląduje tam,
   gdzie by jej szukał instalator: grzejnik przy grzejnikach, otulina
   w izolacji, montaż w robociźnie, kolano PP-R wśród PP-R. Dopiero
   to, czego nie da się rozpoznać po nazwie, idzie do „Moje pozycje”.
   ============================================================ */
const KATALOG_DZIALY = [
  [/^(montaż|demontaż|ułożenie|próba|uruchomienie|bruzd|wymiana|serwis|przegląd|dojazd|transport|robocizna|płukanie|napełnienie|regulacja|podłączenie|wykonanie|przeróbka)/i, 'Robocizna'],
  [/otulin|izolac|peszel|taśma brzegow|folia/i, 'Izolacja'],
  [/ogrzewania podłogow|rozdzielacz podłogow|podłogówk|pe-?rt|pętl|listwa przyścienna|spinki|szyna montażowa/i, 'Ogrzewanie podłogowe'],
  [/c\.w\.u|cwu|zasobnik|cyrkulac|ciepłej wody|antyoparzeniow/i, 'Ciepła woda'],
  [/grzejnik|drabink|głowic|termostatyczn|zestaw przyłącz|zawór powrotny/i, 'Grzejniki i armatura'],
  [/kocioł|pompa ciepła|naczyni|sprzęgło|bufor|neutralizator|pompa obiegow|grupa pompow|zawór mieszając|rozdzielacz|filtr magnet|odmulacz|wymiennik|\bstb\b|termostat bezpiecz|komin|laddomat|zespół ładując/i, 'Źródło ciepła'],
  [/spawan|wspawan|do spawania|hamburs|bez szwu|ze szwem|stal(owa)? czarn/i, 'Stal czarna spawana'],
  [/pp-?r\b|pp-r/i, 'PP-R zgrzewany'],
  [/pe-?x\/al.*skręc|skręcan.*pe-?x/i, 'PE-X/Al skręcana'],
  [/pe-?x|pex/i, 'PE-X/Al zaprasowywana'],
  [/miedź|miedzian/i, 'Miedź zaciskana'],
  [/ocynk.*gwint|gwint.*ocynk/i, 'Ocynk gwintowany'],
  [/stal.*(press|zaciskan)|ocynkowana.*press/i, 'Stal węglowa zaciskana'],
  [/mosiądz|mosiężn/i, 'Mosiądz gwintowany'],
  [/kanaliz|pvc|syfon|wpust/i, 'Kanalizacja PVC/PP'],
  [/zawór|kurek|filtr|reduktor|manometr|termometr|odpowietrznik|złączka|śrubunek/i, 'Armatura'],
];
function katalogDzial(nazwa, cat) {
  const n = String(nazwa || '');
  const r = KATALOG_DZIALY.find(d => d[0].test(n));
  if (r) return r[1];
  return cat === 'rob' ? 'Robocizna' : 'Moje pozycje';
}
/* Własne pozycje, które dotąd lądowały hurtem w „Moje pozycje”, raz
   porządkujemy po nazwie. Pozycja dalej jest „własna” (id c…), więc da się
   ją edytować i usunąć tak jak wcześniej. */
function katalogPorzadkuj(list) {
  let ile = 0;
  (list || []).forEach(c => {
    if (!c || c.grp !== 'Moje pozycje' || !/^c\d/.test(String(c.id || ''))) return;
    if (!c.name || c.name === 'Nowa pozycja') return;
    const g = katalogDzial(c.name, c.cat);
    if (g !== 'Moje pozycje') { c.grp = g; ile++; }
  });
  return ile;
}

function blankItem() {
  return { name: 'Pozycja własna', unit: 'szt', cat: 'mat', price: 0, tag: null, qty: 1 };
}

/* ============================================================
   ROZPOZNAWANIE POZYCJI WPISANYCH RĘCZNIE
   ------------------------------------------------------------
   Pozycja z katalogu ma swój tag. Pozycję wpisaną ręcznie trzeba
   rozpoznać po nazwie, inaczej kontrola kompletności jej nie widzi.

   ZASADA BEZPIECZEŃSTWA: błędne rozpoznanie ma co najwyżej DODAĆ
   ostrzeżenie, nigdy go nie ukryć. Dlatego tagi występujące w polu
   `missing` reguł (izolacja, kształtki, zawory, naczynia, próba…)
   dopasowujemy wąsko i konkretnie, a tagi z pola `when` (rura,
   grzejnik, kocioł) szerzej. Fałszywe trafienie na „rurę" doda
   przypomnienie o izolacji — fałszywe trafienie na „izolację"
   ukryłoby je, a tego nie wolno.
   ============================================================ */
const TAG_HINTS = [
  // --- wąsko: te tagi wyciszają ostrzeżenia ---
  ['izolacja',       /otulin|izolacj[ai]|termoizolac|peszel/i],
  ['ksztaltka',      /kolan[ako]|trójnik|trojnik|złącz|zlacz|mufa|redukcj|nypel|śrubunek|srubunek|kształtk|ksztaltk/i],
  ['zawor_term',     /(zaw[oó]r|głowic|glowic).*(termostat)|termostatyczn/i],
  ['zawor_odc',      /(zaw[oó]r).*(odcinaj|powrotn|kulow)/i],
  ['zestaw_grz',     /zestaw.*(przy[łl][ąa]czeniow|grzejnik)/i],
  ['naczynie_cwu',   /naczyni.*(c\.?w\.?u|wod[yaę] pitn|pzh)/i],
  ['zawor_bezp_cwu', /(zaw[oó]r).*(bezpiecze[ńn]stw).*(c\.?w\.?u|6 ?bar)/i],
  ['naczynie',       /naczyni.*(wzbiorcz|przepon)|wzbiorcz/i],
  ['zawor_bezp',     /(zaw[oó]r).*(bezpiecze[ńn]stw)/i],
  ['proba',          /pr[óo]b[ay].*(szczelno|ci[śs]nien)|szczelno[śs]ci/i],
  ['uruchomienie',   /uruchomien|regulacj[ai].*(instalacj|układ)|rozruch/i],
  ['transport',      /dojazd|transport|delegacj|kilometr/i],
  ['montaz_grz',     /monta[żz].*grzejnik|grzejnik.*monta[żz]|zawieszen.*grzejnik/i],
  ['montaz_rur',     /monta[żz].*(rur|rurociąg|rurociag)|u[łl]o[żz]eni.*rur|prowadzeni.*rur/i],
  ['bruzdy',         /bruzd|kucie|sztrab|przekuci/i],
  ['montaz_kociol',  /monta[żz].*(kot[łl]|pomp[yaę] ciep[łl])|pod[łl][ąa]czeni.*kot[łl]/i],
  ['montaz_zasob',   /monta[żz].*(zasobnik|podgrzewacz|bojler)/i],
  ['rozdzielacz',    /rozdzielacz|szafk[aię].*rozdziel/i],
  ['filtr',          /filtr|odmulacz|separator|magnetyzer/i],
  ['pompa',          /pomp[aeęy] obiegow|obiegow[aej].*pomp/i],
  ['mieszacz',       /(zaw[oó]r).*(mieszaj|mieszacz)|mieszacz/i],
  // --- szerzej: te tagi tylko włączają ostrzeżenia ---
  ['zasobnik',       /zasobnik|podgrzewacz|bojler|zbiornik.*c\.?w\.?u/i],
  ['kociol',         /kocio[łl]|kot[łl][aey]|pomp[aeęy] ciep[łl]|piec\b|[źz]r[óo]d[łl]o ciep[łl]/i],
  ['grzejnik',       /grzejnik|kaloryfer|drabink|konwektor|ogrzewani.*pod[łl]ogow|p[ęe]tl[ae].*pod[łl]ogow/i],
  ['rura',           /\brur[aoyęi]?\b|rurociąg|rurociag|pe-?x|\bpert\b|miedzian|polipropylen|\bpp\b|preizolow|wielowarstwow/i],
];

/* Zwraca rozpoznany tag albo null. Kolejność w TAG_HINTS ma znaczenie:
   pierwszy pasujący wygrywa, a bardziej szczegółowe wzorce są wyżej
   (np. „naczynie do c.w.u." przed ogólnym „naczynie"). */
function guessTag(name) {
  const n = String(name || '');
  if (n.trim().length < 3) return null;
  for (const [tag, re] of TAG_HINTS) if (re.test(n)) return tag;
  return null;
}

/* Zgadywanie, czy pozycja to robocizna — używane tylko dopóki
   użytkownik sam nie przełączy plakietki. */
const LABOUR_RE = /monta[żz]|robocizn|us[łl]ug|wykonani|demonta[żz]|przekuci|bruzdowan|uruchomien|pr[óo]b[ay] szczel|dojazd|transport|regulacj|serwis|przer[óo]bk/i;
function guessCat(name) {
  return LABOUR_RE.test(String(name || '')) ? 'rob' : 'mat';
}

function sampleOffer() {
  /* Brak pozycji pomijamy zamiast wywracać aplikację. Przykładowa oferta
     to dekoracja pierwszego uruchomienia — jeśli kiedyś zniknie z bazy
     któraś z jej pozycji, ma zniknąć ta jedna linijka, a nie cały ekran. */
  const pick = (id, qty) => {
    const c = catalogById(id);
    return c ? itemFromCatalog(c, qty) : null;
  };
  return {
    id: 'demo',
    number: '001/' + new Date().getFullYear(),
    date: todayISO(),
    sample: true,
    client: { name: 'Jan Kowalski (przykład)', address: 'ul. Polna 12, Warszawa',
              phone: '600 100 200', email: 'jan.kowalski@example.com' },
    items: [pick('g1', 4), pick('g4', 4), pick('peal-rura-20', 60),
            pick('p1', 4), pick('p2', 60)].filter(Boolean),
    marginPct: 15,
    vatRate: 0.08,
    notes: 'Oferta ważna 30 dni. Termin realizacji do uzgodnienia.',
  };
}

function blankOffer(list, s) {
  const set = s || DEFAULT_SETTINGS;
  return {
    id: 'o' + Date.now(),
    number: nextNumber(list, set.numberPrefix),
    date: todayISO(),
    client: { name: '', address: '', phone: '', email: '', nip: '', type: 'osoba' },
    invoice: null,
    items: [],
    marginPct: set.marginPct,
    vatRate: set.vatRate,
    notes: set.terms,
  };
}


/* ============================================================
   FAKTURA NA PODSTAWIE OFERTY
   ------------------------------------------------------------
   Faktura nie jest osobnym dokumentem tworzonym od zera — powstaje
   z zatwierdzonej oferty, żeby nie przepisywać pozycji po raz drugi.
   Oferta zostaje nietknięta; faktura to dodatkowy zestaw pól przy niej.
   ============================================================ */

/* Numeracja roczna: FV/2026/007. Liczymy tylko faktury z bieżącego roku,
   bo numeracja zaczyna się od nowa 1 stycznia. */
function nextInvoiceNumber(list, prefix) {
  const p = (prefix || 'FV').trim() || 'FV';
  const year = new Date().getFullYear();
  const head = p + '/' + year + '/';
  let max = 0;
  (list || []).forEach(o => {
    const n = o.invoice && o.invoice.number;
    if (n && n.indexOf(head) === 0) {
      const k = parseInt(n.slice(head.length), 10);
      if (k > max) max = k;
    }
  });
  return head + String(max + 1).padStart(3, '0');
}

const addDaysISO = (iso, days) => {
  const d = new Date(iso + 'T00:00:00');
  d.setDate(d.getDate() + (Number(days) || 0));
  return d.toISOString().slice(0, 10);
};

function makeInvoice(offer, list, s) {
  const set = s || DEFAULT_SETTINGS;
  const today = todayISO();
  return {
    number: nextInvoiceNumber(list, set.invPrefix),
    issue: today,          /* data wystawienia          */
    sale: today,           /* data dokonania dostawy    */
    dueDays: set.payDays,
    method: set.payMethod,
    paid: false,
    paidAt: '',            /* data zapłaty — bez niej znacznik zapłaty
                              nie przechodzi walidacji schematu KSeF */
    footer: set.invFooter || '',
  };
}

/* Czy ta sprzedaż w ogóle podlega KSeF.
   Faktury konsumenckie (dla osób fizycznych nieprowadzących działalności)
   są wyłączone z obowiązku — art. 106ga ust. 2 ustawy o VAT. */
const ksefApplies = offer => !!(offer && offer.client && offer.client.type === 'firma');

/* Braki, które trzeba uzupełnić, zanim faktura będzie dokumentem,
   a nie kartką. Zakres pól wg art. 106e ustawy o VAT. */
function invoiceIssues(offer, s) {
  const set = s || DEFAULT_SETTINGS;
  const out = [];
  if (!set.company) out.push({ level: 'blok', text: 'Brak nazwy Twojej firmy — uzupełnij w Ustawieniach.' });
  if (!set.nip) out.push({ level: 'blok', text: 'Brak Twojego NIP-u — uzupełnij w Ustawieniach.' });
  if (!set.address) out.push({ level: 'blok', text: 'Brak adresu Twojej firmy — uzupełnij w Ustawieniach.' });
  if (!offer.client.name) out.push({ level: 'blok', text: 'Brak nazwy nabywcy.' });
  if (!offer.client.address) out.push({ level: 'blok', text: 'Brak adresu nabywcy.' });
  if (offer.client.type === 'firma' && !offer.client.nip)
    out.push({ level: 'blok', text: 'Nabywca jest firmą, więc faktura musi mieć jego NIP.' });
  if (!(offer.items || []).length) out.push({ level: 'blok', text: 'Oferta nie ma żadnej pozycji.' });
  if ((offer.items || []).some(i => !(Number(i.price) > 0)))
    out.push({ level: 'uwaga', text: 'Część pozycji ma cenę zero — sprawdź, czy tak ma być.' });
  if (set.vatStatus === 'zwolniony' && !set.zwPodstawa)
    out.push({ level: 'uwaga', text: 'Przy zwolnieniu z VAT faktura musi podawać podstawę zwolnienia.' });
  if (!set.bank && (offer.invoice ? offer.invoice.method : set.payMethod) === 'przelew')
    out.push({ level: 'uwaga', text: 'Płatność przelewem, a w Ustawieniach nie ma numeru konta.' });
  return out;
}

/* Suma kontrolna NIP-u. Sprawdzamy ją zanim pójdziemy do wykazu —
   literówka w numerze to najczęstszy powód nieudanego pobrania danych,
   a wyłapać ją można bez internetu.
   Wagi 6,5,7,2,3,4,5,6,7; ostatnia cyfra to reszta z dzielenia przez 11. */
function nipValid(nip) {
  const n = String(nip || '').replace(/[^0-9]/g, '');
  if (n.length !== 10) return false;
  /* Same zera przechodzą sumę kontrolną, a NIP-em nie są. */
  if (/^(\d)\1{9}$/.test(n)) return false;
  const w = [6, 5, 7, 2, 3, 4, 5, 6, 7];
  let sum = 0;
  for (let i = 0; i < 9; i++) sum += w[i] * Number(n[i]);
  const k = sum % 11;
  return k !== 10 && k === Number(n[9]);
}


