/* ===== projekty.js ===== */
/* ============================================================
   BIURO → PROJEKTY
   ------------------------------------------------------------
   Projekt to teczka jednej budowy. W środku są części — ogrzewanie
   podłogowe, ogrzewanie grzejnikowe i schemat kotłowni — każda z danymi
   z kalkulatora i z własnym zestawieniem elementów, a obok oferty
   i faktury tej budowy.

   Część edytuje się w jej kalkulatorze. Kalkulator otwarty z projektu
   jest z nim połączony: każda zmiana zapisuje się w tej części sama,
   aż do „Odłącz” albo do otwarcia innego projektu.

   Zapis (ai_projekty_v1):
   { id, nazwa, adres, notatki, klient, utw, zm, ofertaId,
     czesci: { podl|grz|kot: { mode, v } },
     zest:   { podl|grz|kot: { zm, dod, wyb } } }
   ============================================================ */

const PROJ_KEY = 'ai_projekty_v1';
const PROJ_CZESCI = [
  { c: 'podl', calc: 'rozdz_dia', nazwa: 'Ogrzewanie podłogowe', ikona: 'floor' },
  { c: 'grz', calc: 'co_dia', nazwa: 'Ogrzewanie grzejnikowe', ikona: 'layers' },
  { c: 'kot', calc: 'kotlownia', nazwa: 'Schemat kotłowni', ikona: 'kotlownia' },
];
/* Części tego samego rodzaju może być kilka — kolejne obiegi: grz, grz2,
   grz3… Rodzaj to klucz bez numeru; nazwa dostaje numer od drugiej. */
const projTyp = c => String(c).replace(/\d+$/, '');
const projCz = c => {
  const b = PROJ_CZESCI.find(x => x.c === projTyp(c));
  if (!b) return undefined;
  const n = String(c).slice(b.c.length);
  return n ? Object.assign({}, b, { c, nazwa: b.nazwa + ' ' + n }) : b;
};
const projCzNr = c => +String(c).slice(projTyp(c).length) || 1;
// wszystkie części danego rodzaju w projekcie: podstawowa, 2, 3…
const projCzesciTypu = (p, typ) => Object.keys((p && p.czesci) || {}).filter(k => projTyp(k) === typ).sort((a, b) => projCzNr(a) - projCzNr(b));
const projCzesciWszystkie = p => PROJ_CZESCI.reduce((a, b) => a.concat(projCzesciTypu(p, b.c)), []);
// klucz dla kolejnego obiegu tego rodzaju
const projWolnaCz = (p, typ) => { if (!p.czesci[typ]) return typ; let n = 2; while (p.czesci[typ + n]) n++; return typ + n; };
const projCzCalc = calcId => PROJ_CZESCI.find(x => x.calc === calcId);

/* Projekty z poprzedniej wersji (osobny projekt na każdą rzecz)
   przechodzą na teczki z jedną częścią. */
function projMigracja(p) {
  if (p.czesci) return p;
  p.czesci = {}; p.zest = {};
  const c = p.typ === 'grz' || p.typ === 'podl' ? p.typ : 'kot';
  if (p.kalk) p.czesci[c] = { mode: p.kalk.mode, v: p.kalk.v };
  else if (p.kotlownia) p.czesci.kot = { mode: '_', v: p.kotlownia };
  p.zest[c] = { zm: p.zestZm || {}, dod: p.zestDod || [], wyb: p.zestWyb || {} };
  ['typ', 'kalk', 'kotlownia', 'zestZm', 'zestDod', 'zestWyb'].forEach(k => { delete p[k]; });
  return p;
}
function loadProjekty() {
  try { const l = JSON.parse(localStorage.getItem(PROJ_KEY) || '[]'); return Array.isArray(l) ? l.map(projMigracja) : []; }
  catch (e) { return []; }
}
function saveProjekty(l) {
  try { localStorage.setItem(PROJ_KEY, JSON.stringify(l)); } catch (e) { /* pełna pamięć — trudno */ }
}
state.projekty = loadProjekty();
state.projektId = null;        // projekt otwarty w Biurze
state.projAkt = {};            // kalkulator → { p: id projektu, c: część } — połączenie do autozapisu
state.projWybor = null;        // kalkulator, pod którym rozwinięto „Przenieś do projektu”
state.projUsun = false;        // pierwsze dotknięcie „Usuń projekt”
state.projUsunCz = null;       // pierwsze dotknięcie „Usuń część”
state.projOtwarte = {};        // rozwinięte zestawienia: część → true
state.projWrocDo = null;       // oferta otwarta z projektu — „wstecz” wraca do projektu
state.ktNowaPotw = false;      // pierwsze dotknięcie „Nowa kotłownia”
const persistProj = () => saveProjekty(state.projekty);
const currentProjekt = () => state.projekty.find(p => p.id === state.projektId);
const projKopia = o => JSON.parse(JSON.stringify(o || {}));
function projDzis() { return new Date().toISOString().slice(0, 10); }

/* Wartości części uzupełnione domyślnymi — mogła powstać w starszej
   wersji, w której części pól jeszcze nie było. */
function projCzWartosci(p, c) {
  const cz = projCz(c), calc = CALCS.find(x => x.id === cz.calc);
  const zap = p.czesci[c] || { mode: null, v: {} };
  const mode = calc.modes ? (calc.modes.find(m => m.key === zap.mode) || calc.modes[0]) : activeMode(calc);
  const d = {};
  fieldList(mode).forEach(f => { d[f.k] = (f.def && typeof f.def === 'object') ? projKopia(f.def) : f.def; });
  return { calc, mode, v: Object.assign(d, projKopia(zap.v)) };
}
/* Wynik kalkulatora dla części. Kotłowni nie liczymy przez compute,
   bo ten ma skutki uboczne w stanie kreatora. */
function projCzWynik(p, c) {
  const w = projCzWartosci(p, c);
  if (c === 'kot') return Object.assign(w, { res: {} });
  try { w.res = w.mode.compute(projKopia(w.v)); } catch (e) { w.res = { error: 'Uzupełnij dane w kalkulatorze.' }; }
  return w;
}
const ktKalk = () => CALCS.find(c => c.id === 'kotlownia');
const ktWartosci = () => { const c = ktKalk(); return getValues(c, activeMode(c)); };
function ktDomyslne() {
  const c = ktKalk(), d = {};
  fieldList(activeMode(c)).forEach(f => { d[f.k] = (f.def && typeof f.def === 'object') ? projKopia(f.def) : f.def; });
  return d;
}

function nowyProjekt() {
  const nr = state.projekty.length + 1;
  const p = {
    id: 'p' + Date.now(), nazwa: 'Projekt ' + nr, adres: '', notatki: '',
    klient: { name: '', address: '', phone: '', email: '' },
    utw: projDzis(), zm: projDzis(), czesci: {}, zest: {}, ofertaId: null,
  };
  state.projekty.unshift(p);
  persistProj();
  return p;
}
function projUstawCzesc(p, c, mode, v) {
  const nowaKot = c === 'kot' && !p.czesci.kot;
  p.czesci[c] = { mode, v: projKopia(v) };
  if (!p.zest[c]) p.zest[c] = { zm: {}, dod: [], wyb: {} };
  p.zm = projDzis();
  // obiegi grzewcze projektu → schemat kotłowni (sam się aktualizuje)
  if (projTyp(c) === 'grz' || projTyp(c) === 'podl') projSyncKot(p, projTyp(c));
  else if (nowaKot) { projSyncKot(p, 'grz'); projSyncKot(p, 'podl'); }
  persistProj();
}

/* Schemat kotłowni projektu bierze obiegi z części projektu: każda część
   grzejnikowa i podłogowa to osobny obieg. Aktualizujemy tylko wtedy,
   gdy części się zmieniły od ostatniego razu — ręczne poprawki w kotłowni
   (mieszacz, nazwa, pompa) zostają, dopóki nie zmienisz samych obiegów. */
function projSyncKot(p, typ) {
  if (!p || !p.czesci || !p.czesci.kot || typeof ktZKalkulatora !== 'function') return false;
  const czesci = projCzesciTypu(p, typ);
  let nowe = [];
  // każdy obieg pamięta, z której części projektu pochodzi (zP)
  try { nowe = czesci.reduce((a, c) => { const cw = projCzWartosci(p, c); return a.concat(ktZKalkulatora(cw.calc.id, cw.v, cw.mode.key).map(o => Object.assign(o, { zP: c }))); }, []); }
  catch (e) { return false; }
  const v = p.czesci.kot.v || (p.czesci.kot.v = {});
  const ob = Array.isArray(v.ob) ? v.ob : [];
  const odswiezKreator = () => {
    const a = state.projAkt && state.projAkt.kotlownia;
    if (a && a.p === p.id && typeof ktKalk === 'function') { const kot = ktKalk(); getValues(kot, activeMode(kot)).ob = projKopia(v.ob); saveCalcValues(); }
  };
  if (!nowe.length) {
    /* Nie ma już części tego rodzaju — znikają obiegi, które z nich przyszły.
       Obiegi wpisane ręcznie w kotłowni zostają. */
    const oznaczone = ob.some(o => o.r === typ && o.zP);
    const zProj = o => o.r === typ && (o.zP || (!oznaczone && p.ktSync && p.ktSync[typ]));
    if (!ob.some(zProj)) return false;
    v.ob = ob.filter(o => !zProj(o));
    odswiezKreator();
    return true;
  }
  /* Obiegi z części mają znacznik zP. Dopóki żaden obieg tego rodzaju go
     nie ma (starsza wersja, „Przenieś do Schematu kotłowni”), wszystkie
     traktujemy jak pochodzące z projektu. Gdy znaczniki już są, obiegi bez
     znacznika to dopisane ręcznie w kotłowni — zostają. */
  const oznaczone = ob.filter(o => o.r === typ && o.zP);
  const stare = oznaczone.length ? oznaczone : ob.filter(o => o.r === typ);
  const reczne = oznaczone.length ? ob.filter(o => o.r === typ && !o.zP) : [];
  /* Porównujemy z tym, co naprawdę jest w kotłowni — tyle samo obiegów,
     te same moce, przepływy i dane z kalkulatora — a nie z zapamiętanym
     stanem: kotłownię mogło w międzyczasie nadpisać „Zastąp” z kreatora. */
  const klucz = o => [o.kw, o.dl || 0, o.dp || 0, o.wyj || 0, o.rk && o.rk.q ? +o.rk.q.toFixed(4) : 0, o.rk ? o.rk.p : '', o.zP || '', JSON.stringify(o.rozd || null)].join('|');
  const pod = o => o.r === 'podl' ? (o.m != null ? +o.m : 1) : null;
  if (stare.length === nowe.length && nowe.every((o, i) => klucz(o) === klucz(stare[i]) && (o.r !== 'podl' || pod(o) === pod(stare[i]))
      && (!o.n || o.n === stare[i].n) && (!o.hP || o.hP === stare[i].hP || stare[i].hPz === 'pump'))) return false;
  const zCzesci = nowe.map((o, i) => {
    const s = stare[i];
    const r = { r: o.r, m: o.r === 'grz' ? (s ? s.m : 0) : (o.m != null ? o.m : 1), n: o.n || (s && s.n) || '', kw: o.kw,
      dl: o.dl || 0, dp: o.dp || 0, wyj: o.wyj || 0, hP: o.hP || 0, qP: o.qP || 0, rk: o.rk || null, zP: o.zP, rozd: o.rozd || null };
    if (o.hPz) r.hPz = o.hPz;
    // pompa dobrana ręcznie („Dobór pompy”) zostaje, dopóki moc obiegu się nie zmieni
    if (s && s.hP && s.kw === r.kw && (s.hPz === 'pump' || !r.hP)) { r.hP = s.hP; r.qP = s.qP; if (s.hPz) r.hPz = s.hPz; else delete r.hPz; }
    return r;
  });
  v.ob = ob.filter(o => o.r !== typ).concat(zCzesci, reczne).sort((a, b) => (a.r === 'grz' ? 0 : 1) - (b.r === 'grz' ? 0 : 1));
  odswiezKreator();   // kreator otwarty na tej kotłowni — widzi zmianę od razu
  return true;
}

/* Otwarcie części w jej kalkulatorze — od tej chwili kalkulator pisze
   prosto do projektu. Bieżące wpisy kalkulatora zostają zastąpione. */
/* Edycja części z projektu podmienia wpisy w kalkulatorze. Zapamiętujemy,
   co było w kalkulatorze wcześniej, żeby po otwarciu go „na nowo” z listy
   kalkulatorów wróciło to, co było — bez projektu i bez autozapisu. */
state.projKalkPrzed = {};
function projZapamietajKalk(calcId, modeKey) {
  if (state.projKalkPrzed[calcId]) return;          // już jesteśmy w edycji z projektu — pierwotne wpisy są zapisane
  state.projKalkPrzed[calcId] = { mode: state.mode[calcId], key: vkey(calcId, modeKey),
    v: state.values[vkey(calcId, modeKey)] ? projKopia(state.values[vkey(calcId, modeKey)]) : null };
}
function projPrzywrocKalk(calcId) {
  const a = state.projAkt[calcId];
  if (!a) return false;
  delete state.projAkt[calcId];
  const b = state.projKalkPrzed[calcId];
  delete state.projKalkPrzed[calcId];
  if (b) {
    if (b.v) state.values[b.key] = b.v; else delete state.values[b.key];
    if (b.mode === undefined) delete state.mode[calcId]; else state.mode[calcId] = b.mode;
  }
  saveCalcValues();
  return true;
}
function projDoKalk(p, c) {
  if (c === 'kot' && (projSyncKot(p, 'grz') | projSyncKot(p, 'podl'))) persistProj();
  const { calc, mode, v } = projCzWartosci(p, c);
  projZapamietajKalk(calc.id, mode.key);
  if (calc.modes) state.mode[calc.id] = mode.key;
  state.values[vkey(calc.id, mode.key)] = v;
  saveCalcValues();
  state.projAkt[calc.id] = { p: p.id, c };
  state.tab = 'calc'; state.calc = calc.id; state.screen = 'calc';
  render(true);
}
/* Wołane przy każdym przeliczeniu kalkulatora: zapis do połączonej części. */
function projZapiszZKalk(calcId, modeKey, v) {
  const a = state.projAkt[calcId];
  if (!a) return null;
  const p = state.projekty.find(x => x.id === a.p);
  if (!p) { delete state.projAkt[calcId]; return null; }
  projUstawCzesc(p, a.c, modeKey, v);
  return p;
}

/* Opis części jednym zdaniem. */
function projOpisCz(p, c) {
  const zap = p.czesci[c];
  if (!zap) return '';
  const v = zap.v || {};
  try {
    if (projTyp(c) === 'grz') {
      const n = (v.rad || []).filter(x => Number(x) > 0).length;
      const W = (v.rad || []).reduce((a, x) => a + (Number(x) || 0), 0);
      return (zap.mode === 'rozdz' ? 'z rozdzielacza' : 'trójnikowo') + ' · ' + n + ' ' + odmiana(n, 'grzejnik', 'grzejniki', 'grzejników') + ' · ' + fmt(W / 1000, 1) + ' kW';
    }
    if (projTyp(c) === 'podl') {
      const l = (v.rozdz || []).filter(r => Number(r.w) > 0);
      const W = l.reduce((a, r) => a + (Number(r.w) || 0), 0);
      const wyj = l.reduce((a, r) => a + (Number(r.wyj) || 0), 0);
      return l.length + ' ' + odmiana(l.length, 'rozdzielacz', 'rozdzielacze', 'rozdzielaczy') + ' · ' + wyj + ' ' + odmiana(wyj, 'pętla', 'pętle', 'pętli') + ' · ' + fmt(W / 1000, 1) + ' kW';
    }
    const k = ktKonfig(projCzWartosci(p, 'kot').v);
    const zr = { k1: 'kocioł gazowy 1F', k2: 'kocioł gazowy 2F', pc: 'pompa ciepła', pcs: 'pompa ciepła split',
      pel: 'kocioł na pellet', weg: 'kocioł węglowy', drew: 'zgazowanie drewna' }[k.zr] || '';
    const D = ktDobor(k);
    return zr + (D ? ' ≈ ' + D.pDob + ' kW' : '') + ' · ' + k.obiegi.length + ' ' + odmiana(k.obiegi.length, 'obieg', 'obiegi', 'obiegów')
      + (k.cwu === 'zas' ? ' · zasobnik ' + k.zasL + ' l' : '');
  } catch (e) { return ''; }
}
/* Na kartę w liście projektów. */
function projOpis(p) {
  const cz = PROJ_CZESCI.map(x => { const n = projCzesciTypu(p, x.c).length; return n ? ({ podl: 'podłogówka', grz: 'grzejniki', kot: 'kotłownia' })[x.c] + (n > 1 ? ' ×' + n : '') : ''; }).filter(Boolean);
  return cz.length ? cz.join(' · ') : 'pusty — dodaj części';
}
/* ============================================================
   ZESTAWIENIE ELEMENTÓW ZE SCHEMATU
   ------------------------------------------------------------
   Tylko to, co da się policzyć ze schematu — rury i kształtki liczą
   się w swoich kalkulatorach. Cena z cennika wchodzi wtedy, gdy wpis
   pasuje i rodzajem, i rozmiarem (naczynie 12 l nie dostanie ceny
   naczynia 25 l); reszta trafia do oferty z ceną 0 do uzupełnienia.
   ============================================================ */
function projZestawienie(v) {
  const k = ktKonfig(v), D = ktDobor(k);
  const L = [];
  const dodaj = (name, qty, o) => { if (qty > 0) L.push(Object.assign({ name, qty, unit: 'szt', cat: 'mat', tag: null, wzor: null, wyl: false }, o || {})); };
  const kw = D ? ' ≈ ' + D.pDob + ' kW' : '';
  const zrNazwa = { k1: 'Kocioł gazowy kondensacyjny jednofunkcyjny', k2: 'Kocioł gazowy kondensacyjny dwufunkcyjny',
    pc: 'Pompa ciepła powietrze-woda (monoblok)', pcs: 'Pompa ciepła powietrze-woda (split)',
    pel: 'Kocioł na pellet z podajnikiem', weg: 'Kocioł węglowy retortowy', drew: 'Kocioł zgazowujący drewno' }[k.zr];
  dodaj(zrNazwa + kw, 1, { tag: 'kociol', wzor: D && k.gaz ? new RegExp('kocioł gazowy.*\\b' + D.pDob + ' ?kw', 'i') : null });

  if (k.rozdz === 'sprz') dodaj('Sprzęgło hydrauliczne' + (D ? ' ' + D.dn[1] + ', do ' + fmt(D.dn[2], 1) + ' m³/h' : ''), 1);
  if (k.rozdz === 'buf') {
    const poj = D && D.vbDob ? +String(D.vbDob).replace('2 × ', '') : 0;
    dodaj('Bufor (zbiornik akumulacyjny)' + (poj ? ' ' + poj + ' l' : ''), k.bufy === 2 || (D && D.vbN === 2) ? 2 : 1, { wzor: poj ? new RegExp('bufor.*\\b' + poj + ' ?l', 'i') : null });
  }
  if (k.rozdz === 'wym') dodaj('Wymiennik płytowy', 1);
  if (k.obiegi.length > 1 && k.grp !== 'szaf') dodaj('Rozdzielacz obiegów (belka zasilania i powrotu)', 1);

  if (k.cwu === 'zas') {
    dodaj('Zasobnik c.w.u. z wężownicą ' + k.zasL + ' l', 1, { tag: 'zasobnik', wzor: new RegExp('zasobnik.*\\b' + k.zasL + ' ?l', 'i') });
    if (D && D.nacCwu) dodaj('Naczynie przeponowe c.w.u. ' + D.nacCwu.rec + ' l (do wody pitnej)', 1, { tag: 'naczynie_cwu', wzor: new RegExp('\\b' + D.nacCwu.rec + ' ?l', 'i') });
    dodaj('Zawór bezpieczeństwa c.w.u. 6 bar', 1, { tag: 'zawor_bezp_cwu', wzor: /6 ?bar/i });
    dodaj('Reduktor ciśnienia wody', 1);
    dodaj('Zawór zwrotny na zimnej wodzie', 1);
    if (k.cyrk) dodaj('Pompa cyrkulacyjna c.w.u. (do wody pitnej)', 1);
  }
  if (D && D.nac) {
    const ile = k.gaz ? D.nacDod : D.nac.rec;
    if (ile) dodaj('Naczynie wzbiorcze przeponowe c.o. ' + ile + ' l', 1, { tag: 'naczynie', wzor: new RegExp('c\\.o\\..*\\b' + ile + ' ?l', 'i') });
  }
  if (D && D.vOtw) dodaj('Naczynie wzbiorcze otwarte ≥ ' + D.vOtw + ' l', 1);
  if (!k.gaz && !k.split && !k.otw) dodaj('Zawór bezpieczeństwa c.o. ' + (k.stale ? '2,5' : '3') + ' bar', 1, { tag: 'zawor_bezp', wzor: new RegExp((k.stale ? '2,5' : '3') + ' ?bar', 'i') });
  if (k.stale) {
    dodaj('Separator zanieczyszczeń (odmulacz)', 1);
    dodaj(k.ochr === 'ladd' ? 'Zespół ładujący kotła (laddomat)' : 'Zawór termostatyczny ochrony powrotu', 1);
    if (!k.otw) dodaj('Zawór termiczny do wężownicy schładzającej', 1);
  } else dodaj('Filtr magnetyczny', 1, { tag: 'filtr', wzor: /magnetyczn/i });
  if (k.gaz) dodaj('Neutralizator kondensatu', 1);
  dodaj('Manometr i termometry (komplet)', 1);

  // pompy — pogrupowane po klasie
  if (D) {
    const kl = {};
    D.pompy.filter(Boolean).concat(D.pompyZr.filter(p => p.kl !== 'cyrkulacyjna')).forEach(p => { kl[p.kl] = (kl[p.kl] || 0) + 1; });
    Object.keys(kl).forEach(c => dodaj('Pompa obiegowa elektroniczna ' + c, kl[c], { tag: 'pompa', wzor: /pompa obiegowa/i }));
    const zw = {};
    D.zawory.filter(Boolean).forEach(z => { const n = 'Kvs ' + String(z.kvs).replace('.', ',') + ' ' + z.pick.dn.replace(' ', ''); zw[n] = (zw[n] || 0) + 1; });
    Object.keys(zw).forEach(n => dodaj('Zawór mieszający 3-drogowy ' + n + ' z siłownikiem', zw[n]));
  } else {
    const ile = k.obiegi.length > 1 || k.rozdz !== 'brak' ? k.obiegi.length : 0;
    dodaj('Pompa obiegowa elektroniczna', ile, { tag: 'pompa', wzor: /pompa obiegowa/i });
    dodaj('Zawór mieszający 3-drogowy z siłownikiem', k.obiegi.filter(o => o === 'grzM' || o === 'podlM').length);
  }
  const grupy = k.obiegi.length > 1 || k.rozdz !== 'brak' ? k.obiegi.length : 0;
  dodaj('Zawór kulowy odcinający', 2 + grupy * (k.stale ? 2 : 4) + (k.cwu === 'zas' ? 2 : 0), { tag: 'zawor_odc' });
  dodaj('Zawór zwrotny', grupy + (k.stale ? 1 : 0));
  if (k.stale) dodaj('Filtr siatkowy', grupy + 1 + (k.cwu === 'zas' ? 1 : 0));
  dodaj('Termostat bezpieczeństwa (STB) podłogówki', k.obiegi.filter(o => o === 'podlM').length);

  // robocizna — domyślnie niezaznaczona
  dodaj('Montaż i podłączenie źródła ciepła', 1, { cat: 'rob', unit: 'kpl', tag: 'montaz_kociol', wyl: true });
  if (k.cwu === 'zas') dodaj('Montaż zasobnika c.w.u.', 1, { cat: 'rob', tag: 'montaz_zasob', wyl: true });
  dodaj('Próba szczelności instalacji', 1, { cat: 'rob', unit: 'kpl', tag: 'proba', wyl: true });
  dodaj('Uruchomienie i regulacja instalacji', 1, { cat: 'rob', unit: 'kpl', tag: 'uruchomienie', wyl: true });

  return projCeny(L);
}

/* Ceny z cennika: tag musi się zgadzać, a tam, gdzie liczy się rozmiar,
   także wzór w nazwie. Pozycje bez rozmiaru (zawór, filtr, pompa,
   robocizna) biorą cenę po samym tagu. */
const PROJ_BEZ_ROZMIARU = ['zawor_odc', 'filtr', 'pompa', 'zawor_term', 'zestaw_grz', 'rozdzielacz'];
function projCeny(L) {
  const kat = (typeof state !== 'undefined' && state.catalog) ? state.catalog : (typeof loadCatalog === 'function' ? loadCatalog() : []);
  L.forEach(it => {
    if (!it.tag) return;
    const c = kat.find(x => x.tag === it.tag && (!it.wzor || it.wzor.test(x.name)) && (it.wzor || it.cat === 'rob' || PROJ_BEZ_ROZMIARU.includes(it.tag)));
    if (c) { it.price = c.price; it.katId = c.id; it.zCennika = true; }
  });
  // pozycje bez tagu (rura, grupa pompowa…) — po tej samej nazwie, jeśli już są w katalogu
  L.forEach(it => {
    if (it.zCennika || typeof katalogKlucz !== 'function') return;
    const k = katalogKlucz(it.name);
    const c = kat.find(x => katalogKlucz(x.name) === k && Number(x.price) > 0);
    if (c) { it.price = c.price; it.katId = c.id; it.zCennika = true; }
  });
  return L;
}

/* ============================================================
   PDF PROJEKTU
   ------------------------------------------------------------
   Rysunek wchodzi jako obraz (JPEG z SVG przez canvas), a dobór,
   legenda z opisami i zestawienie — jako prawdziwy tekst.
   ============================================================ */
function ktSvgDoJpeg(svg, w, h, skala) {
  return new Promise((ok, zle) => {
    const img = new Image();
    img.onload = () => {
      try {
        const c = document.createElement('canvas');
        c.width = Math.round(w * skala); c.height = Math.round(h * skala);
        const x = c.getContext('2d');
        x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
        x.drawImage(img, 0, 0, c.width, c.height);
        const b64 = c.toDataURL('image/jpeg', 0.9).split(',')[1];
        ok({ bajty: pdfZB64(b64), w: c.width, h: c.height });
      } catch (e) { zle(e); }
    };
    img.onerror = zle;
    // osobny plik SVG musi mieć przestrzeń nazw — w HTML-u jej nie potrzeba
    const pelne = /xmlns=/.test(svg) ? svg : svg.replace('<svg ', '<svg xmlns="http://www.w3.org/2000/svg" ');
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(pelne);
  });
}

async function projPdf(v, tytul, p) {
  const k = ktKonfig(v), s = ktSchemat(k), D = s.D;
  // sam rysunek — bez tabeli doboru i legendy, te idą tekstem na kolejne strony
  const svgRys = s.rys.replace(/viewBox="0 0 ([\d.]+) ([\d.]+)" width="(\d+)" height="(\d+)"/,
    (_, w) => `viewBox="0 0 ${w} ${s.H0}" width="${w}" height="${s.H0}"`).replace(/font-family="Barlow, sans-serif"/, 'font-family="Arial, Helvetica, sans-serif"');
  const obraz = await ktSvgDoJpeg(svgRys, s.W, s.H0, 3);

  const R = SCHEMAT_A4_POZIOMO, M = 36;
  const cTusz = [0.08, 0.16, 0.23], cSzary = [0.42, 0.50, 0.56], cAkc = [0.90, 0.40, 0.10];
  const kk = pdfKartka(R);
  kk.nowa();
  kk.prostokat(0, 0, R.w, 4, cAkc);
  kk.tekst(M, M + 8, tytul, 15, true, cTusz);
  const kl = p && p.klient && p.klient.name ? p.klient.name : '';
  kk.tekst(M, M + 24, [kl, p && p.adres, 'data ' + new Date().toLocaleDateString('pl-PL')].filter(Boolean).join('  ·  '), 9, false, cSzary);
  const boxY = M + 36, boxH = R.h - boxY - 30, boxW = R.w - 2 * M;
  const sk = Math.min(boxW / obraz.w, boxH / obraz.h);
  kk.obraz(M + (boxW - obraz.w * sk) / 2, boxY, obraz.w * sk, obraz.h * sk, obraz);
  kk.tekst(M, R.h - 16, 'Asystent Instalatora — schemat poglądowy, nie zastępuje projektu instalacji.', 7.5, false, cSzary);

  // strony tekstowe
  const lin = (txt, rozm, gruba, kol, wcz) => {
    pdfZawin(txt, gruba ? FONT_POGRUBIONA : FONT_ZWYKLA, rozm, R.w - 2 * M - (wcz || 0)).forEach(w => {
      kk.miejsce(rozm + 5); kk.tekst(M + (wcz || 0), kk.y, w, rozm, gruba, kol); kk.y += rozm + 4;
    });
  };
  const naglowek = t => { kk.miejsce(40); kk.y += 10; kk.tekst(M, kk.y, t, 12, true, cTusz); kk.y += 6;
    kk.linia(M, kk.y, R.w - M, kk.y, 0.8, [0.85, 0.87, 0.89]); kk.y += 14; };
  kk.nowa(); kk.prostokat(0, 0, R.w, 4, cAkc); kk.y = M;
  kk.tekst(M, kk.y, tytul + ' — dobór i elementy', 13, true, cTusz); kk.y += 10;

  if (D) {
    naglowek('Dobór urządzeń (szacunek z wpisanych kW)');
    lin((k.pc ? 'Pompa ciepła' : 'Kocioł') + ': ≈ ' + D.pDob + ' kW — ' + D.opisP, 9, false, cTusz);
    if (k.rozdz === 'sprz') lin('Sprzęgło: do ' + fmt(D.dn[2], 1) + ' m³/h, ' + D.dn[1] + ', korpus ok. Ø' + D.dSprz + ' mm.', 9, false, cTusz);
    if (D.vbDob) lin('Bufor: ' + D.vbDob + ' l' + (D.wym ? ' (ok. Ø' + D.wym[0] + ' × ' + D.wym[1] + ' mm bez izolacji)' : '') + '. ' + D.opisB, 9, false, cTusz);
    if (D.nac) lin('Naczynie wzbiorcze c.o.: ' + (k.gaz ? (D.nacDod ? 'dodatkowe ' + D.nacDod + ' l obok fabrycznego' : 'fabryczne ' + D.nacFabr + ' l wystarczy') : D.nac.rec + ' l')
      + ', p₀ ' + fmt(D.p0, 1) + ' bar, zład ok. ' + D.zlad + ' l.', 9, false, cTusz);
    if (D.vOtw) lin('Naczynie otwarte: ≥ ' + D.vOtw + ' l.', 9, false, cTusz);
    if (D.nacCwu) lin('Naczynie c.w.u.: ' + D.nacCwu.rec + ' l, p₀ 3,5 bar.', 9, false, cTusz);
    if (D.V) lin('Zasobnik ' + D.V + ' l: nagrzanie 10→55 °C ok. ' + fmt(D.tNagrz, 0) + ' min (' + fmt(D.eCwu, 1) + ' kWh).', 9, false, cTusz);
    naglowek('Obiegi i pompy');
    k.obiegi.forEach((ob, i) => {
      const nz = k.nazwyOb[i];
      const n = (ob[0] === 'g' ? 'Grzejniki' : 'Podłogówka') + (nz.nazwa ? ' — ' + nz.nazwa : nz.nr ? ' ' + nz.nr : '');
      const z = D.zawory[i], pp = D.pompy[i];
      lin(n + ': ' + (k.kw[i] ? fmt(k.kw[i], 1) + ' kW, ' + fmt(D.prz[i], 2) + ' m³/h (Δt ' + D.dts[i] + ' K)' : 'bez wpisanej mocy')
        + (z ? ' · mieszacz Kvs ' + String(z.kvs).replace('.', ',') + ' ' + z.pick.dn : '')
        + (pp ? ' · pompa ' + pp.kl + ', nastawa ' + fmt(pp.H, 1) + ' m' + (pp.szac ? ' (szacunek)' : '') : ''), 9, false, cTusz);
    });
    D.pompyZr.forEach(pp => lin(pp.nazwa + ': ' + (pp.kl === 'cyrkulacyjna' ? 'pompa cyrkulacyjna do wody pitnej' : 'pompa ' + pp.kl + ', ' + fmt(pp.q, 2) + ' m³/h przy ' + fmt(pp.H, 1) + ' m')
      + (pp.szac ? ' (szacunek)' : ''), 9, false, cTusz));
  }
  naglowek('Elementy — numery jak na schemacie');
  s.el.forEach(e => {
    kk.miejsce(16);
    kk.prostokat(M, kk.y - 8, 14, 11, cAkc);
    const nr = String(e[0]);
    kk.tekst(M + 7 - pdfSzerokosc(nr, FONT_POGRUBIONA, 7) / 2, kk.y, nr, 7, true, [1, 1, 1]);
    lin(e[1], 9, true, cTusz, 22);
    lin(e[2], 8, false, cSzary, 22);
    kk.y += 3;
  });
  if (s.dod.length) {
    naglowek('Warto dołożyć');
    s.dod.forEach(e => { lin(e[0], 9, true, cTusz); lin(e[1], 8, false, cSzary); kk.y += 3; });
  }
  naglowek('Zestawienie elementów');
  (p ? projZestPelne(p, 'kot') : projZestawienie(v)).forEach(it => lin('- ' + it.name + ' — ' + it.qty + ' ' + it.unit + (it.cat === 'rob' ? ' (robocizna)' : ''), 9, false, cTusz));
  if (p && p.notatki) { naglowek('Notatki'); lin(p.notatki, 9, false, cTusz); }

  return pdfZloz(kk.strony, tytul, R);
}

function projZapiszPdf(v, p) {
  const tytul = 'Schemat kotłowni' + (p && p.nazwa ? ' — ' + p.nazwa : '');
  toast('Przygotowuję PDF…');
  projPdf(v, tytul, p).then(plik => {
    const nazwa = (tytul.replace(/[^\wąćęłńóśźżĄĆĘŁŃÓŚŹŻ -]+/g, '').trim().replace(/\s+/g, '_') || 'schemat') + '.pdf';
    if (typeof naTelefonie === 'function' && naTelefonie()) {
      wyslijPdfZTelefonu(nazwa, pdfDoB64(plik), { okno: 'Wyślij ' + nazwa },
        w => toast(w.ok ? 'Zapisano ' + nazwa + ' w Dokumentach.' : w.powod));
      return;
    }
    toast(pobierzPdfWPrzegladarce(nazwa, plik) ? 'Pobrano ' + nazwa + '.' : 'Przeglądarka nie pozwoliła zapisać pliku.');
  }).catch(() => toast('Nie udało się przygotować PDF.'));
}
