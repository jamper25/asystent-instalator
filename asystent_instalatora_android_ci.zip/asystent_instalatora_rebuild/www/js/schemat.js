/* ===== schemat.js ===== */
/* ============================================================
   PROJEKT POGLĄDOWY — schemat gałęzi rysowany z wyników doboru
   ------------------------------------------------------------
   Rysunek dla montera na budowę: kolejność odbiorników, średnica
   każdego odcinka i miejsca, w których średnica schodzi. Nie jest
   to projekt ani rzut budynku — nie ma tu skali ani rzeczywistego
   przebiegu rur, jest kolejność i średnice.

   Dane bierzemy z tych samych odcinków, które kalkulator już policzył,
   więc rysunek nie może pokazać nic innego niż tabela nad nim.

   Kształt danych:
     { rodzaj: 'co' | 'woda' | 'gaz',
       galazka: 'Ø 20x3.4'      — podpis gałązki do odbiornika (opcjonalny)
       zrodlo:  'źródło ciepła' — podpis skrzynki po lewej
       odcinki: [{ nazwa, srednica, opis, pod }] }

   Rysujemy w SVG ze stałym viewBox i pozwalamy przewijać w poziomie:
   przy ośmiu grzejnikach żaden telefon nie pomieści tego na szerokość,
   a ściskanie do ekranu zrobiłoby z podpisów mrówki.
   ============================================================ */

/* Grubość kreski rośnie razem ze średnicą — zejście z 32 na 25 widać,
   zanim się przeczyta podpis. Ograniczone z obu stron, żeby DN50 nie
   przykryło podpisów, a 16x2 nie zniknęło. */
function schematGrubosc(srednica) {
  const liczba = parseFloat(String(srednica).replace(/^[^\d]*/, '')) || 20;
  return Math.max(2.5, Math.min(9, liczba / 7));
}

/* ------------------------------------------------------------
   Rozdzielacz rysuje się inaczej niż gałąź: zamiast poziomej magistrali
   z odgałęzieniami jest grzebień — pionowa belka i wachlarz jednakowych
   nitek do odbiorników. Cała informacja siedzi w dojściu do rozdzielacza
   i w liczbie wyjść, bo nitki są równe.

   Woda dostaje dwa grzebienie, bo tak to wygląda na budowie: jeden na zimną,
   drugi na ciepłą, a między nimi zasobnik. Zimna zasila przybory i zasobnik,
   z zasobnika ciepła idzie na swój rozdzielacz i do tych samych przyborów,
   a od najdalszego podejścia wraca cyrkulacja.
   ------------------------------------------------------------ */
/* ------------------------------------------------------------
   Kilka rozdzielaczy podłogówki na jednym rysunku. Ten sam pomysł co przy
   gałęziach grzejnikowych: grzebienie jeden pod drugim, związane pionem od
   źródła, a przy źródle średnica odcinka wspólnego. Instalator dostaje jedną
   kartkę na całe mieszkanie zamiast trzech osobnych, które trzeba sobie
   składać w głowie — a to właśnie z niej odczytuje nastawy przy belce.
   ------------------------------------------------------------ */
/* Grupa pompowa na dojściu: zawór mieszający (z siłownikiem) i pompa,
   pod linią podpis — jaki zawór i jaka pompa. g = { mieszacz, pompa }. */
function schematGrupa(e, x, y, g, linia) {
  let xs = x;
  if (g.mieszacz) {
    e.push(`<path d="M${xs - 8} ${y - 6.5}L${xs - 8} ${y + 6.5}L${xs} ${y}ZM${xs + 8} ${y - 6.5}L${xs + 8} ${y + 6.5}L${xs} ${y}ZM${xs - 6.5} ${y + 8}L${xs + 6.5} ${y + 8}L${xs} ${y}Z" `
      + `fill="var(--surface)" stroke="var(--ink)" stroke-width="1.5" stroke-linejoin="round"/>`
      + `<path d="M${xs} ${y}V${y - 11}" stroke="var(--ink)" stroke-width="1.3"/>`
      + `<rect x="${xs - 7}" y="${y - 23}" width="14" height="12" rx="2" fill="var(--surface)" stroke="var(--ink)" stroke-width="1.3"/>`
      + `<text x="${xs}" y="${y - 13.6}" font-size="9" font-weight="700" text-anchor="middle" fill="var(--ink)">M</text>`);
    xs += 34;
  }
  if (g.pompa) {
    e.push(`<circle cx="${xs}" cy="${y}" r="9.5" fill="var(--surface)" stroke="var(--ink)" stroke-width="1.6"/>`
      + `<path d="M${xs - 4} ${y - 5.5}L${xs - 4} ${y + 5.5}L${xs + 6.5} ${y}Z" fill="var(--ink)"/>`);
  }
  const t = [g.mieszacz ? 'mieszacz ' + g.mieszacz : '', g.pompa ? 'pompa ' + g.pompa : ''].filter(Boolean);
  t.forEach((s, i) => linia(x - 10, y + 27 + i * 13, s));
}

function schematRozdzielacze(d) {
  const roz = (d.rozdzielacze || []).filter(r => r && (r.odcinki || []).length);
  if (!roz.length) return '';

  const WIERSZ = 46, ODSTEP = 86;
  const szerZnaku = (txt, px) => String(txt || '').length * px * 0.62;
  const podpisZrodla = d.zrodlo || 'kocioł';
  const szerZrodla = Math.max(52, Math.ceil(szerZnaku(podpisZrodla, 9.5) + 16));
  const gz = d.grupaZrodla || null;               // wspólna grupa mieszająca w kotłowni
  const maGrupy = roz.some(r => r.grupa);           // grupy przy rozdzielaczach
  const LZr = gz ? 185 : 34;
  const xPion = szerZrodla + LZr;
  const BELKA = xPion + 104 + (maGrupy ? 95 : 0);
  const NITKA = 104, PODPIS = 120;

  const cZas = '#D7443C', cAkc = 'var(--flame)';

  /* Wysokości liczymy z góry, bo pion wspólny musi sięgnąć od pierwszego
     grzebienia do ostatniego, a rysuje się go przed nimi. */
  const pasma = [];
  let y = 72;
  roz.forEach(r => {
    const N = r.odcinki.length;
    pasma.push({ r, N, yGora: y, ySr: y + ((N - 1) * WIERSZ) / 2 });
    y += (N - 1) * WIERSZ + ODSTEP;
  });
  const H = y - ODSTEP + 70;

  const najdluzszy = roz.reduce((a, r) => r.odcinki.reduce((b, o) => Math.max(b,
    szerZnaku(o.nazwa, 12),
    szerZnaku([o.srednica ? 'Ø ' + o.srednica : '', o.wlasna].filter(Boolean).join('  ·  '), 10.5)), a), 0);
  const W = Math.max(440, Math.ceil(BELKA + PODPIS + najdluzszy + 20));

  const e = [];
  const linia = (x1, y1, x2, y2, kolor, gr) =>
    e.push(`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${kolor}" `
      + `stroke-width="${gr}" stroke-linecap="butt"/>`);
  const tekst = (x, yy, s, o) => {
    o = o || {};
    e.push(`<text x="${x}" y="${yy}" font-size="${o.size || 11}" fill="${o.fill || 'var(--ink)'}" `
      + `text-anchor="${o.anchor || 'start'}" font-weight="${o.weight || 400}" `
      + `font-family="ui-monospace, SFMono-Regular, Menlo, monospace">${esc(s)}</text>`);
  };

  /* --- pion wspólny i źródło --- */
  const wsp = d.wspolny || {};
  const grWsp = schematGrubosc(wsp.srednica || '25');
  const yPierwszy = pasma[0].ySr, yOstatni = pasma[pasma.length - 1].ySr;
  const yZrodlo = (yPierwszy + yOstatni) / 2;
  linia(xPion, yPierwszy, xPion, yOstatni, cZas, grWsp);
  linia(xPion - LZr, yZrodlo, xPion, yZrodlo, cZas, grWsp);
  e.push(`<rect x="${xPion - LZr - szerZrodla}" y="${yZrodlo - 20}" width="${szerZrodla}" height="40" `
    + `rx="4" fill="var(--surface)" stroke="var(--ink)" stroke-width="1.6"/>`);
  tekst(xPion - LZr - szerZrodla / 2, yZrodlo + 4, podpisZrodla, { size: 9.5, anchor: 'middle' });
  if (gz) schematGrupa(e, xPion - LZr + 34, yZrodlo, gz,
    (x, yy, s) => tekst(x, yy, s, { size: 10.5, weight: 700, fill: cAkc }));
  if (wsp.srednica) {
    tekst(8, 22, 'Ø ' + wsp.srednica + ' — odcinek wspólny od źródła'
      + (wsp.opis ? '  ·  ' + wsp.opis : ''),
      { size: 11.5, weight: 700 });
  }

  pasma.forEach(p => {
    const { r, N, yGora, ySr } = p;
    const yDol = yGora + (N - 1) * WIERSZ;

    /* dojście od pionu do belki */
    linia(xPion, ySr, BELKA - 9, ySr, cZas, r.dojscie ? schematGrubosc(r.dojscie) : 4);
    e.push(`<circle cx="${xPion}" cy="${ySr}" r="4.5" fill="${cZas}"/>`);
    if (r.dojscie) tekst(r.grupa ? BELKA - 16 : (xPion + BELKA) / 2, ySr - 12, 'Ø ' + r.dojscie,
      { size: 11, weight: 700, anchor: r.grupa ? 'end' : 'middle', fill: cAkc });
    if (r.grupa) schematGrupa(e, xPion + 44, ySr, r.grupa,
      (x, yy, s) => tekst(x, yy, s, { size: 10.5, weight: 700, fill: cAkc }));

    e.push(`<rect x="${BELKA - 9}" y="${yGora - 20}" width="18" height="${(N - 1) * WIERSZ + 40}" `
      + `rx="9" fill="var(--surface)" stroke="var(--ink)" stroke-width="2"/>`);
    tekst(BELKA, yGora - 30, r.nazwa + '  ·  ' + N + ' ' + odmianaWyjsc(N),
      { size: 11.5, weight: 700, anchor: 'middle' });

    r.odcinki.forEach((o, i) => {
      const yy = yGora + i * WIERSZ;
      linia(BELKA + 9, yy, BELKA + NITKA, yy, cZas, 3);
      e.push(`<circle cx="${BELKA + NITKA}" cy="${yy}" r="7" fill="var(--surface)" `
        + `stroke="var(--ink)" stroke-width="1.6"/>`);
      e.push(`<circle cx="${BELKA + 26}" cy="${yy}" r="9" fill="${cAkc}"/>`);
      tekst(BELKA + 26, yy + 4, String(o.nr || (i + 1)),
        { size: 10.5, weight: 700, anchor: 'middle', fill: '#fff' });
      tekst(BELKA + PODPIS, yy - 2, o.nazwa, { size: 12, weight: 600 });
      const pod = [o.srednica ? 'Ø ' + o.srednica : '', o.wlasna].filter(Boolean).join('  ·  ');
      if (pod) tekst(BELKA + PODPIS, yy + 13, pod, { size: 10.5, fill: 'var(--ink-2)' });
    });
    void yDol;
  });

  return `<svg class="sch-fit" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" `
    + `aria-label="Schemat poglądowy rozdzielaczy podłogówki">${e.join('')}</svg>`;
}

function schematRozdzielacz(d) {
  const odc = (d.odcinki || []).filter(Boolean);
  const co = d.rodzaj === 'co';
  const N = odc.length;

  const WIERSZ = 46, GORA = 76, DOL = 56;
  /* Grzebień c.o. rysujemy ciaśniej niż wodny: nitki są krótsze, a podpisy
     bliżej belki. Rysunek mieści się wtedy na ekranie telefonu, a to on
     niesie nastawy rotametrów — przewijanie w bok byłoby tu najgorsze. */
  /* Pudełko źródła stoi na lewo od punktu LEWO, więc najpierw trzeba
     wiedzieć, jak szerokie będzie — inaczej „mieszacz" wychodzi poza
     krawędź rysunku i kończy się w połowie słowa. */
  const szerZnaku = (txt, px) => String(txt || '').length * px * 0.62;
  const podpisZrodla = d.zrodlo || 'kocioł';
  const szerZrodla = Math.max(46, Math.ceil(szerZnaku(podpisZrodla, 9.5) + 16));
  const grupa = co ? (d.grupa || null) : null;
  const LEWO = co ? szerZrodla + 10 : 66;
  const BELKA = co ? LEWO + 92 + (grupa ? 70 : 0) : 176;
  const NITKA = co ? 104 : 138;
  const PODPIS = co ? 120 : 154;
  const PRZERWA = 164;                       /* odstęp między grzebieniami */
  const cZimna = co ? '#D7443C' : 'var(--cat-water)';
  const cCiepla = '#D7443C';
  const cCyrk = '#B07A2A';
  const cAkc = 'var(--flame)';

  const yZimnaDol = GORA + (N - 1) * WIERSZ;
  const yCieplaGora = yZimnaDol + PRZERWA;
  const yCieplaDol = yCieplaGora + (N - 1) * WIERSZ;

  /* Szerokość rysunku rośnie z najdłuższym podpisem. Pismo jest o stałej
     szerokości znaku, więc długość tekstu da się policzyć, zamiast zgadywać
     — a bez tego podpis w rodzaju „Salon 1/2 · Ø 16x2 · 2,6 l/min" uciekał
     poza krawędź i kończył się w połowie liczby. */
  const szer = szerZnaku;
  const najdluzszy = odc.reduce((a, o) => Math.max(a,
    szer(o.nazwa, 12),
    szer([o.srednica ? 'Ø ' + o.srednica : '', o.wlasna].filter(Boolean).join('  ·  '), 10.5)), 0);
  /* Grzebień c.o. zwęża się do tego, co naprawdę trzeba narysować — przy
     czterech pętlach mieści się wtedy na telefonie bez przewijania w bok,
     a to on niesie nastawy, więc przewijanie byłoby tu najbardziej uciążliwe.
     Rysunek wody zostaje przy stałej szerokości: ma pod spodem długi podpis
     cyrkulacji, którego nie obejmuje ten rachunek. */
  const W = Math.max(co ? 420 : 780, Math.ceil(BELKA + PODPIS + najdluzszy + 20));
  const H = co
    ? GORA + (N - 1) * WIERSZ + DOL + (d.zasobnik ? 96 : 0)
    : yCieplaDol + DOL + 40;

  const e = [];
  const linia = (x1, y1, x2, y2, kolor, gr, kres) =>
    e.push(`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${kolor}" `
      + `stroke-width="${gr}"${kres ? ` stroke-dasharray="${kres}"` : ''} stroke-linecap="butt"/>`);
  const tekst = (x, y, s, o) => {
    o = o || {};
    e.push(`<text x="${x}" y="${y}" font-size="${o.size || 11}" fill="${o.fill || 'var(--ink)'}" `
      + `text-anchor="${o.anchor || 'start'}" font-weight="${o.weight || 400}" `
      + `font-family="ui-monospace, SFMono-Regular, Menlo, monospace">${esc(s)}</text>`);
  };

  /* Jeden grzebień: belka, podpis i nitki z numerami. */
  const grzebien = (yGora, kolor, podpis) => {
    const yDol = yGora + (N - 1) * WIERSZ;
    e.push(`<rect x="${BELKA - 9}" y="${yGora - 20}" width="18" height="${(N - 1) * WIERSZ + 40}" `
      + `rx="9" fill="var(--surface)" stroke="var(--ink)" stroke-width="2"/>`);
    tekst(BELKA, yGora - 30, podpis, { size: 11, weight: 600, anchor: 'middle' });
    odc.forEach((o, i) => {
      const y = yGora + i * WIERSZ;
      linia(BELKA + 9, y, BELKA + NITKA, y, kolor, 3);
      e.push(`<circle cx="${BELKA + NITKA}" cy="${y}" r="7" fill="var(--surface)" `
        + `stroke="var(--ink)" stroke-width="1.6"/>`);
      e.push(`<circle cx="${BELKA + 26}" cy="${y}" r="9" fill="${cAkc}"/>`);
      tekst(BELKA + 26, y + 4, String(o.nr || (i + 1)),
        { size: 10.5, weight: 700, anchor: 'middle', fill: '#fff' });
      tekst(BELKA + PODPIS, y - 2, o.nazwa, { size: 12, weight: 600 });
      const pod = [o.srednica ? 'Ø ' + o.srednica : '', o.wlasna].filter(Boolean).join('  ·  ');
      if (pod) tekst(BELKA + PODPIS, y + 13, pod, { size: 10.5, fill: 'var(--ink-2)' });
    });
    return yDol;
  };

  /* --- instalacja grzejnikowa: jeden grzebień plus zasobnik przy kotle --- */
  if (co) {
    const ySr = (GORA + yZimnaDol) / 2;
    grzebien(GORA, cZimna, 'rozdzielacz  ' + N + ' ' + odmianaWyjsc(N));

    linia(LEWO, ySr, BELKA - 9, ySr, cZimna, d.dojscie ? schematGrubosc(d.dojscie) : 4);
    e.push(`<rect x="${LEWO - szerZrodla}" y="${ySr - 20}" width="${szerZrodla}" height="40" rx="4" `
      + `fill="none" stroke="var(--ink)" stroke-width="1.6"/>`);
    tekst(LEWO - szerZrodla / 2, ySr + 4, podpisZrodla, { size: 9.5, anchor: 'middle' });
    if (grupa) schematGrupa(e, LEWO + 30, ySr, grupa,
      (x, yy, s2) => tekst(x, yy, s2, { size: 10.5, weight: 700, fill: cAkc }));
    if (d.dojscie) {
      tekst(grupa ? BELKA - 40 : (LEWO + BELKA) / 2, ySr - 12, 'Ø ' + d.dojscie,
        { size: 11.5, weight: 700, anchor: 'middle', fill: cAkc });
    }

    if (d.zasobnik) {
      const xz = (LEWO + BELKA) / 2, ys = yZimnaDol + 46;
      linia(xz, ySr, xz, ys, cZimna, schematGrubosc(d.zasobnik.srednica));
      e.push(`<rect x="${xz - 26}" y="${ys}" width="52" height="46" rx="10" `
        + `fill="var(--surface)" stroke="var(--ink)" stroke-width="1.6"/>`);
      tekst(xz, ys + 20, 'c.w.u.', { size: 9.5, weight: 600, anchor: 'middle' });
      tekst(xz, ys + 33, 'zasobnik', { size: 8.5, anchor: 'middle', fill: 'var(--ink-2)' });
      tekst(xz + 34, ys + 16, 'Ø ' + d.zasobnik.srednica, { size: 10.5, fill: 'var(--ink-2)' });
      if (d.zasobnik.opis) tekst(xz + 34, ys + 30, d.zasobnik.opis, { size: 10, fill: 'var(--ink-2)' });
    }

    return `<svg class="sch-fit" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" `
      + `aria-label="Schemat poglądowy rozdzielacza">${e.join('')}</svg>`;
  }

  /* --- woda: dwa grzebienie i zasobnik między nimi --- */
  const yZimnaSr = (GORA + yZimnaDol) / 2;
  const yCieplaSr = (yCieplaGora + yCieplaDol) / 2;
  const xPion = LEWO - 8;
  const xZas = (LEWO + BELKA) / 2;
  const yZas = yZimnaDol + 30;

  grzebien(GORA, cZimna, 'rozdzielacz zimnej  ' + N + ' ' + odmianaWyjsc(N));
  grzebien(yCieplaGora, cCiepla, 'rozdzielacz ciepłej  ' + N + ' ' + odmianaWyjsc(N));

  /* pion i dojście zimnej */
  e.push(`<rect x="${xPion - 34}" y="${yZimnaSr - 20}" width="42" height="40" rx="4" `
    + `fill="none" stroke="var(--ink)" stroke-width="1.6"/>`);
  tekst(xPion - 13, yZimnaSr + 4, 'pion', { size: 9.5, anchor: 'middle' });
  linia(xPion, yZimnaSr, BELKA - 9, yZimnaSr, cZimna, d.dojscie ? schematGrubosc(d.dojscie) : 4);
  if (d.dojscie) {
    tekst((xPion + BELKA) / 2, yZimnaSr - 12, 'Ø ' + d.dojscie,
      { size: 11.5, weight: 700, anchor: 'middle', fill: cAkc });
  }

  /* zimna do zasobnika i ciepła z zasobnika na drugi rozdzielacz */
  const grDoj = d.dojscie ? schematGrubosc(d.dojscie) : 4;
  linia(xZas, yZimnaSr, xZas, yZas, cZimna, grDoj);
  e.push(`<rect x="${xZas - 30}" y="${yZas}" width="60" height="64" rx="12" `
    + `fill="var(--surface)" stroke="var(--ink)" stroke-width="1.8"/>`);
  tekst(xZas, yZas + 26, 'zasobnik', { size: 9.5, weight: 600, anchor: 'middle' });
  tekst(xZas, yZas + 39, 'c.w.u.', { size: 9, anchor: 'middle', fill: 'var(--ink-2)' });
  if (d.zasobnik && d.zasobnik.srednica) {
    tekst(xZas + 40, yZas + 16, 'Ø ' + d.zasobnik.srednica + ' — zimna do zasobnika',
      { size: 10, fill: 'var(--ink-2)' });
    tekst(xZas + 40, yZas + 32, 'Ø ' + d.zasobnik.srednica + ' — ciepła na rozdzielacz',
      { size: 10, fill: 'var(--ink-2)' });
  }
  linia(xZas, yZas + 64, xZas, yCieplaSr, cCiepla, grDoj);
  linia(xZas, yCieplaSr, BELKA - 9, yCieplaSr, cCiepla, grDoj);

  /* cyrkulacja: od belki ciepłej z powrotem do zasobnika */
  const yCyr = yCieplaDol + 34;
  linia(BELKA, yCieplaDol + 20, BELKA, yCyr, cCyrk, 2.5, '6 4');
  linia(BELKA, yCyr, xZas - 16, yCyr, cCyrk, 2.5, '6 4');
  linia(xZas - 16, yCyr, xZas - 16, yZas + 64, cCyrk, 2.5, '6 4');
  tekst(BELKA + 14, yCyr + 4, d.cyrkulacja
    ? 'cyrkulacja — gdy w nitce do najdalszego kranu zmieści się ponad 3 litry ('
      + d.cyrkulacja.rura + ' → ok. ' + d.cyrkulacja.metrow + ' m)'
    : 'cyrkulacja do najdalszego podejścia',
    { size: 10.5, fill: 'var(--ink-2)' });

  return `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" `
    + `aria-label="Schemat poglądowy rozdzielaczy zimnej i ciepłej wody">${e.join('')}</svg>`;
}

/* ------------------------------------------------------------
   Kilka gałęzi od jednego kotła. Każda gałąź dostaje własne pasmo —
   rząd grzejników, zasilanie i powrót — a pasma leżą jedno pod drugim,
   związane wspólnym pionem przy kotle. Tak samo robi się to na rozwinięciu
   w projekcie: najpierw widać, co wychodzi z kotła, a potem jak się dzieli.
   Rysowanie gałęzi obok siebie, w lewo i w prawo od kotła, wygląda ładnie
   przy dwóch i rozsypuje się przy trzech, więc pasma są pewniejsze.
   ------------------------------------------------------------ */
/* ------------------------------------------------------------
   Grzejnik na rysunku. Gdy przy pozycji jest dobrany konkretny grzejnik,
   skrzynka dostaje proporcje z jego wymiarów — dłuższy jest szerszy,
   wyższy wyższy — a nad nią stoi typ i wymiar. Skala jest umowna, ma tylko
   pozwolić odróżnić 600×400 od 900×2000 jednym spojrzeniem.
   ------------------------------------------------------------ */
function schematGrzRozmiar(g) {
  if (!g || !g.length) return { w: 96, h: 54 };
  const w = Math.max(64, Math.min(150, 64 + (g.length - 400) / 2600 * 86));
  const h = Math.max(32, Math.min(70, 32 + (g.height - 300) / 600 * 38));
  return { w: Math.round(w), h: Math.round(h) };
}

function schematGrzejnikSvg(e, linia, tekst, cx, yOdb, o, nr) {
  const g = o.grz || null;
  const r = schematGrzRozmiar(g);
  const w = r.w, h = r.h, x0 = cx - w / 2, y0 = yOdb - h;
  const zly = g && g.length && g.ok === false;
  e.push(`<rect x="${x0}" y="${y0}" width="${w}" height="${h}" rx="2" `
    + `fill="var(--surface)" stroke="${zly ? 'var(--flame)' : 'var(--ink)'}" stroke-width="1.6"/>`);
  const zeber = Math.max(4, Math.round(w / 12));
  for (let f = 1; f < zeber; f++) {
    const fx = x0 + (w / zeber) * f;
    linia(fx, y0 + 3, fx, y0 + h - 3, 'var(--ink)', 1);
  }
  /* Numer w kółku przy krawędzi, bo na budowie liczy się kolejność od
     kotła, a nazwa bywa wpisana albo nie. */
  e.push(`<circle cx="${x0 - 9}" cy="${y0 + 10}" r="10" fill="var(--flame)"/>`);
  tekst(x0 - 9, y0 + 14, String(nr), { size: 11.5, weight: 700, fill: '#fff' });
  /* Od dołu: typ i wymiar, moc pomieszczenia, nazwa. */
  let y = y0 - 9;
  if (g) {
    tekst(cx, y, g.lazienka ? 'łazienkowy — za duża moc'
      : g.opis + (zly ? ' (za mały)' : ''),
      { size: 10.5, weight: 700, fill: zly ? 'var(--flame)' : (g.lazienka ? 'var(--ink-2)' : 'var(--flame)') });
    y -= 14;
  }
  if (o.wlasna) { tekst(cx, y, o.wlasna, { size: 11, fill: 'var(--ink-2)' }); y -= 15; }
  tekst(cx, y, o.nazwa, { size: 12.5, weight: 600 });
}

/* Zestawienie do zamówienia: ile sztuk jakiego grzejnika. Zwraca wysokość. */
function schematZestawienieSvg(tekst, x, y, d) {
  const z = (d.zestawienie || []).filter(r => r && r.opis !== 'łazienkowy');
  const laz = (d.zestawienie || []).find(r => r && r.opis === 'łazienkowy');
  if (!z.length && !laz) return 0;
  tekst(x, y, 'Zestawienie grzejników' + (d.rezim ? ' (' + d.rezim + ')' : ''),
    { size: 11, weight: 700, anchor: 'start', fill: 'var(--flame)' });
  let yy = y + 16;
  z.forEach(r => { tekst(x, yy, r.ile + (r.drab ? ' × ' : ' × typ ') + r.opis, { size: 10.5, anchor: 'start' }); yy += 15; });
  if (laz) { tekst(x, yy, laz.ile + ' × łazienkowy — żadna drabinka nie wystarcza', { size: 10.5, anchor: 'start', fill: 'var(--ink-2)' }); yy += 15; }
  return yy - y;
}

/* Podpis podejścia przy kotle — ramka z odnośnikiem do króćców. */
function schematPodejscieSvg(e, linia, tekst, x, y, xDo, yDo, srednica) {
  const t1 = 'podejście Ø ' + srednica, t2 = 'ok. 1 m, z króćca kotła';
  const w = Math.max(t1.length, t2.length) * 6.6 + 18;
  linia(x, y + 4, xDo, yDo, 'var(--flame)', 1.2);
  e.push(`<rect x="${x}" y="${y}" width="${w}" height="36" rx="5" fill="var(--surface)" `
    + `stroke="var(--flame)" stroke-width="1.4"/>`);
  tekst(x + w / 2, y + 15, t1, { size: 11, weight: 700, fill: 'var(--flame)' });
  tekst(x + w / 2, y + 29, t2, { size: 10, fill: 'var(--flame)' });
}

function schematGalezie(d) {
  const gal = (d.galezie || []).filter(g => g && (g.odcinki || []).length);
  if (!gal.length) return '';

  const SLOT = 176, LEWO = 152, PRAWO = 78, PASMO = 300;
  const maxN = gal.reduce((a, g) => Math.max(a, g.odcinki.length), 0);
  const W = LEWO + maxN * SLOT + PRAWO;

  const xZas = 64, xPow = 108;
  const yTop = k => 16 + k * PASMO;
  const yOdbOf = k => yTop(k) + 112;
  const yZasOf = k => yTop(k) + 196;
  const yPowOf = k => yTop(k) + 242;

  const dolTresci = yPowOf(gal.length - 1) + 34;
  const yKociol = dolTresci + 118;          /* dolna krawędź skrzynki kotła */
  const H = Math.max(yKociol + 16, yKociol - 84 + 16 * ((d.zestawienie || []).length + 1) + 14);

  const cZas = '#D7443C', cPow = '#2C72C4', cAkc = 'var(--flame)';

  const e = [];
  const linia = (x1, y1, x2, y2, kolor, gr, kres) =>
    e.push(`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${kolor}" `
      + `stroke-width="${gr}"${kres ? ` stroke-dasharray="${kres}"` : ''} stroke-linecap="butt"/>`);
  const tekst = (x, y, s, o) => {
    o = o || {};
    e.push(`<text x="${x}" y="${y}" font-size="${o.size || 11}" fill="${o.fill || 'var(--ink)'}" `
      + `text-anchor="${o.anchor || 'middle'}" font-weight="${o.weight || 400}" `
      + `font-family="ui-monospace, SFMono-Regular, Menlo, monospace">${esc(s)}</text>`);
  };

  /* --- kocioł i pion wspólny --- */
  const wsp = d.wspolny || {};
  const grWsp = schematGrubosc(wsp.srednica || gal[0].odcinki[0].srednica);
  e.push(`<rect x="26" y="${yKociol - 98}" width="100" height="98" rx="4" fill="none" `
    + `stroke="var(--ink)" stroke-width="2"/>`);
  tekst(76, yKociol - 56, 'źródło', { size: 12 });
  tekst(76, yKociol - 39, 'ciepła', { size: 12 });

  /* Pion wspólny: tym kawałkiem płynie woda do wszystkich gałęzi naraz,
     więc jest najgrubszy na całym rysunku i dlatego ma własny podpis. */
  linia(xZas, yKociol - 98, xZas, yZasOf(0), cZas, grWsp);
  linia(xPow, yPowOf(0), xPow, yKociol - 98, cPow, grWsp);

  /* Podejście przy kotle: ten metr rury, który jest wkręcony w króciec,
     bywa o rozmiar grubszy od reszty. Rysujemy go grubszą kreską u dołu
     pionu, tak jak na rozwinięciu w projekcie. */
  if (d.podejscie) {
    const grPod = schematGrubosc(d.podejscie) + 3;
    const yPod = yKociol - 98;
    linia(xZas, yPod, xZas, yPod - 46, cZas, grPod);
    linia(xPow, yPod - 46, xPow, yPod, cPow, grPod);
    e.push(`<circle cx="${xZas}" cy="${yPod - 46}" r="5" fill="var(--flame)" stroke="var(--surface)" stroke-width="1.5"/>`);
    e.push(`<circle cx="${xPow}" cy="${yPod - 46}" r="5" fill="var(--flame)" stroke="var(--surface)" stroke-width="1.5"/>`);
    schematPodejscieSvg(e, linia, tekst, 142, yKociol - 100, xPow + grPod / 2 + 1, yKociol - 112, d.podejscie);
  }
  schematZestawienieSvg(tekst, Math.max(LEWO + SLOT + 40, 420), yKociol - 84, d);
  if (wsp.srednica) {
    tekst(142, yKociol - (d.podejscie ? 40 : 52), 'Ø ' + wsp.srednica + ' — odcinek wspólny',
      { size: 11.5, weight: 700, anchor: 'start' });
    if (wsp.opis) tekst(142, yKociol - (d.podejscie ? 24 : 36), 'do wszystkich gałęzi · ' + wsp.opis,
      { size: 10.5, anchor: 'start', fill: 'var(--ink-2)' });
  }

  gal.forEach((g, k) => {
    const odc = g.odcinki;
    const N = odc.length;
    const yOdb = yOdbOf(k), yZas = yZasOf(k), yPow = yPowOf(k);
    const bZas = [], bPow = [];
    for (let i = 0; i < N; i++) {
      const cx = LEWO + i * SLOT + SLOT / 2;
      bZas.push(cx - 27); bPow.push(cx + 27);
    }

    /* Kropka w miejscu, gdzie gałąź odchodzi od pionu — żeby było widać,
       że to jedno rozwidlenie, a nie dwie osobne instalacje. */
    e.push(`<circle cx="${xZas}" cy="${yZas}" r="4.5" fill="${cZas}"/>`);
    e.push(`<circle cx="${xPow}" cy="${yPow}" r="4.5" fill="${cPow}"/>`);

    /* Nazwa gałęzi jako tabliczka w lewym górnym rogu pasma. Tabliczka,
       a nie sam napis, bo przechodzi tędy pion wspólny — biała podkładka
       przykrywa kreskę, zamiast dać się przez nią przekreślić. */
    const etykieta = 'GAŁĄŹ ' + (g.nr || k + 1) + (g.opis ? '  ·  ' + g.opis : '');
    const szerE = etykieta.length * 6.9 + 16;
    e.push(`<rect x="10" y="${yTop(k) - 10}" width="${szerE}" height="22" rx="5" `
      + `fill="var(--surface)" stroke="var(--hair)" stroke-width="1"/>`);
    tekst(18, yTop(k) + 5, etykieta,
      { size: 11.5, weight: 700, anchor: 'start', fill: 'var(--ink-2)' });

    for (let i = 0; i < N; i++) {
      const gr = schematGrubosc(odc[i].srednica);
      const x1 = i === 0 ? xZas : bZas[i - 1];
      const x2 = bZas[i] + (i === N - 1 ? 22 : 0);
      linia(x1, yZas, x2, yZas, cZas, gr);
      linia(i === 0 ? xPow : bPow[i - 1], yPow, bPow[i] + (i === N - 1 ? 22 : 0), yPow, cPow, gr);

      const zmiana = i > 0 && odc[i].srednica !== odc[i - 1].srednica;
      /* Podpis pierwszego odcinka odsuwamy od pionu powrotu, inaczej siada
         na niebieskiej kresce biegnącej przez całą wysokość rysunku. */
      tekst(Math.max((x1 + x2) / 2, xPow + 46), yZas - gr / 2 - 9, 'Ø ' + odc[i].srednica,
        { size: 11.5, weight: zmiana ? 700 : 400, fill: zmiana ? cAkc : 'var(--ink)' });
      if (zmiana) linia(x1, yZas - gr / 2 - 22, x1, yPow + 16, cAkc, 1, '3 4');
    }

    odc.forEach((o, i) => {
      const cx = LEWO + i * SLOT + SLOT / 2;
      schematGrzejnikSvg(e, linia, tekst, cx, yOdb, o, o.nr || (i + 1));

      linia(bZas[i], yOdb, bZas[i], yZas, cZas, 3);
      linia(bPow[i], yOdb, bPow[i], yPow, cPow, 3);
      if (d.galazka) tekst(bZas[i] - 6, (yOdb + yZas) / 2 + 4, 'Ø ' + d.galazka,
        { size: 10, anchor: 'end', fill: 'var(--ink-2)' });
      if (o.opis) tekst(cx, yPow + 27, o.opis, { size: 10.5, fill: 'var(--ink-2)' });
    });
  });

  return `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" `
    + `aria-label="Schemat poglądowy instalacji grzejnikowej z kilkoma gałęziami">${e.join('')}</svg>`;
}

function schematSVG(d) {
  if (d && d.uklad === 'galezie') return schematGalezie(d);
  if (d && d.uklad === 'rozdzielacze') return schematRozdzielacze(d);
  const odc = (d && d.odcinki || []).filter(Boolean);
  if (!odc.length) return '';
  if (d.uklad === 'rozdzielacz') return schematRozdzielacz(d);

  const co = d.rodzaj === 'co';
  const gaz = d.rodzaj === 'gaz';
  const N = odc.length;

  const SLOT = 176, LEWO = 152, PRAWO = 78;
  const W = LEWO + N * SLOT + PRAWO;
  /* Przy c.o. nad grzejnikiem stoją trzy wiersze (nazwa, moc, typ
     i wymiar), więc cały rysunek schodzi o kilkanaście punktów niżej. */
  const dy = co ? 14 : 0;
  const yOdb = 118 + dy;            /* dolna krawędź odbiornika */
  const yZas = 212 + dy;            /* magistrala zasilania     */
  const yPow = 258 + dy;            /* magistrala powrotu       */
  const yDol = co ? 396 + dy : 330; /* dół źródła / pionu       */
  const ileZest = co ? (d.zestawienie || []).length : 0;
  const yZest = yDol - 98 + (co && d.podejscie ? 66 : 24);
  const H = co ? Math.max(430 + dy, yZest + 16 * (ileZest + 1) + 14) : 420;
  const xZas = 64, xPow = 108;

  /* Kolory bierzemy z motywu aplikacji, żeby rysunek działał tak samo
     w trybie jasnym i ciemnym. Gaz dostaje żółty, bo tak wygląda rura
     gazowa i tak jest oznaczana na schematach. */
  const cZas = gaz ? 'var(--cat-safe)' : (co ? '#D7443C' : 'var(--cat-water)');
  const cPow = '#2C72C4';
  const cAkc = 'var(--flame)';
  const cCiepla = '#D7443C';        /* ciepła woda — czerwona jak na schematach */
  const cCyrk = '#B07A2A';          /* cyrkulacja — kreskowana, żeby nie mylić z ciepłą */

  const e = [];
  const linia = (x1, y1, x2, y2, kolor, gr, kres) =>
    e.push(`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${kolor}" `
      + `stroke-width="${gr}"${kres ? ` stroke-dasharray="${kres}"` : ''} stroke-linecap="butt"/>`);
  const tekst = (x, y, s, o) => {
    o = o || {};
    e.push(`<text x="${x}" y="${y}" font-size="${o.size || 11}" fill="${o.fill || 'var(--ink)'}" `
      + `text-anchor="${o.anchor || 'middle'}" font-weight="${o.weight || 400}" `
      + `font-family="ui-monospace, SFMono-Regular, Menlo, monospace">${esc(s)}</text>`);
  };

  /* --- punkty odgałęzień --- */
  const bZas = [], bPow = [];
  for (let i = 0; i < N; i++) {
    const cx = LEWO + i * SLOT + SLOT / 2;
    bZas.push(cx - 27);
    bPow.push(cx + 27);
  }

  /* --- źródło: kocioł, pion wodny albo gazomierz --- */
  if (co) {
    e.push(`<rect x="26" y="${yDol - 98}" width="100" height="98" rx="4" fill="none" `
      + `stroke="var(--ink)" stroke-width="2"/>`);
    tekst(76, yDol - 56, 'źródło', { size: 12 });
    tekst(76, yDol - 39, 'ciepła', { size: 12 });

    /* Wyjścia z kotła do magistral. Gdy króciec narzuca grubszą rurę,
       grube są tylko te dwa pionowe kawałki wkręcone w kocioł — na kolanku
       rura schodzi do średnicy pierwszego odcinka, co zaznacza kropka. */
    const grWyj = d.podejscie ? schematGrubosc(d.podejscie) + 3 : schematGrubosc(odc[0].srednica);
    linia(xZas, yDol - 98, xZas, yZas - grWyj / 2, cZas, grWyj);
    linia(xPow, yDol - 98, xPow, yPow - grWyj / 2, cPow, grWyj);
    if (d.podejscie) {
      e.push(`<circle cx="${xZas}" cy="${yZas}" r="5" fill="var(--flame)" stroke="var(--surface)" stroke-width="1.5"/>`);
      e.push(`<circle cx="${xPow}" cy="${yPow}" r="5" fill="var(--flame)" stroke="var(--surface)" stroke-width="1.5"/>`);
      schematPodejscieSvg(e, linia, tekst, 140, yDol - 92, xPow + grWyj / 2 + 1, yDol - 114, d.podejscie);
    }
    schematZestawienieSvg(tekst, 140, yZest, d);

  } else {
    e.push(`<rect x="30" y="${yZas - 24}" width="68" height="48" rx="4" fill="none" `
      + `stroke="var(--ink)" stroke-width="2"/>`);
    tekst(64, yZas + 5, gaz ? 'gazomierz' : 'pion', { size: 10.5 });
  }

  /* --- magistrale, odcinek po odcinku --- */
  for (let i = 0; i < N; i++) {
    const gr = schematGrubosc(odc[i].srednica);
    const x1 = i === 0 ? (co ? xZas : 98) : bZas[i - 1];
    /* ostatni odcinek przedłużamy za gałązkę, żeby rysunek nie wyglądał
       na urwany w pół kreski */
    const x2 = bZas[i] + (i === N - 1 ? 22 : 0);
    linia(x1, yZas, x2, yZas, cZas, gr);
    if (co) {
      const p1 = i === 0 ? xPow : bPow[i - 1];
      linia(p1, yPow, bPow[i] + (i === N - 1 ? 22 : 0), yPow, cPow, gr);
    }

    const zmiana = i > 0 && odc[i].srednica !== odc[i - 1].srednica;
    /* Przy c.o. podpis pierwszego odcinka stoi tuż za kolankiem przy
       kotle — tam, gdzie zaczyna się ta średnica. */
    if (co && i === 0) {
      tekst(xZas + 14, yZas - gr / 2 - 9, 'Ø ' + odc[i].srednica,
        { size: 11.5, weight: 700, anchor: 'start' });
    } else {
      tekst((x1 + x2) / 2, yZas - gr / 2 - 9, 'Ø ' + odc[i].srednica,
        { size: 11.5, weight: zmiana ? 700 : 400, fill: zmiana ? cAkc : 'var(--ink)' });
    }
    if (zmiana) linia(x1, yZas - gr / 2 - 22, x1, (co ? yPow : yZas) + 16, cAkc, 1, '3 4');
  }

  /* --- odbiorniki i gałązki --- */
  odc.forEach((o, i) => {
    const cx = LEWO + i * SLOT + SLOT / 2;

    if (co) {
      schematGrzejnikSvg(e, linia, tekst, cx, yOdb, o, o.nr || (i + 1));
    } else if (gaz) {
      const w = 86, h = 50, x0 = cx - w / 2, y0 = yOdb - h;
      e.push(`<rect x="${x0}" y="${y0}" width="${w}" height="${h}" rx="6" `
        + `fill="var(--surface)" stroke="var(--ink)" stroke-width="1.6"/>`);
      e.push(`<circle cx="${cx}" cy="${y0 + h / 2}" r="9" fill="none" `
        + `stroke="var(--ink)" stroke-width="1.4"/>`);
      tekst(cx, y0 - 12, o.nazwa, { size: 12.5, weight: 600 });
    } else {
      e.push(`<circle cx="${cx}" cy="${yOdb - 24}" r="17" fill="var(--surface)" `
        + `stroke="var(--ink)" stroke-width="1.6"/>`);
      linia(cx, yOdb - 7, cx, yOdb, 'var(--ink)', 1.6);
      tekst(cx, yOdb - 52, o.nazwa, { size: 12.5, weight: 600 });
    }

    /* gałązka albo podejście */
    linia(bZas[i], yOdb, bZas[i], yZas, cZas, 3);
    if (co) linia(bPow[i], yOdb, bPow[i], yPow, cPow, 3);
    /* Każda nitka podpisana — monter patrzy na jeden grzejnik naraz. */
    if (co && d.galazka) {
      tekst(bZas[i] - 6, (yOdb + yZas) / 2 + 4, 'Ø ' + d.galazka,
        { size: 10, anchor: 'end', fill: 'var(--ink-2)' });
    }

    /* przy gazie każde podejście ma własną średnicę i jest to ta,
       którą monter kupuje pod konkretne urządzenie */
    if (gaz && o.pod) {
      tekst(bZas[i] - 7, (yOdb + yZas) / 2, 'Ø ' + o.pod,
        { size: 10.5, anchor: 'end', fill: 'var(--ink-2)' });
    }

    if (o.opis) tekst(cx, (co ? yPow : yZas) + 27, o.opis, { size: 10.5, fill: 'var(--ink-2)' });
  });

  /* Zasobnik c.w.u. przy kotle — odnoga z zasilania, zanim gałąź pójdzie
     do grzejników. Rysowany po lewej, bo tam fizycznie stoi. */
  if (co && d.zasobnik) {
    const xz = 166, ys = yDol - 58;
    /* Kreska wychodzi z krawędzi kotła, nie z jego środka — inaczej
       przecinałaby napis w skrzynce. */
    linia(126, ys, xz, ys, cZas, schematGrubosc(d.zasobnik.srednica));
    e.push(`<rect x="${xz}" y="${ys - 30}" width="58" height="60" rx="10" `
      + `fill="var(--surface)" stroke="var(--ink)" stroke-width="1.6"/>`);
    tekst(xz + 29, ys - 4, 'c.w.u.', { size: 10, weight: 600 });
    tekst(xz + 29, ys + 11, 'zasobnik', { size: 9, fill: 'var(--ink-2)' });
    tekst(xz + 68, ys - 6, 'Ø ' + d.zasobnik.srednica, { size: 10, anchor: 'start', fill: 'var(--ink-2)' });
    if (d.zasobnik.opis) tekst(xz + 68, ys + 9, d.zasobnik.opis, { size: 10, anchor: 'start', fill: 'var(--ink-2)' });
  }

  /* Ciepła woda to osobna gałąź, nie dopisek. Zimna zasila zasobnik,
     z zasobnika wychodzi ciepła i idzie do tych samych przyborów — a jeśli
     najdalsze podejście jest długie, dochodzi cyrkulacja, żeby po odkręceniu
     kranu nie leciała najpierw zimna. Rysujemy to pod gałęzią zimnej, w tej
     samej skali, bo materiału trzeba policzyć dwa razy.

     Ciepła podchodzi do przyborów z drugiej strony niż zimna — tak jak
     w baterii, gdzie ciepła jest po lewej, a zimna po prawej — dzięki czemu
     obie nitki są na rysunku widoczne osobno. */
  if (!co && !gaz) {
    const xz = 64;
    const ysZ = yZas + 30;          /* górna krawędź zasobnika  */
    const hZ = 62;
    const yCw = ysZ + hZ + 26;      /* magistrala ciepłej       */
    const yCyr = yCw + 30;          /* cyrkulacja pod nią       */
    const koniec = bPow[N - 1] + 22;

    /* zimna do zasobnika — od dolnej krawędzi skrzynki pionu */
    linia(xz, yZas + 24, xz, ysZ, cZas, 3);
    e.push(`<rect x="${xz - 30}" y="${ysZ}" width="60" height="${hZ}" rx="12" `
      + `fill="var(--surface)" stroke="var(--ink)" stroke-width="1.8"/>`);
    tekst(xz, ysZ + 26, 'zasobnik', { size: 9.5, weight: 600 });
    tekst(xz, ysZ + 39, 'c.w.u.', { size: 9, fill: 'var(--ink-2)' });
    if (d.zasobnik && d.zasobnik.srednica) {
      tekst(xz + 40, ysZ + 20, 'Ø ' + d.zasobnik.srednica + ' — zimna do zasobnika',
        { size: 10, anchor: 'start', fill: 'var(--ink-2)' });
    }

    /* ciepła z zasobnika do przyborów */
    linia(xz, ysZ + hZ, xz, yCw, cCiepla, 4);
    linia(xz, yCw, koniec, yCw, cCiepla, 4);
    odc.forEach((o, i) => linia(bPow[i], yCw, bPow[i], yOdb + 6, cCiepla, 2.5));
    tekst(xz + 40, ysZ + 36, 'ciepła — osobna gałąź do tych samych przyborów',
      { size: 10, anchor: 'start', fill: 'var(--ink-2)' });

    /* cyrkulacja od najdalszego podejścia z powrotem do zasobnika */
    linia(koniec, yCw, koniec, yCyr, cCyrk, 2.5, '6 4');
    linia(koniec, yCyr, xz, yCyr, cCyrk, 2.5, '6 4');
    linia(xz, yCyr, xz, ysZ + hZ, cCyrk, 2.5, '6 4');
    tekst(xz + 40, yCyr + 16, d.cyrkulacja
      ? 'cyrkulacja — gdy w rurze do najdalszego kranu zmieści się ponad 3 litry ('
        + d.cyrkulacja.rura + ' → ok. ' + d.cyrkulacja.metrow + ' m)'
      : 'cyrkulacja do najdalszego podejścia',
      { size: 10, anchor: 'start', fill: 'var(--ink-2)' });
  }

  /* --- wyniesiony podpis gałązki (tylko tam, gdzie jest jedna dla wszystkich) --- */
  if (d.galazka && !gaz && !co) {
    const cx1 = LEWO + SLOT / 2;
    linia(bZas[0] + 4, yOdb + 20, cx1 + 76, yOdb + 46, 'var(--ink-2)', 1);
    tekst(cx1 + 82, yOdb + 50, 'Ø ' + d.galazka + ' — gałązka',
      { size: 10.5, anchor: 'start', fill: 'var(--ink-2)' });
  }

  return `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" `
    + `aria-label="Schemat poglądowy gałęzi">${e.join('')}</svg>`;
}

/* Arkusz z rysunkiem. Rysunek bywa szerszy od ekranu, więc płótno
   przewija się w poziomie — reszta arkusza stoi. */
function schematHtml(d) {
  const legenda = d.rodzaj === 'co'
    ? [['#D7443C', 'zasilanie'], ['#2C72C4', 'powrót'], ['var(--flame)', 'zmiana średnicy']]
    : d.rodzaj === 'gaz'
      ? [['var(--cat-safe)', 'gałąź gazowa'], ['var(--flame)', 'zmiana średnicy']]
      : [['var(--cat-water)', 'zimna'], ['#D7443C', 'ciepła'], ['#B07A2A', 'cyrkulacja'],
         ['var(--flame)', 'zmiana średnicy']];

  return `<div class="sheet" data-closeschemat>
    <div class="sheet-in" role="dialog" aria-label="Projekt poglądowy">
      <div class="sheet-h">${svg('list')}<strong>${esc(d.tytul || 'Projekt poglądowy')}</strong>
        <button class="item-x" data-closeschemat aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        <div class="sch-leg">${legenda.map(l =>
          `<span><i style="background:${l[0]}"></i>${esc(l[1])}</span>`).join('')}</div>
        <div class="sch-plot">${schematSVG(d)}</div>
        <button class="jump" style="--c:var(--flame);margin-top:12px" data-schpdf>
          ${svg('doc')}Zapisz jako PDF</button>
        <div class="tip">${svg('spark')}<div>Rysunek poglądowy dla montera: kolejność odbiorników
          i średnica każdego odcinka. Nie ma tu skali ani rzeczywistego przebiegu rur w budynku
          i nie zastępuje projektu instalacji.</div></div>
      </div>
    </div></div>`;
}

/* ============================================================
   TEN SAM RYSUNEK W PDF-ie
   ------------------------------------------------------------
   Na budowie telefon leży w kieszeni, a kartka w ręku. Dlatego schemat
   da się zapisać jako PDF: do wydruku albo do wysłania pomocnikowi.

   Rysujemy poziomo, bo gałąź jest szersza niż wyższa, i skalujemy całość
   tak, żeby zmieściła się na jednej stronie. Skala ma dolną granicę przy
   podpisach — poniżej 5,5 punktu nikt tego nie przeczyta, więc zamiast
   ściskać w nieskończoność zmniejszamy odstęp między odbiornikami.
   ============================================================ */
const SCHEMAT_A4_POZIOMO = { w: 841.89, h: 595.28 };

/* Rozdzielacz na kartce. Ten sam grzebień co na ekranie, tylko w punktach
   i z miejscem na podpisy, bo wydruk czyta się z odległości ręki. Woda
   dostaje dwa grzebienie — zimnej i ciepłej — z zasobnikiem między nimi. */
/* Kilka rozdzielaczy na kartce. Wiersz liczymy z sumy wszystkich wyjść,
   żeby całe mieszkanie zmieściło się na jednej stronie; jeżeli pętli jest
   tyle, że nawet przy najciaśniejszym wierszu nie wchodzą, rysunek przechodzi
   na kolejną stronę TEGO SAMEGO pliku — każda strona dostaje wtedy własne
   źródło i własny pion, żeby dało się ją czytać osobno. */
function schematPdfRozdzielacze(d) {
  const roz = (d.rozdzielacze || []).filter(r => r && (r.odcinki || []).length);
  if (!roz.length) return null;

  const R = SCHEMAT_A4_POZIOMO, MARG = 40;
  const cZas = [0.78, 0.20, 0.16], cAkc = [0.90, 0.40, 0.10];
  const cTusz = [0.08, 0.16, 0.23], cSzary = [0.42, 0.50, 0.56];

  const GORA = 124, BELKA = MARG + 190, ODSTEP = 46;
  const DOL = R.h - 54;
  const wierszy = roz.reduce((a, r) => a + r.odcinki.length, 0);
  const zapas = roz.length * 34 + (roz.length - 1) * ODSTEP;
  const WIERSZ = Math.max(15, Math.min(30,
    (DOL - GORA - zapas) / Math.max(1, wierszy - roz.length)));
  const wysokosc = r => (r.odcinki.length - 1) * WIERSZ + 34;

  /* Najpierw rozdzielamy rozdzielacze na strony, bo pion wspólny rysuje się
     przed grzebieniami i musi wiedzieć, gdzie się kończy. */
  const strony = [];
  let biez = [], yb = GORA;
  roz.forEach(r => {
    const h = wysokosc(r);
    if (biez.length && yb + h > DOL) { strony.push(biez); biez = []; yb = GORA; }
    biez.push({ r, yGora: yb, ySr: yb + ((r.odcinki.length - 1) * WIERSZ) / 2 });
    yb += h + ODSTEP;
  });
  if (biez.length) strony.push(biez);

  const k = pdfKartka(R);
  const wsp = d.wspolny || {};

  strony.forEach((pasma, nrStrony) => {
    k.nowa();
    k.prostokat(0, 0, R.w, 4, cAkc);
    k.tekst(MARG, MARG + 14, (d.tytul || 'Projekt poglądowy')
      + (strony.length > 1 ? `  (${nrStrony + 1}/${strony.length})` : ''), 15, true, cTusz);
    k.tekst(MARG, MARG + 32, 'Rysunek poglądowy — wyjścia rozdzielaczy, nastawy przepływomierzy '
      + 'i średnice dojść. Bez skali i bez rzeczywistego przebiegu rur.', 8.5, false, cSzary);
    k.doPrawej(R.w - MARG, MARG + 14, new Date().toLocaleDateString('pl-PL'), 9, false, cSzary);
    if (wsp.srednica) {
      k.tekst(MARG, MARG + 48, 'Ø ' + wsp.srednica + ' — odcinek wspólny od źródła'
        + (wsp.opis ? '  ·  ' + wsp.opis : ''), 9, true, cTusz);
    }
    if (d.grupaZrodla) {
      const g = d.grupaZrodla;
      k.tekst(MARG, MARG + 62, 'Grupa mieszająca w kotłowni: ' + [g.mieszacz ? 'mieszacz ' + g.mieszacz : '', g.pompa ? 'pompa ' + g.pompa : ''].filter(Boolean).join('  ·  '), 9, true, cAkc);
    }

    const xPion = MARG + 96;
    const yPierwszy = pasma[0].ySr, yOstatni = pasma[pasma.length - 1].ySr;
    const yZr = (yPierwszy + yOstatni) / 2;
    const grWsp = Math.max(1.4, Math.min(4.5, schematGrubosc(wsp.srednica || '25') / 2));
    k.linia(xPion, yPierwszy, xPion, yOstatni, grWsp, cZas);
    k.linia(MARG + 58, yZr, xPion, yZr, grWsp, cZas);
    k.linia(MARG, yZr - 15, MARG + 58, yZr - 15, 1.2, cTusz);
    k.linia(MARG, yZr + 15, MARG + 58, yZr + 15, 1.2, cTusz);
    k.linia(MARG, yZr - 15, MARG, yZr + 15, 1.2, cTusz);
    k.linia(MARG + 58, yZr - 15, MARG + 58, yZr + 15, 1.2, cTusz);
    k.tekst(MARG + 8, yZr + 3, d.zrodlo || 'kocioł', 9, false, cTusz);

    pasma.forEach(({ r, yGora, ySr }) => {
      const odc = r.odcinki, N = odc.length;
      const yDol = yGora + (N - 1) * WIERSZ;

      k.linia(xPion, ySr, BELKA - 5, ySr, 2.4, cZas);
      if (r.dojscie) {
        const t = 'Ø ' + r.dojscie;
        k.tekst((xPion + BELKA) / 2 - pdfSzerokosc(t, FONT_POGRUBIONA, 9) / 2, ySr - 7, t, 9, true, cAkc);
      }

      k.prostokat(BELKA - 5, yGora - 14, 10, (N - 1) * WIERSZ + 28, [0.85, 0.87, 0.89]);
      k.linia(BELKA - 5, yGora - 14, BELKA + 5, yGora - 14, 1.2, cTusz);
      k.linia(BELKA - 5, yDol + 14, BELKA + 5, yDol + 14, 1.2, cTusz);
      k.linia(BELKA - 5, yGora - 14, BELKA - 5, yDol + 14, 1.2, cTusz);
      k.linia(BELKA + 5, yGora - 14, BELKA + 5, yDol + 14, 1.2, cTusz);
      const podpis = r.nazwa + ' — ' + N + ' ' + odmianaWyjsc(N);
      k.tekst(BELKA - pdfSzerokosc(podpis, FONT_POGRUBIONA, 9) / 2, yGora - 22, podpis, 9, true, cTusz);
      if (r.grupa) {
        const gt = [r.grupa.mieszacz ? 'mieszacz ' + r.grupa.mieszacz : '', r.grupa.pompa ? 'pompa ' + r.grupa.pompa : ''].filter(Boolean).join('  ·  ');
        k.tekst(BELKA + pdfSzerokosc(podpis, FONT_POGRUBIONA, 9) / 2 + 14, yGora - 22, gt, 8.5, true, cAkc);
      }

      odc.forEach((o, i) => {
        const yy = yGora + i * WIERSZ;
        k.linia(BELKA + 5, yy, BELKA + 110, yy, 1.6, cZas);
        k.prostokat(BELKA + 10, yy - 6, 13, 12, cAkc);
        const nr = String(o.nr || (i + 1));
        k.tekst(BELKA + 16.5 - pdfSzerokosc(nr, FONT_POGRUBIONA, 7) / 2, yy + 3.5, nr, 7, true, [1, 1, 1]);
        k.tekst(BELKA + 122, yy + 1, String(o.nazwa || ''), 9, true, cTusz);
        const pod = [o.srednica ? 'Ø ' + o.srednica : '', o.wlasna].filter(Boolean).join('  ·  ');
        if (pod) k.tekst(BELKA + 270, yy + 1, pod, 8, false, cSzary);
      });
    });

    k.tekst(MARG, R.h - 26, 'Asystent Instalatora — rysunek poglądowy, nie zastępuje projektu instalacji.',
      7.5, false, cSzary);
  });

  return pdfZloz(k.strony, d.tytul || 'Projekt poglądowy', R);
}

function schematPdfRozdzielacz(d) {
  const odc = (d.odcinki || []).filter(Boolean);
  const co = d.rodzaj === 'co';
  const N = odc.length;
  const R = SCHEMAT_A4_POZIOMO, MARG = 40;

  const cZimna = co ? [0.78, 0.20, 0.16] : [0.10, 0.45, 0.72];
  const cCiepla = [0.78, 0.20, 0.16];
  const cCyrk = [0.69, 0.48, 0.16];
  const cAkc = [0.90, 0.40, 0.10];
  const cTusz = [0.08, 0.16, 0.23];
  const cSzary = [0.42, 0.50, 0.56];

  const k = pdfKartka(R).nowa();
  k.prostokat(0, 0, R.w, 4, cAkc);
  k.tekst(MARG, MARG + 14, d.tytul || 'Projekt poglądowy', 15, true, cTusz);
  k.tekst(MARG, MARG + 32, co
    ? 'Rysunek poglądowy — nitki z rozdzielacza i średnica dojścia. Bez skali i bez rzeczywistego przebiegu rur.'
    : 'Rysunek poglądowy — rozdzielacz zimnej, zasobnik, rozdzielacz ciepłej i cyrkulacja. Bez skali.',
    8.5, false, cSzary);
  k.doPrawej(R.w - MARG, MARG + 14, new Date().toLocaleDateString('pl-PL'), 9, false, cSzary);

  const GORA = co ? 130 : 116, BELKA = MARG + 150;
  const dostepna = co ? (R.h - 230) : (R.h - 400);
  const WIERSZ = Math.max(16, Math.min(34, dostepna / Math.max(1, N - 1)));
  const PRZERWA = 124;

  const grzebien = (yGora, kolor, podpis) => {
    const yDol = yGora + (N - 1) * WIERSZ;
    k.prostokat(BELKA - 5, yGora - 14, 10, (N - 1) * WIERSZ + 28, [0.85, 0.87, 0.89]);
    k.linia(BELKA - 5, yGora - 14, BELKA + 5, yGora - 14, 1.2, cTusz);
    k.linia(BELKA - 5, yDol + 14, BELKA + 5, yDol + 14, 1.2, cTusz);
    k.linia(BELKA - 5, yGora - 14, BELKA - 5, yDol + 14, 1.2, cTusz);
    k.linia(BELKA + 5, yGora - 14, BELKA + 5, yDol + 14, 1.2, cTusz);
    k.tekst(BELKA - pdfSzerokosc(podpis, FONT_POGRUBIONA, 9) / 2, yGora - 22, podpis, 9, true, cTusz);
    odc.forEach((o, i) => {
      const y = yGora + i * WIERSZ;
      k.linia(BELKA + 5, y, BELKA + 110, y, 1.6, kolor);
      k.prostokat(BELKA + 10, y - 6, 13, 12, cAkc);
      const nr = String(o.nr || (i + 1));
      k.tekst(BELKA + 16.5 - pdfSzerokosc(nr, FONT_POGRUBIONA, 7) / 2, y + 3.5, nr, 7, true, [1, 1, 1]);
      k.tekst(BELKA + 122, y + 1, String(o.nazwa || ''), 9, true, cTusz);
      const pod = [o.srednica ? 'Ø ' + o.srednica : '', o.wlasna].filter(Boolean).join('  ·  ');
      if (pod) k.tekst(BELKA + 270, y + 1, pod, 8, false, cSzary);
    });
    return yDol;
  };

  const yZimnaDol = grzebien(GORA, cZimna,
    co ? ('rozdzielacz — ' + N + ' ' + odmianaWyjsc(N))
       : ('rozdzielacz zimnej — ' + N + ' ' + odmianaWyjsc(N)));
  const ySr = (GORA + yZimnaDol) / 2;

  /* źródło i dojście */
  k.linia(MARG + 60, ySr, BELKA - 5, ySr, 2.6, cZimna);
  k.linia(MARG, ySr - 16, MARG + 60, ySr - 16, 1.2, cTusz);
  k.linia(MARG, ySr + 16, MARG + 60, ySr + 16, 1.2, cTusz);
  k.linia(MARG, ySr - 16, MARG, ySr + 16, 1.2, cTusz);
  k.linia(MARG + 60, ySr - 16, MARG + 60, ySr + 16, 1.2, cTusz);
  k.tekst(MARG + 14, ySr + 3, co ? (d.zrodlo || 'kocioł') : 'pion', 9, false, cTusz);
  if (d.dojscie) {
    const t = 'Ø ' + d.dojscie;
    k.tekst(MARG + 60 + (BELKA - MARG - 65 - pdfSzerokosc(t, FONT_POGRUBIONA, 9)) / 2, ySr - 7, t, 9, true, cAkc);
  }

  const xz = MARG + 88;

  if (co) {
    if (d.zasobnik) {
      const ys = yZimnaDol + 46;
      k.linia(xz, ySr, xz, ys, 2.4, cZimna);
      k.linia(xz - 21, ys, xz + 21, ys, 1.2, cTusz);
      k.linia(xz - 21, ys + 34, xz + 21, ys + 34, 1.2, cTusz);
      k.linia(xz - 21, ys, xz - 21, ys + 34, 1.2, cTusz);
      k.linia(xz + 21, ys, xz + 21, ys + 34, 1.2, cTusz);
      k.tekst(xz - 16, ys + 14, 'c.w.u.', 8, true, cTusz);
      k.tekst(xz - 16, ys + 26, 'zasobnik', 7, false, cSzary);
      k.tekst(xz + 30, ys + 14, 'Ø ' + d.zasobnik.srednica, 8, false, cSzary);
      if (d.zasobnik.opis) k.tekst(xz + 30, ys + 26, d.zasobnik.opis, 8, false, cSzary);
    }
    k.tekst(MARG, R.h - 26, 'Asystent Instalatora — rysunek poglądowy, nie zastępuje projektu instalacji.',
      7.5, false, cSzary);
    return pdfZloz(k.strony, d.tytul || 'Projekt poglądowy', R);
  }

  /* --- woda: zasobnik i drugi grzebień --- */
  const yZas = yZimnaDol + 26, hZ = 44;
  k.linia(xz, ySr, xz, yZas, 2.4, cZimna);
  k.linia(xz - 23, yZas, xz + 23, yZas, 1.2, cTusz);
  k.linia(xz - 23, yZas + hZ, xz + 23, yZas + hZ, 1.2, cTusz);
  k.linia(xz - 23, yZas, xz - 23, yZas + hZ, 1.2, cTusz);
  k.linia(xz + 23, yZas, xz + 23, yZas + hZ, 1.2, cTusz);
  k.tekst(xz - 18, yZas + 19, 'zasobnik', 7.5, true, cTusz);
  k.tekst(xz - 18, yZas + 31, 'c.w.u.', 7, false, cSzary);
  if (d.zasobnik && d.zasobnik.srednica) {
    k.tekst(xz + 32, yZas + 16, 'Ø ' + d.zasobnik.srednica + ' — zimna do zasobnika', 8, false, cSzary);
    k.tekst(xz + 32, yZas + 29, 'Ø ' + d.zasobnik.srednica + ' — ciepła na rozdzielacz', 8, false, cSzary);
  }

  const yCieplaGora = yZimnaDol + PRZERWA;
  const yCieplaDol = grzebien(yCieplaGora, cCiepla,
    'rozdzielacz ciepłej — ' + N + ' ' + odmianaWyjsc(N));
  const ySrC = (yCieplaGora + yCieplaDol) / 2;
  k.linia(xz, yZas + hZ, xz, ySrC, 2.4, cCiepla);
  k.linia(xz, ySrC, BELKA - 5, ySrC, 2.4, cCiepla);

  const yCyr = yCieplaDol + 26;
  k.linia(BELKA, yCieplaDol + 14, BELKA, yCyr, 1.2, cCyrk);
  k.linia(BELKA, yCyr, xz - 14, yCyr, 1.2, cCyrk);
  k.linia(xz - 14, yCyr, xz - 14, yZas + hZ, 1.2, cCyrk);
  k.tekst(BELKA + 12, yCyr + 3, d.cyrkulacja
    ? 'cyrkulacja — gdy w nitce do najdalszego kranu zmieści się ponad 3 litry ('
      + d.cyrkulacja.rura + ' → ok. ' + d.cyrkulacja.metrow + ' m)'
    : 'cyrkulacja do najdalszego podejścia', 8, false, cCyrk);

  k.tekst(MARG, R.h - 26, 'Asystent Instalatora — rysunek poglądowy, nie zastępuje projektu instalacji.',
    7.5, false, cSzary);
  return pdfZloz(k.strony, d.tytul || 'Projekt poglądowy', R);
}

/* Kilka gałęzi na jednej kartce. Układ ten sam co na ekranie: pasma jedno
   pod drugim, kocioł na dole po lewej, pion wspólny wiążący wszystko.
   Wysokość pasma liczymy z liczby gałęzi, żeby trzy zmieściły się na A4
   poziomo bez zjeżdżania na drugą stronę — rysunek, którego nie widać
   naraz, przestaje być poglądowy. */
/* --- wspólne kawałki rysunku c.o. na kartce PDF --- */
function schematPdfGrzRozmiar(g, wMax) {
  if (!g || !g.length) return { w: Math.min(70, wMax), h: 0 };
  return { w: Math.min(wMax, Math.max(34, 34 + (g.length - 400) / 2600 * 56)),
           h: Math.max(20, Math.min(46, 20 + (g.height - 300) / 600 * 26)) };
}
function schematPdfGrzOpis(o) {
  const g = o.grz;
  if (!g) return '';
  if (g.lazienka) return 'łazienkowy — za duża moc';
  return g.opis + (g.ok === false ? ' (za mały)' : '');
}
function schematPdfKropka(k, x, y, kolor) { k.prostokat(x - 2.6, y - 2.6, 5.2, 5.2, kolor); }
function schematPdfZestawienie(k, x, y, d, cAkc, cTusz, cSzary) {
  const z = (d.zestawienie || []).filter(r => r && r.opis !== 'łazienkowy');
  const laz = (d.zestawienie || []).find(r => r && r.opis === 'łazienkowy');
  if (!z.length && !laz) return;
  k.tekst(x, y, 'Zestawienie grzejników' + (d.rezim ? ' (' + d.rezim + ')' : ''), 8.5, true, cAkc);
  let yy = y + 11;
  z.forEach(r => { k.tekst(x, yy, r.ile + (r.drab ? ' × ' : ' × typ ') + r.opis, 8, false, cTusz); yy += 10; });
  if (laz) k.tekst(x, yy, laz.ile + ' × łazienkowy — żadna drabinka nie wystarcza', 8, false, cSzary);
}

function schematGaleziePdf(d) {
  const gal = (d.galezie || []).filter(g => g && (g.odcinki || []).length);
  if (!gal.length) return null;

  const R = SCHEMAT_A4_POZIOMO;
  const MARG = 40;
  const maxN = gal.reduce((a, g) => Math.max(a, g.odcinki.length), 0);
  const dostepne = R.w - 2 * MARG;
  const LEWO = 112, PRAWO = 34;
  const SLOT = Math.max(76, Math.min(150, (dostepne - LEWO - PRAWO) / maxN));
  const W = LEWO + maxN * SLOT + PRAWO;
  const x0 = MARG + Math.max(0, (dostepne - W) / 2);

  /* Pasmo musi pomieścić, w tej kolejności: nazwę grzejnika i jego moc nad
     ramką, samą ramkę, magistralę zasilania, powrót i moc niesioną pod nim.
     Przy trzech gałęziach robi się ciasno, więc ramka chudnie — ale nic nie
     wychodzi poza kartkę i nic nie wchodzi na sąsiednie pasmo. */
  const yPierwsze = 100;
  const yZrodlo = R.h - 108;                       /* dolna krawędź kotła */
  const PASMO = Math.min(190, (yZrodlo - 62 - yPierwsze) / gal.length);
  const hOdb = Math.min(34, PASMO * 0.30);
  const yGoraOf = k => yPierwsze + k * PASMO;
  const yZasOf = k => yGoraOf(k) + hOdb + Math.min(26, PASMO * 0.24);
  const yPowOf = k => yZasOf(k) + Math.max(15, PASMO * 0.12);

  const cZas = [0.78, 0.20, 0.16], cPow = [0.13, 0.36, 0.66];
  const cAkc = [0.90, 0.40, 0.10], cTusz = [0.08, 0.16, 0.23], cSzary = [0.42, 0.50, 0.56];

  const k = pdfKartka(R).nowa();
  const gr = s => Math.max(1, Math.min(4.5, schematGrubosc(s) / 2));

  k.prostokat(0, 0, R.w, 4, cAkc);
  k.tekst(MARG, MARG + 14, d.tytul || 'Projekt poglądowy', 15, true, cTusz);
  k.tekst(MARG, MARG + 32, 'Rysunek poglądowy — kolejność odbiorników i średnice odcinków. '
    + 'Bez skali i bez rzeczywistego przebiegu rur.', 8.5, false, cSzary);
  k.doPrawej(R.w - MARG, MARG + 14, new Date().toLocaleDateString('pl-PL'), 9, false, cSzary);

  /* --- kocioł i pion wspólny --- */
  const wsp = d.wspolny || {};
  const grWsp = gr(wsp.srednica || gal[0].odcinki[0].srednica);
  const xZ = x0 + 34, xP = x0 + 62;
  k.linia(x0 + 14, yZrodlo - 54, x0 + 90, yZrodlo - 54, 1.2, cTusz);
  k.linia(x0 + 14, yZrodlo, x0 + 90, yZrodlo, 1.2, cTusz);
  k.linia(x0 + 14, yZrodlo - 54, x0 + 14, yZrodlo, 1.2, cTusz);
  k.linia(x0 + 90, yZrodlo - 54, x0 + 90, yZrodlo, 1.2, cTusz);
  k.tekst(x0 + 22, yZrodlo - 24, 'źródło ciepła', 8, false, cTusz);
  k.linia(xZ, yZrodlo - 54, xZ, yZasOf(0), grWsp, cZas);
  k.linia(xP, yPowOf(0), xP, yZrodlo - 54, grWsp, cPow);
  if (d.podejscie) {
    /* Grubsza rura tylko na samym wyjściu z kotła; kropka tam, gdzie
       schodzi do średnicy odcinka wspólnego. */
    const gp = gr(d.podejscie) + 1.5, yp = yZrodlo - 54;
    k.linia(xZ, yp, xZ, yp - 26, gp, cZas);
    k.linia(xP, yp, xP, yp - 26, gp, cPow);
    schematPdfKropka(k, xZ, yp - 26, cAkc);
    schematPdfKropka(k, xP, yp - 26, cAkc);
    k.tekst(x0 + 102, yZrodlo - 46, 'podejście Ø ' + d.podejscie + ' — ok. 1 m, z króćca kotła', 8.5, true, cAkc);
  }
  schematPdfZestawienie(k, x0 + Math.max(340, LEWO + SLOT + 40), yZrodlo - 46, d, cAkc, cTusz, cSzary);
  if (wsp.srednica) {
    k.tekst(x0 + 102, yZrodlo - 30, 'Ø ' + wsp.srednica + ' — odcinek wspólny', 9, true, cTusz);
    if (wsp.opis) k.tekst(x0 + 102, yZrodlo - 18, 'do wszystkich gałęzi · ' + wsp.opis,
      8, false, cSzary);
  }

  gal.forEach((g, b) => {
    const odc = g.odcinki, N = odc.length;
    const yGora = yGoraOf(b), yOdb = yGora + hOdb, yZas = yZasOf(b), yPow = yPowOf(b);
    const bZas = [], bPow = [];
    for (let i = 0; i < N; i++) {
      const cx = x0 + LEWO + i * SLOT + SLOT / 2;
      bZas.push(cx - Math.min(22, SLOT / 4));
      bPow.push(cx + Math.min(22, SLOT / 4));
    }

    /* Tabliczka z nazwą gałęzi stoi w lewym górnym rogu pasma — w tym samym
       miejscu co na ekranie, żeby kartka i telefon czytało się tak samo. */
    const etykieta = 'GAŁĄŹ ' + (g.nr || b + 1) + (g.opis ? '  ·  ' + g.opis : '');
    const szerE = pdfSzerokosc(etykieta, FONT_POGRUBIONA, 8.5);
    /* Biała podkładka pod tabliczką: przechodzi tędy pion wspólny i bez niej
       napis byłby przekreślony dwiema kreskami. */
    k.prostokat(x0 + 2, yGora - 15, szerE + 10, 13, [1, 1, 1]);
    k.tekst(x0 + 6, yGora - 6, etykieta, 8.5, true, cSzary);

    for (let i = 0; i < N; i++) {
      const gg = gr(odc[i].srednica);
      const xa = i === 0 ? xZ : bZas[i - 1];
      const xb = bZas[i] + (i === N - 1 ? 18 : 0);
      k.linia(xa, yZas, xb, yZas, gg, cZas);
      k.linia(i === 0 ? xP : bPow[i - 1], yPow, bPow[i] + (i === N - 1 ? 18 : 0), yPow, gg, cPow);

      const zmiana = i > 0 && odc[i].srednica !== odc[i - 1].srednica;
      const pod = 'Ø ' + odc[i].srednica;
      const szer = pdfSzerokosc(pod, zmiana ? FONT_POGRUBIONA : FONT_ZWYKLA, 7.5);
      /* Przy pierwszym odcinku podpis odsuwamy od pionu powrotu — inaczej
         napis siada na niebieskiej kresce. */
      const sx = Math.max((xa + xb) / 2 - szer / 2, xP + 10);
      k.tekst(sx, yZas - 6, pod, 7.5, zmiana, zmiana ? cAkc : cTusz);
      if (zmiana) k.linia(xa, yZas - 16, xa, yPow + 12, 0.7, cAkc);
    }

    odc.forEach((o, i) => {
      const cx = x0 + LEWO + i * SLOT + SLOT / 2;
      /* W paśmie gałęzi wysokość ramki jest stała, zmienia się tylko
         szerokość — miejsca w pionie przy trzech gałęziach jest mało. */
      const w = schematPdfGrzRozmiar(o.grz, SLOT - 14).w, xa = cx - w / 2;
      const ram = o.grz && o.grz.ok === false ? cAkc : cTusz;
      k.linia(xa, yGora, xa + w, yGora, 1.1, ram);
      k.linia(xa, yOdb, xa + w, yOdb, 1.1, ram);
      k.linia(xa, yGora, xa, yOdb, 1.1, ram);
      k.linia(xa + w, yGora, xa + w, yOdb, 1.1, ram);
      const zeb = Math.max(4, Math.round(w / 12));
      for (let f = 1; f < zeb; f++) k.linia(xa + (w / zeb) * f, yGora + 2, xa + (w / zeb) * f, yOdb - 2, 0.6, cTusz);

      if (o.nr) {
        const nrT = String(o.nr);
        const sr = pdfSzerokosc(nrT, FONT_POGRUBIONA, 7.5);
        k.prostokat(xa - 17, yGora - 2, 14, 14, cAkc);
        k.tekst(xa - 10 - sr / 2, yGora + 8.5, nrT, 7.5, true, [1, 1, 1]);
      }
      const nazwa = String(o.nazwa || '');
      k.tekst(cx - pdfSzerokosc(nazwa, FONT_POGRUBIONA, 8) / 2, yGora - 16, nazwa, 8, true, cTusz);
      /* Moc pomieszczenia i obok, na pomarańczowo, typ i wymiar grzejnika. */
      const mocT = o.wlasna ? String(o.wlasna) : '';
      const grzT = schematPdfGrzOpis(o);
      const sM = mocT ? pdfSzerokosc(mocT, FONT_ZWYKLA, 7.5) : 0;
      const sG = grzT ? pdfSzerokosc(' · ' + grzT, FONT_POGRUBIONA, 7.5) : 0;
      const lx = cx - (sM + sG) / 2;
      if (mocT) k.tekst(lx, yGora - 6, mocT, 7.5, false, cSzary);
      if (grzT) k.tekst(lx + sM, yGora - 6, (mocT ? ' · ' : '') + grzT, 7.5, true, o.grz.lazienka ? cSzary : cAkc);

      k.linia(bZas[i], yOdb, bZas[i], yZas, 1.4, cZas);
      k.linia(bPow[i], yOdb, bPow[i], yPow, 1.4, cPow);
      if (d.galazka) k.doPrawej(bZas[i] - 3, (yOdb + yZas) / 2 + 3, 'Ø ' + d.galazka, 6.5, false, cSzary);
      if (o.opis) k.tekst(cx - pdfSzerokosc(String(o.opis), FONT_ZWYKLA, 7) / 2,
        yPow + 9, String(o.opis), 7, false, cSzary);
    });
  });

  let lx = MARG;
  [[cZas, 'zasilanie'], [cPow, 'powrót'], [cAkc, 'zmiana średnicy']].forEach(l => {
    k.linia(lx, R.h - 46, lx + 16, R.h - 46, 2.2, l[0]);
    k.tekst(lx + 21, R.h - 43, l[1], 8, false, cSzary);
    lx += 26 + pdfSzerokosc(l[1], FONT_ZWYKLA, 8);
  });
  k.tekst(MARG, R.h - 26, 'Asystent Instalatora — rysunek poglądowy, nie zastępuje projektu instalacji.',
    7.5, false, cSzary);

  return pdfZloz(k.strony, d.tytul || 'Projekt poglądowy', R);
}

function schematPdf(d) {
  if (d && d.uklad === 'galezie') return schematGaleziePdf(d);
  if (d && d.uklad === 'rozdzielacze') return schematPdfRozdzielacze(d);
  const odc = (d && d.odcinki || []).filter(Boolean);
  if (!odc.length) return null;
  if (d.uklad === 'rozdzielacz') return schematPdfRozdzielacz(d);

  const co = d.rodzaj === 'co';
  const gaz = d.rodzaj === 'gaz';
  const N = odc.length;
  const R = SCHEMAT_A4_POZIOMO;
  const MARG = 40;

  /* Rozstaw dobieramy do liczby odbiorników: przy trzech jest luźno,
     przy dziesięciu ciasno, ale wszystko nadal na jednej kartce. */
  const dostepne = R.w - 2 * MARG;
  const LEWO = 96, PRAWO = 34;
  const SLOT = Math.max(76, Math.min(150, (dostepne - LEWO - PRAWO) / N));
  const W = LEWO + N * SLOT + PRAWO;
  const x0 = MARG + Math.max(0, (dostepne - W) / 2);

  const yGoraStd = 150;              /* górna krawędź odbiornika */
  const yOdb = co ? 190 : 180;       /* dolna krawędź odbiornika */
  const yZas = 300;
  const yPow = 340;
  const yZrodlo = 430;

  /* Kolory w skali 0–1, jak wymaga PDF. Na wydruku czarno-białym
     i tak zostaną odcienie szarości, więc grubość kreski musi nieść
     tę samą informację co barwa. */
  const cZas = gaz ? [0.85, 0.55, 0.10] : (co ? [0.78, 0.20, 0.16] : [0.10, 0.45, 0.72]);
  const cPow = [0.13, 0.36, 0.66];
  const cAkc = [0.90, 0.40, 0.10];
  const cTusz = [0.08, 0.16, 0.23];
  const cSzary = [0.42, 0.50, 0.56];

  const k = pdfKartka(R).nowa();
  const gr = s => Math.max(1, Math.min(4.5, schematGrubosc(s) / 2));

  /* --- nagłówek --- */
  k.prostokat(0, 0, R.w, 4, cAkc);
  k.tekst(MARG, MARG + 14, d.tytul || 'Projekt poglądowy', 15, true, cTusz);
  k.tekst(MARG, MARG + 32, 'Rysunek poglądowy — kolejność odbiorników i średnice odcinków. '
    + 'Bez skali i bez rzeczywistego przebiegu rur.', 8.5, false, cSzary);
  const dzis = new Date().toLocaleDateString('pl-PL');
  k.doPrawej(R.w - MARG, MARG + 14, dzis, 9, false, cSzary);

  /* --- punkty odgałęzień --- */
  const bZas = [], bPow = [];
  for (let i = 0; i < N; i++) {
    const cx = x0 + LEWO + i * SLOT + SLOT / 2;
    bZas.push(cx - Math.min(22, SLOT / 4));
    bPow.push(cx + Math.min(22, SLOT / 4));
  }

  /* --- źródło --- */
  if (co) {
    k.linia(x0 + 20, yZrodlo - 66, x0 + 84, yZrodlo - 66, 1.2, cTusz);
    k.linia(x0 + 20, yZrodlo, x0 + 84, yZrodlo, 1.2, cTusz);
    k.linia(x0 + 20, yZrodlo - 66, x0 + 20, yZrodlo, 1.2, cTusz);
    k.linia(x0 + 84, yZrodlo - 66, x0 + 84, yZrodlo, 1.2, cTusz);
    k.tekst(x0 + 28, yZrodlo - 30, 'źródło ciepła', 8, false, cTusz);

  } else {
    k.tekst(x0 + 20, yZas - 6, gaz ? 'gazomierz' : 'pion', 8.5, true, cTusz);
  }

  /* --- magistrale --- */
  for (let i = 0; i < N; i++) {
    const g = gr(odc[i].srednica);
    const xa = i === 0 ? (co ? x0 + 40 : x0 + 74) : bZas[i - 1];
    const xb = bZas[i] + (i === N - 1 ? 18 : 0);
    k.linia(xa, yZas, xb, yZas, g, cZas);
    if (co) {
      const pa = i === 0 ? x0 + 64 : bPow[i - 1];
      k.linia(pa, yPow, bPow[i] + (i === N - 1 ? 18 : 0), yPow, g, cPow);
    }
    const zmiana = i > 0 && odc[i].srednica !== odc[i - 1].srednica;
    const pod = 'Ø ' + odc[i].srednica;
    const szer = pdfSzerokosc(pod, zmiana ? FONT_POGRUBIONA : FONT_ZWYKLA, 7.5);
    if (co && i === 0) k.tekst(xa + 8, yZas - 6, pod, 7.5, true, cTusz);
    else k.tekst((xa + xb) / 2 - szer / 2, yZas - 6, pod, 7.5, zmiana, zmiana ? cAkc : cTusz);
    if (zmiana) k.linia(xa, yZas - 16, xa, (co ? yPow : yZas) + 12, 0.7, cAkc);
  }

  if (co) {
    /* Wyjścia z kotła. Przy podejściu grubsze są tylko te dwa pionowe
       kawałki, a kropka na kolanku pokazuje zejście do pierwszego odcinka. */
    const g = d.podejscie ? gr(d.podejscie) + 1.5 : gr(odc[0].srednica);
    k.linia(x0 + 40, yZrodlo - 66, x0 + 40, yZas, g, cZas);
    k.linia(x0 + 64, yPow, x0 + 64, yZrodlo - 66, g, cPow);
    const xt = x0 + (d.zasobnik ? 200 : 96);
    if (d.podejscie) {
      schematPdfKropka(k, x0 + 40, yZas, cAkc);
      schematPdfKropka(k, x0 + 64, yPow, cAkc);
      k.linia(x0 + 66, yZrodlo - 76, xt - 2, yZrodlo - 58, 0.7, cAkc);
      k.tekst(xt, yZrodlo - 54, 'podejście Ø ' + d.podejscie, 8.5, true, cAkc);
      k.tekst(xt, yZrodlo - 43, 'ok. 1 m, z króćca kotła', 7.5, false, cAkc);
    }
    schematPdfZestawienie(k, d.podejscie ? Math.max(xt + 150, x0 + 260) : xt, yZrodlo - 54,
      d, cAkc, cTusz, cSzary);
  }

  /* --- odbiorniki --- */
  odc.forEach((o, i) => {
    const cx = x0 + LEWO + i * SLOT + SLOT / 2;
    /* Przy c.o. ramka dostaje proporcje dobranego grzejnika. */
    const rg = co ? schematPdfGrzRozmiar(o.grz, SLOT - 14) : { w: Math.min(70, SLOT - 14), h: 0 };
    const w = rg.w, xa = cx - w / 2;
    const yGora = rg.h ? yOdb - rg.h : yGoraStd;
    const ram = co && o.grz && o.grz.ok === false ? cAkc : cTusz;

    k.linia(xa, yGora, xa + w, yGora, 1.1, ram);
    k.linia(xa, yOdb, xa + w, yOdb, 1.1, ram);
    k.linia(xa, yGora, xa, yOdb, 1.1, ram);
    k.linia(xa + w, yGora, xa + w, yOdb, 1.1, ram);
    const zeb = Math.max(4, Math.round(w / 12));
    if (co) for (let f = 1; f < zeb; f++) k.linia(xa + (w / zeb) * f, yGora + 2, xa + (w / zeb) * f, yOdb - 2, 0.6, cTusz);

    /* Numer w kółku, nad nim nazwa, pod nią własna moc grzejnika —
       to jest ta część rysunku, dla której monter go w ogóle drukuje. */
    if (o.nr) {
      const nrT = String(o.nr);
      const sr = pdfSzerokosc(nrT, FONT_POGRUBIONA, 7.5);
      k.prostokat(xa - 17, yGora - 2, 14, 14, cAkc);
      k.tekst(xa - 10 - sr / 2, yGora + 8.5, nrT, 7.5, true, [1, 1, 1]);
    }
    const nazwa = String(o.nazwa || '');
    const grzT = co ? schematPdfGrzOpis(o) : '';
    let yt = yGora - 7;
    if (grzT) {
      k.tekst(cx - pdfSzerokosc(grzT, FONT_POGRUBIONA, 7.5) / 2, yt, grzT, 7.5, true,
        o.grz.lazienka ? cSzary : cAkc);
      yt -= 10;
    }
    if (o.wlasna) {
      const sw = pdfSzerokosc(String(o.wlasna), FONT_ZWYKLA, 7.5);
      k.tekst(cx - sw / 2, yt, String(o.wlasna), 7.5, false, cSzary);
      yt -= 11;
    }
    const sn = pdfSzerokosc(nazwa, FONT_POGRUBIONA, 8);
    k.tekst(cx - sn / 2, yt, nazwa, 8, true, cTusz);

    k.linia(bZas[i], yOdb, bZas[i], yZas, 1.4, cZas);
    if (co) k.linia(bPow[i], yOdb, bPow[i], yPow, 1.4, cPow);
    if (co && d.galazka) k.doPrawej(bZas[i] - 3, (yOdb + yZas) / 2 + 3, 'Ø ' + d.galazka, 7, false, cSzary);

    if (gaz && o.pod) {
      k.doPrawej(bZas[i] - 4, (yOdb + yZas) / 2, 'Ø ' + o.pod, 7, false, cSzary);
    }
    if (o.opis) {
      const so = pdfSzerokosc(String(o.opis), FONT_ZWYKLA, 7);
      k.tekst(cx - so / 2, (co ? yPow : yZas) + 16, String(o.opis), 7, false, cSzary);
    }
  });

  /* zasobnik c.w.u. przy kotle */
  if (co && d.zasobnik) {
    /* Skrzynka kotła stoi przy x0+20…x0+84, więc zasobnik zaczynamy
       za jej prawą krawędzią — inaczej obie ramki na siebie wchodzą. */
    const xz = x0 + 104, ys = yZrodlo - 40;
    k.linia(x0 + 84, ys, xz, ys, 2.4, cZas);
    k.linia(xz, ys - 17, xz + 46, ys - 17, 1.2, cTusz);
    k.linia(xz, ys + 17, xz + 46, ys + 17, 1.2, cTusz);
    k.linia(xz, ys - 17, xz, ys + 17, 1.2, cTusz);
    k.linia(xz + 46, ys - 17, xz + 46, ys + 17, 1.2, cTusz);
    k.tekst(xz + 7, ys - 3, 'c.w.u.', 8, true, cTusz);
    k.tekst(xz + 7, ys + 9, 'zasobnik', 7, false, cSzary);
    k.tekst(xz + 56, ys - 3, 'Ø ' + d.zasobnik.srednica, 8, false, cSzary);
    if (d.zasobnik.opis) k.tekst(xz + 56, ys + 9, d.zasobnik.opis, 8, false, cSzary);
  }
  /* Woda: pod gałęzią zimnej rysujemy zasobnik, gałąź ciepłej i cyrkulację.
     Na wydruku to jest ta część, której instalator najczęściej zapomina
     policzyć — a materiału schodzi na nią tyle samo co na zimną. */
  if (!co && !gaz) {
    const cCiepla = [0.78, 0.20, 0.16];
    const cCyrk = [0.69, 0.48, 0.16];
    const xz = x0 + 26;
    const ysZ = yZas + 34, hZ = 40;
    const yCw = ysZ + hZ + 22;
    const yCyr = yCw + 22;
    const koniec = bPow[N - 1] + 18;

    k.linia(xz, yZas, xz, ysZ, 2, cZas);
    k.linia(xz - 21, ysZ, xz + 21, ysZ, 1.2, cTusz);
    k.linia(xz - 21, ysZ + hZ, xz + 21, ysZ + hZ, 1.2, cTusz);
    k.linia(xz - 21, ysZ, xz - 21, ysZ + hZ, 1.2, cTusz);
    k.linia(xz + 21, ysZ, xz + 21, ysZ + hZ, 1.2, cTusz);
    k.tekst(xz - 16, ysZ + 17, 'zasobnik', 7.5, true, cTusz);
    k.tekst(xz - 16, ysZ + 29, 'c.w.u.', 7, false, cSzary);
    if (d.zasobnik && d.zasobnik.srednica) {
      k.tekst(xz + 30, ysZ + 14, 'Ø ' + d.zasobnik.srednica + ' — zimna do zasobnika', 8, false, cSzary);
    }
    k.tekst(xz + 30, ysZ + 27, 'ciepła — osobna gałąź do tych samych przyborów', 8, false, cSzary);

    k.linia(xz, ysZ + hZ, xz, yCw, 2.4, cCiepla);
    k.linia(xz, yCw, koniec, yCw, 2.4, cCiepla);
    odc.forEach((o, i) => k.linia(bPow[i], yCw, bPow[i], yOdb + 4, 1.4, cCiepla));

    k.linia(koniec, yCw, koniec, yCyr, 1.2, cCyrk);
    k.linia(koniec, yCyr, xz, yCyr, 1.2, cCyrk);
    k.linia(xz, yCyr, xz, ysZ + hZ, 1.2, cCyrk);
    k.tekst(xz + 30, yCyr + 11, d.cyrkulacja
      ? 'cyrkulacja — gdy w rurze do najdalszego kranu zmieści się ponad 3 litry ('
        + d.cyrkulacja.rura + ' → ok. ' + d.cyrkulacja.metrow + ' m)'
      : 'cyrkulacja do najdalszego podejścia', 8, false, cCyrk);
  }

  /* --- legenda i stopka --- */
  let lx = MARG;
  const legenda = co
    ? [[cZas, 'zasilanie'], [cPow, 'powrót'], [cAkc, 'zmiana średnicy']]
    : gaz
      ? [[cZas, 'gałąź gazowa'], [cAkc, 'zmiana średnicy']]
      : [[cZas, 'zimna'], [[0.78, 0.20, 0.16], 'ciepła'], [[0.69, 0.48, 0.16], 'cyrkulacja'],
         [cAkc, 'zmiana średnicy']];
  legenda.forEach(l => {
    k.linia(lx, yZrodlo + 60, lx + 16, yZrodlo + 60, 2.2, l[0]);
    k.tekst(lx + 21, yZrodlo + 63, l[1], 8, false, cSzary);
    lx += 26 + pdfSzerokosc(l[1], FONT_ZWYKLA, 8);
  });
  k.tekst(MARG, R.h - 26, 'Asystent Instalatora — rysunek poglądowy, nie zastępuje projektu instalacji.',
    7.5, false, cSzary);

  return pdfZloz(k.strony, d.tytul || 'Projekt poglądowy', R);
}

function schematNazwa(d) {
  const rdz = d.rodzaj === 'gaz' ? 'gaz' : (d.rodzaj === 'woda' ? 'woda' : 'co');
  const dzis = new Date().toISOString().slice(0, 10);
  return `schemat-${rdz}-${dzis}.pdf`;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { schematSVG, schematGrubosc };
}

