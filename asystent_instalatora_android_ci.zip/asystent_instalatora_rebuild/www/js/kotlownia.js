/* ===== kotlownia.js ===== */
/* ============================================================
   SCHEMAT KOTŁOWNI — kreator dla instalatora
   ------------------------------------------------------------
   Instalator wybiera źródło ciepła, c.w.u. i obiegi, a aplikacja sama
   układa schemat hydrauliczny i listę elementów z numerami. To ściąga
   na budowę, nie projekt: bez średnic, bez skali, bez doboru urządzeń
   (do tego są osobne kalkulatory).

   Układ rysunku (jednostki viewBox, szerokość 420):
   źródło po lewej u góry, pod nim zasobnik c.w.u.; sprzęgło lub bufor
   pośrodku; po prawej szyna zasilania i powrotu, z której odchodzą
   obiegi — każdy w swoim wierszu.
   ============================================================ */

const KT_KOL = { zas: '#D7443C', pow: '#2C72C4', cwu: '#D7443C', zw: '#29B6F6', cyrk: '#B07A2A', ink: '#0E2A3B' };
let KT_W = 470;   // szerokość całego rysunku (ustawia ktSchemat)
/* Rozstaw: rysunek układamy w jednostkach jak dawniej, a potem cały
   rozciągamy KT_ROZ razy — rury i urządzenia (kocioł, bufor, zasobnik)
   rosną, a symbole armatury, numery i napisy zostają w tej samej
   wielkości. Dzięki temu między elementami robi się luźno. */
const KT_ROZ = 1.4;
/* Styl rysunku: 'prosty' (dotychczasowy) albo 'pelny' — te same symbole,
   ale rury jak rury (grubsze, z połyskiem), urządzenia z delikatnym
   cieniowaniem, zasobnik i bufor z rozkładem temperatur, siatka w tle. */
let KT_STYL = 'pelny';
const KT_DEFS = `<defs>
<pattern id="ktSiatka" width="14" height="14" patternUnits="userSpaceOnUse"><path d="M14 0H0V14" fill="none" stroke="#E6EDF3" stroke-width=".7"/></pattern>
<linearGradient id="ktKorpus" x1="0" x2="1"><stop offset="0" stop-color="#F1F5F8"/><stop offset=".45" stop-color="#FFFFFF"/><stop offset="1" stop-color="#DDE5EC"/></linearGradient>
<linearGradient id="ktWarstwy" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FBD9D3"/><stop offset=".55" stop-color="#F3ECF1"/><stop offset="1" stop-color="#D6E6F7"/></linearGradient>
<radialGradient id="ktPompa" cx=".35" cy=".3"><stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#CFE1F3"/></radialGradient>
<filter id="ktCien" x="-15%" y="-15%" width="130%" height="135%"><feDropShadow dx="1.2" dy="2" stdDeviation="1.6" flood-color="#0E2A3B" flood-opacity=".18"/></filter>
<filter id="ktCienM" x="-40%" y="-40%" width="180%" height="180%"><feDropShadow dx="0" dy="1" stdDeviation=".8" flood-color="#0E2A3B" flood-opacity=".28"/></filter>
</defs>`;
function ktStyl(s) {
  // rury: grubsze, z jasnym pasem pośrodku
  s = s.replace(/<polyline points="([^"]+)" fill="none" stroke="(#D7443C|#2C72C4|#29B6F6|#B07A2A)" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round"\/>/g,
    (_, pts, kol) => `<polyline points="${pts}" fill="none" stroke="${kol}" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"/>`
      + `<polyline points="${pts}" fill="none" stroke="#fff" stroke-opacity=".3" stroke-width="1" stroke-linejoin="round" stroke-linecap="round"/>`);
  s = s.replace(/stroke="#fff" stroke-width="8"/g, 'stroke="#fff" stroke-width="9.5"');
  // zasobnik i bufor — rozkład temperatur; pozostałe urządzenia — cieniowany korpus
  s = s.replace(/rx="(18|10)" fill="#fff" stroke="#0E2A3B" stroke-width="1.6"/g, 'rx="$1" fill="url(#ktWarstwy)" stroke="#0E2A3B" stroke-width="1.8" filter="url(#ktCien)"');
  s = s.replace(/fill="#fff" stroke="#0E2A3B" stroke-width="1.6"/g, 'fill="url(#ktKorpus)" stroke="#0E2A3B" stroke-width="1.8" filter="url(#ktCien)"');
  s = s.replace(/rx="2" fill="#fff" stroke="#0E2A3B" stroke-width="1.5"/g, 'rx="2" fill="url(#ktKorpus)" stroke="#0E2A3B" stroke-width="1.6" filter="url(#ktCien)"');
  // pompy, numerki
  s = s.replace(/r="8.5" fill="#fff"/g, 'r="8.5" fill="url(#ktPompa)"');
  s = s.replace(/r="7.5" fill="#FF7A33" stroke="#fff"/g, 'r="7.5" fill="#FF7A33" stroke="#fff" filter="url(#ktCienM)"');
  return s;
}

const ktLiczba = x => Math.max(0, parseFloat(String(x || 0).replace(',', '.')) || 0);
/* Klasa pompy w oznaczeniu używanym przez wszystkich producentów:
   średnica przyłącza – maksymalna wysokość podnoszenia w dm (25-60 = 6 m).
   Punkt pracy ma wypaść w środkowej części charakterystyki, więc bierzemy
   klasę z wysokością co najmniej o 30% większą od potrzebnej. */
function ktKlasaPompy(q, H) {
  const dn = q <= 3 ? 25 : q <= 6 ? 32 : 40;
  const hk = [4, 6, 8, 10, 12].find(x => x >= H * 1.3) || 12;
  return dn + '-' + hk * 10;
}

/* Klasa po ludzku: na jaką rurę i do ilu metrów. */
function ktOpisPompy(kl) {
  const [dn, hh] = kl.split('-').map(Number);
  const rura = { 25: 'na rurę 1″ (DN25)', 32: 'na rurę 5/4″ (DN32)', 40: 'kołnierzowa DN40' }[dn] || 'DN' + dn;
  return 'pompa ' + kl + ' — ' + rura + ', podnosi maks. ' + (hh / 10) + ' m';
}

/* ---------- konfiguracja z pól kalkulatora ---------- */
const KT_STALE = { pel: 'PELLET', weg: 'WĘGIEL', drew: 'ZGAZOWANIE' };
function ktKonfig(v) {
  const stale = !!KT_STALE[v.zr];
  const otw = stale && v.uklad === 'otw';     // układ otwarty tylko przy paliwie stałym
  /* Stara instalacja otwarta + nowy kocioł: rozdzielenie wymiennikiem.
     Kocioł pracuje w zamkniętym, stara instalacja zostaje otwarta. */
  const wym = (v.zr === 'k1' || v.zr === 'k2') && v.wym === 'tak';
  const gaz = v.zr === 'k1' || v.zr === 'k2';
  const split = v.zr === 'pcs';               // pompa ciepła split: moduł wewnętrzny + jednostka zewnętrzna
  const pc = v.zr === 'pc' || split;
  const cwu = v.zr === 'k2' ? 'przep' : v.cwu;            // dwufunkcyjny grzeje wodę sam
  /* Obiegi z listy: rodzaj, mieszacz i nazwa (parter, piętro…). Przy
     dwóch obiegach tego samego rodzaju bez nazwy dostają numery. */
  const lista = Array.isArray(v.ob) ? v.ob : [];
  const obiegi = lista.map(o => o.r === 'podl' ? (+o.m ? 'podlM' : 'podlB') : (+o.m ? 'grzM' : 'grz'));
  const ileR = { g: 0, p: 0 }, nrR = { g: 0, p: 0 };
  obiegi.forEach(o => ileR[o[0]]++);
  const nazwyOb = lista.map((o, i) => {
    const r = obiegi[i][0]; nrR[r]++;
    return { nazwa: String(o.n || ''), nr: !o.n && ileR[r] > 1 ? nrR[r] : 0 };
  });
  const potrzebaRozdz = obiegi.length >= 2 || obiegi.some(o => o === 'grzM' || o === 'podlM');
  /* Zgazowanie drewna bez bufora nie ma sensu — kocioł pracuje pełną mocą
     przez cały załadunek. Przy pellecie i węglu bufor dokładamy dopiero
     wtedy, gdy obiegów jest więcej niż jeden. */
  const rozdzAuto = v.zr === 'drew' ? 'buf'
    : potrzebaRozdz ? (gaz ? 'sprz' : 'buf') : 'brak';
  const rozdz = wym ? 'wym' : v.sep === 'auto' ? rozdzAuto : v.sep;
  /* Paliwo stałe: ochrona powrotu zaworem termostatycznym z pompą albo
     zespołem ładującym (laddomat). Zasobnik z bufora albo z kotła przed
     buforem — oba sposoby spotyka się w DTR producentów. */
  const ochr = stale ? (v.ochr === 'ladd' ? 'ladd' : 'term') : null;
  const bufy = rozdz === 'buf' && +v.bufy === 2 ? 2 : 1;
  const cwuZ = stale && rozdz === 'buf' && cwu === 'zas' && v.cwuZ === 'buf' ? 'buf' : 'kot';
  return { gaz, pc, split, stale, otw, wym, zr: v.zr, cwu, cyrk: cwu === 'zas' && v.cyrk === 'tak', obiegi, nazwyOb, rozdz, ochr, cwuZ, bufy, grp: v.grp === 'szaf' ? 'szaf' : 'kot',
    kw: lista.map(o => ktLiczba(o.kw)), dl: lista.map(o => ktLiczba(o.dl)), dpp: lista.map(o => ktLiczba(o.dp)), hP: lista.map(o => ktLiczba(o.hP)), hPz: lista.map(o => o.hPz || ''), wyj: lista.map(o => Math.round(ktLiczba(o.wyj))), qP: lista.map(o => ktLiczba(o.qP)), zasL: +v.zasL || 200, prio: v.prio !== 'nie', pKotl: v.pKotl || null, pCwu: v.pCwu || null, pCyrk: v.pCyrk || null, krocce: v.ktKr || 'auto', rk: lista.map(o => o.rk || null), rozd: lista.map(o => o.rozd || null) };
}

/* ---------- symbole (SVG jako tekst) ---------- */
const KT_I = KT_KOL.ink;
const kt = {
  rura: (pts, kol, w = 2.6, przer) => `<polyline points="${pts.map(p => p.join(',')).join(' ')}" fill="none" stroke="${kol}" stroke-width="${w}" stroke-linejoin="round" stroke-linecap="round"${przer ? ' stroke-dasharray="4 3"' : ''}/>`,
  /* rura przechodząca nad inną: najpierw biała „otulina”, potem kolor */
  most: (pts, kol) => kt.rura(pts, '#fff', 8) + kt.rura(pts, kol),
  strz: (x, y, kier, kol) => {               // grot kierunku przepływu
    const d = { p: [[-4, -4], [4, 0], [-4, 4]], l: [[4, -4], [-4, 0], [4, 4]], d: [[-4, -4], [0, 4], [4, -4]], g: [[-4, 4], [0, -4], [4, 4]] }[kier];
    return `<polyline points="${d.map(([a, b]) => (x + a) + ',' + (y + b)).join(' ')}" fill="none" stroke="${kol}" stroke-width="2" stroke-linejoin="round"/>`;
  },
  zawor: (x, y, pion) => pion
    ? `<path d="M${x - 5} ${y - 6}L${x + 5} ${y - 6}L${x} ${y}ZM${x - 5} ${y + 6}L${x + 5} ${y + 6}L${x} ${y}Z" fill="#fff" stroke="${KT_I}" stroke-width="1.4" stroke-linejoin="round"/>`
    : `<path d="M${x - 6} ${y - 5}L${x - 6} ${y + 5}L${x} ${y}ZM${x + 6} ${y - 5}L${x + 6} ${y + 5}L${x} ${y}Z" fill="#fff" stroke="${KT_I}" stroke-width="1.4" stroke-linejoin="round"/>`,
  zwrotny: (x, y, pion, wDol) => pion   // przepływ w górę (albo w dół), w poziomie w prawo
    ? (wDol
      ? `<path d="M${x - 5} ${y - 5}L${x + 5} ${y - 5}L${x} ${y + 4}Z" fill="${KT_I}"/><path d="M${x - 6} ${y + 5}H${x + 6}" stroke="${KT_I}" stroke-width="1.8"/>`
      : `<path d="M${x - 5} ${y + 5}L${x + 5} ${y + 5}L${x} ${y - 4}Z" fill="${KT_I}"/><path d="M${x - 6} ${y - 5}H${x + 6}" stroke="${KT_I}" stroke-width="1.8"/>`)
    : (wDol
      ? `<path d="M${x + 5} ${y - 5}L${x + 5} ${y + 5}L${x - 4} ${y}Z" fill="${KT_I}"/><path d="M${x - 5} ${y - 6}V${y + 6}" stroke="${KT_I}" stroke-width="1.8"/>`
      : `<path d="M${x - 5} ${y - 5}L${x - 5} ${y + 5}L${x + 4} ${y}Z" fill="${KT_I}"/><path d="M${x + 5} ${y - 6}V${y + 6}" stroke="${KT_I}" stroke-width="1.8"/>`),
  pompa: (x, y, kier = 'p') => {
    const t = { p: [[-4, -5], [-4, 5], [6, 0]], l: [[4, -5], [4, 5], [-6, 0]],
                d: [[-5, -4], [5, -4], [0, 6]], g: [[-5, 4], [5, 4], [0, -6]] }[kier];
    return `<circle cx="${x}" cy="${y}" r="8.5" fill="#fff" stroke="${KT_I}" stroke-width="1.5"/>`
      + `<path d="M${t.map(([a, b]) => (x + a) + ' ' + (y + b)).join('L')}Z" fill="${KT_I}"/>`;
  },
  trojdrog: (x, y, silownik, gora) =>  // zawór 3-drogowy: dwie drogi w poziomie, trzecia w dół (albo w górę)
    `<path d="M${x - 6} ${y - 5}L${x - 6} ${y + 5}L${x} ${y}ZM${x + 6} ${y - 5}L${x + 6} ${y + 5}L${x} ${y}Z${gora ? `M${x - 5} ${y - 6}L${x + 5} ${y - 6}L${x} ${y}Z` : `M${x - 5} ${y + 6}L${x + 5} ${y + 6}L${x} ${y}Z`}" fill="#fff" stroke="${KT_I}" stroke-width="1.4" stroke-linejoin="round"/>`
    + (silownik ? `<path d="M${x} ${y}V${y - 9}" stroke="${KT_I}" stroke-width="1.3"/><rect x="${x - 6}" y="${y - 19}" width="12" height="10" rx="1.5" fill="#fff" stroke="${KT_I}" stroke-width="1.3"/><text x="${x}" y="${y - 11.3}" font-size="8" font-weight="700" text-anchor="middle" fill="${KT_I}">M</text>` : ''),
  naczynie: (x, y, kol) =>              // naczynie przeponowe na króćcu w dół
    `<path d="M${x} ${y}V${y + 9}" stroke="${kol}" stroke-width="2.2"/><rect x="${x - 8}" y="${y + 9}" width="16" height="24" rx="8" fill="#fff" stroke="${KT_I}" stroke-width="1.4"/><path d="M${x - 8} ${y + 21}H${x + 8}" stroke="${KT_I}" stroke-width="1.1"/>`,
  bezp: (x, y, kol) =>                  // zawór bezpieczeństwa na króćcu w górę
    `<path d="M${x} ${y}V${y - 8}" stroke="${kol}" stroke-width="2.2"/>`
    + `<path d="M${x - 5} ${y - 8}L${x + 5} ${y - 8}L${x} ${y - 14}ZM${x - 5} ${y - 20}L${x + 5} ${y - 20}L${x} ${y - 14}Z" fill="#fff" stroke="${KT_I}" stroke-width="1.3" stroke-linejoin="round"/>`
    + `<path d="M${x} ${y - 20}l-3 -2 6 -3 -6 -3 3 -2" fill="none" stroke="${KT_I}" stroke-width="1.1"/>`
    + `<path d="M${x} ${y - 14}H${x + 9}V${y - 6}" fill="none" stroke="${KT_I}" stroke-width="1.2" stroke-dasharray="2 2"/>`,
  /* zawór termiczny (BVTS / STS) — zawór z czujnikiem na kapilarze */
  zaworTerm: (x, y, xc, yc) =>
    `<path d="M${x - 5} ${y - 6}L${x + 5} ${y - 6}L${x} ${y}ZM${x - 5} ${y + 6}L${x + 5} ${y + 6}L${x} ${y}Z" fill="#fff" stroke="${KT_I}" stroke-width="1.4" stroke-linejoin="round"/>`
    + `<path d="M${x} ${y}H${x + 10}" stroke="${KT_I}" stroke-width="1.2"/><rect x="${x + 10}" y="${y - 5}" width="10" height="10" rx="1.5" fill="#fff" stroke="${KT_I}" stroke-width="1.2"/>`
    + `<path d="M${x + 20} ${y}H${xc}V${yc}" fill="none" stroke="${KT_I}" stroke-width="1" stroke-dasharray="2 2"/><circle cx="${xc}" cy="${yc}" r="2.6" fill="${KT_I}"/>`,
  /* manometr / termometr na krótkim króćcu (w górę albo w dół) */
  wskaznik: (x, y, litera, dol) => {
    const cy = dol ? y + 18 : y - 18;
    return `<path d="M${x} ${y}V${dol ? y + 11 : y - 11}" stroke="${KT_I}" stroke-width="1.4"/>`
      + `<circle cx="${x}" cy="${cy}" r="7" fill="#fff" stroke="${KT_I}" stroke-width="1.4"/>`
      + `<path d="M${x} ${cy}l4 -4" stroke="${KT_I}" stroke-width="1.3" stroke-linecap="round"/>`
      + `<text x="${x}" y="${cy + 7.5}" font-size="7.5" font-weight="700" text-anchor="middle" fill="#5E788A">${litera}</text>`;
  },
  /* separator zanieczyszczeń (odmulacz): zbiornik z lejem, spustem i zaworem */
  separator: (x, y) =>
    `<path d="M${x - 9} ${y - 10}h18v12l-5 9h-8l-5 -9Z" fill="#fff" stroke="${KT_I}" stroke-width="1.4" stroke-linejoin="round"/>`
    + `<circle cx="${x - 3.5}" cy="${y - 4}" r="1.6" fill="${KT_I}"/><circle cx="${x + 3}" cy="${y - 1}" r="1.6" fill="${KT_I}"/><circle cx="${x - 1}" cy="${y + 4}" r="1.6" fill="${KT_I}"/>`
    + `<path d="M${x} ${y + 11}v4" stroke="${KT_I}" stroke-width="1.3"/>` + kt.zawor(x, y + 20, true),
  filtr: (x, y) =>
    `<rect x="${x - 8}" y="${y - 6}" width="16" height="12" rx="2" fill="#fff" stroke="${KT_I}" stroke-width="1.4"/><path d="M${x - 6} ${y + 4}L${x + 6} ${y - 4}" stroke="${KT_I}" stroke-width="1.2"/>`,
  /* reduktor ciśnienia (pionowo): zawór ze skośną strzałką */
  reduktor: (x, y) => kt.zawor(x, y, true)
    + `<path d="M${x - 9} ${y + 8}L${x + 8} ${y - 9}" stroke="${KT_I}" stroke-width="1.2"/><path d="M${x + 8} ${y - 9}l-5 1M${x + 8} ${y - 9}l-1 5" stroke="${KT_I}" stroke-width="1.2"/>`,
  /* filtr siatkowy (osadnik) — „skośna kieszeń” pod rurą */
  siatka: (x, y, pion) => {
    const s = `<path d="M${x - 7} ${y - 4}H${x + 7}V${y + 4}H${x + 3}L${x + 7} ${y + 11}H${x + 1}L${x - 3} ${y + 4}H${x - 7}Z" fill="#fff" stroke="${KT_I}" stroke-width="1.3" stroke-linejoin="round"/><path d="M${x - 1} ${y + 5}L${x + 3} ${y + 10}" stroke="${KT_I}" stroke-width="1"/>`;
    return pion ? `<g transform="rotate(90 ${x} ${y})">${s}</g>` : s;
  },
  odpow: (x, y) => `<path d="M${x} ${y}V${y - 7}" stroke="${KT_I}" stroke-width="1.5"/><path d="M${x - 4} ${y - 7}H${x + 4}L${x} ${y - 13}Z" fill="#fff" stroke="${KT_I}" stroke-width="1.3"/>`,
  czujnik: (x, y) => `<circle cx="${x}" cy="${y}" r="5.5" fill="#fff" stroke="${KT_I}" stroke-width="1.3"/><text x="${x}" y="${y + 2.8}" font-size="7.5" font-weight="700" text-anchor="middle" fill="${KT_I}">T</text>`,
  stb: (x, y) => `<rect x="${x - 11}" y="${y - 7}" width="22" height="14" rx="2" fill="#fff" stroke="${KT_I}" stroke-width="1.3"/><text x="${x}" y="${y + 3}" font-size="7.5" font-weight="700" text-anchor="middle" fill="${KT_I}">STB</text>`,
  grzejnik: (x, y, w, h) => {
    let s = `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="2" fill="#fff" stroke="${KT_I}" stroke-width="1.5"/>`;
    for (let i = 1; i < 6; i++) s += `<path d="M${x + i * w / 6} ${y + 4}V${y + h - 4}" stroke="${KT_I}" stroke-width="1.1"/>`;
    return s;
  },
  podloga: (x, y, w, h) => {
    const n = 6, krok = (h - 12) / n;
    let d = `M${x + 5} ${y + 6}`;
    for (let i = 0; i < n; i++) d += `H${i % 2 ? x + 5 : x + w - 5}v${krok}`;
    d += `H${x + 5}`;
    return `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="2" fill="#fff" stroke="${KT_I}" stroke-width="1.5"/><path d="${d}" fill="none" stroke="${KT_KOL.zas}" stroke-width="1.3" opacity=".8"/>`;
  },
  nr: (x, y, n) => `<circle cx="${x}" cy="${y}" r="7.5" fill="#FF7A33" stroke="#fff" stroke-width="1.5"/><text x="${x}" y="${y + 3.4}" font-size="9.5" font-weight="700" text-anchor="middle" fill="#fff">${n}</text>`,
  tekst: (x, y, t, o = {}) => `<text x="${x}" y="${y}" font-size="${o.r || 9.5}" font-weight="${o.w || 600}" text-anchor="${o.a || 'start'}" fill="${o.k || '#5E788A'}">${esc(t)}</text>`,
};
const KT0 = kt;
/* symbol w rozciągniętym rysunku: kotwica się przesuwa, wielkość zostaje */
let KT_KOTWICE = [];   // miejsca symboli armatury — numerek trzyma się najbliższego
const ktSymG = (x, y, s) => KT_ROZ === 1 ? s
  : `<g transform="translate(${x} ${y}) scale(${+(1 / KT_ROZ).toFixed(5)}) translate(${-x} ${-y})">${s}</g>`;
const ktSym = (x, y, s) => { KT_KOTWICE.push([x, y]); return ktSymG(x, y, s); };
const KT_SKAL = {};
for (const n of ['reduktor', 'siatka', 'zawor', 'zwrotny', 'pompa', 'trojdrog', 'naczynie', 'bezp', 'wskaznik', 'separator', 'filtr', 'odpow', 'czujnik', 'stb'])
  KT_SKAL[n] = (x, y, ...r) => ktSym(x, y, KT0[n](x, y, ...r));
for (const n of ['strz', 'tekst'])
  KT_SKAL[n] = (x, y, ...r) => ktSymG(x, y, KT0[n](x, y, ...r));
/* Numerek odkładamy na koniec: gdy stoi przy symbolu armatury, zachowuje
   do niego tę samą odległość co przed rozciągnięciem, a nie odjeżdża. */
KT_SKAL.nr = (x, y, n) => `@@NR ${x} ${y} ${n}@@`;
function ktNumerki(s) {
  return s.replace(/@@NR (\S+) (\S+) (\d+)@@/g, (_, xs, ys, n) => {
    const x = +xs, y = +ys;
    const [px, py] = ktNrPoz(x, y);
    return ktSymG(px, py, KT0.nr(px, py, n));
  });
}
function ktNrPoz(x, y) {
  let best = null, dmin = 50;
  for (const [ax, ay] of KT_KOTWICE) { const d = Math.hypot(ax - x, ay - y); if (d < dmin) { dmin = d; best = [ax, ay]; } }
  if (!best) return [x, y];
  const [ax, ay] = best, k = 1 / KT_ROZ;
  return [ax + (x - ax) * k, ay + (y - ay) * k];   // w jednostkach rysowania
}
const ktS = Object.assign({}, KT0, KT_SKAL);

/* ---------- dobór źródła i bufora z zapotrzebowania obiegów ----------
   Szacunek do wyboru urządzeń, nie projekt: zapotrzebowanie w kW
   instalator przynosi z projektu, audytu albo kalkulatora strat. */
const KT_BUF_TYP = [200, 300, 400, 500, 600, 800, 1000, 1200, 1500, 2000];
/* Przyłącza wg przepływu (prędkość w rurze ok. 0,8 m/s) — tak też
   producenci opisują sprzęgła: „do X m³/h, przyłącza DN…”. */
const KT_DN = [[25, 'DN25 (1")', 2.5], [32, 'DN32 (5/4")', 4], [40, 'DN40 (6/4")', 6], [50, 'DN50 (2")', 9], [65, 'DN65 (2½")', 15], [80, 'DN80 (3")', 25]];
/* Typowe wymiary buforów bez izolacji: średnica × wysokość, mm.
   Izolacja dokłada ok. 100 mm średnicy — zakłada się ją na miejscu. */
const KT_BUF_WYM = { 200: [550, 1250], 300: [550, 1600], 400: [650, 1500], 500: [650, 1750], 600: [700, 1800],
  800: [790, 1800], 1000: [790, 2050], 1200: [850, 2150], 1500: [1000, 2100], 2000: [1100, 2300] };
const KT_MOC_GAZ = [12, 15, 18, 20, 24, 25, 28, 30, 35, 45, 50, 65, 80, 100];
function ktDobor(k) {
  const qco = k.kw.reduce((a, b) => a + b, 0);
  if (!qco) return null;
  const V = k.cwu === 'zas' ? k.zasL : 0;
  const eCwu = V * 4.19 * 45 / 3600;            // kWh na nagrzanie 10 → 55 °C
  const tCwu = k.pc ? 2 : 1;                    // docelowy czas nagrzania, h
  const qcwu = V ? eCwu / tCwu : k.cwu === 'przep' ? 24 : 0;
  let p, opisP;
  if (k.gaz && k.cwu === 'zas' && !k.prio) {
    p = qco * 1.1 + qcwu;
    opisP = 'Bez priorytetu c.w.u.: kocioł grzeje dom i zasobnik jednocześnie, więc moce się sumują — c.o. ' + fmt(qco * 1.1, 1) + ' kW (z zapasem 10%) + nagrzanie zasobnika ' + fmt(qcwu, 1) + ' kW.';
  } else if (k.gaz) {
    p = Math.max(qco * 1.1, qcwu);
    opisP = k.cwu === 'przep' ? 'Kocioł 2F: moc dyktuje woda przepływowa (ok. 24 kW na 1 punkt poboru), c.o. ' + fmt(qco, 1) + ' kW + 10%.'
      : 'Z priorytetem c.w.u. (kocioł na czas grzania wody wyłącza c.o.): liczy się większa z mocy na c.o. (' + fmt(qco * 1.1, 1) + ' kW z zapasem 10%) i na nagrzanie zasobnika (' + fmt(qcwu, 1) + ' kW), a nie ich suma.';
  } else if (k.pc) {
    p = qco * 1.1;
    opisP = 'C.o. ' + fmt(qco, 1) + ' kW + 10% na blokady operatora i grzanie c.w.u. To moc w punkcie projektowym (np. przy −20 °C) — sprawdź ją w DTR, nie moc nominalną z naklejki.';
  } else {
    const z = k.zr === 'drew' ? 1.3 : 1.1;
    p = qco * z;
    opisP = k.zr === 'drew' ? 'C.o. ' + fmt(qco, 1) + ' kW + 30%: kocioł zgazowujący pali z przerwami, więc w czasie palenia musi grzać dom i ładować bufor.'
      : 'C.o. ' + fmt(qco, 1) + ' kW + 10%. Zasobnik grzeje się z kotła albo bufora, więc jego moc się nie dodaje.';
  }
  const pDob = k.gaz ? (KT_MOC_GAZ.find(x => x >= p - 0.05) || Math.ceil(p)) : Math.ceil(p);
  let vb = 0, opisB = '';
  if (k.rozdz === 'buf') {
    const lkw = k.zr === 'drew' ? 55 : k.stale ? 25 : 20;
    vb = lkw * pDob;
    opisB = k.zr === 'drew' ? 'Zgazowanie drewna: minimum 55 l na kW mocy kotła (PN-EN 303-5) — więcej oznacza rzadsze palenie.'
      : k.stale ? 'Pellet / węgiel: ok. 25 l na kW mocy kotła — kocioł rzadziej startuje, a bufor przejmuje szczyty.'
      : 'Pompa ciepła: ok. 20 l na kW mocy — na odszranianie i minimalny przepływ. Sprawdź wymaganie w DTR pompy.';
  }
  let vbDob = '', vbN = 0;
  if (vb) {
    /* Liczba zbiorników jest wyborem instalatora („Jeden bufor” / „Dwa
       bufory równolegle”) — dzielimy pojemność tylko wtedy, gdy tak wybrał. */
    /* Do typowej pojemności — tej bliższej, w górę albo w dół. Przy
       zgazowaniu drewna 55 l/kW to minimum z normy, więc w dół schodzimy
       tylko o kilka procent (do 5%); dla pelletu, węgla i pompy ciepła to
       zasada orientacyjna i liczy się po prostu bliższa wartość. */
    const typowa = need => {
      const gora = KT_BUF_TYP.find(x => x >= need), dol = [...KT_BUF_TYP].reverse().find(x => x <= need);
      if (!gora) return KT_BUF_TYP[KT_BUF_TYP.length - 1];
      if (!dol || dol === gora) return gora;
      if (k.zr === 'drew') return (need - dol) / need <= 0.05 ? dol : gora;
      return need - dol <= gora - need ? dol : gora;
    };
    if (k.bufy === 2) { vbDob = '2 × ' + typowa(vb / 2); vbN = 2; }
    else { vbDob = String(typowa(vb)); vbN = 1; }
  }
  const dt = (ob) => k.pc ? 5 : ob[0] === 'g' ? 15 : 5;
  /* Przepływ obiegu: z kalkulatora, jeśli obieg stamtąd przyszedł (jego Δt),
     inaczej z mocy i typowego Δt. */
  const rkQ = (i, s) => { const x = k.rk && k.rk[i]; return x && x.s === s && x.q > 0 ? x.q : 0; };
  const prz = k.obiegi.map((ob, i) => rkQ(i, 'obieg') || k.kw[i] / (1.163 * dt(ob)));
  // zawór mieszający każdego obiegu z mieszaczem — ten sam dobór co w kalkulatorze zaworu
  const zawory = k.obiegi.map((ob, i) => (ob === 'grzM' || ob === 'podlM') && prz[i] > 0 ? selectMixingValve(prz[i], DP_VALVE_MAX) : null);
  // sprzęgło / bufor: większy z przepływów — źródła albo instalacji
  const dtZr = k.pc ? 5 : k.gaz ? 20 : 15;
  const qZr = pDob / (1.163 * dtZr), qIn = prz.reduce((a, b) => a + b, 0), qMax = Math.max(qZr, qIn);
  const dn = KT_DN.find(x => qMax <= x[2]) || KT_DN[KT_DN.length - 1];
  const dSprz = Math.max(3 * dn[0], Math.ceil(Math.sqrt(4 * qMax / 3600 / (Math.PI * 0.15)) * 100) * 10);   // korpus: ok. 3 × przyłącze, v ≤ 0,15 m/s
  const vPoj = vbN === 2 ? +vbDob.replace('2 × ', '') : +vbDob;
  const wym = KT_BUF_WYM[vPoj];
  const dnBuf = vbN === 2 ? (KT_DN.find(x => qMax / 2 <= x[2]) || dn) : dn;
  /* Naczynie wzbiorcze c.o. z szacowanego zładu: grzejniki ok. 10 l/kW,
     podłogówka ok. 20 l/kW (z rurami i rozdzielaczem), do tego źródło,
     bufor, wężownica zasobnika i rury w kotłowni. Wysokość instalacji
     przyjęta ok. 8 m → ciśnienie wstępne 1,0 bar. */
  const vObiegi = k.obiegi.reduce((a, ob, i) => a + k.kw[i] * (ob[0] === 'p' ? 20 : 10), 0);
  const vZrodla = k.gaz ? 3 : k.pc ? 8 : Math.max(40, Math.round(pDob * 2.5));
  const vBufory = vPoj ? vPoj * (vbN || 1) : 0;
  const vWez = V ? Math.max(5, Math.round(V * 0.04)) : 0;
  const zlad = Math.round(k.wym ? vZrodla + vWez + 5 : vObiegi + vZrodla + vBufory + vWez + (k.rozdz === 'sprz' ? 5 : 0) + 10);
  const tMax = k.pc ? 60 : k.gaz ? 80 : 90, pw = k.stale ? 2.5 : 3, p0 = 1.0;
  const nac = k.otw ? null : expansionVessel(zlad, EXPANSION[tMax], p0, pw);
  const nacFabr = k.gaz ? 8 : 0;                 // fabryczne w kotle gazowym (zwykle 8 l)
  const nacDod = nac ? (nac.vn <= nacFabr ? 0 : standardVessel(nac.vn - nacFabr)) : 0;
  const vOtw = k.otw ? Math.ceil(zlad * 0.04 / 5) * 5 : 0;   // naczynie otwarte min. 4% zładu
  // naczynie c.w.u.: woda pitna, 60 °C, za reduktorem p₀ 3,5 bar, zawór 6 bar
  const nacCwu = V ? expansionVessel(V, EXPANSION[60], 3.5, 6, { reserve: false }) : null;
  /* Pompy. Przepływ z mocy i Δt; wysokość podnoszenia z oporów: rury
     tam i z powrotem (ok. 150 Pa/m + 30% na kształtki), odbiornik,
     zawór mieszający, armatura grupy — i 10% zapasu. Czego instalator
     nie wpisał, bierzemy typowe dla domu i oznaczamy jako szacunek. */
  const R = 0.15;
  const zPompa = (q, dp, szac, nazwa, opis) => ({ q, dp: dp * 1.1, H: dp * 1.1 / 9.81, szac, kl: ktKlasaPompy(q, dp * 1.1 / 9.81), nazwa, opis });
  const maPompy = k.rozdz !== 'brak' || k.obiegi.length > 1;
  const pompy = k.obiegi.map((ob, i) => {
    if (!k.kw[i] || !maPompy) return null;
    const podl = ob[0] === 'p';
    if (k.hP[i] > 0) {   // policzone w kalkulatorze — podłogówki, grzejników albo „Dobór pompy”
      const q = k.qP[i] || prz[i];
      // pompa z kalkulatora grzejników: mieszacz jest dopiero w kotłowni, więc dokładamy jego spadek
      const H = k.hPz[i] === 'co' && zawory[i] ? k.hP[i] + zawory[i].dp * 100 * 1.1 / 9.81 : k.hP[i];
      return { q, H, dp: H * 9.81, szac: k.hPz[i] === 'podlSzac', kl: ktKlasaPompy(q, H), zKalk: true,
        opis: k.hPz[i] === 'pump' ? 'z kalkulatora „Dobór pompy”' : k.hPz[i] === 'co' ? 'z kalkulatora „Ogrzewanie grzejnikowe”'
          : 'z kalkulatora „Ogrzewanie podłogowe”' + (k.hPz[i] === 'podlSzac' ? ' (typowa pętla 80 m)' : '') };
    }
    if (podl) {
      /* Podłogówkę liczymy tym samym silnikiem co kalkulator „Ogrzewanie
         podłogowe” (pętla, przepływomierz, belka, rura, zawór) — wtedy wynik
         zgadza się z kalkulatorem tak samo jak Kvs mieszacza. Mieszacz stoi
         tu w kotłowni, więc pompa pokonuje też rurę do rozdzielacza. */
      try {
        const wyj = k.wyj[i] || Math.max(2, Math.round(k.kw[i] / 1.2));
        const r = dojsciaRozdzielaczy([{ nazwa: '', w: k.kw[i] * 1000, wyj, dl: k.dl[i] || 10, dp: k.dpp[i] || 20 }],
          { dtCo: k.pc ? 5 : k.gaz ? 20 : 15, dtPod: 5, mieszacz: ob === 'podlM', wspolnyMieszacz: ob === 'podlM', mat: 'copper', v: 0.6, zapas: 10 });
        const pp = r.pozycje[0].pompa;
        const q = pp.q;
        return { q, H: pp.H, dp: pp.zZapasem, szac: !(k.dl[i] && k.dpp[i]), kl: ktKlasaPompy(q, pp.H),
          opis: 'pętla ' + fmt(pp.dpPetli, 1) + ' + przepływomierz ' + fmt(pp.dpPrzeplywomierz, 1) + ' + belka ' + fmt(pp.dpBelki, 2)
            + ' + rura ' + fmt(pp.dpRury, 1) + (pp.dpZaworu ? ' + zawór ' + fmt(pp.dpZaworu, 1) : '') + ' kPa' };
      } catch (e) { /* awaryjnie szacunek niżej */ }
    }
    const dl = k.dl[i] || (podl ? 10 : 25);
    const rury = 2 * dl * R * 1.3;
    const odb = podl ? (k.dpp[i] || 20) + 5 : 10;
    const mie = zawory[i] ? zawory[i].dp * 100 : 0;
    const szac = podl ? !(k.dl[i] && k.dpp[i]) : !k.dl[i];
    return zPompa(prz[i], rury + odb + mie + 3, szac, '', (podl ? 'pętla ' + fmt(odb - 5, 0) + ' + rozdzielacz 5' : 'grzejnik i zawór term. ' + fmt(odb, 0))
      + ' + rury ' + fmt(rury, 1) + (mie ? ' + mieszacz ' + fmt(mie, 1) : '') + ' + armatura 3 kPa');
  });
  const pompyZr = [];
  const zKalk = (x, nazwa) => ({ q: x.q, H: x.H, dp: x.H * 9.81, szac: false, zKalk: true, kl: ktKlasaPompy(x.q, x.H), nazwa, opis: 'z kalkulatora „Dobór pompy”' });
  if (k.stale && k.pKotl) pompyZr.push(zKalk(k.pKotl, k.ochr === 'ladd' ? 'Pompa w zespole ładującym' : 'Pompa kotłowa'));
  else if (k.stale) pompyZr.push(zPompa(qZr, (k.ochr === 'ladd' ? 4 : 6) + 3 + 2 + 2 * 6 * R * 1.3 + 1, true, k.ochr === 'ladd' ? 'Pompa w zespole ładującym' : 'Pompa kotłowa',
    'kocioł 3 + ' + (k.ochr === 'ladd' ? 'zespół ładujący 4' : 'zawór ochrony powrotu 6') + ' + separator 2 + rury i zwrotny'));
  if (k.stale && V && k.pCwu) pompyZr.push(zKalk(k.pCwu, 'Pompa ładująca c.w.u.'));
  else if (k.stale && V) { const qL = pDob / (1.163 * 15); pompyZr.push(zPompa(qL, 10 + 2 * 5 * R * 1.3 + 3, true, 'Pompa ładująca c.w.u.', 'wężownica 10 + rury + filtr i zwrotny 3')); }
  if (k.cyrk && k.pCyrk) pompyZr.push({ q: k.pCyrk.q, H: k.pCyrk.H, szac: false, zKalk: true, kl: 'cyrkulacyjna', nazwa: 'Pompa cyrkulacyjna',
    opis: 'z kalkulatora „Dobór pompy”: ' + fmt(k.pCyrk.q, 2) + ' m³/h przy ' + fmt(k.pCyrk.H, 1) + ' m — do wody pitnej, z zegarem lub termostatem' });
  else if (k.cyrk) pompyZr.push({ q: 0.2, H: 1.2, szac: true, kl: 'cyrkulacyjna', nazwa: 'Pompa cyrkulacyjna', opis: 'do wody pitnej (korpus z brązu albo stali nierdzewnej), z zegarem lub termostatem' });
  /* ---------- rury w kotłowni ----------
     Kocioł ↔ sprzęgło/bufor, wężownica zasobnika i sprzęgło ↔ rozdzielacz.
     Średnica z prędkości (do ok. 0,8 m/s — krótkie odcinki w kotłowni), ale nie mniejsza niż króciec:
     rura nie może być cieńsza od gwintu, w który się ją wkręca. */
  /* Średnica nominalna DN (materiał dobiera instalator do systemu).
     Króciec podany jako rura miedziana → odpowiadający mu DN. */
  const ktMat = 'steel';
  const naDN = mm => ({ 15: 21.3, 22: 26.9, 28: 33.7, 35: 42.4, 42: 48.3 })[mm] || 0;
  const krZr = k.krocce === 'auto' ? (k.gaz ? 22 : k.pc ? 28 : 35)
    : ((PRZYLACZA_KOTLA.find(x => x[0] === k.krocce) || [0, 0, 0])[2]);
  /* Obieg z mieszaczem: od rozdzielacza do mieszacza płynie tylko woda
     ze źródła (Δt źródła), za mieszaczem — cały przepływ obiegu (Δt obiegu,
     ten sam, na który liczy się Kvs). Tak samo liczy kalkulator podłogówki. */
  const przP = k.obiegi.map((ob, i) => (ob === 'grzM' || ob === 'podlM') ? (rkQ(i, 'zrodlo') || Math.min(prz[i], k.kw[i] / (1.163 * dtZr))) : prz[i]);
  const qIn1 = przP.reduce((a, b) => a + b, 0);
  const rura = (q, minD, v) => { const r = q > 0 ? selectPipe(q, ktMat, v || 0.8, naDN(minD)) : null; return r ? Object.assign(r, { q }) : null; };
  /* Obieg przeniesiony z kalkulatora: rura stamtąd (przeliczona na DN)
     i jego prędkość — żeby schemat zgadzał się z kalkulatorem. */
  const rkO = i => (k.rk && k.rk[i]) || null;
  const vOb = i => (rkO(i) && rkO(i).v) || 0.8;
  const rk = (i, strona) => {
    const x = rkO(i);
    if (!x || x.s !== strona) return null;
    const dn = ktDNzRury(x.mat, x.p, x.in);
    return dn ? { pick: dn, q: x.q, vAct: x.vAct, zKalk: true } : null;
  };
  const rury = {
    mat: ktMat,
    zr: rura(k.rozdz === 'brak' ? Math.max(qZr, qIn) : qZr, krZr),
    roz: k.rozdz !== 'brak' && k.obiegi.length ? rura(qIn1, 0) : null,
    ob: prz.map((q, i) => rk(i, 'obieg') || rura(q, 0, vOb(i))),     // za mieszaczem (cały obieg)
    obP: przP.map((q, i) => rk(i, 'zrodlo') || rura(q, 0, vOb(i))),  // przed mieszaczem (woda ze źródła)
    pion: przP.map((_, i) => rura(przP.slice(i + 1).reduce((a, b) => a + b, 0), 0)),
    cwu: V ? rura((k.prio ? pDob : qcwu) / (1.163 * (k.pc ? 7 : 15)), V <= 150 ? 22 : V <= 500 ? 28 : 35) : null,
  };
  /* Rozdzielacz w kotłowni: przyłącze z sumy przepływów (woda ze źródła),
     ale nie mniejsze niż rura, która do niego dochodzi. */
  const dnRozQ = KT_DN.find(x => qIn1 <= x[2]) || KT_DN[KT_DN.length - 1];
  const dnRura = k.rozdz === 'brak' ? (rury.zr ? +(String(rury.zr.pick[0]).match(/DN(\d+)/) || [0, 0])[1] : 0)
    : (rury.roz ? +(String(rury.roz.pick[0]).match(/DN(\d+)/) || [0, 0])[1] : 0);
  const dnRoz = dnRozQ[0] >= dnRura ? dnRozQ : (KT_DN.find(x => x[0] >= dnRura) || dnRozQ);
  /* Rozdzielacz spawany z rury: korpus tak gruby, żeby woda płynęła w nim
     wolno (do ok. 0,3 m/s) — wtedy każdy obieg ma to samo ciśnienie na
     odejściu — i zawsze co najmniej rozmiar większy niż przyłącze. */
  const KORPUSY = [[25, 'DN25', 33.7, 27.3], [32, 'DN32', 42.4, 36], [40, 'DN40', 48.3, 41.9], [50, 'DN50', 60.3, 53.1],
    [65, 'DN65', 76.1, 68.9], [80, 'DN80', 88.9, 80.9], [100, 'DN100', 114.3, 105.3]];
  const dKorp = Math.sqrt(4 * qIn1 / 3600 / (Math.PI * 0.3)) * 1000;
  const korpusRoz = KORPUSY.find(x => x[0] > dnRoz[0] && x[3] >= dKorp) || KORPUSY[KORPUSY.length - 1];
  /* Króćce sprzęgła nie mniejsze niż rury, które do nich dochodzą. */
  const dnNr = r => r ? +(String(r.pick[0]).match(/DN(\d+)/) || [0, 0])[1] : 0;
  const dnMin = Math.max(dnNr(rury.zr), dnNr(rury.roz));
  const dnS = dn[0] >= dnMin ? dn : (KT_DN.find(x => x[0] >= dnMin) || dn);
  const dSprzS = dnS === dn ? dSprz : Math.max(3 * dnS[0], dSprz);
  return { rury, pompy, pompyZr, maPompy, qco, V, eCwu, qcwu, p, pDob, opisP, vb, vbDob, vbN, opisB, prz, dts: k.obiegi.map((ob, i) => prz[i] > 0 && k.kw[i] > 0 ? Math.round(k.kw[i] / (1.163 * prz[i])) : dt(ob)),
    zawory, zlad, vObiegi, vZrodla, vBufory, vWez, tMax, pw, p0, nac, nacFabr, nacDod, vOtw, nacCwu, dtZr, qZr, qIn, qMax, dn: dnS, dSprz: dSprzS, wym, dnBuf, qIn1, dnRoz, korpusRoz,
    tNagrz: V ? eCwu / (k.pc ? Math.min(pDob, V / 50) : pDob) * 60 : 0 };
}

/* ---------- schemat i lista elementów ---------- */
function ktSchemat(k) {
  const kt = ktS, sym = ktSym;      // symbole w stałej wielkości (patrz KT_ROZ)
  KT_KOTWICE = [];
  const el = [], dod = [];          // el — z numerem na rysunku, dod — bez rysunku
  const D = ktDobor(k);             // dobór z wpisanych kW (może być null)
  const klik = (rodzaj, i, s) => `<g data-ktklik="${rodzaj}" data-i="${i}" style="cursor:pointer">${s}</g>`;
  /* Pompa do dotknięcia: pomarańczowy przerywany pierścień = „dotknij, żeby
     dobrać w kalkulatorze”, zielony pełny = już dobrana z kalkulatora. */
  const pK = (rodzaj, i, x, y, kier) => {
    const pp = !D ? null : rodzaj === 'ob' ? D.pompy[i] : (D.pompyZr || []).find(z => z.nazwa && (rodzaj === 'cwu' ? /ładująca/.test(z.nazwa) : rodzaj === 'cyrk' ? /cyrkulacyjna/.test(z.nazwa) : /kotłowa|zespole/.test(z.nazwa)));
    const ok = (pp && pp.zKalk) || (rodzaj === 'cyrk' && !!k.pCyrk);
    return `<g data-ktpompa="${rodzaj}" data-i="${i}" style="cursor:pointer">`
      + ktSym(x, y, `<circle cx="${x}" cy="${y}" r="13.5" fill="${ok ? '#E8F7EE' : '#FFF4EC'}" stroke="${ok ? '#22A15A' : '#FF7A33'}" stroke-width="1.6"${ok ? '' : ' stroke-dasharray="3.5 2.5"'}/>`)
      + kt.pompa(x, y, kier)
      + ktSym(x, y, `<circle cx="${x}" cy="${y}" r="17" fill="#fff" fill-opacity="0"/>`) + '</g>';
  };
  const nr = (nazwa, uwaga, krotka) => { el.push([el.length + 1, nazwa, uwaga, krotka || nazwa]); return el.length; };
  const raz = {};                   // ten sam element w kilku obiegach — jeden numer
  const nrRaz = (nazwa, uwaga, krotka) => raz[nazwa] || (raz[nazwa] = nr(nazwa, uwaga, krotka));
  let szyny = '', g = '', top = '';   // kolejność warstw: szyny, reszta, numerki
  const Z = KT_KOL.zas, Pw = KT_KOL.pow;
  const yS = 48, yP = 98;                       // poziom zasilania i powrotu przy źródle
  // Paliwo stałe ma najwięcej armatury przy kotle i dwie nitki zasobnika
  // przed buforem — dlatego cały rysunek jest o 60 szerszy.
  const dx = k.stale ? 60 : 0;
  /* Przy paliwie stałym grupy pompowe obiegów i c.w.u. rysujemy w pełni,
     jak w DTR kotłów: zawory kulowe, filtr siatkowy przed pompą,
     zawór zwrotny i odpowietrznik. Potrzebują więcej miejsca. */
  const det = !k.wym, ext = det ? 60 : 0;
  const pelna = k.stale;              // filtr siatkowy i odpowietrznik w grupach (jak w DTR kotłów stałopalnych)
  const xRz = k.stale ? 344 : k.pc ? 276 : 252;  // oś sprzęgła / bufora
  const xZr = 46, wZr = 84;                     // źródło
  const WIERSZ = 112;                           // wysokość wiersza obiegu
  const X = k.split ? { od: 198, odp: 216, tr: 238, fi: 224, pw: 258, pz: 296, sz: 208, mn: 0 }
    : k.pc ? { od: 158, bz: 174, odp: 192, tr: 212, na: 196, fi: 236, kfe: 176, pw: 258, pz: 296, sz: 166, mn: 232, az: 140 }
    : k.stale ? { od: 142, bz: 162, sz: 196, po: 190, zt: 218, pw: 248, na: 262, fi: 278, tr: 300, pz: 318, mn: 228, wz: 236 }
    : { od: 138, na: k.wym ? 230 : 290, tr: 178, fi: 164, pz: 182, zw: 200, sz: 164, pw: 216, mn: 210 };
  if (k.otw) { X.od = 148; X.mn = 262; X.pw = 256; }   // miejsce na rurę bezpieczeństwa i naczynie
  if (k.wym) X.mn = 186;                   // miejsce na opis wymiennika
  const xTp = k.otw ? 162 : k.stale ? 158 : k.pc ? 166 : 150;   // termometr na powrocie
  /* Dwa bufory równolegle: obok siebie, połączone kolektorem górnym
     (zasilanie) i dolnym (powrót). Rysunek robi się szerszy o tyle,
     ile trzeba, żeby za buforami zmieścił się rozdzielacz. */
  const bufy2 = k.bufy === 2;
  const xA = bufy2 ? Math.max(xRz, (X.pz || 0) + 30) + 6 : xRz, xB = xA + 44;
  const xHl = xA - 22, xHr = xB + 22, yT = yS - 30, yB = yP + 32;
  const d2 = bufy2 ? Math.max(0, xHr + 34 - (330 + dx)) : 0;
  const W0 = 470 + dx + ext + d2;    // szerokość w jednostkach rysowania
  KT_W = Math.round(W0 * KT_ROZ);
  const xSz = 330 + dx + d2, xSp = 344 + dx + d2;   // szyna zasilania i powrotu
  const nOb = k.obiegi.length;
  const yKon = yP + (nOb - 1) * WIERSZ;         // ostatni powrót
  const pompyObiegow = k.rozdz !== 'brak' || nOb > 1;
  let nFil = 0, nOdp = 0, nZwr = 0;
  const numFil = () => nFil || (nFil = nr('Filtr siatkowy (osadnik)',
    'Przed każdą pompą i przed zaworem termostatycznym — łapie zgorzelinę, piasek i opiłki, które przy kotle na paliwo stałe zawsze krążą w instalacji. Z zaworami kulowymi z obu stron, żeby dało się wyjąć siatkę bez spuszczania wody. Czyść po pierwszym tygodniu grzania, potem co sezon.',
    'Filtr siatkowy'));
  const numOdp = () => nOdp || (nOdp = nr('Odpowietrznik automatyczny',
    'W najwyższym punkcie każdej grupy i na górze bufora. Z zaworkiem stopowym, żeby dało się go wymienić bez spuszczania instalacji.',
    'Odpowietrznik'));
  const numZwr = () => nZwr || (nZwr = k.stale ? nr('Zawór zwrotny na powrocie do bufora',
    'Na powrocie obiegu z mieszaczem, za trójnikiem podmieszania. Nie pozwala, żeby pompa obiegu ssała wodę z dołu bufora „od tyłu” i żeby obiegi mieszały się ze sobą.',
    'Zawór zwrotny na powrocie')
    : nr('Zawór zwrotny na powrocie obiegu',
    'Na powrocie każdego obiegu, przed trójnikiem podmieszania. Kiedy pompa jednego obiegu stoi, nie płynie przez niego woda wypychana przez drugi obieg (grzejniki nie grzeją „same”), a mieszacz nie zasysa wody od strony powrotu.',
    'Zawór zwrotny obiegu'));

  /* ===== szyny rozdzielacza (pod spodem) ===== */
  /* Grupy pompowe w kotłowni → rozdzielacz z belkami. Grupy w szafkach
     na kondygnacjach → z kotłowni idą same rury, rozprowadzone trójnikami. */
  const belki = nOb > 1 && k.grp !== 'szaf';
  if (belki) {
    /* Rozdzielacz: dwie belki obok siebie — zasilanie (czerwona) i powrót
       (niebieska), u góry odpowietrzniki, na dole powrotu spust. */
    const yZk = yS + (nOb - 1) * WIERSZ;
    const belka = (x, y1, y2, kol, napis, yN) =>
      `<rect x="${x - 4}" y="${y1}" width="8" height="${y2 - y1}" rx="2.5" fill="${kol}" stroke="${KT_I}" stroke-width="1.3"/>`
      + sym(x, yN, `<text x="${x}" y="${yN}" transform="rotate(-90 ${x} ${yN})" font-size="6.5" font-weight="800" letter-spacing=".6" text-anchor="middle" dominant-baseline="central" fill="#fff">${napis}</text>`);
    szyny += belka(xSz, yS - 12, yZk + 10, Z, 'ZASILANIE', (yS + yP) / 2);
    szyny += belka(xSp, yP - 12, yKon + 12, Pw, 'POWRÓT', (yP + yS + WIERSZ) / 2);
    szyny += kt.odpow(xSz, yS - 12) + kt.odpow(xSp, yP - 12);
    szyny += sym(xSp, yKon + 12, `<path d="M${xSp} ${yKon + 12}v6" stroke="${KT_I}" stroke-width="1.5"/>` + KT0.zawor(xSp, yKon + 24, true));
  } else if (nOb > 1 || (nOb === 1 && k.rozdz !== 'brak')) {
    szyny += kt.rura([[xSz, yS], [xSz, yS + (nOb - 1) * WIERSZ]], Z);
    szyny += kt.rura([[xSp, yP], [xSp, yKon]], Pw);
  }

  /* ===== źródło ciepła ===== */
  if (!k.split) g += `<rect x="${xZr}" y="30" width="${wZr}" height="${k.stale ? 96 : 86}" rx="8" fill="#fff" stroke="${KT_I}" stroke-width="1.6"/>`;
  if (k.stale) {
    const nazwaZr = { pel: 'Kocioł na pellet', weg: 'Kocioł węglowy (retortowy)', drew: 'Kocioł zgazowujący drewno' }[k.zr];
    // zasobnik paliwa z podajnikiem (pellet, węgiel) albo polana w komorze (zgazowanie)
    if (k.zr !== 'drew') {
      g += `<path d="M68 2H108L102 26H74Z" fill="#fff" stroke="${KT_I}" stroke-width="1.5" stroke-linejoin="round"/>`
        + `<path d="M88 26v4" stroke="${KT_I}" stroke-width="1.5"/>`;
      top += kt.nr(114, 12, nr('Zasobnik paliwa z podajnikiem',
        k.zr === 'pel' ? 'Czujnik temperatury podajnika i zabezpieczenie przed cofnięciem płomienia (zawór gaśniczy albo zrzut wody) — wymaga tego instrukcja kotła i ubezpieczyciel.'
                       : 'Podajnik ślimakowy albo tłokowy: zasobnik ustaw tak, żeby dało się go napełnić workiem i żeby pokrywa otwierała się na całą szerokość.'));
    } else {
      g += `<circle cx="68" cy="94" r="7" fill="none" stroke="${KT_I}" stroke-width="1.3"/><circle cx="84" cy="94" r="7" fill="none" stroke="${KT_I}" stroke-width="1.3"/><circle cx="76" cy="104" r="7" fill="none" stroke="${KT_I}" stroke-width="1.3"/>`;
    }
    // wężownica schładzająca w kotle — wymagana w układzie zamkniętym
    if (!k.otw) {
      g += `<path d="M46 54H112V62H54V70H100V126" fill="none" stroke="${KT_KOL.zw}" stroke-width="1.8"/>`;
      g += kt.rura([[14, 16], [24, 16], [24, 54], [46, 54]], KT_KOL.zw);
      g += kt.zaworTerm(24, 34, 56, 70);
      g += kt.tekst(14, 10, 'woda chłodz.', { r: 8, k: '#1E88B5', w: 700 });
      g += kt.rura([[100, 126], [100, 150]], '#8FA3B2', 1.6, true) + kt.tekst(106, 148, 'kanalizacja', { r: 8 });
    }
    if (k.zr !== 'drew') g += `<path d="M${xZr + 42} 84c5 6 9 10 9 17a9 9 0 0 1-18 0c0-4 3-7 4-10 1 3 2 4 3 4 0-4 2-7 2-11z" fill="#FFE1D1" stroke="#FF7A33" stroke-width="1.4"/>`;
    g += kt.tekst(xZr + 42, 120, KT_STALE[k.zr], { a: 'middle', r: 8.5, k: KT_I, w: 700 });
    top += kt.nr(xZr + 6, 30, nr(nazwaZr,
      k.zr === 'drew' ? 'Pracuje pełną mocą przez cały załadunek — nadmiar ciepła musi iść do bufora, inaczej kocioł się dusi i smoli. Komin wymurowany albo wkład ze stali kwasoodpornej, z wkładką nad palenisko wg DTR.'
      : 'Sprawdź w DTR wymagany ciąg kominowy i średnicę czopucha. Kocioł musi mieć ogranicznik temperatury bezpieczeństwa (STB) i czujnik temperatury spalin, jeśli wymaga tego instrukcja.'));
    if (!k.otw) top += kt.nr(24, 72, nr('Wężownica schładzająca z zaworem termicznym',
      'W układzie zamkniętym to warunek legalnego montażu kotła na paliwo stałe (urządzenie do odprowadzania nadmiaru ciepła). Zasilana z wodociągu — na dolocie nie może być zaworu odcinającego, wylot przez lejek do kanalizacji. Czujnik w tulei kotła.', 'Wężownica schładzająca'));
  } else if (k.split) {
    /* Split: na zewnątrz stoi sprężarka, w budynku moduł z wymiennikiem.
       Woda nie wychodzi na dwór, więc nie ma glikolu ani zaworów
       antyzamrożeniowych — za to między jednostkami idzie czynnik chłodniczy. */
    const xJz = 14, wJz = 66, xMw = 104, wMw = 84;
    g += `<rect x="${xJz}" y="34" width="${wJz}" height="76" rx="8" fill="#fff" stroke="${KT_I}" stroke-width="1.6"/>`
      + `<circle cx="${xJz + 33}" cy="64" r="17" fill="none" stroke="${KT_I}" stroke-width="1.4"/>`
      + `<path d="M${xJz + 33} 64l10 -7M${xJz + 33} 64l-10 7M${xJz + 33} 64l7 10M${xJz + 33} 64l-7 -10" stroke="${KT_I}" stroke-width="1.5" stroke-linecap="round"/>`
      + kt.tekst(xJz + 33, 102, 'JEDN. ZEWN.', { a: 'middle', r: 8, k: KT_I, w: 700 });
    g += `<path d="M92 16V136" stroke="#9AAFBF" stroke-width="1.4" stroke-dasharray="5 4"/>`
      + kt.tekst(88, 12, 'na zewnątrz', { a: 'end', r: 8 }) + kt.tekst(96, 12, 'w budynku', { r: 8 });
    // przewody czynnika chłodniczego
    g += kt.rura([[xJz + wJz, 58], [xMw, 58]], KT_KOL.cyrk) + kt.rura([[xJz + wJz, 76], [xMw, 76]], KT_KOL.cyrk);
    g += kt.tekst(90, 150, 'czynnik chłodniczy', { a: 'middle', r: 8, k: KT_KOL.cyrk, w: 700 });
    g += kt.rura([[90, 140], [90, 86]], KT_KOL.cyrk, 1.2, true);
    // moduł wewnętrzny z wymiennikiem i pompą
    g += `<rect x="${xMw}" y="30" width="${wMw}" height="84" rx="8" fill="#fff" stroke="${KT_I}" stroke-width="1.6"/>`;
    g += `<rect x="${xMw + 8}" y="44" width="18" height="52" rx="2.5" fill="#fff" stroke="${KT_I}" stroke-width="1.4"/>`;
    for (let i = 0; i < 2; i++) g += `<path d="M${xMw + 11} ${52 + i * 22}l12 11l-12 11" fill="none" stroke="${KT_I}" stroke-width="1.1"/>`;
    g += kt.rura([[xMw + 26, yS], [xMw + wMw, yS]], Z) + kt.rura([[xMw + wMw, yP], [xMw + 26, yP]], Pw);
    g += kt.pompa(xMw + 52, yS, 'p');
    g += kt.tekst(xMw + wMw / 2, 126, 'MODUŁ WEWNĘTRZNY', { a: 'middle', r: 8, k: KT_I, w: 700 });
    top += kt.nr(xJz + 6, 34, nr('Jednostka zewnętrzna (split)',
      'Na podstawie albo konsoli, z odpływem skroplin i wolną przestrzenią wg DTR. Instalacja i napełnianie czynnika tylko z uprawnieniami F-gaz.',
      'Jednostka zewnętrzna'));
    top += kt.nr(90, 96, nr('Przewody czynnika chłodniczego',
      'Dwie izolowane rury miedziane między jednostkami: długość trasy i różnica poziomów wg DTR. Po połączeniu próba szczelności i wytworzenie próżni, przy dłuższej trasie dopełnienie czynnika. Woda nie wychodzi na zewnątrz, więc nie trzeba glikolu ani zaworów antyzamrożeniowych.',
      'Przewody czynnika chłodniczego'));
    top += kt.nr(xMw + 6, 30, nr('Moduł wewnętrzny (hydrobox)',
      'W środku siedzi wymiennik (skraplacz), pompa obiegowa, naczynie przeponowe, zawór bezpieczeństwa, manometr i zwykle grzałka — dlatego nie dokładasz ich osobno na rurach. W części modułów jest też zawór 3-drogowy c.w.u. i czujnik przepływu; sprawdź w DTR, czego nie trzeba montować podwójnie.',
      'Moduł wewnętrzny (hydrobox)'));
  } else if (k.pc) {
    g += `<circle cx="${xZr + 42}" cy="64" r="20" fill="none" stroke="${KT_I}" stroke-width="1.4"/>`
      + `<path d="M${xZr + 42} 64l12 -8M${xZr + 42} 64l-12 8M${xZr + 42} 64l8 12M${xZr + 42} 64l-8 -12" stroke="${KT_I}" stroke-width="1.6" stroke-linecap="round"/>`
      + kt.tekst(xZr + 42, 106, 'MONOBLOK', { a: 'middle', r: 8.5, k: KT_I, w: 700 });
    g += `<path d="M150 18V134" stroke="#9AAFBF" stroke-width="1.4" stroke-dasharray="5 4"/>`
      + kt.tekst(146, 14, 'na zewnątrz', { a: 'end', r: 8 }) + kt.tekst(154, 14, 'w budynku', { r: 8 });
    top += kt.nr(xZr + 6, 30, nr('Pompa ciepła — monoblok',
      'Cały układ chłodniczy jest w jednostce na zewnątrz, więc nie ma przewodów z czynnikiem i nie trzeba uprawnień F-gaz. Za to woda krąży na dworze: sprawdź w DTR minimalny przepływ i minimalną pojemność wodną instalacji.'));
    // zawory antyzamrożeniowe na obu rurach, po stronie zewnętrznej
    g += kt.zawor(X.az, yS, true) + kt.zawor(X.az, yP, true);
    g += sym(X.az, yS, KT0.rura([[X.az - 7, yS + 8], [X.az - 7, yS + 16]], '#8FA3B2', 1.4, true))
      + sym(X.az, yP, KT0.rura([[X.az - 7, yP + 8], [X.az - 7, yP + 16]], '#8FA3B2', 1.4, true));
    top += kt.nr(X.az, 24, nr('Zawory antyzamrożeniowe',
      'Dwa, na zasilaniu i powrocie, w najniższym punkcie po stronie zewnętrznej. Przy ok. 3 °C otwierają się i zrzucają wodę, żeby wymiennik nie pękł przy zaniku prądu. Alternatywa to napełnienie instalacji glikolem — wtedy pamiętaj o korekcie przepływu i mocy.',
      'Zawory antyzamrożeniowe'));
  } else {
    g += `<path d="M${xZr + 42} 44c7 9 13 14 13 25a13 13 0 0 1-26 0c0-6 4-10 6-14 1 4 3 6 5 6 0-6 2-11 2-17z" fill="#FFE1D1" stroke="#FF7A33" stroke-width="1.6"/>`
      + kt.tekst(xZr + 42, 106, k.zr === 'k2' ? 'KOCIOŁ 2F' : 'KOCIOŁ', { a: 'middle', r: 8.5, k: KT_I, w: 700 });
    top += kt.nr(xZr + 6, 30, nr(k.zr === 'k2' ? 'Kocioł kondensacyjny dwufunkcyjny' : 'Kocioł kondensacyjny jednofunkcyjny',
      'Ma w środku pompę, naczynie wzbiorcze i zawór bezpieczeństwa. Przyłącze gazu z kurkiem — prace przy gazie tylko z uprawnieniami.',
      k.zr === 'k2' ? 'Kocioł kondensacyjny 2F' : 'Kocioł kondensacyjny 1F'));
    g += kt.rura([[118, 116], [118, 146]], '#8FA3B2', 1.6, true) + kt.tekst(118, 154, 'kondensat', { a: 'middle', r: 8 });
    g += sym(118, 131, `<rect x="111" y="124" width="14" height="14" rx="2" fill="#fff" stroke="${KT_I}" stroke-width="1.3"/><text x="118" y="134.5" font-size="8" font-weight="700" text-anchor="middle" fill="${KT_I}">N</text>`);
    top += kt.nr(134, 131, nr('Neutralizator i odprowadzenie kondensatu',
      'Kondensat jest kwaśny: przez neutralizator (wkład z granulatem do wymiany co rok–dwa) i syfon do kanalizacji, ze spadkiem. Bez syfonu cofają się zapachy, a przy niektórych kotłach spaliny. Neutralizator obowiązkowo przy przydomowej oczyszczalni, rurach żeliwnych albo gdy wymaga go DTR.',
      'Neutralizator kondensatu'));
  }

  /* ===== rury źródła ===== */
  const xKonZ = k.rozdz === 'brak' ? xSz : bufy2 ? xHl : xRz - (k.rozdz === 'buf' ? 14 : k.rozdz === 'wym' ? 13 : 8);
  const xKonP = k.rozdz === 'brak' ? xSp : xKonZ;
  g += kt.rura([[xZr + wZr, yS], [xKonZ, yS]], Z);
  g += (k.rozdz === 'brak' && nOb > 1 ? kt.most : kt.rura)([[xKonP, yP], [xZr + wZr, yP]], Pw);
  g += kt.strz(X.sz, yS, 'p', Z) + kt.strz(X.pw, yP, 'l', Pw);
  if (!k.obiegi.length) {   // bez obiegów: rury kończą się podpisem
    g += kt.tekst(xSz + 6, yS + 3, '→ do obiegów', { r: 8, k: '#8CA0B0', w: 700 })
      + kt.tekst(xSp + 6, yP + 3, '← z obiegów', { r: 8, k: '#8CA0B0', w: 700 });
  }

  if (k.split) {
    /* zawór bezpieczeństwa, naczynie i manometr są w module wewnętrznym */
  } else if (k.otw) {
    /* naczynie wzbiorcze otwarte w najwyższym punkcie, rura bezpieczeństwa
       z kotła i rura wzbiorcza do powrotu — obie bez żadnych zaworów */
    g += `<path d="M150 2V24H218V2" fill="#fff" stroke="${KT_I}" stroke-width="1.6" stroke-linejoin="round"/>`
      + `<path d="M154 13H214" stroke="${KT_KOL.zw}" stroke-width="1.4" stroke-dasharray="4 3"/>`
      + kt.tekst(184, 21, D && D.vOtw ? 'otwarte ≥ ' + D.vOtw + ' l' : 'otwarte', { a: 'middle', r: 7.5, k: D && D.vOtw ? KT_I : '#8CA0B0', w: 700 })
      + `<path d="M218 7H236" stroke="#8FA3B2" stroke-width="1.6"/>` + kt.tekst(238, 10, 'przelew', { r: 7.5 });
    g += kt.rura([[140, yS], [140, 30], [168, 30], [168, 24]], Z);
    g += kt.most([[200, 24], [200, 58], [X.wz, 58], [X.wz, yP]], Pw);
    top += kt.nr(134, 20, nr('Naczynie wzbiorcze otwarte',
      'W najwyższym punkcie instalacji, zawsze nad kotłem. Pojemność minimum 4% zładu — policz zład w kalkulatorze „Pojemność instalacji”. Na nieogrzewanym poddaszu izoluj naczynie i rury, inaczej zamarzną. Przelew poprowadź do kanalizacji tak, żeby było widać wypływ.',
      'Naczynie wzbiorcze otwarte'));
    top += kt.nr(186, 38, nr('Rura bezpieczeństwa i wzbiorcza',
      'Obie prowadzone ze stałym wzniosem do naczynia i bez żadnej armatury — żaden zawór, filtr ani zwężenie nie może ich odciąć. Średnice dobierz wg mocy kotła (PN-91/B-02413); rura bezpieczeństwa wychodzi z zasilania kotła, wzbiorcza wraca na powrót.',
      'Rura bezpieczeństwa i wzbiorcza'));
  } else {
  if (!k.gaz) {
  g += kt.bezp(X.bz, yS, Z);
  top += kt.nr(X.bz - 13, yS - 24, nr('Zawór bezpieczeństwa c.o.',
    k.stale ? 'Na zasilaniu tuż przy kotle, bez żadnego zaworu odcinającego po drodze. Nastawa wg DTR kotła (najczęściej 2,5 bar). Dobierzesz go w kalkulatorze „Zawór bezpieczeństwa”.'
    : k.gaz ? 'W kotle jest fabryczny. Zewnętrzny dokładasz tylko wtedy, gdy wymaga go instrukcja — zawsze bez zaworu odcinającego między nim a źródłem.'
            : 'Zwykle w module pompy albo w zestawie przyłączeniowym. Między nim a pompą ciepła nie może być zaworu odcinającego.'));
  }
  g += kt.naczynie(X.na, yP, Pw);
  if (D && D.nac) {
    const nap = k.gaz ? (D.nacDod ? '+' + D.nacDod + ' l' : 'fabr. ' + D.nacFabr + ' l') : D.nac.rec + ' l';
    g += kt.tekst(X.na, yP + 32, nap, { a: 'middle', r: 7.5, k: KT_I, w: 800 })
      + kt.tekst(X.na, yP + 39, 'p₀ ' + fmt(D.p0, 1) + ' bar', { a: 'middle', r: 6.5 });
  }
  top += kt.nr(X.na + (k.stale || k.pc ? -14 : 14), yP + 22, nr('Naczynie wzbiorcze c.o.',
    k.stale ? 'Przy kotle na paliwo stałe naczynie liczy się na cały zład razem z buforem — wychodzi duże. Układ zamknięty wolno zrobić tylko z urządzeniem odprowadzającym nadmiar ciepła (wężownica schładzająca). Alternatywa to naczynie otwarte nad kotłem.'
    : k.gaz ? (k.wym ? 'Po stronie kotła (układ zamknięty). Fabryczne w kotle zwykle wystarcza na sam kocioł i wymiennik — sprawdź w kalkulatorze „Naczynie wzbiorcze”.'
      : 'Dodatkowe, na powrocie instalacji za sprzęgłem — tak rysują to producenci kotłów kondensacyjnych. Fabryczne w kotle (zwykle 8 l) jest za małe przy dużym zładzie: podłogówka, sprzęgło, dużo grzejników. Policz w kalkulatorze „Naczynie wzbiorcze”.')
          : 'Policz w kalkulatorze „Naczynie wzbiorcze” — bufor i podłogówka dużo dokładają. Ciśnienie wstępne ustaw przed napełnieniem.'));
  }
  // manometr i termometry — przy kotle widać od razu ciśnienie i parametry
  if (!k.otw && !k.split) g += kt.wskaznik(X.mn, yS, 'M');
  if (!k.split) g += kt.wskaznik(k.otw ? X.mn : X.mn + 18, yS, 'T') + kt.wskaznik(xTp, yP, 'T');
  const nrWsk = k.split ? 0 : nr(k.otw ? 'Termometry na zasilaniu i powrocie' : 'Manometr i termometry',
    k.otw ? 'W układzie otwartym ciśnienie wynika z wysokości słupa wody, więc manometr nic nie wnosi. Termometry na zasilaniu i powrocie pokazują, czy ochrona powrotu działa.'
          : 'Manometr na zasilaniu tuż za źródłem (w kotłach gazowych jest fabryczny) i termometry na zasilaniu oraz powrocie. Różnica temperatur od razu mówi, czy pompa i ochrona powrotu pracują poprawnie.',
    k.otw ? 'Termometry' : 'Manometr i termometry');
  if (nrWsk) top += kt.nr(X.mn + (k.otw ? 0 : 9), yS + 17, nrWsk);
  if (k.pc) {
    // separator powietrza na zasilaniu — mikropęcherzyki wychodzą tylko tutaj
    g += kt.odpow(X.odp, yS);
    top += kt.nr(X.odp, yS - 24, nr('Separator powietrza z odpowietrznikiem',
      'Na zasilaniu tuż za źródłem, w najcieplejszym punkcie — tam z wody wychodzi najwięcej mikropęcherzyków. Samo odpowietrzenie grzejników nie wystarcza: powietrze w obiegu to pierwsza przyczyna błędów przepływu.',
      'Separator powietrza'));
  }
  if (k.pc && !k.split) {
    // zawór do napełniania i uzupełniania instalacji
    g += sym(X.kfe, yP, `<path d="M${X.kfe} ${yP}v10" stroke="${Pw}" stroke-width="2"/>` + KT0.zawor(X.kfe, yP + 16, true));
    top += kt.nr(X.kfe, yP + 34, nr('Zawór napełniania instalacji',
      'Na powrocie, z zaworem zwrotnym albo zestawem do automatycznego napełniania. Pompa ciepła nie lubi spadków ciśnienia — sprawdzaj je co sezon, bo przy niskim ciśnieniu sterownik blokuje grzanie.',
      'Zawór napełniania'));
  }
  g += k.stale ? kt.separator(X.fi, yP) : kt.filtr(X.fi, yP);
  top += kt.nr(X.fi, k.stale ? yP - 18 : yP + 18, nr(k.stale ? 'Separator zanieczyszczeń (odmulacz)' : 'Filtr magnetyczny',
    k.stale ? 'Przy kotle na paliwo stałe instalacja zawsze nabiera zgorzeliny i piasku, więc zamiast samego filtra daj separator z komorą osadczą i spustem na dole. Z zaworami odcinającymi z obu stron, żeby dało się go czyścić bez spuszczania wody.'
    : k.pc ? 'Filtroodmulnik (separator zanieczyszczeń) na powrocie tuż przed źródłem, z odcięciami z obu stron. Przy pompie ciepła to warunek gwarancji — opiłki i zgorzelina z instalacji w pierwszej kolejności zapychają wymiennik płytowy.'
    : k.zr === 'k1' && k.cwu === 'zas' ? 'Na wspólnym powrocie tuż przy kotle — za trójnikiem z powrotem zasobnika, żeby łapał też to, co wraca z wężownicy. Producenci kotłów kondensacyjnych wymagają go do gwarancji; czyść co przegląd.'
    : 'Na powrocie przed źródłem, z zaworami odcinającymi z obu stron, żeby dało się go czyścić bez spuszczania wody. Producenci kotłów i pomp ciepła zwykle wymagają go do gwarancji.'));
  if (k.stale) {
    // ochrona powrotu: zawór termostatyczny + bypass z zasilania + pompa kotłowa
    g += kt.rura([[X.zt, yS], [X.zt, yP]], Z);
    g += kt.zawor(X.zt, 62, true) + kt.siatka(X.zt, 80, true);
    top += kt.nr(X.zt - 14, 80, numFil());
    g += kt.trojdrog(X.zt, yP, false, true);
    g += pK('kotl', 0, X.po, yP, 'l');
    if (k.ochr !== 'ladd') g += kt.zwrotny(176, yP, false, true);
    if (k.ochr === 'ladd') {
      // zespół ładujący: pompa i zawór termostatyczny w jednym korpusie
      g += `<rect x="${X.po - 12}" y="${yP - 13}" width="${X.zt - X.po + 22}" height="26" rx="6" fill="none" stroke="${KT_I}" stroke-width="1.3" stroke-dasharray="4 3"/>`;
      g += kt.tekst((X.po + X.zt) / 2 - 2, yP + 34, 'zespół ładujący 70 °C', { a: 'middle', r: 8, k: KT_I, w: 700 });
      top += kt.nr(X.zt + 4, yP + 20, nr('Zespół ładujący kotła (laddomat)',
        'Pompa, zawór termostatyczny i zawór zwrotny w jednym korpusie, montowany na powrocie do kotła. Dopóki kocioł się nie rozgrzeje, krąży tylko przez kocioł; potem coraz więcej wody idzie do bufora. Powrót do kotła trzyma 65–72 °C (wkład termostatyczny wg DTR). Klapa grawitacyjna w środku pozwala oddać ciepło do bufora także przy zaniku prądu.',
        'Zespół ładujący (laddomat)'));
    } else {
    g += kt.tekst(X.zt - 2, yP + 34, k.zr === 'drew' ? '65 °C' : '55–65 °C', { a: 'middle', r: 8, k: KT_I, w: 700 });
    top += kt.nr(X.zt + 4, yP + 20, nr('Ochrona powrotu kotła',
      'Zawór termostatyczny (albo zestaw typu Laddomat / zawór 4-drogowy) domieszkuje gorące zasilanie do powrotu, aż kocioł się rozgrzeje. Bez tego na ścianach komory wykrapla się woda ze spalin i kocioł gnije w dwa sezony. Nastawa wg DTR: zwykle 55 °C przy pellecie i węglu, 65 °C przy zgazowaniu.'));
    top += kt.nr(X.po - 22, yP + 20, nr('Pompa kotłowa',
      'Za zaworem ochrony powrotu, tłoczy do kotła. Musi pracować zawsze, gdy w kotle się pali — także po zaniku prądu (zasilanie awaryjne albo układ grawitacyjny).'));
    }
  }
  g += kt.zawor(X.od, yS) + kt.zawor(X.od, yP);
  top += kt.nr(X.od, yS + 16, nr('Zawory odcinające źródła',
    'Na zasilaniu i powrocie — wymiana albo serwis źródła bez spuszczania instalacji.'
    + (k.otw ? ' Uwaga: na rurze bezpieczeństwa i wzbiorczej nie wolno montować żadnego zaworu.' : '')));

  /* ===== c.w.u. ===== */
  let dol = 150;
  if (k.cwu === 'zas') {
    const xZs = 60, yZs = 168, wZs = 64, hZs = 132;
    const yWe = 214, yWy = 270;
    /* Kocioł jednofunkcyjny ma własne króćce zasobnika i zawór 3-drogowy
       w środku — nitki idą wprost z kotła do wężownicy, bez armatury na
       zasilaniu. W części kotłów powrót z wężownicy łączy się z powrotem
       c.o. jeszcze przed kotłem i wtedy na rysunku jest jeden trójnik. */
    const wprost = k.zr === 'k1';
    /* grupa ładująca zasobnik (paliwo stałe), przepływ w lewo do wężownicy:
       zawór kulowy, filtr, pompa, zwrotny, odpowietrznik, zawór kulowy */
    const grupaCwu = () => {
      let s = kt.zawor(262, yWe) + kt.siatka(244, yWe) + pK('cwu', 0, 220, yWe, 'l') + kt.zwrotny(198, yWe, false, true)
        + kt.odpow(178, yWe) + kt.zawor(156, yWe) + kt.zawor(156, yWy);
      top += kt.nr(244, yWe + 22, numFil()) + kt.nr(178, yWe - 22, numOdp());
      return s;
    };
    const xPowZ = X.pz;
    if (wprost) {
      g += kt.zwrotny(X.zw, yP, false, true);
      top += kt.nr(X.zw, yP - 18, nr('Zawór zwrotny na powrocie c.o.',
        'Między sprzęgłem a trójnikiem powrotu zasobnika. Kiedy kocioł grzeje wodę, przepływ z wężownicy nie cofa się przez instalację i sprzęgło.',
        'Zawór zwrotny powrotu c.o.'));
    }
    if (wprost) {
      g += kt.rura([[xZr + wZr, 112], [146, 112], [146, yWe], [xZs + wZs, yWe]], Z);
      g += kt.strz(146, 170, 'd', Z);
      top += kt.nr(146, 188, nr('Przyłącze zasobnika — króćce kotła',
        'Kocioł jednofunkcyjny ma osobne króćce zasobnika i zawór przełączający w środku, więc zasilanie wężownicy idzie wprost z kotła — nie dokładaj zewnętrznego zaworu 3-drogowego. Czujnik zasobnika (T) wepnij w kocioł, bo to on przełącza grzanie na c.w.u.',
        'Przyłącze zasobnika z kotła'));
    } else if (k.cwuZ === 'buf') {
      /* Zasobnik ładowany z bufora: zasilanie z górnej (najcieplejszej)
         części bufora, powrót do dołu bufora. */
      const xT = bufy2 ? xHr + 12 : xRz + 28, xPb = bufy2 ? xA : xRz, yPb = bufy2 ? yB : yP + 18;
      g += kt.rura([[xZs + wZs, yWy], [xPb, yWy], [xPb, yPb]], Pw) + kt.strz(xPb, 168, 'g', Pw);
      if (bufy2) g += `<circle cx="${xPb}" cy="${yB}" r="3" fill="${Pw}"/>`;
      g += kt.rura([[xT, yS], [xT, yS + 8]], Z) + kt.most([[xT, yS + 7], [xT, yWe], [xZs + wZs, yWe]], Z) + `<circle cx="${xT}" cy="${yS}" r="3" fill="${Z}"/>`;
      g += kt.strz(xT, 150, 'd', Z);
      g += grupaCwu();
      top += kt.nr(220, yWe + 22, nr('Pompa ładująca zasobnik c.w.u.',
        'Zasobnik ładujesz z górnej, najcieplejszej części bufora, a powrót z wężownicy wraca do dołu bufora — tak pokazują to m.in. DTR kotłów zgazowujących. Wodę da się wtedy nagrzać z ciepła zgromadzonego w buforze, bez rozpalania. Pompą steruje sterownik kotła z czujnikiem w zasobniku i w górze bufora; za pompą zawór zwrotny.',
        'Pompa ładująca c.w.u.'));
    } else if (k.stale) {
      /* Przy kotle na paliwo stałe zasobnik ładuje osobna pompa ze sterownikiem,
         a nie zawór przełączający — kocioł nie ma własnego trybu c.w.u. */
      g += kt.rura([[X.tr, yS], [X.tr, yS + 8]], Z) + kt.most([[X.tr, yS + 7], [X.tr, yWe], [xZs + wZs, yWe]], Z) + `<circle cx="${X.tr}" cy="${yS}" r="3" fill="${Z}"/>`;
      g += grupaCwu();
      g += kt.strz(X.tr, 120, 'd', Z);
      top += kt.nr(220, yWe + 22, nr('Pompa ładująca zasobnik c.w.u.',
        'Zasilanie i powrót zasobnika wpinasz między kotłem a buforem — tak robią to producenci kotłów na paliwo stałe. Dzięki temu woda idzie do wężownicy pełną temperaturą kotła, a nie tą zmieszaną w buforze, i działa priorytet c.w.u. Pompą steruje sterownik kotła z czujnikiem w zasobniku, a za pompą zawór zwrotny, żeby ciepła woda nie uciekała do instalacji, kiedy pompa stoi. Przy kotle gazowym takiej pompy nie dajesz — kocioł ma własną pompę i zawór przełączający.',
        'Pompa ładująca c.w.u.'));
    } else {
      g += kt.rura([[X.tr, yS], [X.tr, yS + 8]], Z) + kt.most([[X.tr, yS + 7], [X.tr, yWe], [xZs + wZs, yWe]], Z) + `<circle cx="${X.tr}" cy="${yS}" r="3" fill="${Z}"/>`;
      g += kt.trojdrog(X.tr, yS, true);
      g += kt.strz(X.tr, 156, 'd', Z);
      top += kt.nr(k.pc ? X.tr : X.tr + (k.wym ? -14 : 14), k.pc ? yS + 17 : yS - 22, nr('Zawór 3-drogowy c.w.u.',
        k.gaz ? 'W kotle dwufunkcyjnym zawór jest w środku. Zewnętrzny montujesz tylko tam, gdzie kocioł nie ma króćców zasobnika — na zasilaniu tuż za kotłem, przed sprzęgłem.'
        : k.split ? 'Przełącza grzanie między instalacją a zasobnikiem (priorytet c.w.u.), dlatego nie trzeba osobnej pompy ładującej. Przy wielu modułach wewnętrznych zawór jest już w środku — wtedy podłączasz zasobnik do króćców modułu. Zewnętrzny montujesz na zasilaniu tuż za modułem, przed buforem.'
              : 'Na zasilaniu tuż za pompą ciepła, przed buforem — inaczej woda do zasobnika szłaby przez bufor i nie osiągnęłaby temperatury. Zawór przełącza cały przepływ na zasobnik (priorytet c.w.u.), więc osobna pompa ładująca nie jest potrzebna.'));
    }
    if (k.cwuZ !== 'buf') {
      g += kt.rura([[xZs + wZs, yWy], [xPowZ, yWy], [xPowZ, yP]], Pw);
      g += kt.strz(xPowZ, 168, 'g', Pw);
    }
    if (k.stale && k.cwuZ !== 'buf') g += `<circle cx="${xPowZ}" cy="${yP}" r="3" fill="${Pw}"/>`;
    if (wprost) {
      g += `<circle cx="${xPowZ}" cy="${yP}" r="3" fill="${Pw}"/>`;
      top += kt.nr(xPowZ + 14, 190, nr('Powrót wężownicy wpięty w powrót c.o.',
        'Część kotłów jednofunkcyjnych ma jeden wspólny króciec powrotu — wtedy powrót z wężownicy łączysz trójnikiem z powrotem c.o. przed kotłem. Jeśli kocioł ma osobny króciec powrotu zasobnika, podłącz wprost do niego i nie łącz obu powrotów.',
        'Powrót wężownicy w powrót c.o.'));
    }
    let wez = `M${xZs + wZs} ${yWe}H${xZs + 46}`;
    for (let i = 0; i < 6; i++) wez += `l-28 ${(yWy - yWe) / 12}l28 ${(yWy - yWe) / 12}`;
    wez += `H${xZs + wZs}`;
    g += klik('zas', 0, `<rect x="${xZs}" y="${yZs}" width="${wZs}" height="${hZs}" rx="18" fill="#fff" stroke="${KT_I}" stroke-width="1.6"/>`
      + `<path d="${wez}" fill="none" stroke="${Z}" stroke-width="1.6"/>`
      + kt.tekst(xZs + wZs / 2, yZs + 17, 'ZASOBNIK', { a: 'middle', r: 8, k: KT_I, w: 700 })
      + kt.tekst(xZs + wZs / 2, yZs + 28, k.zasL + ' l', { a: 'middle', r: 8.5, k: '#E8590C', w: 800 }))
      + kt.czujnik(xZs + 13, yZs + 40);
    top += kt.nr(xZs + wZs + 4, yZs + 8, nr(k.pc ? 'Zasobnik c.w.u. do pompy ciepła' : 'Zasobnik c.w.u. z wężownicą',
      k.stale ? 'Przy kotle na paliwo stałe wężownica może być zwykła — parametr zasilania jest wysoki. Czujnik (T) podłącz do sterownika kotła albo do pompy ładującej.'
      : k.pc ? 'Z dużą wężownicą przeznaczoną do pomp ciepła (powierzchnia wg instrukcji pompy), zwykle z grzałką do dogrzania i dezynfekcji termicznej. Czujnik (T) podłącz do sterownika pompy.'
           : 'Czujnik temperatury (T) w tulei zasobnika podłącz do kotła — kocioł sam przełącza zawór 3-drogowy.'));
    // ciepła woda do punktów poboru
    g += kt.rura([[xZs + 32, yZs], [xZs + 32, 158], [12, 158]], KT_KOL.cwu) + kt.strz(22, 158, 'l', KT_KOL.cwu)
      + kt.tekst(12, 152, 'c.w.u.', { r: 8.5, k: KT_KOL.cwu, w: 700 });
    // zimna woda od dołu
    const xZw = xZs + 22, yDn = yZs + hZs;
    g += kt.rura([[xZw, 434], [xZw, yDn]], KT_KOL.zw) + kt.strz(xZw, 424, 'g', KT_KOL.zw)
      + kt.tekst(xZw + 8, 440, 'zimna woda', { r: 8.5, k: '#1E88B5', w: 700 });
    g += `<path d="M${xZw} 342H${xZw - 14}" stroke="${KT_KOL.zw}" stroke-width="2.2"/>` + kt.bezp(xZw - 14, 342, KT_KOL.zw);
    g += `<path d="M${xZw} 358H${xZw + 16}" stroke="${KT_KOL.zw}" stroke-width="2.2"/>` + kt.naczynie(xZw + 16, 358, KT_KOL.zw);
    g += kt.zwrotny(xZw, 378, true) + kt.reduktor(xZw, 394) + kt.zawor(xZw, 410, true);
    top += kt.nr(xZw - 32, 330, nr('Zawór bezpieczeństwa c.w.u. (6 bar)',
      'Na zimnej wodzie między zaworem zwrotnym a zasobnikiem, bez zaworu odcinającego po drodze. Wylot przez lejek do kanalizacji.'));
    if (D && D.nacCwu) g += kt.tekst(xZw + 27, 372, D.nacCwu.rec + ' l', { r: 7.5, k: KT_I, w: 800 })
      + kt.tekst(xZw + 27, 380, 'p₀ 3,5 bar', { r: 6.5 });
    top += kt.nr(xZw + 34, 356, nr('Naczynie przeponowe c.w.u.', 'Do wody pitnej (białe lub niebieskie, nie czerwone od c.o.). Przyjmuje rozszerzanie wody, żeby zawór bezpieczeństwa nie kapał przy każdym grzaniu.'));
    top += kt.nr(xZw - 16, 378, nr('Zawór zwrotny na zimnej wodzie', 'Żeby woda z zasobnika nie cofała się do instalacji wodociągowej.'));
    top += kt.nr(xZw - 16, 394, nr('Reduktor ciśnienia', 'Ustaw ok. 3–4 bar. Bez niego przy ciśnieniu z sieci powyżej ok. 5 bar zawór bezpieczeństwa 6 bar kapie przy każdym grzaniu, a baterie i spłuczki szybciej się psują.'));
    top += kt.nr(xZw - 16, 410, nr('Zawór odcinający zimnej wody', 'Na samym początku, przed reduktorem i zaworem zwrotnym.'));
    if (k.gaz || k.pc) dod.push(['Stacja uzdatniania (zmiękczania) wody', 'Na zimnej wodzie przed zasobnikiem, a woda do napełniania instalacji wg wymagań DTR (twardość, pH). Kamień w wymienniku i wężownicy to najczęstsza przyczyna awarii i odmowy gwarancji.']);
    dod.push(['Zawór termostatyczny mieszający (antyoparzeniowy)', 'Na wyjściu c.w.u. — zalecany, gdy woda w zasobniku bywa podgrzewana do 60–70 °C przy dezynfekcji termicznej.']);
    if (k.cyrk) {
      g += kt.rura([[12, 236], [xZs, 236]], KT_KOL.cyrk) + pK('cyrk', 0, 30, 236, 'p') + kt.zwrotny(48, 236)
        + kt.tekst(12, 226, 'cyrkulacja', { r: 8, k: KT_KOL.cyrk, w: 700 });
      top += kt.nr(30, 254, nr('Pompa cyrkulacyjna z zaworem zwrotnym', 'Z zegarem albo czujnikiem — cyrkulacja przez całą dobę wychładza zasobnik i podnosi rachunki.', 'Pompa cyrkulacyjna'));
    }
    dol = 450;
  } else if (k.cwu === 'przep') {
    g += kt.rura([[58, 160], [58, 116]], KT_KOL.zw) + kt.strz(58, 150, 'g', KT_KOL.zw)
      + kt.tekst(58, 172, 'zimna', { a: 'middle', r: 8, k: '#1E88B5', w: 700 });
    g += kt.rura([[100, 116], [100, 160]], KT_KOL.cwu) + kt.strz(100, 152, 'd', KT_KOL.cwu)
      + kt.tekst(100, 172, 'c.w.u.', { a: 'middle', r: 8, k: KT_KOL.cwu, w: 700 });
    g += kt.zawor(58, 134, true);
    top += kt.nr(44, 140, nr('Zimna woda do kotła', 'Zawór odcinający i filtr siatkowy przed kotłem. Przy twardej wodzie rozważ zmiękczanie — wymiennik płytowy szybko zarasta kamieniem.'));
    dol = 180;
  }

  /* ===== sprzęgło / bufor ===== */
  if (bufy2) {
    const w = 28, yG = yS - 14, h = yP - yS + 32;
    // kolektory: górny (zasilanie) i dolny (powrót)
    g += kt.rura([[xHl, yS], [xHl, yT], [xHr, yT], [xHr, yS], [xSz, yS]], Z);
    g += kt.rura([[xA, yT], [xA, yG]], Z) + kt.rura([[xB, yT], [xB, yG]], Z);
    g += kt.rura([[belki ? xSp - 4 : xSp, yP], [xHr, yP], [xHr, yB], [xHl, yB], [xHl, yP]], Pw);
    g += kt.rura([[xA, yP + 18], [xA, yB]], Pw) + kt.rura([[xB, yP + 18], [xB, yB]], Pw);
    for (const xc of [xA, xB]) g += `<rect x="${xc - w / 2}" y="${yG}" width="${w}" height="${h}" rx="10" fill="#fff" stroke="${KT_I}" stroke-width="1.6"/>`;
    for (const [xc, yc, kol] of [[xA, yT, Z], [xB, yT, Z], [xA, yB, Pw], [xB, yB, Pw]]) g += `<circle cx="${xc}" cy="${yc}" r="2.6" fill="${kol}"/>`;
    g += kt.strz(xHl, yT + 12, 'g', Z) + kt.strz(xHr, yT + 12, 'd', Z) + kt.strz(xHr, yB - 12, 'd', Pw) + kt.strz(xHl, yB - 12, 'g', Pw);
    g += kt.tekst((xA + xB) / 2, yT - 7, '2 × BUFOR' + (D && D.vbN === 2 ? ' ' + D.vbDob.replace('2 × ', '') + ' l' : ''), { a: 'middle', r: 8, k: KT_I, w: 700 });
    top += kt.nr(xB + 22, yP + 2, nr('Dwa bufory połączone równolegle',
      'Kolektor górny łączy zasilania obu buforów, dolny — powroty. Podejścia do obu zbiorników zrób tą samą średnicą i możliwie tej samej długości (najlepiej na krzyż: zasilanie od jednej strony, powrót od drugiej — po Tichelmannie), inaczej jeden bufor ładuje się szybciej, a drugi stoi zimny. Każdy bufor z własnym odpowietrznikiem, spustem i zaworami kulowymi, żeby dało się go odciąć do serwisu. Pojemność liczy się łącznie.',
      '2 bufory równolegle'));
  } else if (k.rozdz === 'sprz' || k.rozdz === 'buf') {
    const buf = k.rozdz === 'buf', w = buf ? 28 : 16, xL = xRz - w / 2;
    g += `<rect x="${xL}" y="${yS - 16}" width="${w}" height="${yP - yS + 34}" rx="${buf ? 10 : 3}" fill="#fff" stroke="${KT_I}" stroke-width="1.6"/>`;
    // sprzęgło: króćce i korpus pod spodem, pod zaworem spustowym
    if (!buf && D) {
      const nap = (y, t) => ktSymG(xRz, y, `<text x="${xRz}" y="${y}" font-size="7.5" font-weight="800" text-anchor="middle" fill="#C2410C" stroke="#fff" stroke-width="3" paint-order="stroke">${esc(t)}</text>`);
      g += nap(yP + 46, 'króćce ' + D.dn[1].replace(/^DN\d+ \((.+)\)$/, '$1')) + nap(yP + 55, 'korpus Ø' + D.dSprz);
    }
    if (!buf) g += kt.odpow(xRz, yS - 16) + sym(xRz, yP + 18, `<path d="M${xRz} ${yP + 18}v6" stroke="${KT_I}" stroke-width="1.5"/>` + KT0.zawor(xRz, yP + 30, true));
    g += kt.tekst(xRz, buf ? yS - 22 : yS - 34, buf ? 'BUFOR' + (D && D.vbDob ? ' ' + D.vbDob + ' l' : '') : 'SPRZĘGŁO', { a: 'middle', r: 8, k: KT_I, w: 700 });
    g += kt.rura([[xRz + w / 2, yS], [xSz, yS]], Z) + kt.most([[belki ? xSp - 4 : xSp, yP], [xRz + w / 2, yP]], Pw);
    top += kt.nr(xRz + w / 2 + 12, k.cwuZ === 'buf' ? yS - 27 : yS + 24, nr(buf ? 'Bufor (pełni rolę sprzęgła)' : 'Sprzęgło hydrauliczne',
      buf ? (k.stale
        ? (k.zr === 'drew'
          ? 'Przy zgazowaniu drewna obowiązkowy: minimum 55 l na każdy kW mocy kotła (PN-EN 303-5). Przyjmuje ciepło z całego załadunku, dzięki czemu kocioł pracuje pełną mocą i nie smoli.'
          : 'Przy kotle na paliwo stałe bufor wygładza pracę i pozwala wygasić kocioł bez wychłodzenia domu. Ładuj od góry, odbieraj z dołu — inaczej mieszasz warstwy i tracisz pojemność.')
        : 'Oddziela przepływ pompy ciepła od pomp obiegów i daje pojemność do odszraniania. Pojemność dobierz wg instrukcji pompy ciepła.')
          : 'Dobierz do większego z przepływów: kotła albo całej instalacji. U góry odpowietrznik, na dole zawór spustowy do odmulania. Kocioł z czujnikiem sprzęgła steruje lepiej.'));
  } else if (k.rozdz === 'wym') {
    /* wymiennik płytowy — po lewej kocioł w układzie zamkniętym,
       po prawej stara instalacja, która zostaje otwarta */
    const w = 26, xL = xRz - w / 2;
    g += `<rect x="${xL}" y="${yS - 14}" width="${w}" height="${yP - yS + 28}" rx="3" fill="#fff" stroke="${KT_I}" stroke-width="1.6"/>`;
    for (let i = 0; i < 3; i++) g += `<path d="M${xL + 3} ${yS - 2 + i * 22}l${w - 6} 11l-${w - 6} 11" fill="none" stroke="${KT_I}" stroke-width="1.2"/>`;
    g += kt.tekst(xRz, yS - 22, 'WYMIENNIK', { a: 'middle', r: 8, k: KT_I, w: 700 });
    g += kt.tekst(xRz - 16, 78, 'zamknięty', { a: 'end', r: 8 })
      + kt.tekst(xRz + 16, 78, 'otwarty', { r: 8 });
    g += kt.rura([[xRz + w / 2, yS], [xSz, yS]], Z) + kt.most([[belki ? xSp - 4 : xSp, yP], [xRz + w / 2, yP]], Pw);
    top += kt.nr(xRz, yP + 32, nr('Wymiennik płytowy',
      'Rozdziela nowy kocioł od starej instalacji: szlam i rdza z grzejników nie wchodzą do kotła, a kocioł pracuje w układzie zamkniętym mimo otwartej instalacji. Dobierz go z zapasem powierzchni — na wymienniku tracisz kilka stopni — i zamontuj odcięcia oraz króćce do płukania po obu stronach.'));
    // separator zanieczyszczeń po stronie starej instalacji
    g += kt.separator(288, yP);
    top += kt.nr(304, yP + 16, nr('Separator zanieczyszczeń starej instalacji',
      'Na powrocie starej instalacji, tuż przed wymiennikiem. W starych rurach zawsze siedzi szlam i rdza, a wymiennik płytowy zarasta od tego w jeden sezon. Najlepiej odmulacz magnetyczny z odcięciami i spustem do czyszczenia.',
      'Separator zanieczyszczeń'));
    // naczynie otwarte po stronie starej instalacji
    g += `<path d="M352 2V26H420V2" fill="#fff" stroke="${KT_I}" stroke-width="1.6" stroke-linejoin="round"/>`
      + `<path d="M356 14H416" stroke="${KT_KOL.zw}" stroke-width="1.4" stroke-dasharray="4 3"/>`
      + kt.tekst(394, 22, 'otwarte', { a: 'middle', r: 7.5, k: '#8CA0B0', w: 700 });
    g += kt.rura([[346, yS], [346, 32], [366, 32], [366, 26]], Z);
    g += kt.most([[404, 26], [404, yP]], Pw);
    top += kt.nr(340, 14, nr('Naczynie wzbiorcze otwarte starej instalacji',
      'Zostaje tam, gdzie było: w najwyższym punkcie instalacji, zwykle na poddaszu, z przelewem do kanalizacji. Rura bezpieczeństwa i wzbiorcza bez żadnych zaworów. Po tej stronie nie montuj zaworu bezpieczeństwa ani naczynia przeponowego — zabezpieczeniem jest naczynie otwarte.',
      'Naczynie otwarte starej instalacji'));
  }

  /* ===== rozdzielacz obiegów ===== */
  if (nOb > 1 && !belki) {
    top += kt.nr(xSz - 12, yKon - 24, nr('Rozprowadzenie trójnikami z rury',
      'Bez rozdzielacza: z kotła, bufora albo sprzęgła wychodzą dwie rury — zasilanie i powrót — a każdy obieg odbija się od nich zwykłym trójnikiem (np. gdy grupy pompowe są w szafkach na piętrach). Średnicę rury licz na przepływ wszystkich obiegów, które z niej zasilasz; na każdym odejściu zawory kulowe, żeby dało się odciąć obieg.',
      'Rozprowadzenie trójnikami'));
  }
  if (belki) {
    // korpus rozdzielacza (belki zasilania i powrotu w jednej obudowie)
    // wielkość rozdzielacza pod belkami: korpus i liczba par króćców
    if (D) g += kt.tekst((xSz + xSp) / 2, yKon + 44, 'przyłącze ' + D.dnRoz[1].replace(/^DN\d+ \((.+)\)$/, '$1') + ' · ' + nOb + (nOb < 5 ? ' obiegi' : ' obiegów'), { a: 'middle', r: 8, k: '#C2410C', w: 800 })
      + kt.tekst((xSz + xSp) / 2, yKon + 54, 'przepływ ' + fmt(D.qIn1, 2) + ' m³/h', { a: 'middle', r: 7.5, k: '#C2410C', w: 700 })
      + kt.tekst((xSz + xSp) / 2, yKon + 63, 'spawany: korpus ' + D.korpusRoz[1] + ' (Ø' + String(D.korpusRoz[2]).replace('.', ',') + ')', { a: 'middle', r: 7.5, k: '#C2410C', w: 700 });
    g += kt.tekst((xSz + xSp) / 2 - (k.wym ? 14 : 0), yS - 34, 'ROZDZIELACZ', { a: 'middle', r: 7.5, k: KT_I, w: 700 });
    top += kt.nr(xSp + 16, yKon + 24, nr('Rozdzielacz obiegów',
      nOb > 2 ? 'Rozdzielacz za sprzęgłem (belka zasilania i powrotu albo rozdzielacz modułowy), z którego każdy obieg — parter, piętro, podłogówki — wychodzi z własną grupą pompową. Dobierz go na sumaryczny przepływ wszystkich obiegów; odpowietrzenie u góry, spust na dole. Gotowe rozdzielacze z izolacją mają króćce rozstawione pod grupy pompowe.'
      : 'Pionowa belka zasilania i powrotu, z której odchodzą obiegi. Każdy obieg dostaje swoją grupę pompową: pompa, zawór zwrotny i odcięcia, a przy podłogówce dodatkowo mieszacz. Na belce wygodnie zrobić odpowietrzenie u góry i spust na dole.',
      'Rozdzielacz obiegów'));
  }

  /* ===== obiegi ===== */
  const xOdb = 420 + dx + ext + d2, wOdb = 34;
  k.obiegi.forEach((ob, i) => {
    const ys = yS + i * WIERSZ, yr = yP + i * WIERSZ;
    const miesz = ob === 'podlM' || ob === 'grzM', grz = ob[0] === 'g';
    if (i > 0 && !belki) g += kt.rura([[xSz, ys], [xSz + 6, ys]], Z) + kt.most([[xSz + 5, ys], [xOdb, ys]], Z);
    else g += (i > 0 ? kt.most : kt.rura)([[belki ? xSz + 4 : xSz, ys], [xOdb, ys]], Z);
    g += kt.rura([[xOdb, yr], [belki ? xSp + 4 : xSp, yr]], Pw);
    if (!belki && nOb > 1 && i < nOb - 1)   // trójniki na rurach
      g += `<circle cx="${xSz}" cy="${ys}" r="3" fill="${Z}"/><circle cx="${xSp}" cy="${yr}" r="3" fill="${Pw}"/>`;
    let xMi = xOdb - 72;                 // zawór mieszający
    if (det && pompyObiegow) {
      /* pełna grupa pompowa: kulowy, filtr, (mieszacz), pompa, (zwrotny),
         odpowietrznik, kulowy; przy mieszaczu zwrotny na powrocie do bufora */
      const a = xSz;
      xMi = a + 62;
      if (pelna) {
        g += kt.zawor(a + 28, ys) + kt.siatka(a + 44, ys);
        if (miesz) {
          g += kt.rura([[xMi, yr], [xMi, ys]], Pw) + kt.trojdrog(xMi, ys, true) + pK('ob', i, a + 84, ys, 'p');
          g += kt.zwrotny(a + 40, yr, false, true);
          top += kt.nr(a + 40, yr + 18, numZwr());
        } else {
          g += pK('ob', i, a + 66, ys, 'p') + kt.zwrotny(a + 86, ys);
        }
        g += kt.odpow(a + 102, ys) + kt.zawor(a + 116, ys);
        top += kt.nr(a + 44, ys + 20, numFil()) + kt.nr(a + 102, ys - 22, numOdp());
      } else {
        /* kocioł gazowy — grupa jak u producentów kotłów kondensacyjnych:
           odcięcia na zasilaniu i powrocie, (mieszacz), pompa,
           zawór zwrotny na powrocie przed trójnikiem podmieszania */
        g += kt.zawor(a + 28, ys) + kt.zawor(a + 28, yr) + kt.zawor(a + 116, ys) + kt.zawor(a + 116, yr);
        if (miesz) g += kt.rura([[xMi, yr], [xMi, ys]], Pw) + kt.trojdrog(xMi, ys, true) + pK('ob', i, a + 86, ys, 'p');
        else g += pK('ob', i, a + 62, ys, 'p');
        g += kt.zwrotny(a + 94, yr, false, true);
        top += kt.nr(a + 94, yr + 18, numZwr());
      }
      if (miesz) g += sym(a + 130, ys, `<path d="M${a + 130} ${ys}v-6" stroke="${KT_I}" stroke-width="1.2"/>` + KT0.czujnik(a + 130, ys - 11));
      if (ob === 'podlM') g += sym(a + 102, ys, KT0.stb(a + 102, ys + 16) + `<path d="M${a + 102} ${ys}v9" stroke="${KT_I}" stroke-width="1.2"/>`);
    }
    if (miesz && !(det && pompyObiegow)) {
      g += kt.rura([[xOdb - 72, yr], [xOdb - 72, ys]], Pw) + kt.trojdrog(xOdb - 72, ys, true);
      if (ob === 'podlM') g += sym(xOdb - 30, ys, KT0.stb(xOdb - 30, ys + 16) + `<path d="M${xOdb - 30} ${ys}v9" stroke="${KT_I}" stroke-width="1.2"/>`);
      g += sym(xOdb - 12, ys, `<path d="M${xOdb - 12} ${ys}v-6" stroke="${KT_I}" stroke-width="1.2"/>` + KT0.czujnik(xOdb - 12, ys - 11));
    }
    if (pompyObiegow && !det) {
      const xp = miesz ? xOdb - 48 : xOdb - 62;
      g += pK('ob', i, xp, ys, 'p') + (!miesz ? kt.zwrotny(xOdb - 38, ys) : '');
    }
    const xCz = det && pompyObiegow ? xSz + 130 : xOdb - 12;
    const zv = D && D.zawory[i];
    if (zv) g += kt.tekst(xMi + 5, ys + 35, 'Kvs ' + String(zv.kvs).replace('.', ',') + ' · ' + zv.pick.dn.replace(' ', ''), { r: 7.5, k: KT_I, w: 800 });
    const xStb = det && pompyObiegow ? xSz + 102 : xOdb - 30, yStb = ys + 16;
    /* Obieg z rozdzielaczem (podłogówka, grzejniki rozdzielaczowo): belka
       zasilania i powrotu z odejściami zamiast symbolu odbiornika. */
    const rz = k.rozd && k.rozd[i];
    const belkaOdb = () => {
      const n = Math.max(1, Math.min(rz.wyj || 1, 8)), dxo = wOdb / (n + 1);
      let s = `<rect x="${xOdb}" y="${ys - 3.5}" width="${wOdb}" height="7" rx="2" fill="${Z}" stroke="${KT_I}" stroke-width="1.2"/>`
        + `<rect x="${xOdb}" y="${yr - 3.5}" width="${wOdb}" height="7" rx="2" fill="${Pw}" stroke="${KT_I}" stroke-width="1.2"/>`;
      for (let j = 1; j <= n; j++) {
        const xo = xOdb + j * dxo;
        s += `<path d="M${xo} ${ys + 3.5}V${ys + 12}" stroke="${Z}" stroke-width="1.6"/><path d="M${xo} ${yr - 3.5}V${yr - 12}" stroke="${Pw}" stroke-width="1.6"/>`;
      }
      return s;
    };
    const urz = rz ? belkaOdb() : grz ? kt.grzejnik(xOdb, ys - 8, wOdb, yr - ys + 16) : kt.podloga(xOdb, ys - 8, wOdb, yr - ys + 16);
    const kwOb = k.kw[i];
    const plak = sym(xOdb + wOdb / 2, (ys + yr) / 2, kwOb
      ? `<rect x="${xOdb + wOdb / 2 - 23}" y="${(ys + yr) / 2 - 8}" width="46" height="16" rx="8" fill="#fff" stroke="${grz ? Z : '#C2410C'}" stroke-width="1.3"/><text x="${xOdb + wOdb / 2}" y="${(ys + yr) / 2 + 3.6}" font-size="9" font-weight="800" text-anchor="middle" fill="${KT_I}">${fmt(kwOb, kwOb < 10 ? 1 : 0)} kW</text>`
      : `<rect x="${xOdb + wOdb / 2 - 16}" y="${(ys + yr) / 2 - 8}" width="32" height="16" rx="8" fill="#FFF4EC" stroke="#FF7A33" stroke-width="1.3" stroke-dasharray="3 2"/><text x="${xOdb + wOdb / 2}" y="${(ys + yr) / 2 + 3.6}" font-size="9" font-weight="800" text-anchor="middle" fill="#E8590C">+ kW</text>`);
    g += klik('ob', i, urz + plak);
    const nz = k.nazwyOb[i] || { nazwa: '', nr: 0 };
    const typ = (grz ? 'GRZEJNIKI' : 'PODŁOGÓWKA') + (nz.nr ? ' ' + nz.nr : '');
    const suf = nz.nazwa ? ' — ' + nz.nazwa : nz.nr ? ' ' + nz.nr : '';
    if (nz.nazwa) {
      g += kt.tekst(W0 - 6, yr + 19, nz.nazwa.toUpperCase(), { a: 'end', r: 8, k: KT_I, w: 800 });
      g += kt.tekst(W0 - 6, yr + 29, typ.toLowerCase(), { a: 'end', r: 7.5 });
    } else g += kt.tekst(W0 - 6, yr + 19, typ, { a: 'end', r: 7.5, k: KT_I, w: 700 });
    if (rz) g += kt.tekst(W0 - 6, yr + (nz.nazwa ? 39 : 29), (rz.ile > 1 ? rz.ile + ' × ' : '') + 'rozdzielacz ' + ktKorpusDN(rz.korpus)
      + (rz.wyj ? ' · ' + rz.wyj + ' ' + odmiana(rz.wyj, 'obwód', 'obwody', 'obwodów') : ''), { a: 'end', r: 7.5, k: '#C2410C', w: 800 });

    if (ob === 'grz') {
      top += kt.nr(xOdb + wOdb / 2, ys - 18, nr('Obieg grzejnikowy' + suf,
        (pompyObiegow ? 'Własna pompa z zaworem zwrotnym i zawory odcinające. ' : 'Bez własnej pompy — tłoczy pompa źródła. ')
        + (k.wym ? 'To stara instalacja po stronie otwartej: przed uruchomieniem przepłucz ją i sprawdź, czy grzejniki nie są zamulone. Pompa obiegowa musi pokonać opory starych rur.'
          : k.stale ? 'Zawór upustowy (by-pass) między zasilaniem a powrotem jest tu konieczny: pompa musi mieć gdzie tłoczyć, gdy termostaty pozamykają grzejniki.'
          : k.pc ? 'Grzejniki dobrane na niski parametr (np. 45/40 °C) — sprawdź w kalkulatorze „Dobór grzejnika”.'
                : 'Przy grzejnikach z samymi zaworami termostatycznymi dodaj zawór upustowy (by-pass), żeby pompa nie pracowała na zamkniętej instalacji.')));
    } else if (ob === 'grzM') {
      top += kt.nr(xMi + 15, ys - 28, nrRaz('Zawór mieszający grzejników z siłownikiem',
        'Obniża temperaturę zasilania grzejników wg krzywej grzewczej (czujnik zewnętrzny w sterowniku). Przy buforze producenci kotłów na paliwo stałe zalecają mieszacz na wyjściu do instalacji: dom nie dostaje 80 °C, a bufor oddaje ciepło dłużej. Dobór Kvs w kalkulatorze „Zawór mieszający”.',
        'Mieszacz grzejników'));
      top += kt.nr(xOdb + wOdb / 2, ys - 18, nr('Obieg grzejnikowy z mieszaczem' + suf,
        'Pompa za mieszaczem, zawory kulowe na zasilaniu i powrocie. Przy grzejnikach z zaworami termostatycznymi daj pompę z regulacją ciśnienia albo zawór upustowy.'));
      top += kt.nr(xCz, ys - 30, nrRaz('Czujnik temperatury zasilania grzejników', 'Za pompą, ok. 0,5–1 m od mieszacza. Steruje siłownikiem zaworu.', 'Czujnik temp. grzejników'));
    } else if (ob === 'podlM') {
      top += kt.nr(xMi + 15, ys - 28, nrRaz('Zawór mieszający z siłownikiem',
        'Miesza zasilanie z powrotem, żeby do pętli szła niższa temperatura. Dobór Kvs w kalkulatorze „Zawór mieszający”.'));
      top += kt.nr(xOdb + wOdb / 2, ys - 18, nr('Obieg podłogowy' + suf,
        'Własna pompa za mieszaczem i rozdzielacz z rotametrami — przepływy pętli w kalkulatorze „Ogrzewanie podłogowe”.'));
      top += kt.nr(xCz, ys - 30, nrRaz('Czujnik temperatury zasilania podłogówki', 'Za pompą, ok. 0,5–1 m od mieszacza. Steruje siłownikiem zaworu.', 'Czujnik temp. podłogówki'));
      top += kt.nr(xStb + (det && pompyObiegow ? 20 : 0), yStb + (det && pompyObiegow ? 2 : 18), nrRaz('Termostat bezpieczeństwa (STB)', 'Wyłącza pompę podłogówki przy ok. 55 °C — chroni wylewkę i rury, gdy mieszacz się zatnie.'));
    } else {
      top += kt.nr(xOdb + wOdb / 2, ys - 18, nr('Obieg podłogowy bez mieszacza' + suf,
        k.stale ? 'Przy kotle na paliwo stałe to układ do poprawienia: bez mieszacza do pętli pójdzie 70–80 °C i wylewka tego nie wytrzyma. Dodaj zawór mieszający.'
        : k.gaz ? 'Tylko gdy kocioł grzeje wyłącznie podłogówkę: ogranicz w kotle maksymalną temperaturę zasilania i dodaj termostat bezpieczeństwa na zasilaniu.'
              : 'Pompa ciepła podaje niski parametr wprost do pętli — ustaw krzywą grzewczą pod podłogówkę. Część pętli zostaw bez zaworów strefowych (minimalny przepływ).'));
    }
  });

  if (D) g += kt.tekst(k.split ? 146 : k.stale ? xZr + 26 : xZr + 42, k.split ? 140 : k.stale ? 139 : 129, '≈ ' + D.pDob + ' kW', { a: 'middle', r: 9, k: '#E8590C', w: 800 });
  /* Średnice rur na rysunku: przy zasilaniu każdego odcinka ramka z
     rozmiarem i grot dotykający rury (powrót ma tę samą średnicę). */
  if (D && D.rury) {
    const R = D.rury, odc = [];
    const xZrP = (k.split ? 188 : xZr + wZr) + 2;
    if (R.zr) odc.push({ r: R.zr, poz: 'h', y: yS, a: xZrP, b: (k.rozdz === 'brak' ? xSz : xKonZ) - 2, pref: k.rozdz === 'brak' && belki ? 0.85 : 0.5 });
    if (R.roz && k.rozdz !== 'brak') {
      const pol = { buf: 14, sprz: 8, wym: 13 }[k.rozdz] || 8;
      odc.push({ r: R.roz, poz: 'h', y: yS, a: (bufy2 ? xHr : xRz + pol) + 2, b: xSz - 5, pref: 0.5 });
    }
    k.obiegi.forEach((ob, i) => {
      const ys = yS + i * WIERSZ;
      const miesz = ob === 'grzM' || ob === 'podlM';
      const xMi = det && pompyObiegow ? xSz + 62 : xOdb - 72;
      if (miesz && R.obP[i]) {
        odc.push({ r: R.obP[i], poz: 'h', y: ys, a: (belki ? xSp : xSz) + 6, b: xMi - 3, pref: 1 });
        if (R.ob[i]) odc.push({ r: R.ob[i], poz: 'h', y: ys, a: xMi + 3, b: xOdb - 2, pref: 1 });
      } else if (R.ob[i]) odc.push({ r: R.ob[i], poz: 'h', y: ys, a: (belki ? xSp : xSz) + 6, b: xOdb - 2, pref: 1 });
      // rura główna między trójnikami (bez rozdzielacza)
      if (!belki && R.pion && R.pion[i] && i < nOb - 1) odc.push({ r: R.pion[i], poz: 'v', x: xSz, a: ys + 4, b: ys + WIERSZ - 4, pref: 0.5 });
    });
    if (R.cwu && k.cwu === 'zas') {
      const xZasP = k.zr === 'k1' ? 146 : k.cwuZ === 'buf' ? (bufy2 ? xHr + 12 : xRz + 28) : X.tr;
      // przy kotle jednofunkcyjnym poziomy kawałek do wężownicy jest krótki — opis na pionie
      if (xZasP - 129 < 26) odc.push({ r: R.cwu, poz: 'v', x: xZasP, a: k.zr === 'k1' ? 120 : yS + 12, b: 208, pref: 0.75 });
      else odc.push({ r: R.cwu, poz: 'h', y: 214, a: 126, b: xZasP - 3, pref: 0 });
    }
    top += ktOpisyRur(szyny + g + top, odc, R.mat);
  }
  const H0 = Math.round((Math.max(dol, yKon + (belki ? 67 : 40)) + 8) * KT_ROZ);
  const { svg: tab, h: tabH } = D ? ktTabelaDoboru(k, D, H0) : { svg: '', h: 0 };
  const { svg: leg0, h: legH } = ktLegenda(el, H0 + tabH);
  const leg = tab + leg0;
  const H = H0 + tabH + legH;
  const SK = 1.25;
  // grubość linii nie rośnie razem z rozstawem
  let rysunek = ktNumerki(szyny + g + top);
  const pelny = KT_STYL === 'pelny';
  if (pelny) rysunek = ktStyl(rysunek);
  rysunek = rysunek.replace(/<(path|rect|circle|polyline)\b/g, '$& vector-effect="non-scaling-stroke"');
  const tlo = pelny ? `${KT_DEFS}<rect width="${KT_W}" height="${H}" fill="#fff"/><rect x="6" y="6" width="${KT_W - 12}" height="${H0 - 6}" rx="10" fill="url(#ktSiatka)" stroke="#E2E8EE"/>`
    : `<rect width="${KT_W}" height="${H}" fill="#fff"/>`;
  const rys = `<svg viewBox="0 0 ${KT_W} ${H}" width="${Math.round(KT_W * SK)}" height="${Math.round(H * SK)}" font-family="Barlow, sans-serif" role="img" aria-label="Schemat kotłowni">`
    + tlo + `<g transform="scale(${KT_ROZ})">` + rysunek + '</g>' + leg + '</svg>';
  return { rys, el, dod, D, H0, W: KT_W };
}

/* Nazwa rury do opisu: średnica nominalna z calami. */
function ktNazwaRury(mat, r) {
  return String(r.pick[0]);   // np. DN25 (1")
}

/* Krótki napis na rysunek: sama średnica nominalna. */
function ktKrotkaRury(mat, r) {
  return String(r.pick[0]).split(' ')[0];   // DN25
}

/* Przeszkody na rysunku (w jednostkach rysowania) z gotowego SVG:
   prostokąty, kółka, napisy, odcinki rur, symbole armatury i numerki. */
function ktPrzeszkody(src) {
  const ob = [], k = 1 / KT_ROZ;
  const dodaj = (x1, y1, x2, y2, rura) => ob.push({ x1: Math.min(x1, x2), y1: Math.min(y1, y2), x2: Math.max(x1, x2), y2: Math.max(y1, y2), rura });
  /* Drobne kształty symboli armatury są rysowane w skali 1/KT_ROZ wokół
     kotwicy symbolu — przeliczamy je tak samo. */
  const wSymbolu = (x1, y1, x2, y2) => {
    if (x2 - x1 > 34 || y2 - y1 > 34) return [x1, y1, x2, y2];
    const cx = (x1 + x2) / 2, cy = (y1 + y2) / 2;
    let a = null, dmin = 40;
    for (const [ax, ay] of KT_KOTWICE) { const d = Math.hypot(ax - cx, ay - cy); if (d < dmin) { dmin = d; a = [ax, ay]; } }
    if (!a) return [x1, y1, x2, y2];
    return [a[0] + (x1 - a[0]) * k, a[1] + (y1 - a[1]) * k, a[0] + (x2 - a[0]) * k, a[1] + (y2 - a[1]) * k];
  };
  for (const m of src.matchAll(/<rect x="([-\d.]+)" y="([-\d.]+)" width="([\d.]+)" height="([\d.]+)"/g)) dodaj(...wSymbolu(+m[1], +m[2], +m[1] + +m[3], +m[2] + +m[4]));
  for (const m of src.matchAll(/<circle cx="([-\d.]+)" cy="([-\d.]+)" r="([\d.]+)"([^>]*)>/g)) {
    if (/fill-opacity="0"/.test(m[4])) continue;              // niewidoczne pole do klikania
    const r = +m[3];
    dodaj(...(r > 3.5 ? wSymbolu(+m[1] - r, +m[2] - r, +m[1] + r, +m[2] + r) : [+m[1] - r, +m[2] - r, +m[1] + r, +m[2] + r]));
  }
  for (const m of src.matchAll(/<text x="([-\d.]+)" y="([-\d.]+)"([^>]*)>([\s\S]*?)<\/text>/g)) {
    if (/rotate/.test(m[3])) continue;
    const fs = +((m[3].match(/font-size="([\d.]+)"/) || [0, 9])[1]) * k;
    const t = m[4].replace(/<[^>]+>/g, '').replace(/&[a-z#0-9]+;/g, 'x');
    const w = t.length * fs * 0.56, a = (m[3].match(/text-anchor="(\w+)"/) || [0, 'start'])[1];
    const x0 = a === 'middle' ? +m[1] - w / 2 : a === 'end' ? +m[1] - w : +m[1];
    dodaj(x0, +m[2] - fs * 0.8, x0 + w, +m[2] + fs * 0.2);
  }
  for (const m of src.matchAll(/<polyline points="([^"]+)"[^>]*stroke-width="([\d.]+)"/g)) {
    const p = m[1].trim().split(/\s+/).map(q => q.split(',').map(Number));
    for (let i = 1; i < p.length; i++) dodaj(p[i - 1][0] - 1.5, p[i - 1][1] - 1.5, p[i][0] + 1.5, p[i][1] + 1.5, +m[2] >= 2.5 ? [p[i - 1], p[i]] : null);
  }
  for (const m of src.matchAll(/d="M([-\d.]+) ([-\d.]+)V([-\d.]+)"/g)) dodaj(+m[1] - 1, +m[2], +m[1] + 1, +m[3]);
  for (const [x, y] of KT_KOTWICE) dodaj(x - 6, y - 6, x + 6, y + 6);
  for (const m of src.matchAll(/@@NR (\S+) (\S+) (\d+)@@/g)) {
    const [px, py] = ktNrPoz(+m[1], +m[2]);
    dodaj(px - 6.5, py - 6.5, px + 6.5, py + 6.5);
  }
  return ob;
}

/* Opis średnicy: ramka z rozmiarem i cienka linia z grotem, który dotyka
   rury zasilania. Odcinek poziomy (y, od a do b) albo pionowy (x, od a do b);
   miejsce szuka się samo — bez armatury, numerków, napisów i innych rur. */
function ktOpisyRur(src, odc, mat) {
  const prz = ktPrzeszkody(src);
  const fs = 7.6 / KT_ROZ, kol = '#C2410C', gr = 2.2;
  const koliduje = (x1, y1, x2, y2, o) => prz.some(q => {
    if (q.x2 < x1 || q.x1 > x2 || q.y2 < y1 || q.y1 > y2) return false;
    if (q.rura) {   // sama opisywana rura nie przeszkadza
      const [[ax, ay], [bx, by]] = q.rura;
      if (o.poz === 'h' && Math.abs(ay - by) < 0.5 && Math.abs(ay - o.y) < 0.5) return false;
      if (o.poz === 'v' && Math.abs(ax - bx) < 0.5 && Math.abs(ax - o.x) < 0.5) return false;
    }
    return true;
  });
  let s = '';
  for (const o of odc) {
    const t = o.t || ktKrotkaRury(mat, o.r);
    const w = t.length * fs * 0.62 + 4, h = fs + 3;
    const dl = o.poz === 'h' ? w : h;                  // zasięg ramki wzdłuż rury
    const pp = o.a + (o.b - o.a) * o.pref;
    let best = null;
    for (const [si, str] of (o.strony || (o.poz === 'h' ? ['d', 'g'] : ['p', 'l'])).entries()) {
      for (let p = o.a + dl / 2; p <= o.b - dl / 2 + 0.01; p = p < o.b - dl / 2 && p + 1 > o.b - dl / 2 ? o.b - dl / 2 : p + 1) {
        for (let d = 3; d <= (o.poz === "h" ? 28 : 18); d++) {
          const kara = Math.abs(p - pp) + Math.abs(d - 9) * 1.5 + (d < 6 ? 40 : 0) + si * 12;
          if (best && kara >= best.kara) continue;
          const zn = str === 'd' || str === 'p' ? 1 : -1;
          let lab, lin;
          if (o.poz === 'h') {
            const ym = o.y + zn * (1.4 + d + h / 2);
            lab = [p - w / 2, ym - h / 2, p + w / 2, ym + h / 2];
            lin = [p - 1.2, Math.min(o.y + zn * 2, ym - zn * h / 2), p + 1.2, Math.max(o.y + zn * 2, ym - zn * h / 2)];
          } else {
            const xm = o.x + zn * (1.4 + d + w / 2);
            lab = [xm - w / 2, p - h / 2, xm + w / 2, p + h / 2];
            lin = [Math.min(o.x + zn * 2, xm - zn * w / 2), p - 1.2, Math.max(o.x + zn * 2, xm - zn * w / 2), p + 1.2];
          }
          if (koliduje(lab[0] - 1.3, lab[1] - 1.3, lab[2] + 1.3, lab[3] + 1.3, o)) continue;
          if (koliduje(...lin, o)) continue;
          best = { kara, lab, zn, p, d };
        }
      }
    }
    if (!best) continue;
    const { lab, zn, p, d } = best, cx = (lab[0] + lab[2]) / 2, cy = (lab[1] + lab[3]) / 2;
    let linia, grot;
    if (o.poz === 'h') {
      const g0 = o.y + zn * 1.4;
      linia = `M${p} ${g0 + zn * gr * 1.4}V${o.y + zn * (1.4 + d)}`;
      grot = `M${p} ${g0}l${-gr * 0.7} ${zn * gr * 1.4}h${gr * 1.4}Z`;
    } else {
      const g0 = o.x + zn * 1.4;
      linia = `M${g0 + zn * gr * 1.4} ${p}H${o.x + zn * (1.4 + d)}`;
      grot = `M${g0} ${p}l${zn * gr * 1.4} ${-gr * 0.7}v${gr * 1.4}Z`;
    }
    s += `<g class="kt-rura-opis"><path d="${linia}" stroke="${kol}" stroke-width="0.9"/><path d="${grot}" fill="${kol}"/>`
      + `<rect x="${lab[0].toFixed(1)}" y="${lab[1].toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}" rx="2" fill="#fff" stroke="${kol}" stroke-width="0.8"/>`
      + `<text x="${cx.toFixed(1)}" y="${(cy + fs * 0.36).toFixed(1)}" font-size="${fs.toFixed(2)}" font-weight="800" text-anchor="middle" fill="${kol}">${esc(t)}</text></g>`;
    prz.push({ x1: lab[0], y1: lab[1], x2: lab[2], y2: lab[3] });
  }
  return s;
}

/* Rura z kalkulatora (materiał + rozmiar) → DN: z tabeli odpowiedników,
   a gdy jej tam nie ma — najmniejsze DN o świetle nie mniejszym niż ~95%. */
function ktDNzRury(mat, nazwa, wew) {
  const stal = pipeList('steel');
  if (mat === 'steel') return stal.find(p => p[0] === nazwa) || null;
  const kol = { copper: 2, press: 3, multi: 4, pp20: 5 }[mat];
  const n = String(nazwa).replace(/x/g, '×').replace(/\.(\d)/g, ',$1');
  const w = kol ? KT_DN_ZAM.find(r => r[kol] === n) : null;
  if (w) return stal.find(p => p[0].split(' ')[0] === w[0]) || null;
  return wew > 0 ? (stal.find(p => pipeInner(p) >= wew * 0.95) || stal[stal.length - 1]) : null;
}

/* DN → odpowiedniki o podobnym świetle (stal gwintowana, miedź, press, PEX/Al, PP PN20). */
const KT_DN_ZAM = [
  ['DN15', '1/2"', '18×1', '18×1,2', '20×2', '25×4,2'],
  ['DN20', '3/4"', '22×1', '22×1,5', '26×3', '32×5,4'],
  ['DN25', '1"', '28×1,5', '28×1,5', '32×3', '40×6,7'],
  ['DN32', '1¼"', '35×1,5', '35×1,5', '40×4', '50×8,3'],
  ['DN40', '1½"', '42×1,5', '42×1,5', '50×4,5', '63×10,5'],
  ['DN50', '2"', '54×2', '54×1,5', '63×6', '75×12,5'],
];

/* ---------- tabela doboru na rysunku ----------
   To samo, co w kartach wyników nad schematem, ale na samym rysunku —
   żeby kartka z kotłowni (pełny ekran, zrzut, wydruk) miała komplet. */
function ktTabelaDoboru(k, D, y0) {
  const kafle = [];
  const kvsT = z => 'Kvs ' + String(z.kvs).replace('.', ',') + ' ' + z.pick.dn.replace(' ', '');
  kafle.push([k.pc ? 'Moc pompy ciepła' : 'Moc kotła', '≈ ' + D.pDob + ' kW',
    k.gaz && k.cwu === 'zas' ? (k.prio ? 'z priorytetem c.w.u.' : 'bez priorytetu c.w.u. (suma)') : 'c.o. ' + fmt(D.qco, 1) + ' kW']);
  if (k.rozdz === 'sprz') kafle.push(['Sprzęgło', 'do ' + fmt(D.dn[2], 1) + ' m³/h', 'króćce ' + D.dn[1] + ' · korpus Ø' + D.dSprz + ' mm']);
  if (k.obiegi.length > 1 && k.grp !== 'szaf') kafle.push(['Rozdzielacz — przyłącze', D.dnRoz[1], k.obiegi.length + (k.obiegi.length < 5 ? ' obiegi' : ' obiegów') + ' · ' + fmt(D.qIn1, 2) + ' m³/h · spawany: korpus ' + D.korpusRoz[1]]);
  if (D.vb) kafle.push([D.vbN === 2 ? 'Bufory' : 'Bufor', D.vbDob + ' l', D.wym ? 'Ø' + D.wym[0] + ' × ' + D.wym[1] + ' mm · ' + D.dnBuf[1] : '']);
  if (D.nac) kafle.push(['Naczynie c.o.', k.gaz ? (D.nacDod ? '+ ' + D.nacDod + ' l' : 'fabr. ' + D.nacFabr + ' l') : D.nac.rec + ' l',
    'p₀ ' + fmt(D.p0, 1) + ' bar · zład ≈ ' + D.zlad + ' l']);
  if (D.vOtw) kafle.push(['Naczynie otwarte', '≥ ' + D.vOtw + ' l', '4% zładu ≈ ' + D.zlad + ' l']);
  if (D.nacCwu) kafle.push(['Naczynie c.w.u.', D.nacCwu.rec + ' l', 'p₀ 3,5 bar · zawór 6 bar']);
  if (D.V) kafle.push(['Zasobnik ' + D.V + ' l', '≈ ' + fmt(D.tNagrz, 0) + ' min', 'nagrzanie 10→55 °C · ' + fmt(D.eCwu, 1) + ' kWh']);
  if (D.rury) {
    const R = D.rury, nz = r => ktNazwaRury(R.mat, r), op = r => fmt(r.q, 2) + ' m³/h · ' + fmt(r.vAct, 2) + ' m/s';
    const doCzego = { sprz: 'do sprzęgła', buf: 'do bufora', wym: 'do wymiennika' }[k.rozdz];
    if (R.zr) kafle.push(['Rura kocioł ' + (doCzego || '→ obiegi'), nz(R.zr), op(R.zr)]);
    if (R.roz) kafle.push(['Rura do rozdzielacza', nz(R.roz), op(R.roz)]);
    if (R.cwu) kafle.push(['Rura do wężownicy', nz(R.cwu), op(R.cwu)]);
  }

  const KOL = KT_W >= 640 ? 3 : 2, odst = 8, W = (KT_W - 24 - odst * (KOL - 1)) / KOL, Hk = 46;
  let g = `<path d="M12 ${y0 + 6}H${KT_W - 12}" stroke="#E2E8EE" stroke-width="1.2"/>`
    + kt.tekst(12, y0 + 21, 'DOBÓR URZĄDZEŃ (szacunek z wpisanych kW)', { r: 8.5, k: '#8CA0B0', w: 700 });
  const yK = y0 + 30;
  kafle.forEach((t, i) => {
    const x = 12 + (i % KOL) * (W + odst), y = yK + Math.floor(i / KOL) * (Hk + odst);
    g += `<rect x="${x}" y="${y}" width="${W}" height="${Hk}" rx="9" fill="#FFF3EA" stroke="#FFD2B3" stroke-width="1"/>`
      + kt.tekst(x + 10, y + 13, t[0], { r: 7.5, k: '#8A5A3C', w: 700 })
      + kt.tekst(x + 10, y + 30, t[1], { r: 13, k: '#C2410C', w: 800 })
      + (t[2] ? kt.tekst(x + 10, y + 41, t[2], { r: 7, k: '#7A8C99', w: 600 }) : '');
  });
  let y = yK + Math.ceil(kafle.length / KOL) * (Hk + odst) + 6;
  /* Przeliczenie DN na rury z różnych materiałów — po świetle, tylko
     średnice, które są na schemacie. Ten sam numer to nie ta sama rura:
     PP 25 ma w środku tyle co DN15, nie DN25. */
  if (D.rury) {
    const R = D.rury, uzyte = new Set();
    [R.zr, R.roz, R.cwu].concat(R.ob || [], R.obP || [], R.pion || []).forEach(r => { if (r) uzyte.add(String(r.pick[0]).split(' ')[0]); });
    const wiersze = KT_DN_ZAM.filter(w => uzyte.has(w[0]));
    if (wiersze.length) {
      const kz = [12, KT_W * 0.2, KT_W * 0.36, KT_W * 0.52, KT_W * 0.68, KT_W * 0.84];
      g += kt.tekst(12, y + 10, 'RURY ZE SCHEMATU W INNYCH MATERIAŁACH (podobne światło)', { r: 7.5, k: '#8CA0B0', w: 700 });
      y += 16;
      ['DN', 'STAL (gwint)', 'MIEDŹ', 'STAL PRESS', 'PEX/Al', 'PP PN20'].forEach((t, i) => { g += kt.tekst(kz[i], y + 8, t, { r: 7, k: '#8CA0B0', w: 700 }); });
      y += 12;
      wiersze.forEach((w, j) => {
        if (j % 2 === 0) g += `<rect x="8" y="${y}" width="${KT_W - 16}" height="15" rx="4" fill="#F5F8FA"/>`;
        w.forEach((t, i) => { g += kt.tekst(kz[i], y + 10.5, t, { r: 8, k: i ? KT_I : '#C2410C', w: i ? 600 : 800 }); });
        y += 15;
      });
      g += kt.tekst(12, y + 10, 'Przy PP i PEX bierz rozmiar z tabeli, a nie ten sam numer co DN — PP 25 to w środku DN15.', { r: 7, k: '#8CA0B0', w: 600 });
      y += 20;
    }
  }
  // obiegi: kW, przepływ, mieszacz
  const kol = [12, KT_W * 0.33, KT_W * 0.44, KT_W * 0.6, KT_W * 0.76];
  const pTxt = pp => pp ? (pp.kl === 'cyrkulacyjna' ? 'cyrkulacyjna' + (pp.zKalk ? ' · ' + fmt(pp.H, 1) + ' m' : '') : pp.kl + ' · ' + fmt(pp.H, 1) + ' m') : '—';
  /* Pompa jeszcze niedobrana (szacunek) dostaje dopisek, że da się ją dobrać
     dotknięciem na schemacie. Po doborze dopisek znika. */
  const pKom = (x, y, pp, kolor) => `<text x="${x}" y="${y}" font-size="8" font-weight="700" text-anchor="start" fill="${kolor}">${esc(pTxt(pp))}`
    + (pp && pp.szac ? `<tspan font-size="6.6" font-weight="600" fill="#E8590C"> (kliknij na pompę, aby dobrać)</tspan>` : '') + '</text>';
  g += kt.tekst(kol[0], y + 8, 'OBIEG', { r: 7, k: '#8CA0B0', w: 700 }) + kt.tekst(kol[1], y + 8, 'MOC', { r: 7, k: '#8CA0B0', w: 700 })
    + kt.tekst(kol[2], y + 8, 'PRZEPŁYW', { r: 7, k: '#8CA0B0', w: 700 }) + kt.tekst(kol[3], y + 8, 'MIESZACZ', { r: 7, k: '#8CA0B0', w: 700 })
    + kt.tekst(kol[4], y + 8, 'POMPA', { r: 7, k: '#8CA0B0', w: 700 });
  y += 12;
  k.obiegi.forEach((ob, i) => {
    const nz = k.nazwyOb[i];
    const n = (ob[0] === 'g' ? 'Grzejniki' : 'Podłogówka') + (nz.nazwa ? ' — ' + nz.nazwa : nz.nr ? ' ' + nz.nr : '');
    if (i % 2 === 0) g += `<rect x="8" y="${y}" width="${KT_W - 16}" height="15" rx="4" fill="#F5F8FA"/>`;
    g += kt.tekst(kol[0], y + 10.5, n, { r: 8, k: KT_I, w: 600 })
      + kt.tekst(kol[1], y + 10.5, k.kw[i] ? fmt(k.kw[i], 1) + ' kW' : '—', { r: 8, k: KT_I, w: 700 })
      + kt.tekst(kol[2], y + 10.5, k.kw[i] ? fmt(D.prz[i], 2) + ' m³/h · Δt ' + D.dts[i] : '—', { r: 8, k: KT_I, w: 600 })
      + kt.tekst(kol[3], y + 10.5, D.zawory[i] ? kvsT(D.zawory[i]) : (ob === 'grzM' || ob === 'podlM') ? '—' : 'bez mieszacza', { r: 8, k: D.zawory[i] ? KT_I : '#8CA0B0', w: 700 })
      + (D.maPompy ? pKom(kol[4], y + 10.5, D.pompy[i], D.pompy[i] ? KT_I : '#8CA0B0') : kt.tekst(kol[4], y + 10.5, 'pompa źródła', { r: 8, k: '#8CA0B0', w: 700 }));
    y += 15;
  });
  D.pompyZr.forEach((pp, j) => {
    if ((k.obiegi.length + j) % 2 === 0) g += `<rect x="8" y="${y}" width="${KT_W - 16}" height="15" rx="4" fill="#F5F8FA"/>`;
    g += kt.tekst(kol[0], y + 10.5, pp.nazwa, { r: 8, k: KT_I, w: 600 })
      + kt.tekst(kol[2], y + 10.5, fmt(pp.q, 2) + ' m³/h', { r: 8, k: KT_I, w: 600 })
      + pKom(kol[4], y + 10.5, pp, KT_I);
    y += 15;
  });
  g += kt.tekst(kol[0], y + 11, 'Razem c.o.', { r: 8, k: KT_I, w: 800 })
    + kt.tekst(kol[1], y + 11, fmt(D.qco, 1) + ' kW', { r: 8, k: KT_I, w: 800 })
    + kt.tekst(kol[2], y + 11, fmt(D.prz.reduce((a, b) => a + b, 0), 2) + ' m³/h', { r: 8, k: KT_I, w: 800 });
  y += 20;
  if (D.pompy.some(pp => pp && pp.szac) || D.pompyZr.length) {
    g += kt.tekst(12, y + 2, 'Niedobrana pompa to szacunek z typowych oporów · klasa: przyłącze – maks. wysokość podnoszenia w dm', { r: 7, k: '#8CA0B0', w: 600 });
    y += 10;
  }
  return { svg: g, h: y - y0 };
}

/* ---------- legenda pod rysunkiem (same nazwy, bez opisów) ---------- */
function ktLegenda(el, y0) {
  const KOL = KT_W >= 640 ? 3 : 2, W = (KT_W - 24) / KOL, WIE = 15;
  const rzedy = Math.ceil(el.length / KOL);
  const yStart = y0 + 38;
  let g = `<path d="M12 ${y0 + 6}H${KT_W - 12}" stroke="#E2E8EE" stroke-width="1.2"/>`
    + kt.tekst(12, y0 + 21, 'LEGENDA', { r: 8.5, k: '#8CA0B0', w: 700 });
  el.forEach((e, i) => {
    const kol = Math.floor(i / rzedy), x = 12 + kol * W, y = yStart + (i % rzedy) * WIE;
    g += `<circle cx="${x + 6}" cy="${y}" r="6" fill="#FF7A33"/>`
      + `<text x="${x + 6}" y="${y + 2.9}" font-size="8" font-weight="700" text-anchor="middle" fill="#fff">${e[0]}</text>`
      + kt.tekst(x + 16, y + 3, e[3] || e[1], { r: 8.3, k: KT_I, w: 500 });
  });
  return { svg: g, h: 38 + rzedy * WIE + 4 };
}

/* ---------- uwagi do konfiguracji ---------- */
function ktUwagi(k) {
  const u = [];
  if (k.wym)
    u.push('Po stronie starej instalacji zostaje naczynie otwarte — nie montuj tam zaworu bezpieczeństwa ani naczynia przeponowego. Napełnianie i odpowietrzanie obu obiegów prowadź osobno.');
  if (k.zr === 'drew' && k.rozdz !== 'buf')
    u.push('Kocioł zgazowujący drewno musi pracować z buforem — minimum 55 litrów na każdy kW mocy (PN-EN 303-5). Bez bufora kocioł dławi się i smoli, a wymiennik szybko zarasta.');
  if (k.stale && k.obiegi.includes('podlB'))
    u.push('Kocioł na paliwo stałe nie może zasilać podłogówki bezpośrednio — do pętli pójdzie 70–80 °C. Wybierz podłogówkę z zaworem mieszającym.');
  if (k.otw)
    u.push('W układzie otwartym naczynie musi stać w najwyższym punkcie, nad kotłem, a rura bezpieczeństwa i wzbiorcza nie mogą mieć żadnych zaworów ani zwężeń. Na nieogrzewanym poddaszu zaizoluj naczynie i rury.');
  if (k.stale && !k.otw)
    u.push('Układ zamknięty przy kotle na paliwo stałe jest dozwolony tylko z urządzeniem odprowadzającym nadmiar ciepła (wężownica schładzająca z zaworem termicznym). Pompa kotłowa musi działać także przy zaniku prądu.');
  if (k.obiegi.length >= 2 && k.rozdz === 'brak')
    u.push('Dwa obiegi z własnymi pompami bez sprzęgła lub bufora będą przeszkadzać sobie nawzajem i pompie źródła. Wybierz sprzęgło (kocioł) albo bufor (pompa ciepła).');
  if (k.obiegi.includes('podlB') && (k.obiegi.includes('grz') || k.obiegi.includes('grzM')) && k.gaz)
    u.push('Podłogówka bez mieszacza dostanie tę samą temperaturę co grzejniki — za gorącą dla wylewki. Wybierz podłogówkę z zaworem mieszającym.');
  if (k.pc && k.rozdz === 'brak')
    u.push('Bez bufora sprawdź w instrukcji pompy ciepła minimalną pojemność wodną instalacji (odszranianie) i minimalny przepływ — przy zamkniętych zaworach strefowych pompa zgłasza błędy przepływu.');
  if (k.rozdz === 'buf' && k.gaz)
    u.push('Bufor przy kotle gazowym zwykle nie jest potrzebny — kocioł z modulacją wystarczy ze sprzęgłem. Bufor ma sens przy kotle na paliwo stałe albo pompie ciepła.');
  return u;
}

/* ---------- pełny ekran ----------
   Schemat jest większy niż ekran telefonu. W pełnym widoku wchodzi cały,
   a guzikami można go powiększyć i przesuwać palcem jak mapę. */
function ktPelnyHtml() {
  const z = state.ktPelny.proc || 100;
  return `<div class="kt-full" role="dialog" aria-label="Schemat kotłowni — pełny ekran">
    <div class="kt-full-top">
      <strong>Schemat kotłowni</strong>
      <button class="kt-full-btn" type="button" data-ktzoom="-" aria-label="Pomniejsz">${svg('minus')}</button>
      <button class="kt-full-btn kt-proc" type="button" data-ktzoom="0">${z}%</button>
      <button class="kt-full-btn" type="button" data-ktzoom="+" aria-label="Powiększ">${svg('plus')}</button>
      <button class="item-x" type="button" data-ktclose aria-label="Zamknij">${svg('x')}</button>
    </div>
    <div class="kt-stage" id="ktStage"><div class="kt-fit" id="ktFit">${state.ktPelny.rys}</div></div>
  </div>`;
}
/* Skala dopasowana do ekranu = 100%. Zoom to wielokrotność tej skali,
   dzięki czemu „100%" zawsze znaczy „cały schemat na ekranie". */
function ktDopasuj(zmiana) {
  const st = document.getElementById('ktStage'), fit = document.getElementById('ktFit');
  if (!st || !fit) return;
  const sv = fit.querySelector('svg'); if (!sv) return;
  const w = parseFloat(sv.getAttribute('width')), h = parseFloat(sv.getAttribute('height'));
  const baza = Math.min((st.clientWidth - 8) / w, (st.clientHeight - 8) / h);
  let proc = state.ktPelny.proc || 100;
  if (zmiana === '+') proc = Math.min(400, proc + (proc < 200 ? 50 : 100));
  else if (zmiana === '-') proc = Math.max(100, proc - (proc > 200 ? 100 : 50));
  else if (zmiana === '0') proc = 100;
  state.ktPelny.proc = proc;
  const sk = baza * proc / 100;
  sv.style.transformOrigin = '0 0';
  sv.style.transform = `scale(${sk})`;
  fit.style.width = (w * sk) + 'px';
  fit.style.height = (h * sk) + 'px';
  const pr = document.querySelector('.kt-proc'); if (pr) pr.textContent = proc + '%';
  return proc;
}
document.addEventListener('click', e => {
  if (e.target.closest('[data-ktfull]')) {
    state.ktPelny = { rys: state.ktRys, proc: 100 };
    renderOverlay(); ktDopasuj(); return;
  }
  const z = e.target.closest('[data-ktzoom]');
  if (z && state.ktPelny) {
    const st = document.getElementById('ktStage');
    const sx = st ? (st.scrollLeft + st.clientWidth / 2) : 0, sy = st ? (st.scrollTop + st.clientHeight / 2) : 0;
    const przed = state.ktPelny.proc || 100;
    const po = ktDopasuj(z.dataset.ktzoom) || przed;
    /* po zmianie powiększenia zostajemy w tym samym miejscu rysunku */
    if (st) { const k = po / przed; st.scrollLeft = sx * k - st.clientWidth / 2; st.scrollTop = sy * k - st.clientHeight / 2; }
    return;
  }
  if (e.target.closest('[data-ktclose]')) { state.ktPelny = null; renderOverlay(); return; }
});

/* ---------- lista obiegów (pole formularza) ---------- */
const KT_NAZWY_OB = ['', 'Parter', 'Piętro', 'Poddasze', 'Piwnica', 'Łazienki', 'Strefa dzienna', 'Strefa nocna', 'Garaż', 'Warsztat', 'Biuro', 'Lokal'];
function ktObListaHtml(f, v, cc) {
  const sel = (attr, i, opcje, wart) => '<select ' + attr + '="' + f.k + '" data-i="' + i + '">'
    + opcje.map(o => '<option value="' + esc(o[0]) + '"' + (String(o[0]) === String(wart) ? ' selected' : '') + '>' + esc(o[1]) + '</option>').join('')
    + '</select><span class="chev">' + svg('chevDown') + '</span>';
  const rows = (v[f.k] || []).map((o, i) => '<div class="gpt">'
    + '<div class="gpt-h"><span class="gpt-n" style="--c:' + cc + '">' + (i + 1) + '</span>'
    + '<div class="field"><label>Obieg</label>' + sel('data-obr', i, [['grz', 'Grzejniki'], ['podl', 'Ogrzewanie podłogowe']], o.r) + '</div>'
    + '<button class="del" type="button" data-delob="' + f.k + '" data-i="' + i + '" aria-label="Usuń">' + svg('trash') + '</button></div>'
    + '<div class="row2"><div class="field"><label>Nazwa</label>' + sel('data-obn', i, KT_NAZWY_OB.concat(o.n && KT_NAZWY_OB.indexOf(o.n) < 0 ? [o.n] : []).map(x => [x, x || 'bez nazwy']), o.n || '') + '</div>'
    + '<div class="field"><label>Mieszacz</label>' + sel('data-obm', i, [[1, 'Tak'], [0, 'Nie']], +o.m ? 1 : 0) + '</div></div>'
    + '<div class="row2"><div class="field"><label>Zapotrzebowanie</label><input type="number" inputmode="decimal" step="0.1" min="0" data-obkw="' + f.k + '" data-i="' + i + '" value="' + (o.kw || '') + '" placeholder="np. 8"><span class="unit">kW</span></div><div></div></div>'
    + '</div>').join('');
  return '<div class="nlist">' + rows
    + ((v[f.k] || []).length < 8 ? '<button class="addbtn" type="button" data-addob="' + f.k + '" style="--c:' + cc + '">' + svg('plus') + 'Dodaj obieg</button>' : '')
    + '</div>';
}
document.addEventListener('click', e => {
  const a = e.target.closest('[data-addob]');
  if (a) {
    const { v } = curr(); const l = v[a.dataset.addob];
    const ost = l[l.length - 1];
    l.push(ost ? { r: ost.r, m: ost.m, n: '' } : { r: 'grz', m: 0, n: '' });
    saveCalcValues(); render(false); return;
  }
  const d = e.target.closest('[data-delob]');
  if (d) {
    const { v } = curr(); const lista = v[d.dataset.delob] || [], o = lista[+d.dataset.i];
    /* Obieg z części projektu: usunięcie go tutaj usuwa też tę część —
       inaczej przy następnym otwarciu projektu wróciłby sam. */
    const a = state.projAkt && state.projAkt.kotlownia;
    const p = a && o && o.zP ? state.projekty.find(x => x.id === a.p) : null;
    if (p && p.czesci[o.zP]) {
      const nz = projCz(o.zP).nazwa;
      if (lista.filter(x => x.zP === o.zP).length > 1) {
        toast('Ten obieg to jeden z kilku rozdzielaczy części „' + nz + '” — usuń ten rozdzielacz w jej kalkulatorze (Biuro → projekt → Edytuj).');
        return;
      }
      state.projPotw = { co: 'czesc', c: o.zP, pid: p.id, tytul: 'Usunąć obieg i część „' + nz + '”?',
        tekst: 'Ten obieg pochodzi z części projektu „' + p.nazwa + '”. Usunę jedno i drugie: obieg ze schematu i część z projektu razem z jej zestawieniem. Pozostałe części, oferty i faktury zostają.',
        tak: 'Usuń' };
      renderOverlay(); return;
    }
    lista.splice(+d.dataset.i, 1); saveCalcValues(); render(false);
  }
});
document.addEventListener('change', e => {
  const t = e.target;
  if (t.dataset && t.dataset.obkw) {
    const { v } = curr(); const o = v[t.dataset.obkw][+t.dataset.i]; if (!o) return;
    const nowe = Math.max(0, parseFloat(t.value.replace(',', '.')) || 0);
    if (nowe !== o.kw) { o.hP = 0; o.qP = 0; }
    o.kw = nowe;
    saveCalcValues(); render(false); return;
  }
  const k = t.dataset && (t.dataset.obr || t.dataset.obn || t.dataset.obm);
  if (!k || t.tagName !== 'SELECT') return;
  const { v } = curr(); const o = v[k][+t.dataset.i]; if (!o) return;
  if (t.dataset.obr) { o.r = t.value; o.m = t.value === 'podl' ? 1 : 0; }   // podłogówka domyślnie z mieszaczem
  if (t.dataset.obn !== undefined && t.dataset.obn) o.n = t.value;
  if (t.dataset.obm) o.m = +t.value;
  saveCalcValues(); render(false);
});

/* ---------- okienko po dotknięciu elementu na schemacie ---------- */
function ktOkno(rodzaj, i) {
  const { v } = curr();
  const zamknij = () => { const o = document.getElementById('ktOkno'); if (o) o.remove(); };
  zamknij();
  let tytul, tresc;
  if (rodzaj === 'ob') {
    const o = (v.ob || [])[i]; if (!o) return;
    tytul = (o.r === 'podl' ? 'Podłogówka' : 'Grzejniki') + (o.n ? ' — ' + o.n : ' (obieg ' + (i + 1) + ')');
    tresc = '<label for="ktKw">Zapotrzebowanie na ciepło</label>'
      + '<div class="kt-okno-pole"><input id="ktKw" type="text" inputmode="decimal" autocomplete="off" value="' + String(o.kw || '').replace(".", ",") + '" placeholder="np. 8"><span>kW</span></div>'
      + '<p>Z projektu, audytu albo kalkulatora „Strata ciepła”. Dla całego obiegu — wszystkich grzejników albo pętli razem.</p>'
      + '<label for="ktDl">' + (o.r === 'podl' ? 'Rura do rozdzielacza (w jedną stronę)' : 'Rura do najdalszego grzejnika (w jedną stronę)') + '</label>'
      + '<div class="kt-okno-pole"><input id="ktDl" type="text" inputmode="decimal" autocomplete="off" value="' + String(o.dl || '').replace(".", ",") + '" placeholder="' + (o.r === 'podl' ? 'np. 10' : 'np. 25') + '"><span>m</span></div>'
      + (o.r === 'podl' ? '<label for="ktDp">Opory najdłuższej pętli</label><div class="kt-okno-pole"><input id="ktDp" type="text" inputmode="decimal" autocomplete="off" value="' + String(o.dp || '').replace(".", ",") + '" placeholder="np. 20"><span>kPa</span></div>' : '')
      + '<p>Długość i opory są do doboru pompy — bez nich liczę z typowych wartości.</p>';
  } else {
    tytul = 'Zasobnik c.w.u.';
    tresc = '<label>Pojemność</label><div class="kt-okno-chipy">'
      + [100, 120, 150, 200, 250, 300, 400, 500].map(x => '<button type="button" data-ktl="' + x + '"' + (+v.zasL === x ? ' class="on"' : '') + '>' + x + ' l</button>').join('')
      + '</div><p>Na 1 osobę liczy się zwykle 50–60 l.</p>';
  }
  const d = document.createElement('div');
  d.id = 'ktOkno'; d.className = 'kt-okno';
  d.innerHTML = '<div class="kt-okno-box" role="dialog" aria-label="' + esc(tytul) + '"><b>' + esc(tytul) + '</b>' + tresc
    + '<div class="kt-okno-btn"><button type="button" class="btn2" data-ktanuluj>Anuluj</button>'
    + (rodzaj === 'ob' ? '<button type="button" class="btn2 on" data-ktzapisz>Zapisz</button>' : '') + '</div></div>';
  document.body.appendChild(d);
  const zapisz = val => {
    if (rodzaj === 'ob') {
      const kwStare = v.ob[i].kw;
      v.ob[i].kw = ktLiczba(val);
      if (v.ob[i].kw !== kwStare) { v.ob[i].hP = 0; v.ob[i].qP = 0; v.ob[i].rk = null; }
      const dl = document.getElementById('ktDl'), dp = document.getElementById('ktDp');
      const o = v.ob[i], przed = [o.kw, o.dl, o.dp].join('|');
      if (dl) o.dl = ktLiczba(dl.value);
      if (dp) o.dp = ktLiczba(dp.value);
      // ręczna zmiana danych kasuje pompę przeniesioną z kalkulatora — liczymy od nowa
      if ([o.kw, o.dl, o.dp].join('|') !== przed) { o.hP = 0; o.qP = 0; }
    }
    else v.zasL = +val;
    zamknij(); saveCalcValues(); render(false);
    if (state.ktPelny) { state.ktPelny.rys = state.ktRys; renderOverlay(); ktDopasuj(); }
  };
  d.addEventListener('click', e => {
    if (e.target === d || e.target.closest('[data-ktanuluj]')) { zamknij(); return; }
    if (e.target.closest('[data-ktzapisz]')) { zapisz(document.getElementById('ktKw').value); return; }
    const l = e.target.closest('[data-ktl]'); if (l) zapisz(l.dataset.ktl);
  });
  const inp = document.getElementById('ktKw');
  if (inp) { inp.focus(); inp.addEventListener('keydown', e => { if (e.key === 'Enter') zapisz(inp.value); }); }
}
document.addEventListener('click', e => {
  const g = e.target.closest && e.target.closest('[data-ktklik]');
  if (g) ktOkno(g.dataset.ktklik, +g.dataset.i);
});

/* ---------- przeniesienie mocy z kalkulatorów obiegów ----------
   „Ogrzewanie grzejnikowe” sumuje moce grzejników, „Ogrzewanie podłogowe”
   moce rozdzielaczy — jednym przyciskiem trafiają jako obiegi do kreatora
   kotłowni, żeby nie przepisywać liczb. */
/* Rozdzielacz na końcu obiegu (grzejniki w układzie rozdzielaczowym,
   każda podłogówka): korpus z przepływu przez belkę, jak w kalkulatorach. */
const ktKorpusDN = k => k === '5/4"' ? 'DN32 (5/4")' : 'DN25 (1")';
function ktZKalkulatora(id, v, modeKey) {
  if (id === 'co_dia') {
    const kw = (v.rad || []).reduce((a, x) => a + (+x || 0), 0) / 1000;
    if (!(kw > 0)) return [];
    let rkG = null, rozd = null;
    try {   // rura od kotła — tak jak liczy kalkulator (cała moc, jego Δt, materiał i prędkość)
      const reg = Number(v.reg), dt = reg === -1 ? Number(v.dt) : (REGIMES_CO[reg] || REGIMES_CO[1])[1];
      const q = pumpFlow(kw, dt), sp = selectPipe(q, v.mat, v.v);
      if (sp) rkG = { s: 'obieg', mat: v.mat, p: sp.pick[0], in: pipeInner(sp.pick), q, vAct: sp.vAct, v: +v.v || 0 };
      var ppG = sp ? pompaGrzejnikowa(q, sp, v.mat, Number(v.dlZr) || 0, modeKey === 'rozdz') : null;
      if (modeKey === 'rozdz') {
        const korp = (ROZDZ_KORPUSY.find(x => predkoscWRurze(q, x[1]) <= V_MAX_KORPUS) || ROZDZ_KORPUSY[ROZDZ_KORPUSY.length - 1])[0];
        rozd = { wyj: (v.rad || []).filter(x => +x > 0).length, korpus: korp, ile: 1 };
      }
    } catch (e) { rkG = null; }
    return [Object.assign({ r: 'grz', kw: Math.round(kw * 10) / 10, n: '', rk: rkG, rozd, dl: Math.max(0, Number(v.dlZr) || 0) },
      typeof ppG !== 'undefined' && ppG ? { hP: Math.round(ppG.H * 100) / 100, qP: Math.round(ppG.q * 1000) / 1000, hPz: 'co' } : {})];
  }
  if (id === 'rozdz_dia') {
    const m = v.mie === 'nisko' ? 0 : 1;
    const l = (v.rozdz || []).filter(x => +x.w > 0);
    /* Pompę kalkulator podłogówki liczy dokładnie (pętla, przepływomierz,
       belka, zawór, rura) — bierzemy ją stamtąd, a nie z szacunku. */
    let r = null;
    try {
      const dtPod = (DT_PODLOGOWKA[Number(v.dtp)] || DT_PODLOGOWKA[0])[1], reg = Number(v.reg);
      const dtCo = m ? (reg === -1 ? Number(v.dt) : (REGIMES_CO[reg] || REGIMES_CO[1])[1]) : dtPod;
      r = dojsciaRozdzielaczy(l, { dtCo, dtPod, mieszacz: !!m, wspolnyMieszacz: !!m && v.mieGdzie === 'wsp' && l.length > 1, mat: v.mat, v: v.v, zapas: v.zapas });
    } catch (e) { r = null; }
    const pk = p => p && p.pompa && !p.pompa.brakPetli ? Object.assign({ hP: Math.round(p.pompa.H * 100) / 100, qP: Math.round(p.pompa.q * 1000) / 1000 },
      p.pompa.szacPetli ? { hPz: 'podlSzac' } : {}) : {};
    const rkR = (sp, q, s) => sp ? { rk: { s, mat: v.mat, p: sp.pick[0], in: pipeInner(sp.pick), q, vAct: sp.vAct, v: +v.v || 0 } } : {};
    // jeden mieszacz w kotłowni = jedna grupa pompowa, czyli jeden obieg na schemacie
    if (m && v.mieGdzie === 'wsp' && l.length > 1)
      return [Object.assign({ r: 'podl', m, kw: Math.round(l.reduce((a, x) => a + +x.w, 0) / 100) / 10, n: '',
        dl: Math.max(...l.map(x => +x.dl || 0)), dp: Math.max(...l.map(x => +x.dp || 0)), wyj: l.reduce((a, x) => a + (+x.wyj || 0), 0) },
        r && r.pompaWsp && !r.pozycje.some(p => p.pompa.brakPetli) ? { hP: Math.round(r.pompaWsp.H * 100) / 100, qP: Math.round(r.pompaWsp.q * 1000) / 1000 } : {},
        r ? rkR(r.wspolny, r.qWspolny, 'obieg') : {},
        { rozd: { wyj: l.reduce((a, x) => a + (+x.wyj || 0), 0), korpus: r && r.pozycje.some(p => p.korpus === '5/4"') ? '5/4"' : '1"', ile: l.length } })];
    return l.map((x, i) => Object.assign({ r: 'podl', m, kw: Math.round(+x.w / 100) / 10, n: String(x.nazwa || ''), dl: +x.dl || 0, dp: +x.dp || 0, wyj: +x.wyj || 0 },
      pk(r && r.pozycje[i]), r && r.pozycje[i] ? rkR(r.pozycje[i].rura, r.pozycje[i].qDoj, r.pozycje[i].przezMieszacz ? 'zrodlo' : 'obieg') : {},
      { rozd: { wyj: +x.wyj || 0, korpus: r && r.pozycje[i] ? r.pozycje[i].korpus : '1"', ile: 1 } }));
  }
  return [];
}
function ktPrzyciskPrzenies(id, v) {
  return '';   // obiegi idą do kotłowni przez „Przenieś do projektu”
  const l = ktZKalkulatora(id, v);
  if (!l.length) return '';
  const suma = l.reduce((a, o) => a + o.kw, 0);
  return '<button class="btn2" type="button" style="width:100%" data-dokotl="' + id + '">' + svg('kotlownia')
    + 'Przenieś ' + fmt(suma, 1) + ' kW do „Schematu kotłowni”' + '</button>';
}
/* Obiegi z kalkulatora dopisane do listy kotłowni: obiegi tego samego
   rodzaju zastępujemy, reszta zostaje; mieszacz grzejników zostaje taki,
   jaki był, a przy jednym obiegu — także jego nazwa. */
function ktScalObiegi(stare, nowe) {
  stare = stare || [];
  if (!nowe.length) return stare;
  const rodzaj = nowe[0].r;
  const mGrz = (stare.find(o => o.r === 'grz') || { m: 0 }).m;
  const stareTego = stare.filter(o => o.r === rodzaj);
  if (nowe.length === 1 && stareTego.length === 1 && !nowe[0].n) nowe[0].n = stareTego[0].n || '';
  const l = stare.filter(o => o.r !== rodzaj).concat(nowe.map(o => ({ r: o.r, m: o.r === 'grz' ? mGrz : o.m, n: o.n, kw: o.kw, dl: o.dl || 0, dp: o.dp || 0, wyj: o.wyj || 0, hP: o.hP || 0, qP: o.qP || 0, rk: o.rk || null })));
  l.sort((x, y) => (x.r === 'grz' ? 0 : 1) - (y.r === 'grz' ? 0 : 1));   // grzejniki nad podłogówką
  return l;
}
/* Przeniesienie obiegów do wybranej kotłowni: projektu (pid) albo kreatora
   bez projektu (pid = ''). Kotłownię projektu, której jeszcze nie ma,
   zakładamy, a kreator od razu się z nią łączy. */
function ktPrzeniesDo(t, pid) {
  const kot = CALCS.find(c => c.id === 'kotlownia'), mk = activeMode(kot);
  const p = pid ? state.projekty.find(x => x.id === pid) : null;
  if (p) {
    if (!p.czesci.kot) projUstawCzesc(p, 'kot', mk.key, ktDomyslne());
    if (typeof projZapamietajKalk === 'function') projZapamietajKalk(kot.id, mk.key);
    state.values[vkey(kot.id, mk.key)] = projCzWartosci(p, 'kot').v;
    state.projAkt.kotlownia = { p: p.id, c: 'kot' };
  } else if (state.projAkt && state.projAkt.kotlownia && typeof projPrzywrocKalk === 'function') projPrzywrocKalk('kotlownia');
  /* Do kotłowni projektu, z którym połączony jest kalkulator: obiegi ze
     WSZYSTKICH części tego rodzaju (parter, piętro…), a nie tylko z tej
     jednej — inaczej druga część skasowałaby pierwszą. */
  let nowe = t.nowe;
  const a = state.projAkt[t.zrodlo];
  if (p && a && a.p === p.id && typeof projCzesciTypu === 'function') {
    nowe = projCzesciTypu(p, projTyp(a.c)).reduce((acc, c) => acc.concat(c === a.c ? t.nowe
      : (() => { const cw = projCzWartosci(p, c); return ktZKalkulatora(cw.calc.id, cw.v, cw.mode.key); })()), []);
  }
  const kv = getValues(kot, mk);
  kv.ob = ktScalObiegi(kv.ob, nowe);
  if (p) projUstawCzesc(p, 'kot', mk.key, kv);
  state.tab = 'calc'; state.calc = 'kotlownia'; state.screen = 'calc';
  saveCalcValues(); render(true);
  const n = nowe.length;
  toast('Przeniesiono ' + n + (n === 1 ? ' obieg' : ' obiegi') + ' do schematu kotłowni' + (p ? ' w projekcie „' + p.nazwa + '”' : ' (bez projektu)') + ' — '
    + (n === 1 ? 'zastąpił' : 'zastąpiły') + (t.nowe[0].r === 'grz' ? ' wcześniejsze obiegi grzejnikowe.' : ' wcześniejsze obiegi podłogowe.')
    + (t.przyklad ? ' Uwaga: część rozdzielaczy to przykładowe wartości.' : ''));
}
/* Dokąd można przenieść: kotłownia projektu, z którym połączony jest
   kalkulator (nawet jeśli jej jeszcze nie ma), kotłownie innych projektów
   i kreator bez projektu. */
function ktCele(zrodlo) {
  const a = state.projAkt && state.projAkt[zrodlo];
  const ten = a ? state.projekty.find(x => x.id === a.p) : null;
  const l = [];
  if (ten) l.push({ pid: ten.id, nazwa: ten.nazwa || 'Projekt', opis: ten.czesci.kot ? projOpisCz(ten, 'kot') : 'założę w nim nową kotłownię', ten: true });
  state.projekty.filter(p => p !== ten && p.czesci && p.czesci.kot)
    .forEach(p => l.push({ pid: p.id, nazwa: p.nazwa || 'Projekt', opis: projOpisCz(p, 'kot') }));
  return l;
}
function ktCelHtml(t) {
  const wiersze = ktCele(t.zrodlo).map(c => `<button class="ocard" data-ktcel="${esc(c.pid)}" style="margin-bottom:8px;width:100%">
      <span class="ocard-n">${svg(c.pid ? 'kotlownia' : 'plus').replace('<svg', '<svg style="width:20px;height:20px"')}</span>
      <span class="ocard-t"><strong>${esc(c.nazwa)}</strong><span>${esc(c.opis)}${c.ten ? ' · ten projekt' : ''}</span></span>
    </button>`).join('');
  return `<div class="sheet" data-closekt role="dialog" aria-label="Do którego schematu kotłowni">
    <div class="sheet-in" data-stop>
      <div class="sheet-h">${svg('kotlownia')}<strong>Do którego schematu?</strong>
        <button class="item-x" data-closekt aria-label="Zamknij">${svg('x')}</button></div>
      <div class="sheet-body">
        <p class="hint" style="margin:0 0 10px">Przenosisz: <b>${esc(t.opis)}</b></p>
        ${wiersze}
      </div>
    </div></div>`;
}
const _renderOverlayKt = renderOverlay;
renderOverlay = function () {
  const el = document.getElementById('overlay');
  if (state.ktCel && el) { el.innerHTML = ktCelHtml(state.ktCel); return; }
  return _renderOverlayKt();
};
document.addEventListener('click', e => {
  if (!e.target.closest) return;
  const c = e.target.closest('[data-ktcel]');
  if (c && state.ktCel) { const t = state.ktCel; state.ktCel = null; renderOverlay(); ktPrzeniesDo(t, c.dataset.ktcel); return; }
  if (state.ktCel && e.target.closest('[data-closekt]')
      && (!e.target.closest('[data-stop]') || e.target.closest('.sheet-h [data-closekt]'))) { state.ktCel = null; renderOverlay(); return; }
  const b = e.target.closest('[data-dokotl]');
  if (!b) return;
  const { v } = curr();
  const zrodlo = b.dataset.dokotl;
  const nowe = ktZKalkulatora(zrodlo, v, activeMode(CALCS.find(c => c.id === zrodlo)).key);
  if (!nowe.length) return;
  const t = { zrodlo, nowe, przyklad: zrodlo === 'rozdz_dia' && (v.rozdz || []).some(x => x.przyklad),
    opis: (nowe[0].r === 'grz' ? 'grzejniki ' : 'podłogówka ') + fmt(nowe.reduce((s2, o) => s2 + o.kw, 0), 1) + ' kW' };
  const cele = ktCele(zrodlo);
  if (!cele.length) { toast('Najpierw stwórz projekt ze schematem kotłowni: Kalkulatory → Schemat kotłowni → „Stwórz projekt”.'); return; }
  state.ktCel = t; renderOverlay();
});

/* ---------- pompa ze schematu → kalkulator „Dobór pompy” i z powrotem ---------- */
document.addEventListener('click', e => {
  const g = e.target.closest && e.target.closest('[data-ktpompa]');
  if (!g) return;
  e.stopPropagation();
  ktDobierzPompe(g.dataset.ktpompa, +g.dataset.i);
}, true);
/* Dobór pompy ze schematu w kalkulatorze „Dobór pompy” — z kreatora
   (dotknięcie pompy) albo z projektu („dobierz ręcznie”). */
function ktDobierzPompe(rodzaj, i) {
  const { v } = curr(); const k = ktKonfig(v); const D = ktDobor(k);
  if (state.ktPelny) { state.ktPelny = null; renderOverlay(); }
  if (rodzaj === 'ob' && ((v.ob || [])[i] || {}).r === 'podl') {
    state.tab = 'calc'; state.calc = 'rozdz_dia'; state.screen = 'calc'; render(true);
    toast('Pompę podłogówki liczy ten kalkulator — wpisz rozdzielacze z oporami pętli i przenieś wynik do projektu („Przenieś do projektu” → „Zastąp”).');
    return;
  }
  const pc = CALCS.find(c => c.id === 'pump'); const pv = getValues(pc, activeMode(pc));
  const cel = rodzaj === 'ob' ? 'grz' : rodzaj, C = POMPA_CEL[cel];
  pv.cel = cel; ['sup', 'ret', 'len', 'rb', 'rv', 'rr'].forEach(x => { pv[x] = C[x]; });
  if (rodzaj === 'ob') {
    if (k.kw[i]) pv.power = k.kw[i];
    if (k.rozdz !== 'brak') pv.rb = 0;             // za sprzęgłem / buforem kocioł nie leży na drodze tej pompy
    if (D && D.zawory[i]) pv.rv = Math.round((C.rv + D.zawory[i].dp * 100) * 10) / 10;
    if (k.pc) { pv.sup = 45; pv.ret = 40; }
    if (k.dl[i]) pv.len = 2 * k.dl[i];
  } else if (D && rodzaj !== 'cyrk') pv.power = D.pDob;
  const nz = rodzaj === 'ob' ? k.nazwyOb[i] : null;
  const zlecenie = { rodzaj, i, nazwa: rodzaj === 'ob' ? 'Grzejniki' + (nz.nazwa ? ' — ' + nz.nazwa : nz.nr ? ' ' + nz.nr : '')
    : rodzaj === 'kotl' ? 'Pompa kotłowa' : rodzaj === 'cyrk' ? 'Pompa cyrkulacyjna' : 'Pompa ładująca c.w.u.' };
  state.tab = 'calc'; state.calc = 'pump'; state.screen = 'calc';
  state.ktPompa = zlecenie;
  saveCalcValues(); render(true);
  toast(rodzaj === 'cyrk' ? 'Wpisz długość rur cyrkulacji i średnicę, potem „Zapisz pompę w schemacie”.' : 'Moc i temperatury są już wpisane ze schematu. Uzupełnij długość obiegu i średnicę rury, potem „Zapisz pompę w schemacie”.');
}
document.addEventListener('click', e => {
  const b = e.target.closest && e.target.closest('[data-ktzapiszpompe]');
  if (!b || !state.ktPompa || !state.pompaWynik) return;
  const t = state.ktPompa, w = state.pompaWynik;
  const kot = CALCS.find(c => c.id === 'kotlownia'); const kv = getValues(kot, activeMode(kot));
  if (t.rodzaj === 'ob') {
    const o = (kv.ob || [])[t.i]; if (!o) return;
    o.hP = Math.round(w.H * 100) / 100; o.qP = Math.round(w.q * 1000) / 1000; o.hPz = 'pump';
  } else kv[t.rodzaj === 'kotl' ? 'pKotl' : t.rodzaj === 'cyrk' ? 'pCyrk' : 'pCwu'] = { q: Math.round(w.q * 1000) / 1000, H: Math.round(w.H * 100) / 100 };
  state.tab = 'calc'; state.calc = 'kotlownia'; state.screen = 'calc';
  saveCalcValues(); render(true);
  toast('Zapisano w schemacie: ' + t.nazwa + ' — ' + ktKlasaPompy(w.q, w.H) + ', ' + fmt(w.H, 1) + ' m przy ' + fmt(w.q, 2) + ' m³/h.');
});

/* ---------- rejestracja kalkulatora ---------- */
ICO.minus = '<path d="M5 12h14"/>';
ICO.pelny = '<path d="M9 4H4v5M15 4h5v5M15 20h5v-5M9 20H4v-5"/>';
ICO.kotlownia = '<rect x="3" y="4" width="7" height="9" rx="1.5"/><path d="M10 6.5h4.5M10 10.5h4.5"/><rect x="14.5" y="4" width="3" height="12" rx="1"/><path d="M17.5 7H21M17.5 13H21M6.5 13v4.5h8"/>';

CALCS.push({
  id: 'kotlownia', cat: 'pumps', icon: 'kotlownia',
  title: 'Schemat kotłowni',
  desc: 'Kreator schematu c.o. i c.w.u. z listą elementów',
  sub: 'Źródło, c.w.u. i obiegi — ściąga do montażu',
  cards: [
    { title: 'Źródło ciepła', icon: 'fire', fields: [
      { k: 'zr', type: 'select', label: 'Źródło', def: 'k1', options: [
        { value: 'k1', label: 'Kocioł gazowy kondensacyjny — jednofunkcyjny' },
        { value: 'k2', label: 'Kocioł gazowy kondensacyjny — dwufunkcyjny' },
        { value: 'pc', label: 'Pompa ciepła powietrze–woda (monoblok)' },
        { value: 'pcs', label: 'Pompa ciepła powietrze–woda (split)' },
        { value: 'pel', label: 'Kocioł na pellet (z podajnikiem)' },
        { value: 'weg', label: 'Kocioł węglowy — retortowy' },
        { value: 'drew', label: 'Kocioł zgazowujący drewno' }] },
    ]},
    { title: 'Układ', icon: 'gauge', fields: [
      { k: 'uklad', type: 'seg', def: 'zam', options: [{ value: 'zam', label: 'Zamknięty' }, { value: 'otw', label: 'Otwarty' }],
        when: v => v.zr === 'pel' || v.zr === 'weg' || v.zr === 'drew' },
      { k: 'wym', type: 'seg', def: 'nie',
        options: [{ value: 'nie', label: 'Bez wymiennika' }, { value: 'tak', label: 'Wymiennik płytowy' }],
        when: v => v.zr === 'k1' || v.zr === 'k2' },
      { k: 'ochr', type: 'select', label: 'Ochrona powrotu kotła', def: 'term', options: [
        { value: 'term', label: 'Zawór termostatyczny + pompa kotłowa' },
        { value: 'ladd', label: 'Zespół ładujący (laddomat)' }],
        when: v => v.zr === 'pel' || v.zr === 'weg' || v.zr === 'drew' },
    ]},
    { title: 'Ciepła woda (c.w.u.)', icon: 'drop', fields: [
      { k: 'cwu', type: 'seg', def: 'zas', options: [{ value: 'zas', label: 'Zasobnik' }, { value: 'brak', label: 'Bez c.w.u.' }],
        when: v => v.zr !== 'k2' },
      { k: 'cwuZ', type: 'select', label: 'Ładowanie zasobnika', def: 'kot',
        options: [{ value: 'kot', label: 'Z kotła — przed buforem' }, { value: 'buf', label: 'Z bufora — góra bufora, powrót na dół' }],
        when: v => v.cwu === 'zas' && !!KT_STALE[v.zr] && ktKonfig(v).rozdz === 'buf' },
      { k: 'zasL', type: 'select', label: 'Pojemność zasobnika', def: 200,
        options: [100, 120, 150, 200, 250, 300, 400, 500].map(x => ({ value: x, label: x + ' l' })),
        when: v => v.zr !== 'k2' && v.cwu === 'zas' },
      { k: 'prio', type: 'seg', def: 'tak', options: [{ value: 'tak', label: 'Z priorytetem c.w.u.' }, { value: 'nie', label: 'Bez priorytetu' }],
        when: v => v.zr === 'k1' && v.cwu === 'zas' },
      { k: 'cyrk', type: 'seg', def: 'nie', options: [{ value: 'nie', label: 'Bez cyrkulacji' }, { value: 'tak', label: 'Z cyrkulacją' }],
        when: v => v.zr !== 'k2' && v.cwu === 'zas' },
    ]},
    /* Obiegi grzewcze nie są wpisywane w kreatorze — przyjdą z części
       projektu (grzejniki, podłogówka). Tu tylko sama kotłownia. */
    { title: 'Sprzęgło / bufor', icon: 'layers', fields: [
      { k: 'sep', type: 'select', label: 'Sprzęgło / bufor', def: 'auto',
        when: v => !((v.zr === 'k1' || v.zr === 'k2') && v.wym === 'tak'), options: [
        { value: 'auto', label: 'Dobierz automatycznie' },
        { value: 'brak', label: 'Bez sprzęgła i bufora' },
        { value: 'sprz', label: 'Sprzęgło hydrauliczne' },
        { value: 'buf', label: 'Bufor' }] },
      { k: 'bufy', type: 'seg', def: 1, options: [{ value: 1, label: 'Jeden bufor' }, { value: 2, label: 'Dwa bufory równolegle' }],
        when: v => ktKonfig(v).rozdz === 'buf' },
    ]},
    { title: 'Rury w kotłowni', icon: 'pipe', fields: [
      { k: 'ktKr', type: 'select', label: 'Króćce kotła (zasilanie i powrót)', def: 'auto',
        options: [{ value: 'auto', label: 'Typowe dla źródła (gaz 3/4", PC 1", stałe 5/4")' }]
          .concat(PRZYLACZA_KOTLA.map(x => ({ value: x[0], label: x[1] }))) },
    ]},
  ],
  tip: 'Przy kotle na paliwo stałe schemat pokazuje też ochronę powrotu i wężownicę schładzającą — bez nich układu zamkniętego nie wolno zrobić. Schemat poglądowy do montażu: pokazuje kolejność i miejsce elementów, nie zastępuje projektu ani instrukcji producenta. Średnice policzysz w kalkulatorach „Ogrzewanie grzejnikowe” i „Ogrzewanie podłogowe”.',
  compute(v) {
    // kreator otwarty z menu (bez projektu) pokazuje samą kotłownię, bez obiegów
    const zProj = !!v._zProjektu;    // podgląd w projekcie (Biuro) — bez paska i bez zapisu
    if (!zProj && !(state.projAkt && state.projAkt.kotlownia) && (v.ob || []).length) v = Object.assign({}, v, { ob: [] });
    const k = ktKonfig(v);
    state.ktPompa = null;           // powrót do schematu kończy dobór pompy „na zlecenie” schematu
    const { rys, el, dod, D } = ktSchemat(k);
    state.ktRys = rys;              // do podglądu na pełnym ekranie
    const nazwaZr = { k1: 'Kocioł 1F', k2: 'Kocioł 2F', pc: 'Pompa ciepła (monoblok)', pcs: 'Pompa ciepła (split)',
      pel: 'Kocioł na pellet', weg: 'Kocioł węglowy', drew: 'Zgazowanie drewna' }[k.zr];
    const nazwaRozdz = { brak: '', sprz: '+ sprzęgło', buf: '+ bufor', wym: '+ wymiennik' }[k.rozdz];
    const opis = [].concat(k.stale ? [k.otw ? 'układ otwarty' : 'układ zamknięty'] : [],
      k.wym ? ['stara instalacja otwarta'] : [],
      k.cwu === 'zas' ? 'zasobnik c.w.u.' : k.cwu === 'przep' ? 'c.w.u. przepływowo' : 'bez c.w.u.',
      k.obiegi.length === 0 ? 'obiegi dojdą z projektu' : k.obiegi.length === 1 ? '1 obieg' : k.obiegi.length + ' obiegi');
    if (v.sep === 'auto' && (k.rozdz === 'sprz' || k.rozdz === 'buf')) opis.push(k.rozdz === 'sprz' ? 'sprzęgło dobrane automatycznie' : 'bufor dobrany automatycznie');
    const uwagi = ktUwagi(k);
    const leg = [[KT_KOL.zas, 'zasilanie, c.w.u.'], [KT_KOL.pow, 'powrót'], [KT_KOL.zw, 'zimna woda']]
      .concat(k.cyrk ? [[KT_KOL.cyrk, 'cyrkulacja']] : []);
    const extra = (typeof ktPasekProjektu === 'function' && !zProj ? ktPasekProjektu(v) : '')
      + `<div class="subhead">Schemat — przesuń w bok, żeby zobaczyć całość</div>
      <div class="sch-leg">${leg.map(l => `<span><i style="background:${l[0]}"></i>${esc(l[1])}</span>`).join('')}</div>
      <div class="sch-plot kt-plot">${rys}</div>
      <button class="btn2" style="width:100%;margin-top:10px" data-ktfull>${svg('pelny')}Pełny ekran</button>
      <div class="subhead">Elementy — numery jak na schemacie</div>
      <ol class="kt-lista">${el.map(e => `<li><span class="kt-n">${e[0]}</span><div><b>${esc(e[1])}</b><p>${esc(e[2])}</p></div></li>`).join('')}</ol>`
      + (dod.length ? `<div class="subhead">Warto dołożyć</div><ol class="kt-lista kt-lista--dod">${dod.map(e => `<li><span class="kt-n">+</span><div><b>${esc(e[0])}</b><p>${esc(e[1])}</p></div></li>`).join('')}</ol>` : '');
    const wyniki = [{ label: 'Układ kotłowni', icon: 'kotlownia', value: nazwaZr, unit: nazwaRozdz, foot: opis.join(' · ') }];
    let rows;
    const rows0 = k.obiegi.map((ob, i) => { const nz = k.nazwyOb[i];
      return (ob[0] === 'g' ? 'grzejniki' : 'podłogówka') + (nz.nazwa ? ' — ' + nz.nazwa : nz.nr ? ' ' + nz.nr : ''); });
    if (D) {
      wyniki.push({ label: k.pc ? 'Moc pompy ciepła' : 'Moc kotła', icon: 'fire', value: '≈ ' + D.pDob, unit: 'kW',
        foot: D.opisP + (k.gaz ? ' Najbliższa typowa moc kotła.' : '') });
      if (D.vb) wyniki.push({ label: D.vbN === 2 ? 'Bufory' : 'Pojemność bufora', icon: 'drop', value: D.vbDob, unit: 'l',
        foot: D.opisB + ' Wychodzi ' + fmt(D.vb, 0) + ' l' + (D.vbN === 2 ? ' — podzielone na dwa zbiorniki połączone równolegle, każdy do najbliższej typowej pojemności.'
          : D.vb > +D.vbDob ? ' — więcej niż największy typowy zbiornik (' + D.vbDob + ' l). Wybierz w formularzu „Dwa bufory równolegle”.'
          : ', zaokrąglone do najbliższej typowej pojemności' + (k.zr === 'drew' ? ' (w dół najwyżej o 5%, bo 55 l/kW to minimum z normy).' : '.') + (D.vb > 1500 ? ' To duży zbiornik — sprawdź, czy wejdzie do kotłowni; można też dać dwa mniejsze („Dwa bufory równolegle”).' : '')) });
      if (k.rozdz === 'sprz') wyniki.push({ label: 'Sprzęgło hydrauliczne', icon: 'pipe', value: 'do ' + fmt(D.dn[2], 1), unit: 'm³/h · ' + D.dn[1],
        foot: 'Dobierasz na większy z przepływów: kocioł ' + fmt(D.qZr, 2) + ' m³/h (Δt ' + D.dtZr + ' K), instalacja ' + fmt(D.qIn, 2) + ' m³/h. Liczy się ' + fmt(D.qMax, 2) + ' m³/h. Korpus ok. Ø' + D.dSprz + ' mm (zasada 3 × średnica przyłącza), żeby woda płynęła w nim wolno — tylko wtedy sprzęgło rozdziela obiegi, odpowietrza i odmula. Króćce w rozstawie wg producenta.' });
      if (D.vb && D.wym) wyniki.push({ label: D.vbN === 2 ? 'Wymiary bufora (każdy)' : 'Wymiary bufora', icon: 'ruler', small: true,
        value: 'Ø' + D.wym[0] + ' × ' + D.wym[1], unit: 'mm',
        foot: 'Typowo, bez izolacji — u różnych producentów różni się o kilka cm. Z izolacją ok. Ø' + (D.wym[0] + 100) + ' mm. Sprawdź wysokość kotłowni (z odpowietrznikiem i zapasem ok. ' + (D.wym[1] + 150) + ' mm) i czy wejdzie w drzwi. Przyłącza ' + D.dnBuf[1] + ' przy przepływie ' + fmt(D.vbN === 2 ? D.qMax / 2 : D.qMax, 2) + ' m³/h.' });
      if (D.nac) wyniki.push({ label: 'Naczynie wzbiorcze c.o.', icon: 'tank',
        value: k.gaz ? (D.nacDod ? '+ ' + D.nacDod : 'fabryczne') : String(D.nac.rec), unit: k.gaz ? (D.nacDod ? 'l obok fabrycznego' : '') : 'l',
        foot: 'Zład ok. ' + D.zlad + ' l' + (k.wym ? ' (tylko strona kotła: kocioł, wymiennik, wężownica)' : ' (obiegi ' + fmt(D.vObiegi, 0) + ' l'
          + (D.vBufory ? ', bufor ' + D.vBufory + ' l' : '') + ', źródło ' + D.vZrodla + ' l' + (D.vWez ? ', wężownica ' + D.vWez + ' l' : '') + ', rury w kotłowni)')
          + '. Przy ' + D.tMax + ' °C, zawór ' + fmt(D.pw, 1) + ' bar, p₀ ' + fmt(D.p0, 1) + ' bar (instalacja ok. 8 m wysokości) wychodzi ' + fmt(D.nac.vn, 1) + ' l'
          + (k.gaz ? (D.nacDod ? ' — fabryczne ' + D.nacFabr + ' l w kotle nie wystarczy, dołóż drugie na powrocie.' : ' — fabryczne ' + D.nacFabr + ' l w kotle wystarczy.')
            : k.pc ? '. Jeśli pompa ma naczynie w środku, odejmij jego pojemność.' : '.')
          + ' Zład jest szacunkiem z mocy — dokładnie policzysz w kalkulatorze „Naczynie wzbiorcze”.' });
      const listaP = D.pompy.map((pp, i) => pp ? { ...pp, nazwa: 'Obieg: ' + rows0[i] } : null).filter(Boolean).concat(D.pompyZr);
      if (listaP.length) wyniki.push({ label: 'Pompy', icon: 'gauge', value: String(listaP.length), unit: listaP.length === 1 ? 'pompa' : listaP.length < 5 ? 'pompy' : 'pomp',
        foot: listaP.map(pp => '• ' + pp.nazwa + ': ' + (pp.kl === 'cyrkulacyjna' ? (pp.zKalk ? 'pompa cyrkulacyjna do wody pitnej, ' + fmt(pp.q, 2) + ' m³/h przy ' + fmt(pp.H, 1) + ' m (z kalkulatora)' : 'pompa cyrkulacyjna do wody pitnej, ok. 0,2 m³/h przy 1–1,5 m — dotknij jej na schemacie, żeby dobrać dokładnie')
            : ktOpisPompy(pp.kl) + '. Nastaw ok. ' + fmt(pp.H, 1) + ' m przy ' + fmt(pp.q, 2) + ' m³/h') + (pp.szac ? ' (szacunek)' : '')).join('\n')
          + '\nOznaczenie pompy: pierwsza liczba to przyłącze (25 = rura 1″), druga to maksymalna wysokość podnoszenia w decymetrach (60 = 6 m). Dobrane z zapasem, żeby pompa pracowała w środku zakresu. Bierz pompę elektroniczną i ustaw tryb stałej różnicy ciśnień na podaną wysokość. „Szacunek” = typowe opory domu. Dotknij pompy na schemacie (pomarańczowe kółko) — przejdziesz do kalkulatora „Dobór pompy” z wpisanymi danymi i zapiszesz dokładny wynik. Zielone kółko = pompa już dobrana z kalkulatora.'
          + (!D.maPompy ? '' : k.gaz && k.rozdz !== 'brak' ? ' Pompa w kotle obsługuje tylko obieg kotła do sprzęgła.' : '') });
      else if (!D.maPompy && !k.stale) wyniki.push({ label: 'Pompy', icon: 'gauge', small: true, value: 'w źródle', unit: '',
        foot: 'Jeden obieg bez sprzęgła — wodę tłoczy pompa wbudowana w ' + (k.pc ? 'pompę ciepła' : 'kocioł') + '. Sprawdź w DTR, czy jej dyspozycyjna wysokość podnoszenia wystarczy na instalację.' });
      if (D.vOtw) wyniki.push({ label: 'Naczynie otwarte', icon: 'tank', small: true, value: '≥ ' + D.vOtw, unit: 'l',
        foot: 'Minimum 4% zładu (ok. ' + D.zlad + ' l). Ustaw w najwyższym punkcie, z rurą bezpieczeństwa, wzbiorczą i przelewem.' });
      if (D.nacCwu) wyniki.push({ label: 'Naczynie c.w.u.', icon: 'tank', small: true, value: String(D.nacCwu.rec), unit: 'l',
        foot: 'Zasobnik ' + D.V + ' l, woda do 60 °C, reduktor ok. 4 bar (p₀ naczynia 3,5 bar), zawór 6 bar — wychodzi ' + fmt(D.nacCwu.vn, 1) + ' l. Naczynie do wody pitnej (białe lub niebieskie).' });
      if (D.V) wyniki.push({ label: 'Nagrzanie zasobnika ' + D.V + ' l', icon: 'thermo', small: true, value: '≈ ' + fmt(D.tNagrz, 0), unit: 'min',
        foot: 'Od 10 do 55 °C potrzeba ' + fmt(D.eCwu, 1) + ' kWh.' + (k.pc ? ' Przy pompie ciepła ogranicza to też powierzchnia wężownicy (ok. 1 kW na 50 l) — sprawdź w DTR zasobnika.' : k.stale ? ' Przy kotle na paliwo stałe zakładamy pełną moc kotła w czasie palenia.' : '') });
      rows = k.obiegi.map((ob, i) => {
        const nz = k.nazwyOb[i];
        const n = (ob[0] === 'g' ? 'Grzejniki' : 'Podłogówka') + (nz.nazwa ? ' — ' + nz.nazwa : nz.nr ? ' ' + nz.nr : '');
        const zv = D.zawory[i];
        return [n, k.kw[i] ? fmt(k.kw[i], 1) + ' kW · ' + fmt(D.prz[i], 2) + ' m³/h (Δt ' + D.dts[i] + ' K)'
          + (zv ? ' · mieszacz Kvs ' + String(zv.kvs).replace('.', ',') + ' ' + zv.pick.dn + ', spadek ' + fmt(zv.dp * 100, 1) + ' kPa' : '') : 'nie wpisano kW'];
      }).concat([['Razem c.o.', fmt(D.qco, 1) + ' kW · ' + fmt(D.prz.reduce((a, b) => a + b, 0), 2) + ' m³/h', 1]]);
      if (k.kw.some(x => !x)) uwagi.unshift('Nie każdy obieg ma wpisane zapotrzebowanie — dobór liczy tylko te z kW.');
      if (D.vb > 1500 && k.bufy !== 2) uwagi.unshift('Bufor wychodzi ' + fmt(D.vb, 0) + ' l — rozważ dwa mniejsze połączone równolegle (opcja „Dwa bufory równolegle” w formularzu).');
    } else {
      wyniki.push(k.obiegi.length
        ? { label: 'Dobór kotła i bufora', icon: 'fire', small: true, value: 'dotknij obiegu', unit: '',
          foot: 'Dotknij grzejników albo podłogówki na schemacie (pomarańczowe „+ kW”) i wpisz zapotrzebowanie. Zasobnik — dotknij, żeby zmienić litraż. Policzę moc źródła, bufor i przepływy.' }
        : { label: 'Dobór kotła i bufora', icon: 'fire', small: true, value: 'po obiegach', unit: '',
          foot: 'Moc źródła, pojemność bufora, naczynia, pompy i średnice rur policzę, gdy w projekcie dojdą obiegi z mocą (grzejniki, podłogówka). Zasobnik — dotknij go na schemacie, żeby zmienić litraż.' });
    }
    return {
      results: wyniki,
      warn: uwagi.length ? uwagi.join(' ') : undefined,
      rows,
      extra,
    };
  },
});

