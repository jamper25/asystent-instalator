#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v node >/dev/null || { echo "Brak Node.js"; exit 1; }
command -v npm >/dev/null || { echo "Brak npm"; exit 1; }
command -v java >/dev/null || { echo "Brak JDK"; exit 1; }
if [ ! -d node_modules ]; then npm install; fi
npx cap sync android
if [ -x android/gradlew ]; then
  (cd android && ./gradlew assembleDebug)
elif command -v gradle >/dev/null; then
  (cd android && gradle assembleDebug)
else
  echo "Nie znaleziono Gradle Wrapper ani Gradle w PATH."
  echo "Otwórz katalog android/ w Android Studio, dodaj Gradle Wrapper i uruchom assembleDebug."
  exit 2
fi
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
