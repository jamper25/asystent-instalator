#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const htmlPath = path.join(root, 'www', 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const errors = [];
const scripts = [...html.matchAll(/<script\b[^>]*\bsrc=["']([^"']+)["']/gi)].map(m => m[1]);
for (const src of scripts) {
  if (/^(https?:)?\/\//i.test(src) || src.startsWith('data:')) continue;
  const file = path.resolve(root, 'www', src.replace(/^\.?\//, ''));
  if (!file.startsWith(path.join(root, 'www') + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    errors.push(`Brak lokalnego skryptu: ${src}`);
  }
}
const localRefs = [...html.matchAll(/\b(?:src|href)=["']([^"']+)["']/gi)].map(m => m[1]);
for (const ref of localRefs) {
  if (/^(https?:)?\/\//i.test(ref) || /^(data:|mailto:|tel:|javascript:|#)/i.test(ref)) continue;
  const clean = ref.split(/[?#]/, 1)[0].replace(/^\.\//, '').replace(/^\//, '');
  if (!clean) continue;
  const file = path.resolve(root, 'www', clean);
  if (!file.startsWith(path.join(root, 'www') + path.sep) || !fs.existsSync(file)) {
    errors.push(`Brak lokalnego zasobu HTML: ${ref}`);
  }
}
const staticIds = [...html.matchAll(/\bid=["']([^"']+)["']/gi)].map(m => m[1]);
const idCounts = new Map();
for (const id of staticIds) idCounts.set(id, (idCounts.get(id) || 0) + 1);
for (const [id, count] of idCounts) if (count > 1) errors.push(`Powielony identyfikator HTML: ${id} (${count} razy)`);
const app = JSON.parse(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8'));
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
if (app.appId !== 'pl.asystentinstalatora.app') errors.push('Niezgodny applicationId w Capacitor.');
if (app.webDir !== 'www') errors.push('webDir Capacitor musi wskazywać www.');
for (const plugin of ['@capacitor/core','@capacitor/android','@capacitor/app','@capacitor/filesystem','@capacitor/local-notifications','@capacitor/share','@capacitor/splash-screen','@capacitor/status-bar']) {
  if (!pkg.dependencies || !pkg.dependencies[plugin]) errors.push(`Brak zależności: ${plugin}`);
}
if (!fs.existsSync(path.join(root, 'www', 'vendor', 'store.js'))) errors.push('Brak lokalnego adaptera vendor/store.js.');
if (scripts.length !== 34) errors.push(`Oczekiwano 34 skryptów aplikacji, znaleziono ${scripts.length}.`);
if (errors.length) {
  console.error('BŁĘDY INTEGRALNOŚCI PROJEKTU:');
  errors.forEach(x => console.error(' - ' + x));
  process.exit(1);
}
console.log(`OK: ${scripts.length} skryptów; ${localRefs.length} lokalnych odwołań HTML; identyfikatory bez kolizji; konfiguracja Capacitor i zależności spójne.`);
