const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawnSync } = require("child_process");
const root = path.join(__dirname, "..");
const order = ["radson.js", "drabinki.js", "data.js", "fonty.js", "pdf.js", "ksztaltki.js", "buderus_catalog.js", "offers.js", "ksef.js", "natywne.js", "engine.js", "dobor_grzejnika.js", "schemat.js", "ui.js", "ui_offers.js", "dopisz.js", "grzejnik_wybor.js", "karta_tresc.js", "polityka_tresc.js", "kopia.js", "ui_settings.js", "ui_assist.js", "conowego.js", "kody_dane.js", "kody_bledow.js", "kotlownia.js", "projekty.js", "projekty_kalk.js", "projekty_zest.js", "projekty_folder.js", "notatnik.js", "pro.js", "boot.js"];
const files = [path.join(root, "www", "vendor", "store.js"), ...order.map(f => path.join(root, "www", "js", f))];
let failed = false;
for (const file of files) {
  if (!fs.existsSync(file)) {
    console.error("MISSING", path.relative(root, file));
    failed = true;
  }
}
if (!failed) {
  const combined = files.map(f => fs.readFileSync(f, "utf8")).join("\n");
  const tmp = path.join(os.tmpdir(), "asystent-inst-syntax-check.js");
  fs.writeFileSync(tmp, combined);
  const r = spawnSync(process.execPath, ["--check", tmp], { encoding: "utf8" });
  if (r.status !== 0) {
    console.error(r.stderr);
    failed = true;
  } else {
    console.log(`OK: ${files.length} skryptów w oryginalnej kolejności; składnia i kolizje deklaracji globalnych poprawne.`);
  }
}
if (failed) process.exit(1);
