# Asystent Instalatora — odzyskany projekt roboczy

Projekt odtworzony z przesłanego APK. To baza do dalszego rozwoju, nie oryginalne repozytorium.

## Struktura
- `www/index.html` — oryginalny dokument UI z zachowanym CSS; skrypty zostały przeniesione do osobnych plików.
- `www/vendor/store.js` — biblioteka zakupowa osadzona w APK.
- `www/js/` — 32 moduły JavaScript wydzielone z oryginalnego skryptu.
- `capacitor.config.json` — konfiguracja Capacitor dla katalogu `www`.
- `capacitor.plugins.json`, `native-bridge.js`, `AndroidManifest.xml` — artefakty odzyskane z APK.
- `docs/` — architektura, inwentaryzacja modułów, model danych i plan rozwoju.

## Uwaga o budowaniu
Szkielet `package.json` zawiera robocze zakresy wersji Capacitor. Nie potwierdzono jeszcze ich zgodności z oryginalnym APK. Przed instalacją zależności i budową Androida trzeba zweryfikować wersję natywnego runtime oraz pluginów. Oryginalny klucz podpisujący nie jest odzyskiwalny z APK.

## Kontrola składni
Po zainstalowaniu Node.js:
```bash
npm install
npm run check:syntax
npm run test:buderus
```

## Uruchomienie podglądu WWW
```bash
npm run serve
```
Następnie otwórz `http://localhost:8080`.

Uwaga: część funkcji wymaga środowiska Capacitor/Android i nie będzie działać w zwykłej przeglądarce.

## Zasady
- Nie nadpisuj oryginalnego APK.
- Nie wprowadzaj zmian w logice obliczeniowej bez testów wzorcowych.
- Nie przechowuj danych klientów w repozytorium Git.
- Ceny zakupu i marże nie mogą być widoczne w ofertach dla klientów.

## Pierwszy dodany moduł
`www/js/buderus_catalog.js` zawiera warstwę danych katalogu Buderus (bez ekranu UI i bez wprowadzonych jeszcze danych katalogowych). Testy obejmują CRUD, wyszukiwanie po SKU, obliczanie brutto, adapter do pozycji oferty, historię cen oraz import/eksport JSON.

## Katalog Buderus — ekran v1
W zakładce **Biuro** znajduje się przycisk **Katalog kotłów Buderus**. Można dodawać i edytować produkty, wyszukiwać po SKU/nazwie, ustawiać ceny, VAT i źródło danych, importować/eksportować katalog JSON oraz dodawać produkt do oferty. Katalog jest pusty, ponieważ nie wprowadzamy niezweryfikowanych produktów ani cen.

Obecny silnik ofert ma jedną stawkę VAT na cały dokument. Dodanie produktu do oferty o innej stawce VAT jest blokowane, aby nie wygenerować błędnego podatku. Obsługa wielu stawek na pozycjach jest osobnym zadaniem dla PDF/KSeF.
