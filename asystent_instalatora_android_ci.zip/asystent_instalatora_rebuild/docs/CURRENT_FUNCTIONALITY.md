# Stan funkcjonalny odzyskanej aplikacji

## Moduły i funkcje widoczne w kodzie
- `engine.js`: wspólne funkcje obliczeniowe, m.in. straty ciepła, przepływy, opory, naczynie przeponowe, podłogówka i gaz.
- `radson.js`, `drabinki.js`, `dobor_grzejnika.js`, `grzejnik_wybor.js`: dane i dobór grzejników.
- `schemat.js`, `kotlownia.js`: schematy i kreator kotłowni.
- `projekty.js`, `projekty_kalk.js`, `projekty_zest.js`, `projekty_folder.js`: projekty, wyniki kalkulatorów i zestawienia.
- `offers.js`, `ui_offers.js`: katalog materiałów/usług, klienci, oferty, podsumowania, generowanie faktury i walidacja danych.
- `pdf.js`: generowanie PDF.
- `ksef.js`: generowanie XML faktury FA(3) — trzeba wykonać osobne testy zgodności i nie traktować samego wygenerowania XML jako potwierdzenia poprawności lub wysłania do KSeF.
- `kopia.js`: eksport i odtwarzanie kopii zapasowej.
- `notatnik.js`: notatki, zdjęcia i przypomnienia.
- `ui_assist.js`, `kody_dane.js`, `kody_bledow.js`: asystent i baza kodów błędów.
- `pro.js`: obsługa uprawnień/abonamentu.

## Istniejący model handlowy — ważne
Kod `offers.js` już zawiera:
- katalog domyślny `DEFAULT_CATALOG` i pozycje użytkownika;
- ustawienia firmy;
- osobne klucze localStorage dla ustawień, katalogu i cen (`ai_ustawienia_v1`, `ai_katalog_v1`, `ai_ceny_v1`);
- listę klientów (`loadKlienci` / `saveKlienci`);
- oferty i pozycje ofert;
- sumowanie materiałów, robocizny, marży i VAT (`offerTotals`);
- utworzenie obiektu faktury (`makeInvoice`);
- walidację danych faktury (`invoiceIssues`).

## Czego nie należy zakładać
Na podstawie tego kodu nie ma jeszcze potwierdzonego, kompletnego procesu: zamówienie → płatności częściowe → dostawa → ruchy magazynowe → wydanie → faktura → zamknięcie realizacji. To będzie nowy zakres rozbudowy.
Nie ma też potwierdzonej, ustrukturyzowanej bazy produktów Buderus ani zweryfikowanych reguł kompatybilności. Obecny katalog jest głównie katalogiem materiałów instalacyjnych i usług.

## Wniosek techniczny
Nie budujemy modułu ofert od zera. Rozszerzymy istniejące `offers.js` i `ui_offers.js` poprzez kontrolowaną migrację danych oraz nowe encje sprzedażowe, zachowując kompatybilność ze starymi ofertami.

## Pierwszy nowy fundament — katalog Buderus
Dodano izolowany moduł `buderus_catalog.js` z wersjonowanym magazynem danych w localStorage, kartą produktu, kategoriami, źródłem danych (oficjalne/ręczne/import), cenami zakupu i sprzedaży, historią zmian cen, importem/eksportem JSON oraz adapterem do istniejących pozycji ofert. Nie dodano jeszcze ekranu UI ani rzeczywistych danych produktowych. Ceny i kompatybilność należy wprowadzić z potwierdzonych źródeł Buderus.

## Katalog Buderus — ekran v1
- Dodano wejście do katalogu z zakładki Biuro.
- Lista produktów z wyszukiwaniem po nazwie i symbolu SKU.
- Formularz dodawania i edycji: symbol, nazwa, kategoria, opis, źródło, data źródła, aktywność, ceny katalogowe/zakupowe/sprzedażowe i VAT.
- Widoczne są ceny zakupu i sprzedaży netto oraz brutto sprzedaży; to ekran wewnętrzny, nie dokument klienta.
- Dodano import i eksport katalogu w formacie JSON.
- Produkt można dodać do istniejącej oferty albo utworzyć nową ofertę.
- Ochrona podatkowa: obecny silnik ofert obsługuje jedną stawkę VAT na cały dokument. Jeśli stawka produktu różni się od stawki istniejącej oferty, dodanie jest blokowane. Przy pustej ofercie stawka jest ustawiana z produktu. Obsługa wielu stawek VAT w jednym dokumencie wymaga osobnej przebudowy `docLines`, PDF i generatora KSeF.
- Nie dodano rzeczywistych pozycji katalogowych Buderus ani cen; katalog startuje pusty.


## Konfigurator zestawów Buderus

Dodano ekran konfiguratora korzystający z produktów zapisanych w katalogu. Użytkownik może dobrać po jednym produkcie z kategorii: kocioł, zasobnik CWU, regulator, moduł, czujnik, hydraulika, system kominowy i akcesoria. Konfigurator pokazuje wybrane pozycje, sumę netto i brutto, o ile wszystkie pozycje mają ceny i wspólną stawkę VAT. Można utworzyć nową ofertę z wybranego zestawu. Kompatybilność nie jest automatycznie potwierdzana — należy ją zweryfikować w dokumentacji producenta.

## Magazyn i zakupy

Dodano lokalny rejestr kart towarowych: SKU, nazwa, ilość, stan minimalny, cena zakupu netto, VAT, dostawca, lokalizacja i uwagi. Dostępne są ruchy: przyjęcie, wydanie oraz korekta stanu. Każdy ruch zapisuje datę, kontrahenta/powód, numer dokumentu, ilość oraz stan przed i po operacji. Wydanie blokowane jest, gdy spowodowałoby ujemny stan. Widok pokazuje orientacyjną wartość magazynu netto i towary osiągające stan minimalny. Dane są lokalne na urządzeniu i nie są jeszcze synchronizowane między urządzeniami.


## Integracja sprzedaży z magazynem
- Przy przenoszeniu zaakceptowanej oferty do rejestru sprzedaży zachowywane są pozycje jako dane strukturalne (nazwa, SKU jeśli dostępne, ilość, jednostka i cena netto).
- W rejestrze sprzedaży dostępna jest jawna akcja „Wydaj z magazynu”. Nie zmniejsza ona stanu automatycznie przy rejestracji sprzedaży.
- Wydanie dopasowuje pozycje wyłącznie po dokładnym SKU lub dokładnej nazwie karty magazynowej. Brak dopasowania lub niewystarczający stan blokuje całą operację.
- Wydanie zapisuje ruchy magazynowe typu „out” powiązane z identyfikatorem sprzedaży i blokuje ponowne wydanie dla tego wpisu.
- Wpisy ręczne i starsze wpisy bez strukturalnych pozycji nie są automatycznie wydawane. Marża nie jest jeszcze raportowana jako pełna; wymaga osobnego rozliczenia kosztów pozycji i robocizny.


## Koszty i szacowana marża sprzedaży
- Rejestr sprzedaży przechowuje przychód netto oraz ręcznie uzupełniany koszt robocizny netto.
- Przy wydaniu magazynowym zapisywana jest kopia jednostkowej ceny zakupu netto z chwili wydania, dzięki czemu późniejsza zmiana ceny na karcie towaru nie zmienia historycznego kosztu tej sprzedaży.
- Karta sprzedaży pokazuje koszt materiałów, koszt robocizny i szacowaną marżę netto.
- Marża jest oznaczana jako niepełna, dopóki nie ma przychodu netto oraz wydania pozycji magazynowych. To szacunek operacyjny, nie księgowy wynik finansowy.


## Raport rentowności i zakupów
- Rejestr sprzedaży pokazuje łączną marżę tylko z wpisów oznaczonych jako kompletne oraz liczbę wpisów z niepełnymi danymi.
- Magazyn pokazuje sumę wartości przyjęć zakupowych w bieżącym miesiącu oraz łącznie.
- Wartość przyjęcia jest zapisywana według aktualnej ceny zakupu netto w chwili rejestracji ruchu. Starsze ruchy bez zapisanej ceny korzystają z bieżącej ceny karty i mogą być mniej dokładne.


## Rejestr dokumentów zakupowych
- Rejestr przechowuje dostawcę, numer, datę, kwoty netto/VAT/brutto, termin płatności, status i uwagi.
- Duplikaty są wykrywane po dostawcy i numerze dokumentu.
- Dane są lokalne; skany PDF i księgowanie nie są jeszcze obsługiwane.

- Dokument zakupowy może mieć lokalny załącznik PDF/JPG/PNG do 2 MB; plik jest przechowywany jako data URL w lokalnym rejestrze i dostępny do otwarcia/pobrania na liście dokumentów.

- Dokumenty zakupowe obsługują rejestrowanie wielu wpłat częściowych z datą, historię wpłat, automatyczny status częściowo opłacona/opłacona i saldo do zapłaty. Wpłata większa niż saldo jest blokowana.

- Rejestr dokumentów zakupowych umożliwia edycję i usuwanie dokumentu (z potwierdzeniem) oraz eksport CSV z danymi dokumentów i historią wpłat.

- Status płatności dokumentu zakupowego jest wyliczany automatycznie z sumy wpłat i kwoty brutto: nieopłacona, częściowo opłacona albo opłacona. Formularz nie pozwala już ręcznie ustawić niespójnego statusu.

- Dokumenty zakupowe: pełna kopia zapasowa JSON obejmująca dokumenty, załączniki i historię wpłat; przywracanie kopii z walidacją formatu i potwierdzeniem zastąpienia rejestru.

- Główna kopia zapasowa aplikacji rozszerzona o rejestr sprzedaży, karty i ruchy magazynowe oraz dokumenty zakupowe z załącznikami i historią wpłat. Przy przywracaniu odświeżane są również aktywne stany tych modułów. Zdjęcia z osobnej bazy IndexedDB pozostają poza zakresem tej kopii.

- Główna kopia zapasowa obejmuje również zdjęcia notatek z IndexedDB. Przywracanie kopii zastępuje bazę zdjęć zawartością archiwum; operacja cofnięcia przywraca poprzedni zestaw zdjęć, jeśli przeglądarka udostępnia IndexedDB.

- CRM klienta: karta klienta zawiera chronologiczną historię serwisów, przeglądów, montaży, wycen, kontaktów i reklamacji z urządzeniem, opisem prac i opcjonalnym kosztem. Można dodawać i usuwać wpisy. Widok klienta pokazuje również powiązane rekordy sprzedaży. Historia jest przechowywana w rekordzie klienta i wchodzi do głównej kopii zapasowej.
- Baza kodów błędów odzyskana z aplikacji: 4 720 wpisów dla kotłów i pomp ciepła, w tym wspólna grupa Bosch/Buderus/Junkers oraz osobne serie producentów.

- CRM klienta rozszerzony o ewidencję urządzeń i instalacji: producent, model, numer seryjny, miejsce montażu, data montażu, koniec gwarancji i uwagi. Wpisy są przypisane do klienta i objęte kopią zapasową; usunięcie urządzenia nie usuwa historii serwisowej.

- Kartoteka urządzeń CRM ma pole następnego przeglądu. Przy dodaniu urządzenia z przyszłą datą aplikacja próbuje zaplanować lokalne powiadomienie Android (jeśli plugin Local Notifications i uprawnienia są dostępne); bez pluginu termin pozostaje zapisany w karcie klienta.

## Terminarz płatności dostawcom
- Ekran dokumentów zakupowych pokazuje osobne podsumowanie zaległych płatności oraz dokumentów z terminem przypadającym w ciągu najbliższych 7 dni.
- W obu sekcjach widoczna jest nazwa dostawcy, numer dokumentu, termin i pozostała kwota do zapłaty. Uwzględniane są wpłaty częściowe, więc zestawienie pokazuje saldo, a nie pierwotną wartość faktury.
- Sekcje dotyczą wyłącznie dokumentów z dodatnim saldem i ustawionym terminem płatności. To lokalne przypomnienie w aplikacji, bez automatycznych powiadomień.

## Zakres poza projektem
- Moduł serwisowy, historia przeglądów i terminarz serwisu nie są rozwijane w Asystencie Instalatora; obsługuje je osobna aplikacja.


## Rozliczenia sprzedaży — wpłaty częściowe
- Rejestr sprzedaży obsługuje teraz wiele wpłat dla jednego zamówienia/sprzedaży; każda wpłata zapisuje kwotę i datę.
- Karta sprzedaży pokazuje łączną kwotę zapłaconą, saldo pozostałe do zapłaty oraz historię wpłat.
- Aplikacja blokuje wpłatę większą niż pozostałe saldo; po pełnym rozliczeniu ukrywa formularz kolejnej wpłaty i pokazuje status rozliczenia.
- Podsumowanie rejestru pokazuje łączne saldo należności oraz sumę zaległych płatności według terminu płatności.
- Zachowano zgodność ze starszymi wpisami: wcześniejsza wartość pola `paid` jest traktowana jako kwota już zapłacona, a nowe wpłaty trafiają do tablicy `payments`.
- Funkcja działa lokalnie na urządzeniu; nie jest integracją bankową ani automatycznym potwierdzeniem przelewu.

### Korekta wpłat do dokumentów zakupowych
- W historii wpłat przy każdym dokumencie można usunąć błędnie zarejestrowaną wpłatę.
- Usunięcie wymaga potwierdzenia; saldo pozostałe i status dokumentu są przeliczane ponownie.
- Korekta dotyczy wybranej wpłaty, bez kasowania całego dokumentu zakupowego.

### Korekta wpłat od klientów
- Historia wpłat w rejestrze sprzedaży umożliwia usunięcie pojedynczej błędnej wpłaty.
- Operacja wymaga potwierdzenia i natychmiast przelicza saldo klienta; wpis sprzedaży i pozostałe wpłaty pozostają bez zmian.

### Eksport rejestru sprzedaży i rentowności
- Rejestr sprzedaży ma eksport CSV zgodny z Excelem, obejmujący klienta, inwestycję, datę, kwoty brutto/netto, koszt materiałów i robocizny, szacowaną marżę, kompletność danych, wpłaty, saldo, termin płatności, dostawę i dokument sprzedaży.
- Marża jest eksportowana tylko dla wpisów, dla których istnieją dane pozwalające ją oszacować; pozostałe rekordy są oznaczone jako niepełne.

### Kopia zapasowa rejestru sprzedaży
- Rejestr sprzedaży można wyeksportować do JSON i przywrócić z wcześniej utworzonej kopii.
- Kopia obejmuje wpisy sprzedaży, historię wpłat, dane dostawy, pozycje powiązane z wydaniami magazynowymi i dane używane do szacowania marży.
- Przywrócenie wymaga potwierdzenia i zastępuje bieżący rejestr; format i podstawowa struktura rekordów są sprawdzane przed importem.

### Kontrola integralności projektu i gotowości Android
- Dodano `tools/check-project-integrity.js`, który sprawdza lokalne odwołania do 34 skryptów, podstawową konfigurację Capacitor oraz wymagane zależności.
- Dodano `npm run check:integrity` i zbiorcze `npm test`.
- Udokumentowano wymagania kompilacji Android i jawnie wskazano brak oryginalnego projektu Gradle, Android SDK i oryginalnego klucza podpisującego w środowisku odzyskiwania.

### Odtworzony szkielet Android
- Dodano katalog `android/` z konfiguracją Gradle dla Capacitor 6, modułem `app`, `MainActivity`, manifestem, podstawowymi zasobami i modułem zgodności Cordova.
- Dodano `tools/build-android.sh` do synchronizacji Capacitor i budowania APK debug w środowisku z Android SDK/Gradle.
- Kompilacja nie została wykonana: środowisko nie ma Android SDK ani Gradle, a połączenie z rejestrem npm jest niedostępne. Szkielet wymaga synchronizacji pluginów przez `npx cap sync android` oraz weryfikacji w Android Studio.
