# Architektura odzyskanego projektu

## Co potwierdza APK
- Aplikacja ma identyfikator `pl.asystentinstalatora.app` i nazwę `Asystent Instalatora`.
- Interfejs jest dostarczany jako lokalna aplikacja webowa uruchamiana przez Android WebView/Capacitor.
- Kod użytkowy był osadzony w jednym dużym skrypcie; APK zawiera 32 jawne znaczniki plików `.js`.
- Pierwszy skrypt to biblioteka `capacitor-plugin-cdv-purchase` 13.20.0.
- Zarejestrowane pluginy: App, Filesystem, Local Notifications, Share, Splash Screen, Status Bar i CDV Purchase.
- Główna logika HTML/CSS/JS jest lokalna. W zidentyfikowanym kodzie jest żądanie do `https://wl-api.mf.gov.pl` w celu wyszukania podatnika po NIP.
- Ustawienia, katalog, ceny i inne rekordy korzystają z `localStorage`; zdjęcia notatek mają bazę IndexedDB `asystent_zdjecia`.

## Układ odzyskanego projektu
- `www/index.html` — odtworzony dokument aplikacji; style pozostawiono w oryginalnej postaci.
- `www/vendor/store.js` — skrypt biblioteki zakupowej.
- `www/js/*.js` — 32 moduły wydzielone w kolejności oryginalnego ładowania.
- `capacitor.config.json` — konfiguracja Capacitor dostosowana do katalogu `www`.
- `capacitor.plugins.json`, `native-bridge.js`, `AndroidManifest.xml` — odzyskane artefakty.

## Ograniczenia
To nie jest oryginalne repozytorium źródłowe. APK nie dostarcza oryginalnych plików Gradle, `package-lock.json`, historii Git, certyfikatu do podpisywania przyszłych aktualizacji ani pełnych metadanych procesu budowania. Wersje Capacitor w `package.json` są szkieletem roboczym i muszą zostać zweryfikowane podczas odtwarzania środowiska Android. Nie należy publikować aplikacji ani aktualizować istniejącej instalacji, dopóki nie zostanie potwierdzona zgodność identyfikatora, podpisu i migracji danych.

## Zasady dalszej pracy
1. Zachować oryginalny APK jako niezmienny punkt odniesienia.
2. Najpierw uruchomić i porównać odzyskany interfejs.
3. Dodać testy regresji dla obliczeń i eksportu danych.
4. Wprowadzać nową bazę danych przez migracje, bez kasowania `localStorage`.
5. Zmiany modułów wykonywać małymi commitami Git.
