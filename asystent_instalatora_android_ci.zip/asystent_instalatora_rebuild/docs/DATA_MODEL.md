# Proponowany model danych — docelowy

Model jest projektem docelowym, nie opisem istniejącej bazy APK.

## Główne encje
- `clients`: osoba/firma, NIP, kontakty, adresy.
- `addresses`: adresy klienta, w tym oddzielny adres montażu.
- `products`: producent, symbol, nazwa, kategoria, parametry, aktywność.
- `product_documents`: instrukcje, karty katalogowe, deklaracje.
- `product_compatibility`: jawne relacje zgodności akcesoriów z kotłami.
- `price_lists`: źródło, waluta, data obowiązywania.
- `product_prices`: cena katalogowa, zakupowa, sprzedażowa, VAT, rabat, daty.
- `offers` i `offer_items`: oferta oraz zamrożone dane/ceny pozycji w chwili utworzenia.
- `orders` i `order_items`: zamówienie zaakceptowane na podstawie oferty.
- `payments`: wpłaty, daty, kwoty, metody i powiązania z dokumentami.
- `purchase_documents`: dokumenty zakupowe dostawców.
- `deliveries`: dostawy częściowe/pełne i kontrola zgodności.
- `warehouse_locations`, `stock_balances`, `stock_movements`: magazyn i historia ruchów.
- `invoices`: dokumenty sprzedaży/zakupu, status KSeF i identyfikatory zewnętrzne.
- `projects`, `service_jobs`, `installed_equipment`: realizacje, serwis i urządzenia u klienta.
- `attachments`: zdjęcia, PDF-y i pliki powiązane z rekordami.

## Zasady integralności
1. Oferta i zamówienie przechowują snapshot nazwy, symbolu, ilości, stawki VAT i cen; późniejsza zmiana katalogu nie zmienia dokumentu.
2. Nie wolno utożsamiać płatności z dostawą ani wydania magazynowego z fakturą.
3. Każdy ruch magazynowy ma typ, datę, ilość, produkt, źródło i dokument powiązany.
4. Usunięcia dokumentów finansowych powinny być zastępowane korektą/anulowaniem zgodnie z zasadami księgowymi, nie cichym kasowaniem.
5. Marża i cena zakupu są danymi wewnętrznymi i nie mogą trafiać do PDF dla klienta.
6. Dane techniczne i kompatybilność Buderus wymagają potwierdzenia w dokumentacji producenta.
7. Import cennika musi mieć źródło, datę, walutę i regułę VAT; nie nadpisuje historii cen.
