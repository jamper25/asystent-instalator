# Plan wykonania

## Faza 0 — odzyskanie i kontrola (bieżąca)
- [x] Wyodrębnienie HTML/CSS/JS z APK.
- [x] Rozdzielenie 32 modułów według znaczników w oryginalnym skrypcie.
- [x] Zachowanie kolejności ładowania.
- [x] Odtworzenie podstawowego szkieletu projektu i konfiguracji.
- [x] Kontrola składni 33 skryptów (biblioteka zakupowa + 32 moduły) w oryginalnej kolejności.
- [ ] Uruchomienie lokalne i porównanie widoków z APK.
- [ ] Zweryfikowanie wersji Capacitor i pluginów.

## Faza 1 — stabilizacja
- Testy regresji kalkulatorów: wartości wzorcowe, jednostki, granice i błędne dane.
- Testy eksportu/importu kopii zapasowej.
- Testy PDF, ofert, KSeF i powiadomień.
- Inwentaryzacja localStorage/IndexedDB i schematów danych.
- Zapisanie przykładowej kopii danych do testów, bez danych osobowych.

## Faza 2 — katalog Buderus
- [x] Izolowana warstwa danych katalogu Buderus (CRUD, ceny, historia, import/eksport JSON).
- [x] Ekran katalogu i edycji produktu.
- [x] Wyszukiwanie SKU/nazwy, import/eksport JSON i dodawanie do oferty.
- [ ] Import CSV/XLSX oraz pobieranie oficjalnych danych producenta po weryfikacji dostępnych źródeł.
- Kategorie i karta produktu.
- Import CSV/XLSX oraz ręczne dodawanie/edycja.
- Dane katalogowe ze źródeł producenta, z oznaczeniem źródła i daty.
- Ceny zakupu i sprzedaży, rabaty, VAT, historia cen.
- Załączniki produktowe.
- Reguły kompatybilności potwierdzane dokumentacją.

## Faza 3 — konfigurator i sprzedaż
- Konfigurator zestawu kotła i akcesoriów.
- Rozbudowa dokumentów do obsługi różnych stawek VAT na pozycjach (obecnie dokument ma jedną stawkę; różne stawki są bezpiecznie blokowane).
- Walidacja zgodności i brakujących elementów.
- Oferta PDF z terminem ważności i warunkami.
- Akceptacja oferty i konwersja do zamówienia.
- Zaliczki, częściowe wpłaty i saldo.
- Dostawy, przyjęcia i wydania magazynowe.
- Faktury i obsługa KSeF po walidacji zgodności ze schemą.

## Faza 4 — CRM, magazyn i serwis
- Klienci, adresy, historia kontaktu.
- Urządzenia zainstalowane u klienta i historia serwisowa.
- Zlecenia, protokoły, zdjęcia i dokumenty.
- Magazyn, rezerwacje i inwentaryzacja.

## Faza 5 — migracja i wydanie
- Migracja starych danych bez utraty danych użytkownika.
- Testy na kopiach i kilku wersjach Androida.
- Testy offline/online.
- Budowa APK, podpisanie własnym kluczem i procedura aktualizacji.


- [x] Podstawowy konfigurator zestawów Buderus z przekazaniem wybranych produktów do nowej oferty.
- [ ] Reguły kompatybilności oparte na zweryfikowanych danych producenta.
- [ ] Możliwość zapisania konfiguracji jako projektu i ponownego otwarcia.
- [ ] Obsługa wielu stawek VAT w jednej ofercie (po przebudowie silnika dokumentów).
- [x] Rejestr magazynowy: karty towarowe, przyjęcia, wydania, korekty i progi minimalne.

## Zakres wyłączony
- Moduł serwisu, terminarz przeglądów i historia czynności serwisowych pozostają poza zakresem Asystenta Instalatora — użytkownik korzysta z osobnej aplikacji.
- Priorytet dalszych prac: CRM handlowy, oferty, katalog Buderus, sprzedaż, magazyn, zakupy, płatności i dokumenty.
