# Status przygotowania wydania Android

## Stan odzyskanego projektu

- Identyfikator aplikacji: `pl.asystentinstalatora.app`.
- Nazwa: `Asystent Instalatora`.
- Aplikacja WWW: katalog `www/`, ładowany przez Capacitor.
- Wersja robocza zależności Capacitor: 6.x.
- Oryginalny projekt Gradle nie został odzyskany z APK.
- Odtworzono katalog `android/` z konfiguracją Gradle, modułem aplikacji, `MainActivity`, manifestem i zasobami bazowymi. Oryginalny wrapper Gradle i konfiguracja podpisywania nie zostały odzyskane.
- JDK 21 jest dostępny w środowisku; `gradle`, Android SDK, `adb` i `sdkmanager` nie są dostępne.
- Pobieranie z npm registry nie działa w tym środowisku (DNS nie rozwiązuje `registry.npmjs.org`), więc zależności nie mogły zostać pobrane i nie wykonano kompilacji.

## Co jest potrzebne do utworzenia APK

1. Środowisko z Node.js/npm, JDK 17 oraz Android SDK (platform-tools, platform SDK i build-tools).
2. Instalacja zależności z `npm install`.
3. Uruchomienie `npx cap sync android`, które uzupełni wygenerowane pliki pluginów w odtworzonym katalogu Android.
4. Otwarcie projektu w Android Studio, kompilacja debug i test na urządzeniu.
5. Osobne skonfigurowanie klucza podpisującego release APK.

## Ważne ograniczenia wydania

- Nowa instalacja może mieć inny podpis niż oryginalna aplikacja. Bez oryginalnego keystore nowa kompilacja nie będzie aktualizacją podpisaną tym samym kluczem.
- Testy Node sprawdzają składnię, integralność zasobów i wybrane funkcje logiki. Nie zastępują testów WebView/Android, uprawnień, powiadomień, eksportu plików ani zakupów w aplikacji.
- Nie deklarować gotowego APK, dopóki nie powstanie artefakt i nie zostanie zainstalowany oraz sprawdzony na urządzeniu.

## Odtworzone pliki Android

- `android/settings.gradle`, `android/build.gradle`, `android/gradle.properties`.
- `android/app/build.gradle`, manifest, `MainActivity.java`, podstawowe style i ikona wektorowa.
- `tools/build-android.sh` automatyzuje instalację npm, `cap sync` i kompilację debug, gdy dostępne są wymagane narzędzia.

## Kontrole lokalne

Uruchom:

```bash
npm test
```

Zestaw obejmuje kontrolę składni modułów, spójności ścieżek zasobów i konfiguracji Capacitor oraz testy katalogu Buderus.


## Automatyczna kompilacja w GitHub Actions

Dodano workflow `.github/workflows/android-debug.yml`. Po umieszczeniu projektu w repozytorium GitHub i wypchnięciu gałęzi `main` lub `master` workflow automatycznie: instaluje Java 17, Node 20, Gradle 8.2.1 i Android SDK 34, instaluje zależności npm, uruchamia `npm test`, wykonuje `npx cap sync android`, buduje `assembleDebug` i publikuje `app-debug.apk` jako artefakt działania GitHub Actions. Można go też uruchomić ręcznie przez zakładkę Actions → Build Android APK → Run workflow.

**Status:** workflow został dodany i uzupełniony o jawne przygotowanie Gradle 8.2.1 oraz uruchomienie testów projektu przed kompilacją; nie został jeszcze uruchomiony. Nie jest to potwierdzenie kompilacji APK. Pierwszy przebieg ujawni ewentualne problemy z kompatybilnością pluginów i odtworzonym szkieletem Android.
