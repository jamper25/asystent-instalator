# Inwentaryzacja odzyskanych modułów

Kod aplikacji został odzyskany z drugiego skryptu osadzonego w `assets/public/index.html` i rozdzielony według oryginalnych znaczników `===== nazwa.js =====`. Kolejność ładowania w `www/index.html` zachowuje kolejność z APK.

| Moduł | Rozmiar | Linie | Funkcje | Klasy |
|---|---:|---:|---:|---:|
| `radson.js` | 8,055 B | 123 | 0 | 0 |
| `drabinki.js` | 5,854 B | 131 | 9 | 0 |
| `data.js` | 27,680 B | 608 | 4 | 0 |
| `fonty.js` | 73,188 B | 31 | 0 | 0 |
| `pdf.js` | 18,985 B | 479 | 17 | 0 |
| `ksztaltki.js` | 20,969 B | 452 | 5 | 0 |
| `offers.js` | 40,283 B | 827 | 40 | 0 |
| `ksef.js` | 8,645 B | 186 | 4 | 0 |
| `natywne.js` | 4,300 B | 86 | 4 | 0 |
| `engine.js` | 48,267 B | 1,025 | 31 | 0 |
| `dobor_grzejnika.js` | 7,561 B | 140 | 3 | 0 |
| `schemat.js` | 71,030 B | 1,425 | 20 | 0 |
| `ui.js` | 197,367 B | 3,105 | 28 | 0 |
| `ui_offers.js` | 101,220 B | 2,089 | 52 | 0 |
| `dopisz.js` | 23,254 B | 501 | 15 | 0 |
| `grzejnik_wybor.js` | 21,067 B | 405 | 17 | 0 |
| `karta_tresc.js` | 64,305 B | 14 | 0 | 0 |
| `polityka_tresc.js` | 9,460 B | 16 | 0 | 0 |
| `kopia.js` | 15,699 B | 372 | 15 | 0 |
| `ui_settings.js` | 38,685 B | 720 | 13 | 0 |
| `ui_assist.js` | 21,787 B | 312 | 6 | 0 |
| `conowego.js` | 7,053 B | 130 | 5 | 0 |
| `kody_dane.js` | 2,783,399 B | 12 | 0 | 0 |
| `kody_bledow.js` | 12,702 B | 244 | 14 | 0 |
| `kotlownia.js` | 148,504 B | 1,877 | 27 | 0 |
| `projekty.js` | 26,826 B | 465 | 21 | 0 |
| `projekty_kalk.js` | 17,575 B | 289 | 8 | 0 |
| `projekty_zest.js` | 10,415 B | 209 | 8 | 0 |
| `projekty_folder.js` | 37,512 B | 632 | 18 | 0 |
| `notatnik.js` | 37,776 B | 638 | 29 | 0 |
| `pro.js` | 24,767 B | 482 | 23 | 0 |
| `boot.js` | 318 B | 9 | 0 | 0 |

| `buderus_catalog.js` (nowy) | warstwa katalogu Buderus | CRUD, ceny, historia cen, import/eksport JSON, adapter do pozycji oferty |
